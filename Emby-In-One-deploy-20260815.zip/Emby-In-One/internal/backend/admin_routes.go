package backend

import (
	"fmt"
	"io/fs"
	"net/http"
)

func (a *App) registerAdminRoutes(mux *http.ServeMux) {
	mux.HandleFunc("POST /admin/api/login", a.handleAdminLogin)
	mux.HandleFunc("POST /admin/api/logout", a.withContext(a.handleAdminLogout))
	mux.HandleFunc("GET /admin/api/client-info", a.withContext(a.requireAdmin(a.handleAdminClientInfo)))
	mux.HandleFunc("GET /admin/api/status", a.withContext(a.requireAdmin(a.handleAdminStatus)))
	mux.HandleFunc("GET /admin/api/upstream", a.withContext(a.requireAdmin(a.handleAdminUpstreamList)))
	mux.HandleFunc("POST /admin/api/upstream", a.withContext(a.requireAdmin(a.handleAdminUpstreamCreate)))
	mux.HandleFunc("PUT /admin/api/upstream/{index}", a.withContext(a.requireAdmin(a.handleAdminUpstreamUpdate)))
	mux.HandleFunc("POST /admin/api/upstream/reorder", a.withContext(a.requireAdmin(a.handleAdminUpstreamReorder)))
	mux.HandleFunc("DELETE /admin/api/upstream/{index}", a.withContext(a.requireAdmin(a.handleAdminUpstreamDelete)))
	mux.HandleFunc("POST /admin/api/upstream/{index}/reconnect", a.withContext(a.requireAdmin(a.handleAdminUpstreamReconnect)))
	mux.HandleFunc("GET /admin/api/proxies", a.withContext(a.requireAdmin(a.handleAdminProxiesList)))
	mux.HandleFunc("POST /admin/api/proxies", a.withContext(a.requireAdmin(a.handleAdminProxiesCreate)))
	mux.HandleFunc("POST /admin/api/proxies/test", a.withContext(a.requireAdmin(a.handleAdminProxyTest)))
	mux.HandleFunc("DELETE /admin/api/proxies/{id}", a.withContext(a.requireAdmin(a.handleAdminProxiesDelete)))
	mux.HandleFunc("GET /admin/api/settings", a.withContext(a.requireAdmin(a.handleAdminSettings)))
	mux.HandleFunc("PUT /admin/api/settings", a.withContext(a.requireAdmin(a.handleAdminSettingsUpdate)))
	mux.HandleFunc("GET /admin/api/logs", a.withContext(a.requireAdmin(a.handleAdminLogs)))
	mux.HandleFunc("GET /admin/api/logs/download", a.withContext(a.requireAdmin(a.handleAdminLogsDownload)))
	mux.HandleFunc("DELETE /admin/api/logs", a.withContext(a.requireAdmin(a.handleAdminLogsClear)))
	mux.HandleFunc("GET /admin/api/users", a.withContext(a.requireAdmin(a.handleAdminUsersList)))
	mux.HandleFunc("POST /admin/api/users", a.withContext(a.requireAdmin(a.handleAdminUsersCreate)))
	mux.HandleFunc("PUT /admin/api/users/{id}", a.withContext(a.requireAdmin(a.handleAdminUsersUpdate)))
	mux.HandleFunc("DELETE /admin/api/users/{id}", a.withContext(a.requireAdmin(a.handleAdminUsersDelete)))
	mux.Handle("/admin/", a.adminFileServer())
	mux.HandleFunc("GET /admin", a.handleAdminShell)
	mux.HandleFunc("GET /admin/{$}", a.handleAdminShell)
}

func (a *App) handleAdminShell(w http.ResponseWriter, r *http.Request) {
	shell, err := fs.ReadFile(a.adminFS(), "admin.html")
	if err != nil {
		http.Error(w, fmt.Sprintf("admin shell unavailable: %v", err), http.StatusNotFound)
		return
	}
	w.Header().Set("Content-Type", "text/html; charset=utf-8")
	w.WriteHeader(http.StatusOK)
	_, _ = w.Write(shell)
}
