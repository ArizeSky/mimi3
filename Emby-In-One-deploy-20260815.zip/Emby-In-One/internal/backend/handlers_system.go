package backend

import (
	"encoding/json"
	"io"
	"net/http"
)

func writeJSON(w http.ResponseWriter, status int, payload any) {
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	w.WriteHeader(status)
	_ = json.NewEncoder(w).Encode(payload)
}

func decodeJSONBody(r *http.Request, out any) error {
	defer r.Body.Close()
	decoder := json.NewDecoder(r.Body)
	return decoder.Decode(out)
}

func (a *App) handleSystemInfoPublic(w http.ResponseWriter, r *http.Request) {
	cfg := a.ConfigStore.Snapshot()
	writeJSON(w, http.StatusOK, map[string]any{
		"LocalAddress":                         requestOrigin(r),
		"ServerName":                           cfg.Server.Name,
		"Version":                              "4.7.14.0",
		"ProductName":                          "Emby Server",
		"Id":                                   cfg.Server.ID,
		"StartupWizardCompleted":               true,
		"OperatingSystem":                      "Linux",
		"CanSelfRestart":                       false,
		"CanLaunchWebBrowser":                  false,
		"HasUpdateAvailable":                   false,
		"SupportsAutoRunAtStartup":             false,
		"HardwareAccelerationRequiresPremiere": false,
	})
}

func (a *App) handleSystemInfo(w http.ResponseWriter, r *http.Request) {
	cfg := a.ConfigStore.Snapshot()
	writeJSON(w, http.StatusOK, map[string]any{
		"LocalAddress":                         requestOrigin(r),
		"WanAddress":                           "",
		"ServerName":                           cfg.Server.Name,
		"Version":                              "4.7.14.0",
		"ProductName":                          "Emby Server",
		"Id":                                   cfg.Server.ID,
		"StartupWizardCompleted":               true,
		"OperatingSystem":                      "Linux",
		"OperatingSystemDisplayName":           "Linux",
		"CanSelfRestart":                       false,
		"CanLaunchWebBrowser":                  false,
		"HasUpdateAvailable":                   false,
		"SupportsAutoRunAtStartup":             false,
		"SystemUpdateLevel":                    "Release",
		"HardwareAccelerationRequiresPremiere": false,
		"HasPendingRestart":                    false,
		"IsShuttingDown":                       false,
		"TranscodingTempPath":                  "/tmp",
		"LogPath":                              "/tmp",
		"InternalMetadataPath":                 "/tmp",
		"CachePath":                            "/tmp",
		"ProgramDataPath":                      "/tmp",
		"ItemsByNamePath":                      "/tmp",
	})
}

func (a *App) handleSystemEndpoint(w http.ResponseWriter, r *http.Request) {
	writeJSON(w, http.StatusOK, map[string]any{"IsLocal": false, "IsInNetwork": false})
}

func (a *App) handleSystemPing(w http.ResponseWriter, r *http.Request) {
	_, _ = w.Write([]byte("Emby Aggregator"))
}

func (a *App) handleRoot(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "text/html; charset=utf-8")
	_, _ = io.WriteString(w, `<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Emby-In-One</title>
  <style>
    :root{color-scheme:dark;background:#07090d;color:#f7f8fa;font-family:Inter,ui-sans-serif,system-ui,-apple-system,"Segoe UI",sans-serif}
    *{box-sizing:border-box}
    body{display:grid;place-items:center;min-height:100vh;margin:0;padding:1.25rem;background:radial-gradient(circle at 18% 10%,rgb(255 107 74 / .18),transparent 24rem),#07090d}
    .box{width:min(100%,32rem);padding:clamp(1.6rem,6vw,3.2rem);border:1px solid rgb(255 255 255 / .14);border-radius:22px;background:#131923;box-shadow:0 24px 72px rgb(0 0 0 / .4);text-align:center}
    .icon{display:grid;place-items:center;width:3.25rem;height:3.25rem;margin:0 auto 1.25rem;border-radius:13px;background:linear-gradient(145deg,#ff8a6f,#ff6b4a);color:#1d0b07;font-size:1.25rem;font-weight:800}
    .title{margin-bottom:.7rem;font-size:clamp(1.2rem,4vw,1.55rem);font-weight:760}
    .sub{margin:0;color:#9aa6b6;font-size:.93rem;line-height:1.75}
    .actions{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:.75rem;margin-top:1.75rem}
    .btn{display:inline-flex;align-items:center;justify-content:center;min-height:2.8rem;padding:.65rem 1rem;border:1px solid transparent;border-radius:10px;background:#ff6b4a;color:#1d0b07;text-decoration:none;font-size:.9rem;font-weight:720}
    .btn.secondary{border-color:rgb(255 255 255 / .16);background:#1a2230;color:#f7f8fa}
    .btn:focus-visible{outline:2px solid #ff8a6f;outline-offset:3px;box-shadow:0 0 0 4px rgb(255 107 74 / .2)}
    @media(max-width:520px){.actions{grid-template-columns:1fr}}
  </style>
</head>
<body>
  <main class="box">
    <div class="icon" aria-hidden="true">E</div>
    <div class="title">欢迎使用 Emby-In-One</div>
    <p class="sub">此地址可供 Emby 客户端连接。你也可以直接进入网页观影，或打开管理面板进行设置。</p>
    <div class="actions">
      <a class="btn" href="/web">进入网页观影</a>
      <a class="btn secondary" href="/admin">打开管理面板</a>
    </div>
  </main>
</body>
</html>`)
}
