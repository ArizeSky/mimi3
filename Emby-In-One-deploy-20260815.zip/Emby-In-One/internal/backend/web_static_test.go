package backend

import (
	"net/http"
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func TestWebRoutesServeViewerShell(t *testing.T) {
	withTempApp(t, func(app *App, handler http.Handler) {
		shell := doJSONRequest(t, handler, http.MethodGet, "/web", nil, "")
		if shell.Code != http.StatusOK {
			t.Fatalf("GET /web status = %d, body=%s", shell.Code, shell.Body.String())
		}
		if got := shell.Header().Get("Content-Type"); !strings.Contains(got, "text/html") {
			t.Fatalf("GET /web Content-Type = %q", got)
		}
		if !strings.Contains(shell.Body.String(), `id="web-app"`) {
			t.Fatalf("GET /web did not serve viewer shell: %s", shell.Body.String())
		}

		deepLink := doJSONRequest(t, handler, http.MethodGet, "/web/item/item-123", nil, "")
		if deepLink.Code != http.StatusOK {
			t.Fatalf("GET /web/item/item-123 status = %d, body=%s", deepLink.Code, deepLink.Body.String())
		}
		if !strings.Contains(deepLink.Body.String(), `<script type="module" src="/web/app/index.js"></script>`) {
			t.Fatalf("deep link did not serve web shell")
		}

		styles := doJSONRequest(t, handler, http.MethodGet, "/web/styles/layout.css", nil, "")
		if styles.Code != http.StatusOK {
			t.Fatalf("GET /web/styles/layout.css status = %d, body=%s", styles.Code, styles.Body.String())
		}
		if got := styles.Header().Get("Content-Type"); !strings.Contains(got, "text/css") {
			t.Fatalf("GET /web/styles/layout.css Content-Type = %q", got)
		}
		if !strings.Contains(styles.Body.String(), ".topbar") {
			t.Fatalf("GET /web/styles/layout.css did not serve layout stylesheet: %s", styles.Body.String())
		}

		admin := doJSONRequest(t, handler, http.MethodGet, "/admin", nil, "")
		if admin.Code != http.StatusOK {
			t.Fatalf("GET /admin status = %d, body=%s", admin.Code, admin.Body.String())
		}
		if admin.Header().Get("Location") != "" {
			t.Fatalf("GET /admin should not redirect, Location=%q", admin.Header().Get("Location"))
		}
		if !strings.Contains(admin.Body.String(), "admin") {
			t.Fatalf("GET /admin did not serve admin shell: %s", admin.Body.String())
		}

		adminSlash := doJSONRequest(t, handler, http.MethodGet, "/admin/", nil, "")
		if adminSlash.Code != http.StatusOK {
			t.Fatalf("GET /admin/ status = %d, body=%s", adminSlash.Code, adminSlash.Body.String())
		}
		if adminSlash.Header().Get("Location") != "" {
			t.Fatalf("GET /admin/ should not redirect, Location=%q", adminSlash.Header().Get("Location"))
		}
		if !strings.Contains(adminSlash.Body.String(), "admin") {
			t.Fatalf("GET /admin/ did not serve admin shell: %s", adminSlash.Body.String())
		}

		adminFile := doJSONRequest(t, handler, http.MethodGet, "/admin/admin.html", nil, "")
		if adminFile.Code != http.StatusOK || !strings.Contains(adminFile.Body.String(), "admin") {
			t.Fatalf("GET /admin/admin.html status=%d body=%s", adminFile.Code, adminFile.Body.String())
		}
	})
}

func TestRootPageOffersViewerAndAdminEntrypoints(t *testing.T) {
	withTempApp(t, func(app *App, handler http.Handler) {
		root := doJSONRequest(t, handler, http.MethodGet, "/", nil, "")
		if root.Code != http.StatusOK {
			t.Fatalf("GET / status = %d, body=%s", root.Code, root.Body.String())
		}
		body := root.Body.String()
		if !strings.Contains(body, `href="/web"`) || !strings.Contains(body, `href="/admin"`) {
			t.Fatalf("root page missing viewer/admin entrypoints: %s", body)
		}
	})
}

func TestAdminStaticResourcesRemainAvailable(t *testing.T) {
	withTempApp(t, func(app *App, handler http.Handler) {
		cwd, err := os.Getwd()
		if err != nil {
			t.Fatalf("get working directory: %v", err)
		}
		vendorDir := filepath.Join(cwd, "public", "vendor")
		if err := os.MkdirAll(vendorDir, 0o755); err != nil {
			t.Fatalf("create vendor directory: %v", err)
		}
		if err := os.WriteFile(filepath.Join(cwd, "public", "admin.js"), []byte("window.__admin = true;"), 0o644); err != nil {
			t.Fatalf("write admin.js: %v", err)
		}
		if err := os.WriteFile(filepath.Join(vendorDir, "test.js"), []byte("window.__vendor = true;"), 0o644); err != nil {
			t.Fatalf("write vendor asset: %v", err)
		}
		t.Cleanup(func() {
			_ = os.Remove(filepath.Join(cwd, "public", "admin.js"))
			_ = os.Remove(filepath.Join(vendorDir, "test.js"))
			_ = os.Remove(vendorDir)
		})

		for _, target := range []string{"/admin/admin.js", "/admin/vendor/test.js"} {
			asset := doJSONRequest(t, handler, http.MethodGet, target, nil, "")
			if asset.Code != http.StatusOK {
				t.Fatalf("GET %s status = %d, body=%s", target, asset.Code, asset.Body.String())
			}
		}
	})
}

func TestWebPathsHaveStrictCSP(t *testing.T) {
	withTempApp(t, func(app *App, handler http.Handler) {
		shell := doJSONRequest(t, handler, http.MethodGet, "/web", nil, "")
		if shell.Code != http.StatusOK {
			t.Fatalf("GET /web status = %d, body=%s", shell.Code, shell.Body.String())
		}
		if got := shell.Header().Get("Content-Security-Policy"); !strings.Contains(got, "default-src 'self'") {
			t.Fatalf("GET /web Content-Security-Policy = %q", got)
		}
		if got := shell.Header().Get("X-Content-Type-Options"); got != "nosniff" {
			t.Fatalf("GET /web X-Content-Type-Options = %q, want nosniff", got)
		}
		if got := shell.Header().Get("X-Frame-Options"); got != "SAMEORIGIN" {
			t.Fatalf("GET /web X-Frame-Options = %q, want SAMEORIGIN", got)
		}
		if got := shell.Header().Get("Referrer-Policy"); got != "same-origin" {
			t.Fatalf("GET /web Referrer-Policy = %q, want same-origin", got)
		}

		login := doJSONRequest(t, handler, http.MethodPost, "/web/api/login", map[string]string{
			"username": "viewer",
			"password": "wrong",
		}, "")
		if got := login.Header().Get("Content-Security-Policy"); !strings.Contains(got, "default-src 'self'") {
			t.Fatalf("POST /web/api/login Content-Security-Policy = %q", got)
		}
		if got := login.Header().Get("X-Content-Type-Options"); got != "nosniff" {
			t.Fatalf("POST /web/api/login X-Content-Type-Options = %q, want nosniff", got)
		}

		public := doJSONRequest(t, handler, http.MethodGet, "/System/Info/Public", nil, "")
		if got := public.Header().Get("Content-Security-Policy"); got != "" {
			t.Fatalf("GET /System/Info/Public Content-Security-Policy = %q, want empty", got)
		}
	})
}
