import { escapeHtml } from '../utils/escape.js';

function normalizePath(path) {
  const raw = String(path || '/web').split('?')[0].replace(/\/+$/, '');
  return raw || '/web';
}

function isNavCurrent(activePath, href) {
  if (href === '/web/search') return activePath === href || activePath.startsWith(`${href}/`);
  if (href === '/web/resume') return activePath === href || activePath.startsWith(`${href}/`);
  if (href === '/web') {
    return activePath === '/web'
      || activePath.startsWith('/web/item/')
      || activePath.startsWith('/web/library/')
      || activePath.startsWith('/web/play/');
  }
  return activePath === href;
}

export function renderAppShell({ title, content, showNav = true, session = null, pageClass = '', currentPath = '' }) {
  const showUserMenu = showNav && session && session.username;
  const shellClass = ['app-shell', pageClass].filter(Boolean).join(' ');
  const userMenuLabel = showUserMenu ? escapeHtml(String(session.username).trim().charAt(0).toUpperCase() || '●') : '●';
  const activePath = normalizePath(currentPath || (typeof window !== 'undefined' ? window.location.pathname : '/web'));
  const navItems = [
    { href: '/web', label: '首页' },
    { href: '/web/search', label: '搜索' },
    { href: '/web/resume', label: '继续观看' },
  ];
  return `
    <div class="${shellClass}">
      <header class="topbar">
        <a class="brand" href="/web" data-nav>
          <div class="brand__mark" aria-hidden="true">E</div>
          Emby-In-One
        </a>
        ${showNav ? `
        <nav class="topnav" aria-label="主导航">
          ${navItems.map(({ href, label }) => `<a href="${href}" data-nav${isNavCurrent(activePath, href) ? ' aria-current="page"' : ''}>${label}</a>`).join('')}
        </nav>
        ` : ''}
        ${showUserMenu ? `
        <div class="topbar__actions">
          <button type="button" class="user-menu__button" data-user-menu-button aria-label="打开用户菜单" aria-expanded="false" aria-haspopup="menu" aria-controls="web-user-menu">${userMenuLabel}</button>
          <div class="user-menu" id="web-user-menu" data-user-menu role="menu" hidden>
            <div class="user-menu__username" data-user-menu-username>${escapeHtml(session.username)}</div>
            <button type="button" class="user-menu__logout" data-user-menu-logout role="menuitem">退出登录</button>
          </div>
        </div>
        ` : ''}
      </header>
      <main class="page-wrap">
        ${title ? `<h1 class="page-title">${escapeHtml(title)}</h1>` : ''}
        ${content}
      </main>
    </div>
  `;
}
