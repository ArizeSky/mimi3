export function renderAuthShell({ content }) {
  return `
    <div class="auth-shell">
      <main class="auth-shell__main">
        <section class="auth-shell__brand">
          <div class="auth-shell__mark" aria-hidden="true">E</div>
          <div class="auth-shell__title-group">
            <p class="auth-shell__eyebrow">PERSONAL CINEMA</p>
            <h1 class="auth-shell__title">Emby-In-One</h1>
            <p class="auth-shell__subtitle">登录后继续浏览你的内容库，随时接着上次的进度观看。</p>
            <ul class="auth-shell__promises" aria-label="网页观影特点">
              <li>整洁的片库导航</li>
              <li>跨设备同步观看进度</li>
            </ul>
          </div>
        </section>
        <section class="auth-shell__panel">
          ${content}
        </section>
      </main>
    </div>
  `;
}
