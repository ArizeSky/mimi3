import { renderMediaCard } from './media-card.js';

export function renderLibraryGrid(items) {
  return `
    <section class="library-grid">
      ${(items || []).map((item) => renderMediaCard(item, item.href || `/web/item/${item.id}`)).join('')}
      ${(items || []).length ? '' : '<p class="empty-state library-grid__empty">这里还没有可展示的内容。</p>'}
    </section>
  `;
}
