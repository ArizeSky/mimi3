import { escapeAttr, escapeHtml } from '../utils/escape.js';

export function renderMediaCard(item, href) {
  const media = item || {};
  const title = media.name || '';
  const meta = [media.subtitle, media.type, media.year ? String(media.year) : ''].filter(Boolean).join(' · ');
  return `
    <a class="media-card" href="${escapeAttr(href)}" data-nav aria-label="${escapeAttr(title)}">
      <div class="media-card__poster">
        <img class="media-card__image" src="${escapeAttr(media.image || '')}" alt="${escapeAttr(title)}" loading="lazy">
      </div>
      <div class="media-card__body">
        <div class="media-card__title" title="${escapeAttr(title)}">${escapeHtml(title)}</div>
        <div class="media-card__meta">${escapeHtml(meta)}</div>
      </div>
    </a>
  `;
}
