import { playbackRates } from '../player/playback-rate.js';
import { escapeAttr, escapeHtml } from '../utils/escape.js';
import { formatVersionLabel } from '../utils/version-label.js';
import { renderAudioTrackOptions, renderSubtitleTrackOptions } from './track-select-options.js';

export function renderPlayerShell(playback) {
  const versions = playback.versions || [];
  const audioTracks = playback.audioTracks || [];
  const subtitleTracks = playback.subtitleTracks || [];
  const previousEpisode = playback.previousEpisode || null;
  const nextEpisode = playback.nextEpisode || null;
  const currentRate = String(playback.playbackRate || 1);
  const selectedVersion = String(playback.selection?.mediaSourceId || versions[0]?.id || '');
  const selectedAudio = playback.selection?.audioStreamIndex;
  const selectedSubtitle = playback.selection?.subtitleStreamIndex;
  return `
    <section class="player-shell">
      <div class="player-shell__meta">
        <strong class="player-shell__title">${escapeHtml(playback.title || '播放中')}</strong>
        <span class="player-shell__subtitle">${escapeHtml([playback.seriesName, playback.episodeLabel].filter(Boolean).join(' · '))}</span>
      </div>
      <div class="player-video-wrap" aria-label="视频播放器">
        <video controls playsinline data-player aria-label="视频播放器"></video>
        <div class="player-subtitle-overlay" data-subtitle-overlay aria-live="off"></div>
        <div class="player-playback-status" data-player-status role="status" aria-live="polite" hidden></div>
        <div class="player-playback-error" data-player-error role="alert" hidden></div>
      </div>
      <div class="player-toolbar">
        <button type="button" data-player-prev aria-label="播放上一集" ${previousEpisode ? '' : 'disabled'}>上一集</button>
        <button type="button" data-player-next aria-label="播放下一集" ${nextEpisode ? '' : 'disabled'}>下一集</button>
        <label class="player-toolbar__field">倍速<select class="player-toolbar__select" data-player-rate>${playbackRates.map((rate) => `<option value="${escapeAttr(rate)}" ${currentRate === String(rate) ? 'selected' : ''}>${escapeHtml(`${rate}x`)}</option>`).join('')}</select></label>
        <label class="player-toolbar__field">版本<select class="player-toolbar__select" data-player-version>${versions.map((version) => `<option value="${escapeAttr(version.id)}" ${selectedVersion === String(version.id) ? 'selected' : ''}>${escapeHtml(formatVersionLabel(versions, version))}</option>`).join('')}</select></label>
        <label class="player-toolbar__field">音轨<select class="player-toolbar__select" data-player-audio>${renderAudioTrackOptions(audioTracks, selectedVersion, selectedAudio)}</select></label>
        <label class="player-toolbar__field">字幕<select class="player-toolbar__select" data-player-subtitle>${renderSubtitleTrackOptions(subtitleTracks, selectedVersion, selectedSubtitle)}</select></label>
      </div>
    </section>
  `;
}
