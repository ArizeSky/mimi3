import { searchFilterOptions } from '../search/filter-config.js';

export function renderSearchTypeFilters(enabledTypes) {
  const enabled = new Set(enabledTypes || []);
  return `
    <fieldset class="search-filter-bar" data-search-filter-bar>
      <legend class="search-filter-bar__legend">筛选类型</legend>
      ${searchFilterOptions.map((option) => `
        <label class="search-filter-bar__option" title="筛选${option.label}">
          <input type="checkbox" data-search-filter="${option.type}" value="${option.type}" ${enabled.has(option.type) ? 'checked' : ''}>
          <span>${option.label}</span>
        </label>
      `).join('')}
    </fieldset>
  `;
}
