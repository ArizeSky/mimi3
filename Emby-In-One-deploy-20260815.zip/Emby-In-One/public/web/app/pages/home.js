import { api } from '../api/client.js';
import { renderBrowseShell } from '../components/browse-shell.js';
import { renderContentRail, renderContentRailTrack, renderLibraryEntryArea } from '../components/content-rail.js';
import { createHomeRailState } from '../state/home-rails.js';
import { resumePlaybackHref } from '../utils/playback-href.js';
import { escapeAttr, escapeHtml } from '../utils/escape.js';

const RAIL_BATCH_SIZE = 12;

function railItemHref(item) {
  return `/web/item/${item.id}`;
}

function renderRailTrackInto(track, items) {
  if (track) track.innerHTML = renderContentRailTrack(items, railItemHref);
}

function syncRailControls(viewport, state, prevButton, nextButton) {
  const scrollLeft = viewport?.scrollLeft || 0;
  const clientWidth = viewport?.clientWidth || 0;
  const scrollWidth = viewport?.scrollWidth || 0;
  const canScrollLeft = scrollLeft > 0;
  const canScrollRight = scrollWidth > 0 && scrollLeft + clientWidth < scrollWidth - 1;

  if (prevButton) prevButton.disabled = !canScrollLeft;
  if (nextButton) nextButton.disabled = !state.hasMore && !canScrollRight;
}

function renderHomeHero(session, payload, views) {
  const username = String(session?.username || '观众').trim() || '观众';
  const resume = Array.isArray(payload.resume) ? payload.resume : [];
  const hasResume = resume.length > 0 && resume[0]?.id;
  const libraryCount = views.length;
  const resumeAction = hasResume
    ? `<a class="home-hero__action home-hero__action--primary" href="${escapeAttr(resumePlaybackHref(resume[0]))}" data-nav>继续观看</a>`
    : '';
  return `
    <section class="home-hero" aria-labelledby="home-hero-title">
      <div class="home-hero__glow" aria-hidden="true"></div>
      <div class="home-hero__content">
        <p class="home-hero__eyebrow">YOUR EVENING, CURATED</p>
        <h2 class="home-hero__title" id="home-hero-title">晚上好，${escapeHtml(username)}</h2>
        <p class="home-hero__message">从喜欢的故事开始，沉浸在属于你的片库时光。</p>
        <div class="home-hero__actions">
          ${resumeAction}
          <a class="home-hero__action home-hero__action--secondary" href="/web/search" data-nav>搜索片库</a>
        </div>
      </div>
      <dl class="home-hero__stats" aria-label="片库概览">
        <div><dt>媒体库</dt><dd>${libraryCount}</dd></div>
        <div><dt>待续看</dt><dd>${resume.length}</dd></div>
      </dl>
    </section>
  `;
}

export async function renderHomePage(session) {
  const payload = await api('/web/api/home');
  const views = payload.views || [];
  const railStates = new Map(
    views.map((section) => [section.id, createHomeRailState(section.items || [], RAIL_BATCH_SIZE)]),
  );

  const sections = [
    renderContentRail({
      id: 'resume',
      title: '继续观看',
      items: payload.resume || [],
      hrefBuilder: resumePlaybackHref,
      nextDisabled: true,
    }),
    renderLibraryEntryArea(views),
    ...views.map((section) => renderContentRail({
      id: section.id,
      title: section.name,
      items: section.items || [],
      hrefBuilder: railItemHref,
      titleHref: `/web/library/${section.id}`,
      nextDisabled: false,
    })),
    renderContentRail({
      id: 'latest',
      title: '最新内容',
      items: payload.latest || [],
      hrefBuilder: railItemHref,
      nextDisabled: true,
    }),
    renderContentRail({
      id: 'next-up',
      title: '继续追剧',
      items: payload.nextUp || [],
      hrefBuilder: railItemHref,
      nextDisabled: true,
    }),
  ];

  return {
    html: renderBrowseShell({ title: '首页', content: `${renderHomeHero(session, payload, views)}${sections.join('')}`, session }),
    mount() {
      for (const section of views) {
        const state = railStates.get(section.id);
        const prevButton = document.querySelector(`[data-rail-prev="${section.id}"]`);
        const nextButton = document.querySelector(`[data-rail-next="${section.id}"]`);
        const viewport = document.querySelector(`[data-rail-viewport="${section.id}"]`);
        const track = document.querySelector(`[data-rail-track="${section.id}"]`);
        const status = document.querySelector(`[data-rail-status="${section.id}"]`);
        if (!state || !nextButton || !track) continue;

        syncRailControls(viewport, state, prevButton, nextButton);
        viewport?.addEventListener('scroll', () => {
          syncRailControls(viewport, state, prevButton, nextButton);
        });

        prevButton?.addEventListener('click', (event) => {
          event.preventDefault();
          viewport?.scrollBy({ left: -Math.max(320, viewport?.clientWidth || 0) });
          syncRailControls(viewport, state, prevButton, nextButton);
        });

        nextButton.addEventListener('click', async (event) => {
          event.preventDefault();
          const scrollLeft = viewport?.scrollLeft || 0;
          const clientWidth = viewport?.clientWidth || 0;
          const scrollWidth = viewport?.scrollWidth || 0;
          const canScrollRight = scrollWidth > 0 && scrollLeft + clientWidth < scrollWidth - 1;

          if (canScrollRight) {
            viewport?.scrollBy({ left: Math.max(320, viewport?.clientWidth || 0) });
            syncRailControls(viewport, state, prevButton, nextButton);
            return;
          }

          if (state.loading || !state.hasMore) return;
          state.startLoading();
          if (status) status.textContent = '加载中...';

          try {
            const nextPayload = await api(`/web/api/libraries/${section.id}?offset=${state.offset}&limit=${RAIL_BATCH_SIZE}`);
            state.appendBatch(nextPayload.items || [], nextPayload.hasMore);
            renderRailTrackInto(track, state.items);
            if (status) status.textContent = '';
            viewport?.scrollBy({ left: Math.max(320, viewport?.clientWidth || 0) });
            syncRailControls(viewport, state, prevButton, nextButton);
          } catch (_error) {
            state.setError();
            if (status) status.textContent = state.error;
            syncRailControls(viewport, state, prevButton, nextButton);
          }
        });
      }
    },
  };
}

export { createHomeRailState, syncRailControls };
