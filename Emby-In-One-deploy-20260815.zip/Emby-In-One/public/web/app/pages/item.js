import { api } from '../api/client.js';
import { renderImmersiveShell } from '../components/immersive-shell.js';
import { renderItemSidebar } from '../components/item-sidebar.js';
import { nextSelection, parseTrackSelectionValue } from '../state/selection.js';
import { navigate } from '../router.js';
import { escapeHtml } from '../utils/escape.js';
import { start as progressStart } from '../components/progress-bar.js';
import { groupEpisodesBySeason } from '../utils/episode-grouping.js';
import { renderAudioTrackOptions, renderSubtitleTrackOptions } from '../components/track-select-options.js';
import { appendResumePosition } from '../utils/playback-href.js';

/* Legacy app-shell remains as immersive shell implementation for detail/play pages. */

function isDirectlyPlayable(item) {
  return ['Movie', 'Episode', 'Video', 'Audio'].includes(String(item?.Type || item?.type || ''));
}

function renderEpisodeLink(episode) {
  const id = episode.Id || episode.id;
  return `<a href="/web/item/${encodeURIComponent(String(id || ''))}" data-nav class="item-page__episode-link">${escapeHtml(episode.Name || episode.name || '')}</a>`;
}

function renderEpisodesSection(detail) {
  const episodes = detail.episodes || [];
  if (episodes.length === 0) return '';
  const groups = groupEpisodesBySeason(detail.seasons, episodes);
  const hasSeasonInfo = groups.some((g) => g.seasonNumber !== null);
  if (!hasSeasonInfo) {
    return `<section class="item-page__episodes-section" aria-labelledby="item-episodes-title"><h2 id="item-episodes-title" class="item-page__section-title">剧集</h2><div class="item-page__episodes">${episodes.map(renderEpisodeLink).join('')}</div></section>`;
  }
  return `
    <section class="item-page__episodes-section" aria-labelledby="item-seasons-title">
      <h2 id="item-seasons-title" class="item-page__section-title">剧集</h2>
      <div class="item-page__seasons">
      ${groups.map((group) => `
        <section class="item-page__season">
          <h3 class="item-page__season-title">${escapeHtml(group.title)}</h3>
          <div class="item-page__season-episodes">
            ${group.episodes.map(renderEpisodeLink).join('')}
          </div>
        </section>
      `).join('')}
      </div>
    </section>
  `;
}

function replaceSelection(target, next) {
  Object.keys(target).forEach((key) => delete target[key]);
  Object.assign(target, next);
}

function syncTrackSelectionControls(detail, selection) {
  const mediaSourceId = selection.mediaSourceId || detail.versions?.[0]?.id || '';
  const audioSelect = document.querySelector('[data-selection="audioStreamIndex"]');
  const subtitleSelect = document.querySelector('[data-selection="subtitleStreamIndex"]');
  if (audioSelect) {
    audioSelect.innerHTML = renderAudioTrackOptions(
      detail.audioTracks || [],
      mediaSourceId,
      selection.audioStreamIndex,
    );
  }
  if (subtitleSelect) {
    subtitleSelect.innerHTML = renderSubtitleTrackOptions(
      detail.subtitleTracks || [],
      mediaSourceId,
      selection.subtitleStreamIndex,
    );
  }
}

export async function renderItemPage(session, params) {
  const detail = await api(`/web/api/items/${params.itemId}`);
  const selection = { ...(detail.defaultSelection || {}) };
  const itemID = detail.item && (detail.item.Id || detail.item.id) ? String(detail.item.Id || detail.item.id) : '';
  const itemName = (detail.item && (detail.item.Name || detail.item.name)) || '详情';
  const itemOverview = detail.item && (detail.item.Overview || detail.item.overview) || '';
  const itemType = detail.item && (detail.item.Type || detail.item.type) || '';
  const canPlay = isDirectlyPlayable(detail.item);
  const encodedItemID = itemID ? encodeURIComponent(itemID) : '';
  const backdropStyle = encodedItemID ? ` style="--item-backdrop-image: url('/Items/${encodedItemID}/Images/Primary')"` : '';
  return {
    html: renderImmersiveShell({
      title: null,
      session,
      content: `
        <div class="item-page"${backdropStyle}>
          ${renderItemSidebar(detail, selection, { includeOverview: false })}
          <section class="item-page__content">
            <header class="item-page__intro">
              <p class="item-page__eyebrow">${escapeHtml(itemType || '媒体详情')}</p>
              <h1 class="page-title">${escapeHtml(itemName)}</h1>
              ${itemOverview ? `<p class="item-page__overview">${escapeHtml(itemOverview)}</p>` : ''}
            </header>
            ${canPlay ? '<div class="item-page__actions"><button type="button" data-play-button class="item-page__play-button">立即播放</button></div>' : ''}
            ${renderEpisodesSection(detail)}
          </section>
        </div>
      `,
    }),
    mount() {
      document.querySelectorAll('[data-selection]').forEach((select) => {
        select.addEventListener('change', (event) => {
          const value = event.target.value;
          const key = event.target.dataset.selection;
          if (key === 'mediaSourceId') {
            replaceSelection(selection, nextSelection(selection, {
              mediaSourceId: value,
              audioStreamIndex: undefined,
              subtitleStreamIndex: undefined,
            }));
            syncTrackSelectionControls(detail, selection);
            return;
          }
          const parsed = parseTrackSelectionValue(value);
          const patch = { [key]: parsed?.streamIndex };
          if (parsed?.mediaSourceId) patch.mediaSourceId = parsed.mediaSourceId;
          replaceSelection(selection, nextSelection(selection, patch));
        });
      });
      document.querySelector('[data-play-button]')?.addEventListener('click', async (event) => {
        event.preventDefault();
        progressStart();
        const response = await api(`/web/api/items/${params.itemId}/select`, {
          method: 'POST',
          body: selection,
        });
        navigate(appendResumePosition(response.playPath, detail.resumePosition));
      });
    },
  };
}
