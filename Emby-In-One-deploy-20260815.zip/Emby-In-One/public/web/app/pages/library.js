import { api } from '../api/client.js';
import { renderBrowseShell } from '../components/browse-shell.js';
import { renderLibraryGrid } from '../components/library-grid.js';
import { renderLibraryPagination } from '../components/library-pagination.js';
import { navigate } from '../router.js';
import { readPositivePage, updateQueryParam } from '../utils/query-state.js';
import { escapeHtml } from '../utils/escape.js';

function libraryPagePath(libraryId, page) {
  return updateQueryParam(`/web/library/${libraryId}`, 'page', page > 1 ? page : null);
}

export async function renderLibraryPage(session, params) {
  const requestedPage = readPositivePage(window.location.search);
  const limit = 50;
  const offset = (requestedPage - 1) * limit;

  const payload = await api(`/web/api/libraries/${params.libraryId}?offset=${offset}&limit=${limit}`);
  const total = Number(payload.total || 0);
  const totalPages = Math.max(1, Math.ceil(total / limit));
  const safePage = Math.min(requestedPage, totalPages);
  const currentPage = safePage;
  const currentPath = libraryPagePath(params.libraryId, currentPage);

  if (safePage !== requestedPage) {
    const safeOffset = (safePage - 1) * limit;
    const correctedPayload = await api(`/web/api/libraries/${params.libraryId}?offset=${safeOffset}&limit=${limit}`);
    Object.assign(payload, correctedPayload);
  }

  return {
    html: renderBrowseShell({
      title: payload.name || '媒体库',
      session,
      content: `
        <div class="library-page">
          <section class="library-page__header">
            <h2 class="section-title">${escapeHtml(payload.name || '媒体库')}</h2>
          </section>
          ${renderLibraryGrid(payload.items || [])}
          ${renderLibraryPagination({
            libraryId: params.libraryId,
            currentPage,
            totalPages,
          })}
        </div>
      `,
    }),
    mount() {
      if (currentPage !== requestedPage && window.history?.replaceState) {
        window.history.replaceState({}, '', currentPath);
      }

      const prevButton = document.querySelector('[data-library-page-prev]');
      const nextButton = document.querySelector('[data-library-page-next]');
      const pageInput = document.querySelector('[data-library-page-input]');
      const submitButton = document.querySelector('[data-library-page-submit]');

      prevButton?.addEventListener('click', (event) => {
        event.preventDefault();
        navigate(libraryPagePath(params.libraryId, Math.max(1, currentPage - 1)));
      });

      nextButton?.addEventListener('click', (event) => {
        event.preventDefault();
        navigate(libraryPagePath(params.libraryId, Math.min(totalPages, currentPage + 1)));
      });

      submitButton?.addEventListener('click', (event) => {
        event.preventDefault();
        const raw = Number.parseInt(pageInput?.value || '', 10);
        const target = Number.isFinite(raw) ? Math.min(totalPages, Math.max(1, raw)) : 1;
        navigate(libraryPagePath(params.libraryId, target));
      });
    },
  };
}

export { renderLibraryPagination };
