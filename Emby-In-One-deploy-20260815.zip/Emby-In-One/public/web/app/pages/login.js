import { api } from '../api/client.js';
import { renderAuthShell } from '../components/auth-shell.js';
import { navigate } from '../router.js';

export function renderLoginPage() {
  return {
    html: renderAuthShell({
      content: `
        <form class="login-form" data-login-form>
          <div class="login-form__intro">
            <p class="login-form__eyebrow">WELCOME BACK</p>
            <h2 class="login-form__title">进入你的片库</h2>
            <p class="login-form__description">使用 Emby 账号登录，继续享受你的专属观影空间。</p>
          </div>
          <div class="error" data-login-error></div>
          <label>用户名<input name="username" type="text" autocomplete="username" required></label>
          <label>密码<input name="password" type="password" autocomplete="current-password" required></label>
          <button type="submit" class="login-form__submit">登录</button>
        </form>
      `,
    }),
    mount() {
      const form = document.querySelector('[data-login-form]');
      form?.addEventListener('submit', async (event) => {
        event.preventDefault();
        const formData = new FormData(form);
        const errorBox = document.querySelector('[data-login-error]');
        if (errorBox) errorBox.textContent = '';
        try {
          await api('/web/api/login', {
            method: 'POST',
            body: {
              username: formData.get('username'),
              password: formData.get('password'),
            },
          });
          navigate('/web');
        } catch (error) {
          if (errorBox) errorBox.textContent = error.message;
        }
      });
    },
  };
}
