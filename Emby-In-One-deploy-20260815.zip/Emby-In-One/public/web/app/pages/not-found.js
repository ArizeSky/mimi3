import { renderBrowseShell } from '../components/browse-shell.js';

export function renderNotFoundPage(session) {
  return {
    html: renderBrowseShell({
      title: null,
      session,
      content: `
        <div class="not-found-page">
          <div class="not-found-page__icon">404</div>
          <h1 class="not-found-page__title">页面未找到</h1>
          <p class="not-found-page__message">您访问的页面不存在或已被移除。</p>
          <a href="/web" data-nav class="not-found-page__link">返回首页</a>
        </div>
      `,
    }),
    mount() {},
  };
}
