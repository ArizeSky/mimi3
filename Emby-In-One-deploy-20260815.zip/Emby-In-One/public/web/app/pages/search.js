import { api } from '../api/client.js';
import { renderBrowseShell } from '../components/browse-shell.js';
import { renderLibraryGrid } from '../components/library-grid.js';
import { renderLibraryPagination } from '../components/library-pagination.js';
import { renderSearchTypeFilters } from '../components/search-type-filters.js';
import { navigate } from '../router.js';
import { defaultSearchFilterTypes, filterSearchItems, toggleSearchFilterType } from '../search/filter-state.js';
import { escapeAttr } from '../utils/escape.js';
import { buildSearchPath, readSearchQuery } from '../utils/search-query.js';

const SEARCH_PAGE_SIZE = 50;

function withSearchItemHrefs(items) {
  return (items || []).map((item) => ({ ...item, href: `/web/item/${item.id}` }));
}

function renderSearchResults(items) {
  return renderLibraryGrid(withSearchItemHrefs(items));
}

function readSearchPage(search) {
  const params = new URLSearchParams(search);
  const page = Number.parseInt(params.get('page') || '1', 10);
  return Number.isFinite(page) && page > 0 ? page : 1;
}

export async function renderSearchPage(session) {
  const query = readSearchQuery(window.location.search);
  const currentPage = readSearchPage(window.location.search);
  const offset = (currentPage - 1) * SEARCH_PAGE_SIZE;
  const payload = query
    ? await api(`/web/api/search?SearchTerm=${encodeURIComponent(query)}&offset=${offset}&limit=${SEARCH_PAGE_SIZE}`)
    : { items: [], total: 0 };

  let enabledTypes = defaultSearchFilterTypes();
  const allItems = payload.items || [];
  const filteredItems = filterSearchItems(allItems, enabledTypes);
  const total = Number(payload.total || allItems.length || 0);
  const totalPages = Math.max(1, Math.ceil(total / SEARCH_PAGE_SIZE));

  return {
    html: renderBrowseShell({
      title: '搜索',
      session,
      content: `
        <form class="search-form" data-search-form role="search">
          <label class="search-form__label" for="web-search-input">搜索片库</label>
          <div class="search-form__controls">
            <input id="web-search-input" class="search-form__input" name="SearchTerm" value="${escapeAttr(query)}" placeholder="搜索电影、剧集、演员..." autocomplete="off">
            <button class="search-form__button" type="submit">搜索</button>
          </div>
        </form>
        ${renderSearchTypeFilters(enabledTypes)}
        <div data-search-results>${renderSearchResults(filteredItems)}</div>
        ${query ? renderLibraryPagination({ libraryId: `search?q=${encodeURIComponent(query)}`, currentPage, totalPages }) : ''}
      `,
    }),
    mount() {
      const form = document.querySelector('[data-search-form]');
      const resultSlot = document.querySelector('[data-search-results]');
      const renderLocalResults = () => {
        const nextItems = filterSearchItems(payload.items || [], enabledTypes);
        if (resultSlot) resultSlot.innerHTML = renderSearchResults(nextItems);
      };
      form?.addEventListener('submit', (event) => {
        event.preventDefault();
        const formData = new FormData(form);
        const next = formData.get('SearchTerm') || '';
        navigate(buildSearchPath(next));
      });
      document.querySelectorAll('[data-search-filter]').forEach((input) => {
        input.addEventListener('change', (event) => {
          enabledTypes = toggleSearchFilterType(enabledTypes, event.target.value);
          renderLocalResults();
        });
      });
    },
  };
}
