#!/usr/bin/env bash
set -euo pipefail

VERSION="${1:-v1.4.2}"
BUILD_DIR="./build"
MODULE="./cmd/emby-in-one"

# LDFLAGS: 静态链接并压缩体积
LDFLAGS="-s -w -buildid= -extldflags \"-static\""

# TAGS 优化
TAGS="netgo,osusergo,sqlite_omit_load_extension"

mkdir -p "$BUILD_DIR"

GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

# 获取核心数用于多核编译
CORES=$(nproc)

echo -e "${GREEN}====================================================${NC}"
echo -e "${GREEN}  Emby-In-One 跨平台编译 (Debian 13 母机 / CGO开启) ${VERSION}${NC}"
echo -e "${GREEN}====================================================${NC}"
echo -e "  ✔ 检测到 CPU 核心数: ${YELLOW}${CORES}${NC} (将开启多核加速)"
echo -e "  ✔ 本次仅编译目标: ${YELLOW}linux-amd64${NC}"

TARGET_NAME="linux-amd64"
TARGET_ENV='GOARCH=amd64 CC=gcc' # 宿主机是 amd64，直接用 gcc
TARGET_COMPILER="gcc"
TARGET_OUTPUT="${BUILD_DIR}/Emby-In-One-${TARGET_NAME}-${VERSION}"

if ! command -v go &> /dev/null; then
    echo -e "${RED}错误：未找到 go 命令！${NC}"
    exit 1
fi

echo -e "\n${YELLOW}▶ 准备编译 ${TARGET_NAME}...${NC}"

if ! command -v "${TARGET_COMPILER}" &> /dev/null; then
    echo -e "${RED}错误：缺少编译器 ${TARGET_COMPILER}${NC}"
    exit 1
fi

echo -e "  ✔ 编译器已确认: ${TARGET_COMPILER}"

if eval "env CGO_ENABLED=1 GOOS=linux ${TARGET_ENV} \
  go build -p \"${CORES}\" -trimpath -tags \"${TAGS}\" -ldflags \"${LDFLAGS}\" -o \"${TARGET_OUTPUT}\" \"${MODULE}\""; then
    echo -e "  ${GREEN}✔ 成功生成: ${TARGET_OUTPUT} ($(du -h "${TARGET_OUTPUT}" | cut -f1))${NC}"
else
    echo -e "${RED}  ✖ 编译失败: ${TARGET_NAME}${NC}"
    exit 1
fi

echo -e "\n${GREEN}=========================================${NC}"
echo -e "${GREEN}  编译任务结束！产物列表：${NC}"
echo -e "${GREEN}=========================================${NC}"

# ── Docker 源码包 ──
DOCKER_ARCHIVE="${BUILD_DIR}/Emby-In-One-docker-${VERSION}.tar.gz"
echo -e "\n${YELLOW}▶ 打包 Docker 源码包...${NC}"
tar -czf "${DOCKER_ARCHIVE}" \
  --transform 's,^,emby-in-one/,' \
  go.mod cmd internal third_party public \
  Dockerfile docker-compose.yml emby-in-one-cli.sh 2>/dev/null || true
echo -e "  ${GREEN}✔ 已生成: ${DOCKER_ARCHIVE} ($(du -h "${DOCKER_ARCHIVE}" | cut -f1))${NC}"

ls -lh "${BUILD_DIR}/" | grep "Emby-In-One" || echo "没有生成任何文件"
