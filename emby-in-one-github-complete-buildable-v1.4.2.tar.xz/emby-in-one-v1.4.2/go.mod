module emby-in-one

go 1.23

require golang.org/x/text v0.22.0
