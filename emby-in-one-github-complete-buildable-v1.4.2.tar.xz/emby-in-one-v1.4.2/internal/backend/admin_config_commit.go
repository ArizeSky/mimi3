package backend

func (a *App) commitConfig(nextCfg Config) error {
	return a.commitConfigFull(nextCfg, true)
}

func (a *App) commitConfigSettingsOnly(nextCfg Config) error {
	return a.commitConfigFull(nextCfg, false)
}

func (a *App) commitConfigFull(nextCfg Config, reloadUpstreams bool) error {
	previous := a.ConfigStore.Snapshot()
	a.ConfigStore.Replace(nextCfg)
	if err := a.ConfigStore.Save(); err != nil {
		a.ConfigStore.Replace(previous)
		return err
	}
	if reloadUpstreams {
		a.Upstream.Reload(nextCfg)
		go a.Upstream.LoginAll()
	}
	return nil
}
