package backend

import (
	"net/http"
	"os"
	"strconv"
)

func (a *App) handleAdminLogs(w http.ResponseWriter, r *http.Request) {
	limit, _ := strconv.Atoi(r.URL.Query().Get("limit"))
	writeJSON(w, http.StatusOK, a.Logger.Entries(limit))
}

func (a *App) handleAdminLogsDownload(w http.ResponseWriter, r *http.Request) {
	logFile := a.Logger.FilePath()
	if logFile == "" {
		writeJSON(w, http.StatusNotFound, map[string]any{"error": "Log file not found"})
		return
	}
	if _, err := os.Stat(logFile); err != nil {
		writeJSON(w, http.StatusNotFound, map[string]any{"error": "Log file not found"})
		return
	}
	w.Header().Set("Content-Type", "text/plain; charset=utf-8")
	w.Header().Set("Content-Disposition", "attachment; filename=\"emby-in-one.log\"")
	http.ServeFile(w, r, logFile)
}

func (a *App) handleAdminLogsClear(w http.ResponseWriter, r *http.Request) {
	if err := a.Logger.ClearFile(); err != nil {
		writeJSON(w, http.StatusInternalServerError, map[string]any{"error": err.Error()})
		return
	}
	a.Logger.Infof("Log file cleared by admin")
	writeJSON(w, http.StatusOK, map[string]any{"success": true})
}
