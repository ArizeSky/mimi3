package backend

import (
	"net/http"
	"net/url"
	"strings"
	"time"
)

type adminProxyInput struct {
	Name string `json:"name"`
	URL  string `json:"url"`
}

func (a *App) handleAdminProxiesList(w http.ResponseWriter, r *http.Request) {
	cfg := a.ConfigStore.Snapshot()
	out := make([]map[string]any, 0, len(cfg.Proxies))
	for _, proxy := range cfg.Proxies {
		out = append(out, map[string]any{
			"id":   proxy.ID,
			"name": proxy.Name,
			"url":  sanitizeProxyURL(proxy.URL),
		})
	}
	writeJSON(w, http.StatusOK, out)
}

func (a *App) handleAdminProxiesCreate(w http.ResponseWriter, r *http.Request) {
	var body adminProxyInput
	if err := decodeJSONBody(r, &body); err != nil {
		writeJSON(w, http.StatusBadRequest, map[string]any{"error": "Invalid request body"})
		return
	}
	if err := validateHTTPURL(body.URL); err != nil {
		writeJSON(w, http.StatusBadRequest, map[string]any{"error": err.Error()})
		return
	}
	proxy := ProxyConfig{ID: randomHex(16), Name: body.Name, URL: strings.TrimRight(body.URL, "/")}
	if proxy.Name == "" {
		proxy.Name = "Proxy"
	}
	cfg := a.ConfigStore.Snapshot()
	nextCfg := cfg
	nextCfg.Proxies = append(append([]ProxyConfig(nil), cfg.Proxies...), proxy)
	if err := a.commitConfig(nextCfg); err != nil {
		writeJSON(w, http.StatusInternalServerError, map[string]any{"error": err.Error()})
		return
	}
	writeJSON(w, http.StatusOK, map[string]any{"id": proxy.ID, "name": proxy.Name, "url": sanitizeProxyURL(proxy.URL)})
}

func (a *App) handleAdminProxiesDelete(w http.ResponseWriter, r *http.Request) {
	id := r.PathValue("id")
	cfg := a.ConfigStore.Snapshot()
	next := make([]ProxyConfig, 0, len(cfg.Proxies))
	for _, proxy := range cfg.Proxies {
		if proxy.ID != id {
			next = append(next, proxy)
		}
	}
	nextCfg := cfg
	nextCfg.Proxies = next
	if err := a.commitConfig(nextCfg); err != nil {
		writeJSON(w, http.StatusInternalServerError, map[string]any{"error": err.Error()})
		return
	}
	writeJSON(w, http.StatusOK, map[string]any{"success": true})
}

func (a *App) handleAdminProxyTest(w http.ResponseWriter, r *http.Request) {
	var body struct {
		ProxyURL  string `json:"proxyUrl"`
		ProxyID   string `json:"proxyId"`
		TargetURL string `json:"targetUrl"`
	}
	if err := decodeJSONBody(r, &body); err != nil {
		writeJSON(w, http.StatusBadRequest, map[string]any{"error": "Invalid request body"})
		return
	}
	proxyURL := strings.TrimSpace(body.ProxyURL)
	if strings.TrimSpace(body.ProxyID) != "" {
		cfg := a.ConfigStore.Snapshot()
		proxy := findProxy(cfg.Proxies, body.ProxyID)
		if proxy == nil {
			writeJSON(w, http.StatusOK, map[string]any{"success": false, "latency": int64(0), "error": "Proxy not found"})
			return
		}
		proxyURL = proxy.URL
	}
	if err := validateHTTPURL(proxyURL); err != nil {
		writeJSON(w, http.StatusBadRequest, map[string]any{"error": "Invalid proxy URL: " + err.Error()})
		return
	}
	if err := validateHTTPURL(body.TargetURL); err != nil {
		writeJSON(w, http.StatusBadRequest, map[string]any{"error": "Invalid target URL: " + err.Error()})
		return
	}
	parsedTarget, _ := url.Parse(body.TargetURL)
	if parsedTarget != nil && isPrivateOrReservedIP(parsedTarget.Hostname()) {
		writeJSON(w, http.StatusBadRequest, map[string]any{"error": "Target URL resolves to a private or reserved address"})
		return
	}
	transport, ok := buildProxyTransport(proxyURL, a.Logger, "proxy-test")
	if !ok {
		writeJSON(w, http.StatusOK, map[string]any{"success": false, "latency": int64(0), "error": "Failed to create proxy transport (invalid URL or scheme)"})
		return
	}
	safeTransport := wrapTransportWithSSRFCheck(transport)
	client := &http.Client{Transport: safeTransport, Timeout: 10 * time.Second}
	start := time.Now()
	resp, err := client.Get(body.TargetURL)
	latency := time.Since(start).Milliseconds()
	if err != nil {
		writeJSON(w, http.StatusOK, map[string]any{"success": false, "latency": latency, "error": err.Error()})
		return
	}
	resp.Body.Close()
	result := map[string]any{"success": true, "latency": latency, "statusCode": resp.StatusCode}
	writeJSON(w, http.StatusOK, result)
}
