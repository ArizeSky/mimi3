package backend

import (
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
)

func TestRegisterAdminRoutesRegistersAdminEndpoints(t *testing.T) {
	withTempApp(t, func(app *App, _ http.Handler) {
		mux := http.NewServeMux()
		app.registerAdminRoutes(mux)

		req := httptest.NewRequest(http.MethodGet, "/admin/api/status", nil)
		rr := httptest.NewRecorder()
		mux.ServeHTTP(rr, req)

		if rr.Code == http.StatusNotFound {
			t.Fatalf("expected admin routes to be registered")
		}
	})
}

func findCookie(cookies []*http.Cookie, name string) *http.Cookie {
	for _, cookie := range cookies {
		if cookie.Name == name {
			return cookie
		}
	}
	return nil
}

func TestAdminLoginSetsStrictSessionCookie(t *testing.T) {
	withTempApp(t, func(app *App, handler http.Handler) {
		rr := doJSONRequest(t, handler, http.MethodPost, "/admin/api/login", map[string]string{
			"username": "admin",
			"password": "secret",
		}, "")
		if rr.Code != http.StatusOK {
			t.Fatalf("login status = %d, body=%s", rr.Code, rr.Body.String())
		}
		if strings.Contains(rr.Body.String(), "AccessToken") {
			t.Fatalf("admin login should not expose access token in body: %s", rr.Body.String())
		}
		cookie := findCookie(rr.Result().Cookies(), adminSessionCookieName)
		if cookie == nil {
			t.Fatalf("missing admin session cookie: %#v", rr.Result().Cookies())
		}
		if cookie.Value == "" {
			t.Fatal("admin session cookie should not be empty")
		}
		if cookie.Path != "/admin" {
			t.Fatalf("cookie path = %q, want /admin", cookie.Path)
		}
		if !cookie.HttpOnly {
			t.Fatal("admin session cookie should be HttpOnly")
		}
		if cookie.SameSite != http.SameSiteStrictMode {
			t.Fatalf("cookie SameSite = %v, want Strict", cookie.SameSite)
		}
	})
}

func TestAdminLoginRejectsInvalidCredentials(t *testing.T) {
	withTempApp(t, func(app *App, handler http.Handler) {
		rr := doJSONRequest(t, handler, http.MethodPost, "/admin/api/login", map[string]string{
			"username": "admin",
			"password": "wrong",
		}, "")
		if rr.Code != http.StatusUnauthorized {
			t.Fatalf("login status = %d, want 401 body=%s", rr.Code, rr.Body.String())
		}
		if cookie := findCookie(rr.Result().Cookies(), adminSessionCookieName); cookie != nil && cookie.Value != "" {
			t.Fatalf("unexpected admin session cookie on failed login: %#v", cookie)
		}
	})
}

func TestAdminCookieAuthorizesAndLogoutRevokesSession(t *testing.T) {
	withTempApp(t, func(app *App, handler http.Handler) {
		login := doJSONRequest(t, handler, http.MethodPost, "/admin/api/login", map[string]string{
			"username": "admin",
			"password": "secret",
		}, "")
		if login.Code != http.StatusOK {
			t.Fatalf("login status = %d, body=%s", login.Code, login.Body.String())
		}
		cookie := findCookie(login.Result().Cookies(), adminSessionCookieName)
		if cookie == nil {
			t.Fatalf("missing admin session cookie: %#v", login.Result().Cookies())
		}

		statusReq := httptest.NewRequest(http.MethodGet, "/admin/api/status", nil)
		statusReq.AddCookie(cookie)
		statusRR := httptest.NewRecorder()
		handler.ServeHTTP(statusRR, statusReq)
		if statusRR.Code != http.StatusOK {
			t.Fatalf("status before logout = %d, body=%s", statusRR.Code, statusRR.Body.String())
		}

		logoutReq := httptest.NewRequest(http.MethodPost, "/admin/api/logout", nil)
		logoutReq.AddCookie(cookie)
		logoutRR := httptest.NewRecorder()
		handler.ServeHTTP(logoutRR, logoutReq)
		if logoutRR.Code != http.StatusOK {
			t.Fatalf("logout status = %d, body=%s", logoutRR.Code, logoutRR.Body.String())
		}
		cleared := findCookie(logoutRR.Result().Cookies(), adminSessionCookieName)
		if cleared == nil || cleared.MaxAge >= 0 {
			t.Fatalf("logout should clear admin session cookie: %#v", logoutRR.Result().Cookies())
		}

		statusAfterReq := httptest.NewRequest(http.MethodGet, "/admin/api/status", nil)
		statusAfterReq.AddCookie(cookie)
		statusAfterRR := httptest.NewRecorder()
		handler.ServeHTTP(statusAfterRR, statusAfterReq)
		if statusAfterRR.Code != http.StatusUnauthorized {
			t.Fatalf("status after logout = %d, want 401 body=%s", statusAfterRR.Code, statusAfterRR.Body.String())
		}
	})
}

func TestAdminLogoutStillRevokesHeaderToken(t *testing.T) {
	withTempApp(t, func(app *App, handler http.Handler) {
		token := loginToken(t, handler, "secret")

		status := doJSONRequest(t, handler, http.MethodGet, "/admin/api/status", nil, token)
		if status.Code != http.StatusOK {
			t.Fatalf("status before logout = %d, body=%s", status.Code, status.Body.String())
		}

		logout := doJSONRequest(t, handler, http.MethodPost, "/admin/api/logout", nil, token)
		if logout.Code != http.StatusOK {
			t.Fatalf("logout status = %d, body=%s", logout.Code, logout.Body.String())
		}

		statusAfter := doJSONRequest(t, handler, http.MethodGet, "/admin/api/status", nil, token)
		if statusAfter.Code != http.StatusUnauthorized {
			t.Fatalf("status after logout = %d, want 401 body=%s", statusAfter.Code, statusAfter.Body.String())
		}
	})
}
