package backend

import (
	"net/http"
)

const adminSessionCookieName = "eio_admin_session"

type adminLoginRequest struct {
	Username       string `json:"username"`
	Password       string `json:"password"`
	LegacyUsername string `json:"Username"`
	LegacyPassword string `json:"Pw"`
}

func (r adminLoginRequest) credentials() (string, string) {
	username := r.Username
	if username == "" {
		username = r.LegacyUsername
	}
	password := r.Password
	if password == "" {
		password = r.LegacyPassword
	}
	return username, password
}

func adminSessionToken(r *http.Request) string {
	cookie, err := r.Cookie(adminSessionCookieName)
	if err != nil {
		return ""
	}
	return cookie.Value
}

func setAdminSessionCookie(w http.ResponseWriter, r *http.Request, token string) {
	http.SetCookie(w, &http.Cookie{
		Name:     adminSessionCookieName,
		Value:    token,
		Path:     "/admin",
		HttpOnly: true,
		Secure:   webRequestIsHTTPS(r),
		SameSite: http.SameSiteStrictMode,
		MaxAge:   int(authTokenTTL.Seconds()),
	})
}

func clearAdminSessionCookie(w http.ResponseWriter, r *http.Request) {
	http.SetCookie(w, &http.Cookie{
		Name:     adminSessionCookieName,
		Value:    "",
		Path:     "/admin",
		HttpOnly: true,
		Secure:   webRequestIsHTTPS(r),
		SameSite: http.SameSiteStrictMode,
		MaxAge:   -1,
	})
}

func (a *App) handleAdminLogin(w http.ResponseWriter, r *http.Request) {
	ip := clientIP(r, a.ConfigStore.Snapshot().Server.TrustProxy)
	if !a.loginLimiter.checkAndRecord(ip) {
		writeJSON(w, http.StatusTooManyRequests, map[string]any{"message": "Too many failed login attempts, please try again later"})
		return
	}

	var body adminLoginRequest
	if err := decodeJSONBody(r, &body); err != nil {
		writeJSON(w, http.StatusBadRequest, map[string]any{"message": "Invalid request body"})
		return
	}
	username, password := body.credentials()
	if !a.Auth.VerifyAdminCredentials(username, password) {
		writeJSON(w, http.StatusUnauthorized, map[string]any{"message": "Invalid username or password"})
		return
	}

	result, ok, err := a.Auth.Authenticate(username, password)
	if err != nil {
		writeJSON(w, http.StatusInternalServerError, map[string]any{"message": err.Error()})
		return
	}
	if !ok {
		writeJSON(w, http.StatusUnauthorized, map[string]any{"message": "Invalid username or password"})
		return
	}
	token, _ := result["AccessToken"].(string)
	if token == "" {
		writeJSON(w, http.StatusInternalServerError, map[string]any{"message": "missing admin session token"})
		return
	}

	a.loginLimiter.recordSuccess(ip)
	setAdminSessionCookie(w, r, token)
	writeJSON(w, http.StatusOK, map[string]any{"success": true})
}
