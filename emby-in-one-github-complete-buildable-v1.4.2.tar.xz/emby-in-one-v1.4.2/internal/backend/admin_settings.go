package backend

import (
	"net/http"
	"strings"
)

type adminSettingsInput struct {
	ServerName      *string        `json:"serverName"`
	PlaybackMode    *string        `json:"playbackMode"`
	AdminUsername   *string        `json:"adminUsername"`
	AdminPassword   *string        `json:"adminPassword"`
	CurrentPassword *string        `json:"currentPassword"`
	Timeouts        map[string]any `json:"timeouts"`
}

func (a *App) handleAdminSettings(w http.ResponseWriter, r *http.Request) {
	cfg := a.ConfigStore.Snapshot()
	writeJSON(w, http.StatusOK, map[string]any{
		"serverName":    cfg.Server.Name,
		"port":          cfg.Server.Port,
		"playbackMode":  cfg.Playback.Mode,
		"adminUsername": cfg.Admin.Username,
		"timeouts": map[string]any{
			"api":                 cfg.Timeouts.API,
			"global":              cfg.Timeouts.Global,
			"login":               cfg.Timeouts.Login,
			"healthCheck":         cfg.Timeouts.HealthCheck,
			"healthInterval":      cfg.Timeouts.HealthInterval,
			"searchGracePeriod":   cfg.Timeouts.SearchGracePeriod,
			"metadataGracePeriod": cfg.Timeouts.MetadataGracePeriod,
			"latestGracePeriod":   cfg.Timeouts.LatestGracePeriod,
		},
	})
}

func (a *App) handleAdminSettingsUpdate(w http.ResponseWriter, r *http.Request) {
	var body adminSettingsInput
	if err := decodeJSONBody(r, &body); err != nil {
		writeJSON(w, http.StatusBadRequest, map[string]any{"error": "Invalid request body"})
		return
	}
	cfg := a.ConfigStore.Snapshot()
	nextCfg := cfg

	if body.ServerName != nil {
		name := strings.TrimSpace(*body.ServerName)
		if err := validateRequiredLength("serverName", name, 1, 100); err != nil {
			writeJSON(w, http.StatusBadRequest, map[string]any{"error": err.Error()})
			return
		}
		nextCfg.Server.Name = name
	}
	if body.PlaybackMode != nil && strings.TrimSpace(*body.PlaybackMode) != "" {
		mode := strings.TrimSpace(*body.PlaybackMode)
		if err := validatePlaybackMode(mode); err != nil {
			writeJSON(w, http.StatusBadRequest, map[string]any{"error": err.Error()})
			return
		}
		nextCfg.Playback.Mode = mode
	}
	if body.AdminUsername != nil && strings.TrimSpace(*body.AdminUsername) != "" {
		username := strings.TrimSpace(*body.AdminUsername)
		if err := validateRequiredLength("adminUsername", username, 1, 50); err != nil {
			writeJSON(w, http.StatusBadRequest, map[string]any{"error": err.Error()})
			return
		}
		nextCfg.Admin.Username = username
	}
	if body.AdminPassword != nil && *body.AdminPassword != "" {
		currentPassword := ""
		if body.CurrentPassword != nil {
			currentPassword = *body.CurrentPassword
		}
		if !VerifyPassword(currentPassword, cfg.Admin.Password) {
			writeJSON(w, http.StatusForbidden, map[string]any{"error": "当前密码不正确"})
			return
		}
		hashed, err := HashPassword(*body.AdminPassword)
		if err != nil {
			writeJSON(w, http.StatusInternalServerError, map[string]any{"error": err.Error()})
			return
		}
		nextCfg.Admin.Password = hashed
	}
	for _, key := range []string{"api", "global", "login", "healthCheck", "healthInterval", "searchGracePeriod", "metadataGracePeriod"} {
		if raw, ok := body.Timeouts[key]; ok {
			if parsed, ok := toPositiveInt(raw); ok {
				switch key {
				case "api":
					nextCfg.Timeouts.API = parsed
				case "global":
					nextCfg.Timeouts.Global = parsed
				case "login":
					nextCfg.Timeouts.Login = parsed
				case "healthCheck":
					nextCfg.Timeouts.HealthCheck = parsed
				case "healthInterval":
					nextCfg.Timeouts.HealthInterval = parsed
				case "searchGracePeriod":
					nextCfg.Timeouts.SearchGracePeriod = parsed
				case "metadataGracePeriod":
					nextCfg.Timeouts.MetadataGracePeriod = parsed
				}
			}
		}
	}
	if raw, ok := body.Timeouts["latestGracePeriod"]; ok {
		if parsed, ok := toNonNegativeInt(raw); ok {
			nextCfg.Timeouts.LatestGracePeriod = parsed
		}
	}

	passwordChanged := nextCfg.Admin.Password != cfg.Admin.Password

	if err := a.commitConfigSettingsOnly(nextCfg); err != nil {
		writeJSON(w, http.StatusInternalServerError, map[string]any{"error": err.Error()})
		return
	}
	if passwordChanged {
		a.Auth.RevokeAllTokens()
		if a.Logger != nil {
			a.Logger.Infof("Admin password changed — all proxy tokens revoked")
		}
	}
	writeJSON(w, http.StatusOK, map[string]any{"success": true})
}
