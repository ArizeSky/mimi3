package backend

import "net/http"

func (a *App) handleAdminClientInfo(w http.ResponseWriter, r *http.Request) {
	writeJSON(w, http.StatusOK, a.Identity.GetInfo())
}

func (a *App) handleAdminStatus(w http.ResponseWriter, r *http.Request) {
	cfg := a.ConfigStore.Snapshot()
	clients := a.Upstream.Clients()
	upstream := make([]map[string]any, 0, len(clients))
	online := 0
	for _, client := range clients {
		if client.Online {
			online++
		}
		upstream = append(upstream, map[string]any{
			"index":        client.ServerIndex,
			"name":         client.Name,
			"url":          sanitizeUpstreamURL(client.BaseURL),
			"online":       client.Online,
			"playbackMode": client.Config.PlaybackMode,
		})
	}
	writeJSON(w, http.StatusOK, map[string]any{
		"version":        a.Version,
		"serverName":     cfg.Server.Name,
		"serverId":       cfg.Server.ID,
		"port":           cfg.Server.Port,
		"playbackMode":   cfg.Playback.Mode,
		"idMappings":     a.IDStore.Stats(),
		"upstreamCount":  len(clients),
		"upstreamOnline": online,
		"upstream":       upstream,
	})
}
