package backend

import "net/http"

type adminUpstreamInput struct {
	Name                *string   `json:"name"`
	URL                 *string   `json:"url"`
	Username            *string   `json:"username"`
	Password            *string   `json:"password"`
	APIKey              *string   `json:"apiKey"`
	PlaybackMode        *string   `json:"playbackMode"`
	SpoofClient         *string   `json:"spoofClient"`
	FollowRedirects     *bool     `json:"followRedirects"`
	ProxyID             *string   `json:"proxyId"`
	PriorityMetadata    *bool     `json:"priorityMetadata"`
	CustomUserAgent     *string   `json:"customUserAgent"`
	CustomClient        *string   `json:"customClient"`
	CustomClientVersion *string   `json:"customClientVersion"`
	CustomDeviceName    *string   `json:"customDeviceName"`
	CustomDeviceId      *string   `json:"customDeviceId"`
	MaxConcurrent       *int      `json:"maxConcurrent"`
	StreamingURL        *string   `json:"streamingUrl"`
	StreamingURLs       *[]string `json:"streamingUrls"`
}

func (a *App) handleAdminUpstreamList(w http.ResponseWriter, r *http.Request) {
	cfg := a.ConfigStore.Snapshot()
	clients := a.Upstream.Clients()
	onlineByIndex := map[int]bool{}
	for _, client := range clients {
		onlineByIndex[client.ServerIndex] = client.Online
	}
	out := make([]map[string]any, 0, len(cfg.Upstream))
	for index, upstream := range cfg.Upstream {
		authType := "password"
		if upstream.APIKey != "" {
			authType = "apiKey"
		}
		out = append(out, map[string]any{
			"index":               index,
			"name":                upstream.Name,
			"url":                 sanitizeUpstreamURL(upstream.URL),
			"username":            upstream.Username,
			"authType":            authType,
			"online":              onlineByIndex[index],
			"playbackMode":        upstream.PlaybackMode,
			"spoofClient":         upstream.SpoofClient,
			"followRedirects":     upstream.FollowRedirects,
			"proxyId":             valueOrNil(upstream.ProxyID),
			"priorityMetadata":    upstream.PriorityMetadata,
			"customUserAgent":     upstream.CustomUserAgent,
			"customClient":        upstream.CustomClient,
			"customClientVersion": upstream.CustomClientVersion,
			"customDeviceName":    upstream.CustomDeviceName,
			"customDeviceId":      upstream.CustomDeviceId,
			"maxConcurrent":       upstream.MaxConcurrent,
			"streamingUrl":        upstream.StreamingURL,
			"streamingUrls":       cloneStreamingURLs(upstream.StreamingURLs),
		})
	}
	writeJSON(w, http.StatusOK, out)
}

func (a *App) handleAdminUpstreamCreate(w http.ResponseWriter, r *http.Request) {
	a.mu.Lock()
	defer a.mu.Unlock()

	var body adminUpstreamInput
	if err := decodeJSONBody(r, &body); err != nil {
		writeJSON(w, http.StatusBadRequest, map[string]any{"error": "Invalid request body"})
		return
	}

	cfg := a.ConfigStore.Snapshot()
	draft := UpstreamConfig{FollowRedirects: true}
	applyAdminUpstreamInput(&draft, body, true)
	normalizeUpstream(&draft, len(cfg.Upstream), &cfg)
	if err := validateUpstreamDraft(draft); err != nil {
		writeJSON(w, http.StatusBadRequest, map[string]any{"error": err.Error()})
		return
	}
	validation, err := a.validateUpstreamConnectivity(cfg, draft, len(cfg.Upstream), requestContextFrom(r.Context()))
	if err != nil {
		writeJSON(w, http.StatusBadGateway, map[string]any{"error": err.Error()})
		return
	}

	nextCfg := cfg
	nextCfg.Upstream = append(append([]UpstreamConfig(nil), cfg.Upstream...), draft)
	if err := a.commitConfig(nextCfg); err != nil {
		writeJSON(w, http.StatusInternalServerError, map[string]any{"error": err.Error()})
		return
	}
	online := validation.Online
	if client := a.Upstream.GetClient(len(cfg.Upstream)); client != nil {
		online = client.IsOnline()
	}
	payload := map[string]any{"success": true, "index": len(cfg.Upstream), "name": draft.Name, "online": online}
	if validation.Warning != "" && !online {
		payload["warning"] = validation.Warning
	}
	writeJSON(w, http.StatusOK, payload)
}

func (a *App) handleAdminUpstreamUpdate(w http.ResponseWriter, r *http.Request) {
	a.mu.Lock()
	defer a.mu.Unlock()

	index, ok := parsePathIndex(r, "index")
	if !ok {
		writeJSON(w, http.StatusBadRequest, map[string]any{"error": "Invalid upstream index"})
		return
	}
	cfg := a.ConfigStore.Snapshot()
	if index < 0 || index >= len(cfg.Upstream) {
		w.WriteHeader(http.StatusNotFound)
		return
	}

	var body adminUpstreamInput
	if err := decodeJSONBody(r, &body); err != nil {
		writeJSON(w, http.StatusBadRequest, map[string]any{"error": "Invalid request body"})
		return
	}

	draft := cfg.Upstream[index]
	applyAdminUpstreamInput(&draft, body, false)
	normalizeUpstream(&draft, index, &cfg)
	if err := validateUpstreamDraft(draft); err != nil {
		writeJSON(w, http.StatusBadRequest, map[string]any{"error": err.Error()})
		return
	}
	validation, err := a.validateUpstreamConnectivity(cfg, draft, index, requestContextFrom(r.Context()))
	if err != nil {
		writeJSON(w, http.StatusBadGateway, map[string]any{"error": err.Error()})
		return
	}

	nextCfg := cfg
	nextCfg.Upstream = append([]UpstreamConfig(nil), cfg.Upstream...)
	nextCfg.Upstream[index] = draft
	if err := a.commitConfig(nextCfg); err != nil {
		writeJSON(w, http.StatusInternalServerError, map[string]any{"error": err.Error()})
		return
	}
	online := validation.Online
	if client := a.Upstream.GetClient(index); client != nil {
		online = client.IsOnline()
	}
	payload := map[string]any{"success": true, "index": index, "name": draft.Name, "online": online}
	if validation.Warning != "" && !online {
		payload["warning"] = validation.Warning
	}
	writeJSON(w, http.StatusOK, payload)
}

func (a *App) handleAdminUpstreamReorder(w http.ResponseWriter, r *http.Request) {
	a.mu.Lock()
	defer a.mu.Unlock()

	var body struct {
		FromIndex int `json:"fromIndex"`
		ToIndex   int `json:"toIndex"`
	}
	if err := decodeJSONBody(r, &body); err != nil {
		writeJSON(w, http.StatusBadRequest, map[string]any{"error": "Invalid request body"})
		return
	}
	cfg := a.ConfigStore.Snapshot()
	if body.FromIndex < 0 || body.FromIndex >= len(cfg.Upstream) || body.ToIndex < 0 || body.ToIndex >= len(cfg.Upstream) {
		writeJSON(w, http.StatusBadRequest, map[string]any{"error": "Index out of bounds"})
		return
	}
	nextCfg := cfg
	nextCfg.Upstream = append([]UpstreamConfig(nil), cfg.Upstream...)
	item := nextCfg.Upstream[body.FromIndex]
	nextCfg.Upstream = append(nextCfg.Upstream[:body.FromIndex], nextCfg.Upstream[body.FromIndex+1:]...)
	reordered := append([]UpstreamConfig(nil), nextCfg.Upstream[:body.ToIndex]...)
	reordered = append(reordered, item)
	reordered = append(reordered, nextCfg.Upstream[body.ToIndex:]...)
	nextCfg.Upstream = reordered
	a.IDStore.ReorderServerIndices(body.FromIndex, body.ToIndex)
	if a.UserStore != nil {
		a.UserStore.ReorderServerIndices(body.FromIndex, body.ToIndex)
	}
	if err := a.commitConfig(nextCfg); err != nil {
		a.IDStore.ReorderServerIndices(body.ToIndex, body.FromIndex)
		if a.UserStore != nil {
			a.UserStore.ReorderServerIndices(body.ToIndex, body.FromIndex)
		}
		writeJSON(w, http.StatusInternalServerError, map[string]any{"error": err.Error()})
		return
	}
	a.Auth.RevokeNonAdminTokens()
	writeJSON(w, http.StatusOK, map[string]any{"success": true})
}

func (a *App) handleAdminUpstreamDelete(w http.ResponseWriter, r *http.Request) {
	a.mu.Lock()
	defer a.mu.Unlock()

	index, ok := parsePathIndex(r, "index")
	if !ok {
		writeJSON(w, http.StatusBadRequest, map[string]any{"error": "Invalid upstream index"})
		return
	}
	cfg := a.ConfigStore.Snapshot()
	if index < 0 || index >= len(cfg.Upstream) {
		writeJSON(w, http.StatusNotFound, map[string]any{"error": "Server not found"})
		return
	}
	nextCfg := cfg
	nextCfg.Upstream = append([]UpstreamConfig(nil), cfg.Upstream[:index]...)
	nextCfg.Upstream = append(nextCfg.Upstream, cfg.Upstream[index+1:]...)
	if err := a.commitConfig(nextCfg); err != nil {
		writeJSON(w, http.StatusInternalServerError, map[string]any{"error": err.Error()})
		return
	}
	a.IDStore.RemoveByServerIndex(index)
	a.IDStore.ShiftServerIndices(index)
	if a.UserStore != nil {
		a.UserStore.ShiftServerIndices(index)
	}
	writeJSON(w, http.StatusOK, map[string]any{"success": true})
}

func (a *App) handleAdminUpstreamReconnect(w http.ResponseWriter, r *http.Request) {
	index, ok := parsePathIndex(r, "index")
	if !ok {
		writeJSON(w, http.StatusBadRequest, map[string]any{"error": "Invalid upstream index"})
		return
	}
	client := a.Upstream.Reconnect(index)
	if client == nil {
		writeJSON(w, http.StatusNotFound, map[string]any{"error": "Server not found"})
		return
	}
	writeJSON(w, http.StatusOK, map[string]any{"success": true, "online": client.Online})
}
