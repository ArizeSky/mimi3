package backend

import (
	"net/http"
	"strings"
)

func (a *App) handleAdminUsersList(w http.ResponseWriter, r *http.Request) {
	if a.UserStore == nil {
		writeJSON(w, http.StatusOK, []any{})
		return
	}
	users := a.UserStore.List()
	cfg := a.ConfigStore.Snapshot()
	result := make([]map[string]any, 0, len(users))
	for _, u := range users {
		serverNames := make([]string, 0, len(u.AllowedServers))
		for _, idx := range u.AllowedServers {
			if idx >= 0 && idx < len(cfg.Upstream) {
				serverNames = append(serverNames, cfg.Upstream[idx].Name)
			}
		}
		result = append(result, map[string]any{
			"id":             u.ID,
			"username":       u.Username,
			"enabled":        u.Enabled,
			"allowedServers": u.AllowedServers,
			"serverNames":    serverNames,
			"createdAt":      u.CreatedAt,
		})
	}
	writeJSON(w, http.StatusOK, result)
}

func (a *App) handleAdminUsersCreate(w http.ResponseWriter, r *http.Request) {
	if a.UserStore == nil {
		writeJSON(w, http.StatusServiceUnavailable, map[string]any{"error": "multi-user disabled"})
		return
	}
	var input struct {
		Username       string `json:"username"`
		Password       string `json:"password"`
		AllowedServers []int  `json:"allowedServers"`
	}
	if err := decodeJSONBody(r, &input); err != nil {
		writeJSON(w, http.StatusBadRequest, map[string]any{"error": "Invalid request body"})
		return
	}
	if input.Username == "" || input.Password == "" {
		writeJSON(w, http.StatusBadRequest, map[string]any{"error": "用户名和密码不能为空"})
		return
	}
	cfg := a.ConfigStore.Snapshot()
	if strings.EqualFold(input.Username, cfg.Admin.Username) {
		writeJSON(w, http.StatusConflict, map[string]any{"error": "用户名与管理员冲突"})
		return
	}
	user, err := a.UserStore.Create(input.Username, input.Password, input.AllowedServers)
	if err != nil {
		if strings.Contains(err.Error(), "UNIQUE") || strings.Contains(err.Error(), "already exists") {
			writeJSON(w, http.StatusConflict, map[string]any{"error": "用户名已存在"})
			return
		}
		writeJSON(w, http.StatusInternalServerError, map[string]any{"error": err.Error()})
		return
	}
	writeJSON(w, http.StatusCreated, map[string]any{"id": user.ID, "username": user.Username})
}

func (a *App) handleAdminUsersUpdate(w http.ResponseWriter, r *http.Request) {
	if a.UserStore == nil {
		writeJSON(w, http.StatusServiceUnavailable, map[string]any{"error": "multi-user disabled"})
		return
	}
	id := r.PathValue("id")
	var input struct {
		Username       *string `json:"username"`
		Password       *string `json:"password"`
		Enabled        *bool   `json:"enabled"`
		AllowedServers *[]int  `json:"allowedServers"`
	}
	if err := decodeJSONBody(r, &input); err != nil {
		writeJSON(w, http.StatusBadRequest, map[string]any{"error": "Invalid request body"})
		return
	}
	if input.Username != nil {
		cfg := a.ConfigStore.Snapshot()
		if strings.EqualFold(*input.Username, cfg.Admin.Username) {
			writeJSON(w, http.StatusConflict, map[string]any{"error": "用户名与管理员冲突"})
			return
		}
	}
	if err := a.UserStore.Update(id, input.Username, input.Password, input.Enabled, input.AllowedServers); err != nil {
		writeJSON(w, http.StatusInternalServerError, map[string]any{"error": err.Error()})
		return
	}
	if input.Username != nil || input.Password != nil || input.Enabled != nil || input.AllowedServers != nil {
		a.Auth.RevokeTokensByUserID(id)
	}
	writeJSON(w, http.StatusOK, map[string]any{"success": true})
}

func (a *App) handleAdminUsersDelete(w http.ResponseWriter, r *http.Request) {
	if a.UserStore == nil {
		writeJSON(w, http.StatusServiceUnavailable, map[string]any{"error": "multi-user disabled"})
		return
	}
	id := r.PathValue("id")
	if err := a.UserStore.Delete(id); err != nil {
		writeJSON(w, http.StatusInternalServerError, map[string]any{"error": err.Error()})
		return
	}
	a.Auth.RevokeTokensByUserID(id)
	if a.WatchStore != nil {
		if err := a.WatchStore.DeleteUser(id); err != nil && a.Logger != nil {
			a.Logger.Warnf("failed to delete watch data for user %s: %v", id, err)
		}
	}
	writeJSON(w, http.StatusOK, map[string]any{"success": true})
}
