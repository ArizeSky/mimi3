package backend

import (
	"context"
	"net/http"
	"strings"
)

type requestContextKey struct{}

type authTokenSource string

const (
	authSourceNone          authTokenSource = ""
	authSourceHeader        authTokenSource = "header"
	authSourceQuery         authTokenSource = "query"
	authSourceWebCookie     authTokenSource = "web_cookie"
	authSourceAdminCookie   authTokenSource = "admin_cookie"
	authSourceAuthorization authTokenSource = "authorization"
)

type RequestContext struct {
	Headers    http.Header
	ProxyToken string
	ProxyUser  *tokenInfo
	AuthSource authTokenSource
}

func (a *App) withContext(next http.HandlerFunc) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		token, source := extractTokenWithSource(r)
		var proxyUser *tokenInfo
		if token != "" {
			proxyUser = a.Auth.ValidateToken(token)
		}
		ctx := context.WithValue(r.Context(), requestContextKey{}, &RequestContext{
			Headers:    r.Header.Clone(),
			ProxyToken: token,
			ProxyUser:  proxyUser,
			AuthSource: source,
		})
		next(w, r.WithContext(ctx))
	}
}

func (a *App) requireAuth(next http.HandlerFunc) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		if reqCtx := requestContextFrom(r.Context()); reqCtx == nil || reqCtx.ProxyUser == nil {
			writeJSON(w, http.StatusUnauthorized, map[string]any{"message": "Authentication required"})
			return
		}
		next(w, r)
	}
}

func (a *App) requireAdmin(next http.HandlerFunc) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		reqCtx := requestContextFrom(r.Context())
		if reqCtx == nil || reqCtx.ProxyUser == nil {
			writeJSON(w, http.StatusUnauthorized, map[string]any{"message": "Authentication required"})
			return
		}
		if reqCtx.ProxyUser.Role != "admin" {
			writeJSON(w, http.StatusForbidden, map[string]any{"message": "需要管理员权限"})
			return
		}
		next(w, r)
	}
}

func requestContextFrom(ctx context.Context) *RequestContext {
	reqCtx, _ := ctx.Value(requestContextKey{}).(*RequestContext)
	return reqCtx
}

func isWebCookieAuth(reqCtx *RequestContext) bool {
	return reqCtx != nil && reqCtx.AuthSource == authSourceWebCookie
}

// allowedClients returns only the online upstream clients that the
// current user is permitted to access. Admin users see all online servers.
func (a *App) allowedClients(reqCtx *RequestContext) []*UpstreamClient {
	a.mu.RLock()
	defer a.mu.RUnlock()

	all := a.Upstream.OnlineClients()
	if reqCtx == nil || reqCtx.ProxyUser == nil {
		return nil
	}
	if reqCtx.ProxyUser.AllowedServers == nil {
		return all
	}
	allowed := make(map[int]bool, len(reqCtx.ProxyUser.AllowedServers))
	for _, idx := range reqCtx.ProxyUser.AllowedServers {
		allowed[idx] = true
	}
	filtered := make([]*UpstreamClient, 0, len(all))
	for _, c := range all {
		if allowed[c.ServerIndex] {
			filtered = append(filtered, c)
		}
	}
	return filtered
}

// isServerAllowed checks whether the current user is allowed to access the
// upstream server at the given index. Returns true for admin users (nil AllowedServers).
func (a *App) isServerAllowed(reqCtx *RequestContext, serverIndex int) bool {
	a.mu.RLock()
	defer a.mu.RUnlock()

	if reqCtx == nil || reqCtx.ProxyUser == nil {
		return false
	}
	if reqCtx.ProxyUser.AllowedServers == nil {
		return true
	}
	for _, idx := range reqCtx.ProxyUser.AllowedServers {
		if idx == serverIndex {
			return true
		}
	}
	return false
}

func extractToken(r *http.Request) string {
	token, _ := extractTokenWithSource(r)
	return token
}

func extractTokenWithSource(r *http.Request) (string, authTokenSource) {
	if token := r.Header.Get("X-Emby-Token"); token != "" {
		return token, authSourceHeader
	}
	if token := r.URL.Query().Get("api_key"); token != "" {
		return token, authSourceQuery
	}
	if token := r.URL.Query().Get("ApiKey"); token != "" {
		return token, authSourceQuery
	}
	if token := adminSessionToken(r); token != "" {
		return token, authSourceAdminCookie
	}
	if cookie, err := r.Cookie(webSessionCookieName); err == nil && cookie.Value != "" {
		return cookie.Value, authSourceWebCookie
	}
	for _, headerName := range []string{"X-Emby-Authorization", "Authorization"} {
		if auth := r.Header.Get(headerName); auth != "" {
			if token := extractTokenFromAuthHeader(auth); token != "" {
				return token, authSourceAuthorization
			}
		}
	}
	return "", authSourceNone
}

func extractTokenFromAuthHeader(header string) string {
	for _, marker := range []string{"Token=\"", "Token="} {
		idx := strings.Index(header, marker)
		if idx < 0 {
			continue
		}
		rest := header[idx+len(marker):]
		if marker == "Token=\"" {
			if end := strings.Index(rest, "\""); end >= 0 {
				return rest[:end]
			}
		}
		end := strings.IndexAny(rest, ", ")
		if end >= 0 {
			return rest[:end]
		}
		return rest
	}
	return ""
}
