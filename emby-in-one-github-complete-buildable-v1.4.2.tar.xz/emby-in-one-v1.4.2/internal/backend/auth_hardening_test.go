package backend

import (
	"net/http"
	"os"
	"path/filepath"
	"regexp"
	"runtime"
	"strconv"
	"strings"
	"testing"
	"time"
)

var hashedPasswordPattern = regexp.MustCompile(`(?i)^[0-9a-f]{32}:[0-9a-f]{128}$`)

func TestStartupHashesPlaintextPasswordBeforeFirstLogin(t *testing.T) {
	config := strings.Replace(parityConfigWithUpstreams(""), `password: "secret"`, `password: "plain-password"`, 1)
	dir := prepareTempWorkspace(t, config, nil)
	chdirForTest(t, dir)
	_, _ = newTestApp(t)

	raw, err := os.ReadFile(filepath.Join(dir, "config.yaml"))
	if err != nil {
		t.Fatalf("read config after startup: %v", err)
	}
	parsed, err := parseConfigYAML(string(raw))
	if err != nil {
		t.Fatalf("parse config after startup: %v", err)
	}
	if parsed.Admin.Password == "plain-password" {
		t.Fatalf("admin password remained plaintext after startup")
	}
	if !hashedPasswordPattern.MatchString(parsed.Admin.Password) {
		t.Fatalf("admin password = %q, want hashed salt:digest format", parsed.Admin.Password)
	}
}

func TestColonContainingPlaintextPasswordStillAuthenticates(t *testing.T) {
	config := strings.Replace(parityConfigWithUpstreams(""), `password: "secret"`, `password: "colon:plain"`, 1)
	withTempAppPrepared(t, config, nil, func(app *App, handler http.Handler, dir string) {
		token := loginToken(t, handler, "colon:plain")
		if token == "" {
			t.Fatalf("expected colon plaintext password login to succeed")
		}
	})
}

func TestTokenFileWrittenWith0600OnUnix(t *testing.T) {
	if runtime.GOOS == "windows" {
		t.Skip("POSIX file mode assertion is not reliable on Windows")
	}
	withTempAppPrepared(t, parityConfigWithUpstreams(""), nil, func(app *App, handler http.Handler, dir string) {
		_ = loginToken(t, handler, "secret")
		info, err := os.Stat(filepath.Join(dir, "data", "tokens.json"))
		if err != nil {
			t.Fatalf("stat tokens.json: %v", err)
		}
		if got := info.Mode().Perm(); got != 0o600 {
			t.Fatalf("tokens.json mode = %#o, want 0600", got)
		}
	})
}

func TestConfigSaveUsesAtomicReplace(t *testing.T) {
	if runtime.GOOS == "windows" {
		t.Skip("atomic replacement identity assertion is not reliable on Windows")
	}
	dir := prepareTempWorkspace(t, parityConfigWithUpstreams(""), nil)
	chdirForTest(t, dir)
	_, handler := newTestApp(t)
	configPath := filepath.Join(dir, "config.yaml")

	beforeInfo, err := os.Stat(configPath)
	if err != nil {
		t.Fatalf("stat before save: %v", err)
	}

	token := loginToken(t, handler, "secret")
	rr := doJSONRequest(t, handler, "PUT", "/admin/api/settings", map[string]any{"serverName": "Atomic Name"}, token)
	if rr.Code != 200 {
		t.Fatalf("settings update status = %d, body=%s", rr.Code, rr.Body.String())
	}

	afterInfo, err := os.Stat(configPath)
	if err != nil {
		t.Fatalf("stat after save: %v", err)
	}
	if os.SameFile(beforeInfo, afterInfo) {
		t.Fatalf("config file identity did not change; expected atomic replace")
	}

	raw, err := os.ReadFile(configPath)
	if err != nil {
		t.Fatalf("read config after save: %v", err)
	}
	if !strings.Contains(string(raw), `name: "Atomic Name"`) {
		t.Fatalf("updated config missing server name: %s", string(raw))
	}
}

func TestIsPrivateOrReservedIP(t *testing.T) {
	for _, ip := range []string{"127.0.0.1", "10.0.0.1", "192.168.1.1", "172.16.0.1", "169.254.169.254", "0.0.0.0", "::1"} {
		if !isPrivateOrReservedIP(ip) {
			t.Errorf("expected %s to be private/reserved", ip)
		}
	}
}

func TestProxyTestSSRFBlocksPrivateIP(t *testing.T) {
	withTempAppPrepared(t, parityConfigWithUpstreams(""), nil, func(app *App, handler http.Handler, dir string) {
		token := loginToken(t, handler, "secret")
		rr := doJSONRequest(t, handler, "POST", "/admin/api/proxies/test", map[string]any{
			"proxyUrl":  "http://1.2.3.4:8080",
			"targetUrl": "http://169.254.169.254/latest/meta-data/",
		}, token)
		if rr.Code != 400 {
			t.Fatalf("expected 400 for private target, got %d: %s", rr.Code, rr.Body.String())
		}
		if !strings.Contains(rr.Body.String(), "private or reserved") {
			t.Fatalf("expected private/reserved error, got: %s", rr.Body.String())
		}
	})
}

func TestLoginRateLimiterMaxCapacity(t *testing.T) {
	limiter := &loginRateLimiter{}
	for i := 0; i < loginMaxTrackedIPs; i++ {
		if !limiter.checkAndRecord("ip-" + strconv.Itoa(i)) {
			t.Fatalf("expected checkAndRecord to succeed for ip-%d", i)
		}
	}
	// Next unique IP should be rejected
	if limiter.checkAndRecord("ip-overflow") {
		t.Fatal("expected checkAndRecord to reject new IP when at capacity")
	}
	// Existing IP should still work
	if !limiter.checkAndRecord("ip-0") {
		t.Fatal("expected checkAndRecord to allow existing IP")
	}
}

func TestValidateTokenRejectsExpired(t *testing.T) {
	withTempApp(t, func(app *App, handler http.Handler) {
		user, err := app.UserStore.Create("expired-user", "pw", []int{0})
		if err != nil {
			t.Fatalf("create user: %v", err)
		}
		_, token, err := app.Auth.AuthenticateUser(user)
		if err != nil {
			t.Fatalf("AuthenticateUser: %v", err)
		}
		if app.Auth.ValidateToken(token) == nil {
			t.Fatalf("token should be valid right after creation")
		}

		app.Auth.mu.Lock()
		info := app.Auth.tokens[token]
		info.ExpiresAt = time.Now().Add(-time.Minute).UnixMilli()
		app.Auth.tokens[token] = info
		app.Auth.mu.Unlock()

		if app.Auth.ValidateToken(token) != nil {
			t.Fatalf("expired token must be rejected")
		}
	})
}

func TestValidateTokenAcceptsLegacyZeroExpiresAt(t *testing.T) {
	withTempApp(t, func(app *App, handler http.Handler) {
		now := time.Now().UnixMilli()
		app.Auth.mu.Lock()
		app.Auth.tokens["legacy-token"] = tokenInfo{
			UserID:    "legacy-user",
			Username:  "legacy-user",
			Role:      "user",
			CreatedAt: now,
		}
		app.Auth.mu.Unlock()

		if app.Auth.ValidateToken("legacy-token") == nil {
			t.Fatalf("legacy token with zero ExpiresAt must remain valid")
		}
	})
}

func TestPruneExpiredTokensRemovesExpiredOnly(t *testing.T) {
	withTempApp(t, func(app *App, handler http.Handler) {
		now := time.Now().UnixMilli()
		app.Auth.mu.Lock()
		app.Auth.tokens["t-fresh"] = tokenInfo{
			UserID:    "u1",
			Username:  "fresh",
			Role:      "user",
			CreatedAt: now,
			ExpiresAt: now + 60_000,
		}
		app.Auth.tokens["t-stale"] = tokenInfo{
			UserID:    "u2",
			Username:  "stale",
			Role:      "user",
			CreatedAt: now - 120_000,
			ExpiresAt: now - 60_000,
		}
		app.Auth.tokens["t-legacy"] = tokenInfo{
			UserID:    "u3",
			Username:  "legacy",
			Role:      "user",
			CreatedAt: now - 999_999,
		}
		app.Auth.mu.Unlock()

		removed := app.Auth.PruneExpiredTokens()
		if removed != 1 {
			t.Fatalf("removed = %d, want 1", removed)
		}

		app.Auth.mu.RLock()
		_, freshExists := app.Auth.tokens["t-fresh"]
		_, staleExists := app.Auth.tokens["t-stale"]
		_, legacyExists := app.Auth.tokens["t-legacy"]
		app.Auth.mu.RUnlock()

		if !freshExists || staleExists || !legacyExists {
			t.Fatalf("post-prune state wrong: fresh=%v stale=%v legacy=%v", freshExists, staleExists, legacyExists)
		}
	})
}

func TestRunMaintenanceTickPrunesExpiredTokens(t *testing.T) {
	withTempApp(t, func(app *App, handler http.Handler) {
		now := time.Now().UnixMilli()
		app.Auth.mu.Lock()
		app.Auth.tokens["tick-stale"] = tokenInfo{
			UserID:    "u4",
			Username:  "tick-stale",
			Role:      "user",
			CreatedAt: now - 120_000,
			ExpiresAt: now - 60_000,
		}
		app.Auth.mu.Unlock()

		app.runMaintenanceTick()

		app.Auth.mu.RLock()
		_, exists := app.Auth.tokens["tick-stale"]
		app.Auth.mu.RUnlock()
		if exists {
			t.Fatalf("maintenance tick should prune expired tokens")
		}
	})
}

func TestTokenReloadRestoresEmptyAllowedServersSlice(t *testing.T) {
	withTempApp(t, func(app *App, handler http.Handler) {
		// 1. 创建一个 AllowedServers 为空切片 []int{} 的普通用户
		user, err := app.UserStore.Create("test-restricted-user", "password123", []int{})
		if err != nil {
			t.Fatalf("Failed to create restricted user: %v", err)
		}
		
		// 2. 认证用户生成 Token，在内存中其 AllowedServers 应为非 nil 的空切片 []int{}
		_, token, err := app.Auth.AuthenticateUser(user)
		if err != nil {
			t.Fatalf("Failed to authenticate user: %v", err)
		}
		
		// 3. 强制持久化保存到磁盘上的 tokens.json，随后清空内存中加载的 tokens
		if err := app.Auth.save(); err != nil {
			t.Fatalf("Failed to save tokens: %v", err)
		}
		
		app.Auth.mu.Lock()
		delete(app.Auth.tokens, token)
		app.Auth.mu.Unlock()
		
		// 4. 从磁盘重新加载，触发反序列化。如果 omitempty 逻辑生效，且没有防线纠正，
		// 反序列化出来的 AllowedServers 会是 nil 零值
		if err := app.Auth.load(); err != nil {
			t.Fatalf("Failed to reload tokens: %v", err)
		}
		
		reloadedToken := app.Auth.ValidateToken(token)
		if reloadedToken == nil {
			t.Fatalf("Reloaded token not found")
		}
		
		// 5. 断言：防线 1 + 2 应强制让重载后的普通用户的 AllowedServers 保持为非 nil 的 []int{}
		if reloadedToken.AllowedServers == nil {
			t.Errorf("FAIL: reloaded token has nil AllowedServers slice! (Reboot escalation path open)")
		}
		
		// 6. 验证鉴权层是否完美拦截，其允许访问的上游客户端数量必须为 0 
		reqCtx := &RequestContext{
			ProxyUser: reloadedToken,
		}
		allowed := app.allowedClients(reqCtx)
		if len(allowed) != 0 {
			t.Errorf("FAIL: User with no allowed servers can access %d upstreams! (Privilege Escalation)", len(allowed))
		}
	})
}

