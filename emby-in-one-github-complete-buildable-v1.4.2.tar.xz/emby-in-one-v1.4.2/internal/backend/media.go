package backend

import (
	"net/http"
	"net/url"
)

type routeResolution struct {
	OriginalID     string
	ServerIndex    int
	Client         *UpstreamClient
	OtherInstances []AdditionalInstance
}

type upstreamItemsResult struct {
	ServerIndex int
	Items       []map[string]any
}

func (a *App) registerMediaRoutes(mux *http.ServeMux) {
	mux.HandleFunc("GET /Users/{userId}/Items", a.withContext(a.requireAuth(a.handleUserItems)))
	mux.HandleFunc("GET /Items", a.withContext(a.requireAuth(a.handleItemsCollection)))
	mux.HandleFunc("GET /Users/{userId}/Items/Resume", a.withContext(a.requireAuth(a.handleUserItemsResume)))
	mux.HandleFunc("GET /Users/{userId}/Items/Latest", a.withContext(a.requireAuth(a.handleUserItemsLatest)))
	mux.HandleFunc("GET /Users/{userId}/Items/{itemId}", a.withContext(a.requireAuth(a.handleUserItemByID)))
	mux.HandleFunc("GET /Items/{itemId}", a.withContext(a.requireAuth(a.handleItemByID)))
	mux.HandleFunc("GET /Items/{itemId}/Similar", a.withContext(a.requireAuth(a.handleItemSimilar)))
	mux.HandleFunc("GET /Items/{itemId}/ThemeMedia", a.withContext(a.requireAuth(a.handleItemThemeMedia)))
	mux.HandleFunc("GET /Shows/NextUp", a.withContext(a.requireAuth(a.handleShowsNextUp)))
	mux.HandleFunc("GET /Items/{itemId}/PlaybackInfo", a.withContext(a.requireAuth(a.handlePlaybackInfo)))
	mux.HandleFunc("POST /Items/{itemId}/PlaybackInfo", a.withContext(a.requireAuth(a.handlePlaybackInfo)))
	mux.HandleFunc("GET /Videos/{itemId}/{rest...}", a.withContext(a.requireAuth(a.handleVideoProxy)))
	mux.HandleFunc("GET /Audio/{itemId}/{rest...}", a.withContext(a.requireAuth(a.handleAudioProxy)))
	mux.HandleFunc("DELETE /Videos/ActiveEncodings", a.withContext(a.requireAuth(a.handleDeleteActiveEncodings)))
}

func (a *App) resolveRouteID(id string) *routeResolution {
	a.mu.RLock()
	defer a.mu.RUnlock()

	resolved := a.IDStore.ResolveVirtualID(id)
	if resolved == nil {
		return nil
	}
	return a.selectRouteResolutionForRequest(nil, resolved)
}

func (a *App) resolveRouteIDForRequest(reqCtx *RequestContext, id string) *routeResolution {
	a.mu.RLock()
	defer a.mu.RUnlock()

	if reqCtx == nil || reqCtx.ProxyUser == nil {
		return nil
	}
	resolved := a.IDStore.ResolveVirtualID(id)
	if resolved == nil {
		return nil
	}
	return a.selectRouteResolutionForRequest(reqCtx, resolved)
}

func (a *App) selectRouteResolutionForRequest(reqCtx *RequestContext, resolved *ResolvedID) *routeResolution {
	if resolved == nil {
		return nil
	}
	type candidate struct {
		originalID  string
		serverIndex int
	}
	candidates := []candidate{{originalID: resolved.OriginalID, serverIndex: resolved.ServerIndex}}
	for _, other := range resolved.OtherInstances {
		candidates = append(candidates, candidate{originalID: other.OriginalID, serverIndex: other.ServerIndex})
	}

	for i, current := range candidates {
		if reqCtx != nil && !a.isServerAllowed(reqCtx, current.serverIndex) {
			continue
		}
		client := a.Upstream.GetClient(current.serverIndex)
		if client == nil || !client.IsOnline() {
			continue
		}
		remaining := make([]AdditionalInstance, 0, len(candidates)-1)
		for j, other := range candidates {
			if j == i {
				continue
			}
			if reqCtx != nil && !a.isServerAllowed(reqCtx, other.serverIndex) {
				continue
			}
			otherClient := a.Upstream.GetClient(other.serverIndex)
			if otherClient == nil || !otherClient.IsOnline() {
				continue
			}
			remaining = append(remaining, AdditionalInstance{OriginalID: other.originalID, ServerIndex: other.serverIndex})
		}
		return &routeResolution{
			OriginalID:     current.originalID,
			ServerIndex:    current.serverIndex,
			Client:         client,
			OtherInstances: remaining,
		}
	}
	return nil
}

func cloneValues(values url.Values) url.Values {
	cloned := url.Values{}
	for key, rawValues := range values {
		cloned[key] = append([]string(nil), rawValues...)
	}
	return cloned
}

func asItems(payload any) []map[string]any {
	switch typed := payload.(type) {
	case []any:
		items := make([]map[string]any, 0, len(typed))
		for _, raw := range typed {
			if item, ok := raw.(map[string]any); ok {
				items = append(items, item)
			}
		}
		return items
	case map[string]any:
		if rawItems, ok := typed["Items"]; ok {
			return asItems(rawItems)
		}
		if rawItems, ok := typed["items"]; ok {
			return asItems(rawItems)
		}
	}
	return []map[string]any{}
}

func (a *App) rewriteItems(items []map[string]any, serverIndex int) []map[string]any {
	cfg := a.ConfigStore.Snapshot()
	for _, item := range items {
		rewriteResponseIDs(item, serverIndex, a.IDStore, cfg.Server.ID, a.Auth.ProxyUserID())
	}
	return items
}
