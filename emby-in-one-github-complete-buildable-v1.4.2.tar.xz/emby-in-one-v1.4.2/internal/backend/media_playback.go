package backend

import (
	"context"
	"encoding/json"
	"net/http"
	"net/url"
	"strings"
)

type playbackSourceSelection struct {
	VirtualMediaSourceID  string
	OriginalMediaSourceID string
	OriginalItemID        string
	ServerIndex           int
	OriginalPlaySessionID string
	ProxyPlaySessionID    string
	ResponseBase          map[string]any
}

type playbackInfoIntent uint8

const (
	playbackInfoIntentProbe playbackInfoIntent = iota + 1
	playbackInfoIntentStart
)

type playbackInfoIntentContextKey struct{}

func withPlaybackInfoIntent(r *http.Request, intent playbackInfoIntent) *http.Request {
	if r == nil {
		return nil
	}
	ctx := context.WithValue(r.Context(), playbackInfoIntentContextKey{}, intent)
	return r.WithContext(ctx)
}

func playbackInfoStartsPlayback(r *http.Request) bool {
	if r == nil {
		return false
	}
	switch intent, _ := r.Context().Value(playbackInfoIntentContextKey{}).(playbackInfoIntent); intent {
	case playbackInfoIntentStart:
		return true
	case playbackInfoIntentProbe:
		return false
	default:
		// Native Emby clients normally POST the actual playback handshake while
		// GET is also used for passive capability/track inspection.
		return r.Method == http.MethodPost
	}
}

func (a *App) handlePlaybackInfo(w http.ResponseWriter, r *http.Request) {
	reqCtx := requestContextFrom(r.Context())
	resolved := a.resolveRouteIDForRequest(reqCtx, r.PathValue("itemId"))
	if resolved == nil {
		if a.Logger != nil {
			a.Logger.Warnf("PlaybackInfo: itemId=%s not found in mappings", r.PathValue("itemId"))
		}
		writeJSON(w, http.StatusNotFound, map[string]any{"message": "Item not found"})
		return
	}
	instances := a.collectItemInstances(resolved)
	if a.Logger != nil {
		a.Logger.Debugf("PlaybackInfo: itemId=%s → server=[%s] originalId=%s, instances=%d",
			r.PathValue("itemId"), resolved.Client.Name, resolved.OriginalID, len(instances))
	}
	query := cloneValues(r.URL.Query())
	body := map[string]any{}
	selectedServerIndex := resolved.ServerIndex
	selectedVirtualMediaSourceID := ""
	selectedMediaSourceID := ""
	if r.Method == http.MethodPost && r.Body != nil {
		_ = json.NewDecoder(r.Body).Decode(&body)
	}
	if mediaSourceID, ok := body["MediaSourceId"].(string); ok {
		selectedVirtualMediaSourceID = mediaSourceID
		if msResolved := a.IDStore.ResolveVirtualID(mediaSourceID); msResolved != nil {
			body["MediaSourceId"] = msResolved.OriginalID
			selectedServerIndex = msResolved.ServerIndex
			selectedMediaSourceID = msResolved.OriginalID
		}
	}
	if mediaSourceID := query.Get("MediaSourceId"); mediaSourceID != "" {
		selectedVirtualMediaSourceID = mediaSourceID
		if msResolved := a.IDStore.ResolveVirtualID(mediaSourceID); msResolved != nil {
			query.Set("MediaSourceId", msResolved.OriginalID)
			selectedServerIndex = msResolved.ServerIndex
			selectedMediaSourceID = msResolved.OriginalID
		}
	}
	query.Del("api_key")
	query.Del("ApiKey")

	var base map[string]any
	baseServerIndex := resolved.ServerIndex
	allMediaSources := []map[string]any{}
	var firstCandidate *playbackSourceSelection
	var preferredServerCandidate *playbackSourceSelection
	var selectedCandidate *playbackSourceSelection
	for _, inst := range instances {
		instanceQuery := cloneValues(query)
		instanceBody := deepCloneMap(body)
		if selectedVirtualMediaSourceID != "" && inst.ServerIndex != selectedServerIndex {
			removePlaybackSelection(instanceQuery, instanceBody)
		}
		payload, err := inst.Client.RequestJSON(r.Context(), reqCtx, a.Identity, r.Method, "/Items/"+inst.OriginalID+"/PlaybackInfo", instanceQuery, instanceBody)
		if err != nil {
			if a.Logger != nil {
				a.Logger.Warnf("PlaybackInfo: server=[%s] originalId=%s failed: %v", inst.Client.Name, inst.OriginalID, err)
			}
			continue
		}
		data, ok := payload.(map[string]any)
		if !ok {
			continue
		}
		if base == nil {
			base = deepCloneMap(data)
			baseServerIndex = inst.ServerIndex
		}
		originalPlaySessionID := webString(data["PlaySessionId"])
		proxyPlaySessionID := ""
		if originalPlaySessionID != "" {
			proxyPlaySessionID = a.IDStore.GetOrCreateVirtualID(originalPlaySessionID, inst.ServerIndex)
		}
		for _, raw := range asItems(map[string]any{"Items": data["MediaSources"]}) {
			originalMediaSourceID := webString(raw["Id"])
			mediaSource := normalizePlaybackMediaSource(a, reqCtx, playbackItemInstance{
				OriginalID:  inst.OriginalID,
				ServerIndex: inst.ServerIndex,
				Client:      inst.Client,
			}, r.PathValue("itemId"), deepCloneMap(raw), proxyPlaySessionID)
			candidate := playbackSourceSelection{
				VirtualMediaSourceID:  webString(mediaSource["Id"]),
				OriginalMediaSourceID: originalMediaSourceID,
				OriginalItemID:        inst.OriginalID,
				ServerIndex:           inst.ServerIndex,
				OriginalPlaySessionID: originalPlaySessionID,
				ProxyPlaySessionID:    proxyPlaySessionID,
				ResponseBase:          data,
			}
			if firstCandidate == nil {
				candidateCopy := candidate
				firstCandidate = &candidateCopy
			}
			if preferredServerCandidate == nil && inst.ServerIndex == selectedServerIndex {
				candidateCopy := candidate
				preferredServerCandidate = &candidateCopy
			}
			if selectedVirtualMediaSourceID != "" && (candidate.VirtualMediaSourceID == selectedVirtualMediaSourceID || candidate.OriginalMediaSourceID == selectedVirtualMediaSourceID) {
				candidateCopy := candidate
				selectedCandidate = &candidateCopy
			}
			allMediaSources = append(allMediaSources, mediaSource)
		}
	}
	if base == nil {
		if a.Logger != nil {
			a.Logger.Errorf("PlaybackInfo: all upstream requests failed for itemId=%s", r.PathValue("itemId"))
		}
		writeJSON(w, http.StatusBadGateway, map[string]any{"message": "Failed to fetch playback info from upstream"})
		return
	}
	chosenCandidate := selectedCandidate
	if chosenCandidate == nil {
		if preferredServerCandidate != nil {
			chosenCandidate = preferredServerCandidate
		} else {
			chosenCandidate = firstCandidate
		}
	}
	selectedOriginalPlaySessionID := ""
	selectedProxyPlaySessionID := ""
	selectedOriginalItemID := resolved.OriginalID
	if chosenCandidate != nil {
		selectedServerIndex = chosenCandidate.ServerIndex
		selectedOriginalItemID = chosenCandidate.OriginalItemID
		if chosenCandidate.OriginalMediaSourceID != "" {
			selectedMediaSourceID = chosenCandidate.OriginalMediaSourceID
		}
		selectedOriginalPlaySessionID = chosenCandidate.OriginalPlaySessionID
		selectedProxyPlaySessionID = chosenCandidate.ProxyPlaySessionID
		base = deepCloneMap(chosenCandidate.ResponseBase)
		baseServerIndex = chosenCandidate.ServerIndex
	}
	startsPlayback := playbackInfoStartsPlayback(r)
	if startsPlayback && reqCtx != nil && reqCtx.ProxyUser != nil && reqCtx.ProxyUser.Role != "admin" && a.PlaybackLimiter != nil {
		cfg := a.ConfigStore.Snapshot()
		if selectedServerIndex >= 0 && selectedServerIndex < len(cfg.Upstream) {
			maxConcurrent := cfg.Upstream[selectedServerIndex].MaxConcurrent
			if maxConcurrent > 0 && selectedOriginalPlaySessionID == "" {
				writeJSON(w, http.StatusBadGateway, map[string]any{"message": "Playback session unavailable"})
				return
			}
			playbackID := playbackRegistrationID(reqCtx.ProxyUser.UserID, selectedOriginalPlaySessionID, selectedOriginalItemID, selectedMediaSourceID)
			if !a.PlaybackLimiter.TryStart(reqCtx.ProxyUser.UserID, selectedServerIndex, playbackID, maxConcurrent) {
				writeJSON(w, http.StatusTooManyRequests, map[string]any{"message": "已达到最大同时播放数限制"})
				return
			}
		}
	}
	if startsPlayback && len(allMediaSources) > 0 {
		if virtualItemID := r.PathValue("itemId"); virtualItemID != "" {
			a.IDStore.SetActiveStream(virtualItemID, selectedServerIndex)
		}
	}
	if a.Logger != nil {
		selectedServerName := ""
		if client := a.Upstream.GetClient(selectedServerIndex); client != nil {
			selectedServerName = client.Name
		}
		a.Logger.Infof("PlaybackInfo selection: itemId=%s requestedMediaSourceId=%s selectedServer=[%s] selectedMediaSourceId=%s selectedSessionPresent=%t mediaSources=%d",
			r.PathValue("itemId"),
			selectedVirtualMediaSourceID,
			selectedServerName,
			selectedMediaSourceID,
			selectedOriginalPlaySessionID != "",
			len(allMediaSources),
		)
	}
	if a.Logger != nil {
		a.Logger.Debugf("PlaybackInfo: returning %d MediaSources for itemId=%s", len(allMediaSources), r.PathValue("itemId"))
	}
	cfg := a.ConfigStore.Snapshot()
	delete(base, "MediaSources")
	rewriteResponseIDs(base, baseServerIndex, a.IDStore, cfg.Server.ID, a.Auth.ProxyUserID())
	base["MediaSources"] = make([]any, 0, len(allMediaSources))
	for _, mediaSource := range allMediaSources {
		base["MediaSources"] = append(base["MediaSources"].([]any), mediaSource)
	}
	delete(base, "PlaySessionId")
	if selectedProxyPlaySessionID != "" {
		base["PlaySessionId"] = selectedProxyPlaySessionID
	}
	if chosenCandidate != nil && chosenCandidate.VirtualMediaSourceID != "" {
		base["SelectedMediaSourceId"] = chosenCandidate.VirtualMediaSourceID
	}
	logPlaybackInfoResponse(a, r.PathValue("itemId"), base)
	writeJSON(w, http.StatusOK, base)
}

func logPlaybackInfoResponse(a *App, itemID string, payload map[string]any) {
	if a == nil || a.Logger == nil {
		return
	}
	body, err := json.Marshal(redactPlaybackInfoLogValue(payload))
	if err != nil {
		a.Logger.Debugf("PlaybackInfo response: itemId=%s body=<marshal error: %v>", itemID, err)
		return
	}
	a.Logger.Debugf("PlaybackInfo response: itemId=%s body=%s", itemID, string(body))
}

func redactPlaybackInfoLogValue(value any) any {
	switch typed := value.(type) {
	case map[string]any:
		cloned := make(map[string]any, len(typed))
		for key, nested := range typed {
			if isPlaybackInfoSecretKey(key) {
				cloned[key] = "[redacted]"
				continue
			}
			cloned[key] = redactPlaybackInfoLogValue(nested)
		}
		return cloned
	case []any:
		cloned := make([]any, 0, len(typed))
		for _, nested := range typed {
			cloned = append(cloned, redactPlaybackInfoLogValue(nested))
		}
		return cloned
	case string:
		return redactPlaybackInfoLogString(typed)
	default:
		return value
	}
}

func isPlaybackInfoSecretKey(key string) bool {
	switch strings.ToLower(key) {
	case "api_key", "apikey", "access_token", "accesstoken", "x-emby-token":
		return true
	default:
		return false
	}
}

func redactPlaybackInfoLogString(value string) string {
	parsed, err := url.Parse(value)
	if err != nil || parsed.RawQuery == "" {
		return value
	}
	query := parsed.Query()
	changed := false
	for key := range query {
		if !isPlaybackInfoSecretKey(key) {
			continue
		}
		query.Set(key, "[redacted]")
		changed = true
	}
	if !changed {
		return value
	}
	parsed.RawQuery = query.Encode()
	return parsed.String()
}

func firstMapItem(value any) map[string]any {
	items := asItems(map[string]any{"Items": value})
	if len(items) == 0 {
		return nil
	}
	return items[0]
}

func deepCloneMap(source map[string]any) map[string]any {
	encoded, _ := json.Marshal(source)
	var decoded map[string]any
	_ = json.Unmarshal(encoded, &decoded)
	if decoded == nil {
		decoded = map[string]any{}
	}
	return decoded
}

func removePlaybackSelection(query url.Values, body map[string]any) {
	for _, key := range []string{"MediaSourceId", "AudioStreamIndex", "SubtitleStreamIndex"} {
		query.Del(key)
		query.Del(strings.ToLower(key[:1]) + key[1:])
		delete(body, key)
		delete(body, strings.ToLower(key[:1])+key[1:])
	}
}

func resolveMediaSourceInPath(rest string, idStore *IDStore) string {
	slash := strings.IndexByte(rest, '/')
	if slash <= 0 {
		return rest
	}
	firstSeg := rest[:slash]
	after := rest[slash:]
	if !strings.HasPrefix(after, "/Subtitles/") && !strings.HasPrefix(after, "/Attachments/") {
		return rest
	}
	if resolved := idStore.ResolveVirtualID(firstSeg); resolved != nil {
		return resolved.OriginalID + after
	}
	return rest
}
