package backend

import (
	"context"
	"errors"
	"io"
	"net/http"
	"net/url"
	"strings"
)

var errInvalidHLSManifestResponse = errors.New("invalid HLS manifest response")

func translateProxyStreamPlaySessionQuery(query url.Values, idStore *IDStore) {
	if playSessionID := query.Get("PlaySessionId"); playSessionID != "" {
		if psResolved := idStore.ResolveVirtualID(playSessionID); psResolved != nil {
			query.Set("PlaySessionId", psResolved.OriginalID)
		}
	}
}

func applyUpstreamStreamAuth(query url.Values, client *UpstreamClient) {
	query.Del("api_key")
	query.Del("ApiKey")
	if token := client.getAccessToken(); token != "" {
		query.Set("api_key", token)
	}
}

func buildProxyStreamHeaders(r *http.Request) http.Header {
	streamHeaders := http.Header{}
	for _, h := range []string{"Range", "Accept", "Accept-Encoding", "Accept-Language"} {
		if v := r.Header.Get(h); v != "" {
			streamHeaders.Set(h, v)
		}
	}
	return streamHeaders
}

func copyProxyStreamHeaders(dst, src http.Header) {
	for _, header := range []string{
		"Content-Type", "Content-Length", "Content-Range", "Accept-Ranges",
		"Cache-Control", "ETag", "Last-Modified", "Transfer-Encoding",
		"Content-Disposition", "Content-Encoding", "Date", "Server",
	} {
		if value := src.Get(header); value != "" {
			if strings.EqualFold(header, "Transfer-Encoding") && strings.Contains(strings.ToLower(value), "chunked") {
				continue
			}
			dst.Set(header, value)
		}
	}
}

func shouldLogProxyCopyDiagnostics(rest string) bool {
	lowerRest := strings.ToLower(rest)
	switch {
	case strings.Contains(lowerRest, "/subtitles/"):
		return true
	case strings.HasSuffix(lowerRest, ".m3u8"):
		return true
	case strings.HasPrefix(lowerRest, "stream."):
		return true
	case strings.Contains(lowerRest, "/stream."):
		return true
	case strings.HasPrefix(lowerRest, "universal"):
		return true
	case strings.Contains(lowerRest, "/universal"):
		return true
	default:
		return false
	}
}

func (a *App) logProxyCopyResult(label, virtualItemID, requestRest string, status int, copied int64, copyErr error) {
	if a.Logger == nil {
		return
	}
	if copyErr != nil {
		if errors.Is(copyErr, context.Canceled) {
			a.Logger.Debugf("%s proxy copy canceled: itemId=%s path=%s status=%d bytes=%d", label, virtualItemID, requestRest, status, copied)
			return
		}
		a.Logger.Warnf("%s proxy copy error: itemId=%s path=%s status=%d bytes=%d err=%v", label, virtualItemID, requestRest, status, copied, copyErr)
		return
	}
	if shouldLogProxyCopyDiagnostics(requestRest) {
		a.Logger.Debugf("%s proxy copy complete: itemId=%s path=%s status=%d bytes=%d", label, virtualItemID, requestRest, status, copied)
	}
}

func (a *App) tryRegisterProxyPlayback(w http.ResponseWriter, r *http.Request, serverIndex int, originalItemID, rest string, query url.Values) bool {
	reqCtx := requestContextFrom(r.Context())
	if reqCtx == nil || reqCtx.ProxyUser == nil || reqCtx.ProxyUser.Role == "admin" || a.PlaybackLimiter == nil {
		return true
	}
	if !shouldTrackPlaybackProxyRequest(rest) {
		return true
	}
	cfg := a.ConfigStore.Snapshot()
	if serverIndex < 0 || serverIndex >= len(cfg.Upstream) {
		return true
	}
	maxConcurrent := cfg.Upstream[serverIndex].MaxConcurrent
	playbackID := playbackRegistrationIDFromQuery(reqCtx.ProxyUser.UserID, originalItemID, query)
	if maxConcurrent > 0 && playbackID == "" {
		writeJSON(w, http.StatusBadRequest, map[string]any{"message": "PlaySessionId is required"})
		return false
	}
	if !a.PlaybackLimiter.TryStart(reqCtx.ProxyUser.UserID, serverIndex, playbackID, maxConcurrent) {
		writeJSON(w, http.StatusTooManyRequests, map[string]any{"message": "已达到最大同时播放数限制"})
		return false
	}
	return true
}

func (a *App) resolveProxyMediaSourceTarget(w http.ResponseWriter, r *http.Request, virtualItemID string, resolved *routeResolution, query url.Values, logLabel string) (*UpstreamClient, string, bool) {
	actualClient := resolved.Client
	actualOriginalID := resolved.OriginalID
	virtualMediaSourceID := query.Get("MediaSourceId")
	if virtualMediaSourceID == "" {
		return actualClient, actualOriginalID, true
	}
	msResolved := a.IDStore.ResolveVirtualID(virtualMediaSourceID)
	if msResolved == nil {
		if a.Logger != nil {
			a.Logger.Warnf("%s: MediaSourceId %s cannot be resolved to any server", logLabel, virtualMediaSourceID)
		}
		return actualClient, actualOriginalID, true
	}
	query.Set("MediaSourceId", msResolved.OriginalID)
	if msResolved.ServerIndex == resolved.ServerIndex {
		return actualClient, actualOriginalID, true
	}
	if !a.isServerAllowed(requestContextFrom(r.Context()), msResolved.ServerIndex) {
		writeJSON(w, http.StatusForbidden, map[string]any{"message": "Access denied"})
		return nil, "", false
	}
	client := a.Upstream.GetClient(msResolved.ServerIndex)
	if client == nil || !client.IsOnline() {
		writeJSON(w, http.StatusBadGateway, map[string]any{"message": "Target media source server is unavailable"})
		return nil, "", false
	}
	if a.Logger != nil {
		a.Logger.Infof("%s: switching to server [%s] for MediaSourceId %s", logLabel, client.Name, virtualMediaSourceID)
	}
	actualClient = client
	for _, other := range resolved.OtherInstances {
		if other.ServerIndex == msResolved.ServerIndex {
			actualOriginalID = other.OriginalID
			break
		}
	}
	return actualClient, actualOriginalID, true
}

func buildRegisteredPlaybackStreamRequest(targetURL string, client *UpstreamClient) (string, string, url.Values, bool) {
	if client == nil || targetURL == "" {
		return "", "", nil, false
	}
	parsed, err := url.Parse(targetURL)
	if err != nil || !parsed.IsAbs() {
		return "", "", nil, false
	}
	query := parsed.Query()
	applyUpstreamStreamAuth(query, client)
	parsed.RawQuery = query.Encode()
	return parsed.String(), parsed.Path, query, true
}

func tryFallbackRegisteredPlaybackTarget(client *UpstreamClient, target MediaSourceProxyTarget) (MediaSourceProxyTarget, string, bool) {
	if client == nil {
		return target, "", false
	}
	nextURL, ok := client.nextAbsoluteStreamURL(target.UpstreamURL)
	if !ok {
		return target, "", false
	}
	target.UpstreamURL = nextURL
	return target, nextURL, true
}

func isBrowserSubtitleVTTRequest(rest string) bool {
	lowerRest := strings.ToLower(rest)
	return strings.Contains(lowerRest, "/subtitles/") && strings.HasSuffix(lowerRest, ".vtt")
}

func replaceSubtitleExtension(value, fromExt, toExt string) string {
	parsed, err := url.Parse(value)
	if err != nil {
		return value
	}
	lowerPath := strings.ToLower(parsed.Path)
	lowerFromExt := strings.ToLower(fromExt)
	if !strings.HasSuffix(lowerPath, lowerFromExt) {
		return value
	}
	parsed.Path = parsed.Path[:len(parsed.Path)-len(fromExt)] + toExt
	return parsed.String()
}

func convertSRTBodyToVTT(body []byte) []byte {
	text := strings.ReplaceAll(string(body), "\r\n", "\n")
	text = strings.TrimPrefix(text, "\ufeff")
	trimmed := strings.TrimSpace(text)
	if strings.HasPrefix(trimmed, "WEBVTT") {
		return []byte(text)
	}
	lines := strings.Split(text, "\n")
	for i, line := range lines {
		if strings.Contains(line, "-->") {
			lines[i] = strings.ReplaceAll(line, ",", ".")
		}
	}
	return []byte("WEBVTT\n\n" + strings.Join(lines, "\n"))
}

func isM3U8Path(rest string) bool {
	return strings.HasSuffix(strings.ToLower(rest), ".m3u8")
}

func isDirectProxyStreamPath(rest string) bool {
	lowerRest := strings.ToLower(rest)
	return strings.HasPrefix(lowerRest, "stream.") || strings.Contains(lowerRest, "/stream.")
}

func isM3U8ContentType(contentType string) bool {
	return strings.Contains(strings.ToLower(contentType), "mpegurl")
}

func looksLikeM3U8Manifest(body []byte) bool {
	text := strings.TrimSpace(strings.TrimPrefix(string(body), "\ufeff"))
	return strings.HasPrefix(text, "#EXTM3U")
}

func readProxyM3U8Body(resp *http.Response, rest string) ([]byte, error) {
	if isM3U8ContentType(resp.Header.Get("Content-Type")) {
		return io.ReadAll(resp.Body)
	}
	if !isM3U8Path(rest) {
		return nil, errInvalidHLSManifestResponse
	}
	// Read a small prefix first so bogus large bodies on *.m3u8 paths do not
	// get buffered into memory before we know they are actual manifests.
	prefix, err := io.ReadAll(io.LimitReader(resp.Body, 4096))
	if err != nil {
		return nil, err
	}
	if !looksLikeM3U8Manifest(prefix) {
		return nil, errInvalidHLSManifestResponse
	}
	tail, err := io.ReadAll(resp.Body)
	if err != nil {
		return nil, err
	}
	return append(prefix, tail...), nil
}

func writeInvalidHLSManifestResponse(w http.ResponseWriter) {
	writeJSON(w, http.StatusBadGateway, map[string]any{"message": "Invalid HLS manifest response"})
}

func trySubtitleSRTFallback(a *App, r *http.Request, client *UpstreamClient, upstreamRequestURL, upstreamPath string, query url.Values, streamHeaders http.Header) (*http.Response, error, string, string) {
	if client == nil {
		return nil, nil, "", ""
	}
	if upstreamRequestURL != "" {
		srtURL := replaceSubtitleExtension(upstreamRequestURL, ".vtt", ".srt")
		if srtURL == upstreamRequestURL {
			return nil, nil, "", ""
		}
		resp, err := client.StreamAbsolute(r.Context(), requestContextFrom(r.Context()), a.Identity, srtURL, streamHeaders)
		return resp, err, srtURL, ""
	}
	srtPath := replaceSubtitleExtension(upstreamPath, ".vtt", ".srt")
	if srtPath == upstreamPath {
		return nil, nil, "", ""
	}
	resp, err := client.Stream(r.Context(), requestContextFrom(r.Context()), a.Identity, srtPath, query, streamHeaders)
	return resp, err, "", srtPath
}

func (a *App) handleVideoProxy(w http.ResponseWriter, r *http.Request) {
	virtualItemID := r.PathValue("itemId")
	query := cloneValues(r.URL.Query())
	if a.Logger != nil {
		a.Logger.Debugf("Stream request: itemId=%s, query=%s", virtualItemID, query.Encode())
	}
	resolved := a.resolveRouteIDForRequest(requestContextFrom(r.Context()), virtualItemID)
	if resolved == nil {
		if a.Logger != nil {
			a.Logger.Warnf("Stream: itemId=%s not found in mappings", virtualItemID)
		}
		writeJSON(w, http.StatusNotFound, map[string]any{"message": "Item not found"})
		return
	}
	requestRest := r.PathValue("rest")
	if requestRest == "" {
		writeJSON(w, http.StatusNotFound, map[string]any{"message": "Stream not found"})
		return
	}
	rest := requestRest
	rest = resolveMediaSourceInPath(rest, a.IDStore)
	actualClient, actualOriginalID, ok := a.resolveProxyMediaSourceTarget(w, r, virtualItemID, resolved, query, "Stream")
	if !ok {
		return
	}
	translateProxyStreamPlaySessionQuery(query, a.IDStore)
	playbackQuery := cloneValues(query)
	upstreamPath := "/Videos/" + actualOriginalID + "/" + rest
	upstreamRequestURL := ""
	var registeredTarget MediaSourceProxyTarget
	var registeredTargetKey string
	var hasRegisteredTarget bool
	if !isDirectProxyStreamPath(rest) {
		if target, targetKey, ok := resolveRegisteredPlaybackProxyTarget(a, upstreamPath, r.URL.Query()); ok {
			hasRegisteredTarget = true
			registeredTarget = target
			registeredTargetKey = targetKey
			if target.ServerIndex >= 0 {
				if client := a.Upstream.GetClient(target.ServerIndex); client != nil && client.IsOnline() {
					actualClient = client
				}
			}
			if absoluteURL, path, targetQuery, ok := buildRegisteredPlaybackStreamRequest(target.UpstreamURL, actualClient); ok {
				upstreamRequestURL = absoluteURL
				upstreamPath = path
				query = targetQuery
			} else if parsed, err := url.Parse(target.UpstreamURL); err == nil {
				upstreamPath = parsed.Path
				query = parsed.Query()
			}
		}
	}
	if !a.tryRegisterProxyPlayback(w, r, actualClient.ServerIndex, actualOriginalID, rest, playbackQuery) {
		return
	}
	if upstreamRequestURL == "" {
		// Keep ordinary direct playback on the configured path-based stream route.
		// Non-direct proxy paths such as HLS segments can still reuse the remembered
		// upstream stream host so subsequent requests stay pinned to the same node.
		if !isDirectProxyStreamPath(rest) {
			if virtualMediaSourceID := r.URL.Query().Get("MediaSourceId"); virtualMediaSourceID != "" && a.IDStore != nil {
				if remembered := a.IDStore.GetMediaSourceStreamURL(virtualMediaSourceID); remembered != "" {
					base := actualClient.currentStreamBaseFromAbsolute(remembered)
					if base != "" {
						absoluteURL := resolveAbsolutePlaybackURL(base, upstreamPath)
						if parsed, err := url.Parse(absoluteURL); err == nil {
							query.Del("api_key")
							query.Del("ApiKey")
							if token := actualClient.getAccessToken(); token != "" {
								query.Set("api_key", token)
							}
							parsed.RawQuery = query.Encode()
							upstreamRequestURL = parsed.String()
						}
					}
				}
			}
		}
		if upstreamRequestURL != "" {
			// Keep the remembered absolute target for HLS/subtitle continuation paths.
		} else {
			// Registered playback targets keep using absolute routing above; plain
			// direct stream.* playback stays on the configured path-based route here.
			applyUpstreamStreamAuth(query, actualClient)
		}
	}
	if a.Logger != nil {
		a.Logger.Debugf("Stream target resolved: itemId=%s path=%s mediaSourceId=%s playSessionPresent=%t registeredTarget=%t absolute=%t server=[%s] upstreamPath=%s",
			virtualItemID,
			requestRest,
			r.URL.Query().Get("MediaSourceId"),
			query.Get("PlaySessionId") != "",
			hasRegisteredTarget,
			upstreamRequestURL != "",
			actualClient.Name,
			upstreamPath,
		)
	}
	if a.Logger != nil {
		a.Logger.Infof("Stream: /Videos/%s/%s → [%s] %s (using token: %v)",
			virtualItemID, rest, actualClient.Name, upstreamPath, query.Get("api_key") != "")
	}
	playbackMode := actualClient.Config.PlaybackMode
	if playbackMode == "" {
		playbackMode = a.ConfigStore.Snapshot().Playback.Mode
	}
	if playbackMode == "redirect" && !isWebCookieAuth(requestContextFrom(r.Context())) {
		redirectURL := upstreamRequestURL
		if redirectURL == "" {
			redirectURL = actualClient.BuildURL(upstreamPath, query, true)
		}
		if a.Logger != nil {
			a.Logger.Debugf("Stream redirect: /Videos/%s/%s → 302 %s", virtualItemID, rest, redirectURL)
		}
		http.Redirect(w, r, redirectURL, http.StatusFound)
		return
	}
	streamHeaders := buildProxyStreamHeaders(r)
	if a.Logger != nil {
		a.Logger.Debugf("Stream request headers: Range=%q, Accept=%q, AE=%q",
			r.Header.Get("Range"), r.Header.Get("Accept"), r.Header.Get("Accept-Encoding"))
	}
	var resp *http.Response
	var err error
	subtitleVTTRequest := isBrowserSubtitleVTTRequest(rest)
	subtitleFallbackKind := "none"
	if upstreamRequestURL != "" {
		resp, err = actualClient.StreamAbsolute(r.Context(), requestContextFrom(r.Context()), a.Identity, upstreamRequestURL, streamHeaders)
	} else {
		resp, err = actualClient.Stream(r.Context(), requestContextFrom(r.Context()), a.Identity, upstreamPath, query, streamHeaders)
	}
	if err != nil && hasRegisteredTarget {
		if fallbackTarget, fallbackURL, ok := tryFallbackRegisteredPlaybackTarget(actualClient, registeredTarget); ok {
			registeredTarget = fallbackTarget
			resp, err = actualClient.StreamAbsolute(r.Context(), requestContextFrom(r.Context()), a.Identity, fallbackURL, streamHeaders)
			if err == nil {
				upstreamRequestURL = fallbackURL
				if registeredTargetKey != "" {
					a.IDStore.SetMediaSourceProxyTarget(registeredTargetKey, registeredTarget)
				}
				if parsed, parseErr := url.Parse(fallbackURL); parseErr == nil {
					upstreamPath = parsed.Path
					query = parsed.Query()
				}
			}
		}
	}
	if err == nil && subtitleVTTRequest && resp != nil && resp.StatusCode == http.StatusNotFound {
		_ = resp.Body.Close()
		resp = nil
		fallbackResp, fallbackErr, fallbackURL, fallbackPath := trySubtitleSRTFallback(a, r, actualClient, upstreamRequestURL, upstreamPath, query, streamHeaders)
		if fallbackErr == nil && fallbackResp != nil {
			resp = fallbackResp
			subtitleFallbackKind = "srt"
			upstreamRequestURL = fallbackURL
			if fallbackPath != "" {
				upstreamPath = fallbackPath
			}
		} else {
			err = fallbackErr
		}
	}
	if err != nil {
		if errors.Is(err, context.Canceled) || errors.Is(err, context.DeadlineExceeded) {
			return
		}
		if a.Logger != nil {
			a.Logger.Errorf("Stream error: /Videos/%s/%s: %s", virtualItemID, rest, err.Error())
		}
		writeJSON(w, http.StatusBadGateway, map[string]any{"message": err.Error()})
		return
	}
	if resp.StatusCode >= http.StatusBadGateway && hasRegisteredTarget {
		if fallbackTarget, fallbackURL, ok := tryFallbackRegisteredPlaybackTarget(actualClient, registeredTarget); ok {
			_ = resp.Body.Close()
			registeredTarget = fallbackTarget
			resp, err = actualClient.StreamAbsolute(r.Context(), requestContextFrom(r.Context()), a.Identity, fallbackURL, streamHeaders)
			if err == nil {
				upstreamRequestURL = fallbackURL
				if registeredTargetKey != "" {
					a.IDStore.SetMediaSourceProxyTarget(registeredTargetKey, registeredTarget)
				}
				if parsed, parseErr := url.Parse(fallbackURL); parseErr == nil {
					upstreamPath = parsed.Path
					query = parsed.Query()
				}
			}
		}
	}
	if err != nil {
		if a.Logger != nil {
			a.Logger.Errorf("Stream error: /Videos/%s/%s: %s", virtualItemID, rest, err.Error())
		}
		writeJSON(w, http.StatusBadGateway, map[string]any{"message": err.Error()})
		return
	}
	defer resp.Body.Close()
	contentType := resp.Header.Get("Content-Type")
	isM3U8 := isM3U8ContentType(contentType) || isM3U8Path(rest)
	if isM3U8 {
		if resp.StatusCode == http.StatusPartialContent {
			writeInvalidHLSManifestResponse(w)
			return
		}
		if resp.StatusCode < http.StatusOK || resp.StatusCode >= http.StatusMultipleChoices {
			copyProxyStreamHeaders(w.Header(), resp.Header)
			w.WriteHeader(resp.StatusCode)
			written, copyErr := io.Copy(w, resp.Body)
			a.logProxyCopyResult("Stream", virtualItemID, requestRest, resp.StatusCode, written, copyErr)
			return
		}
		body, err := readProxyM3U8Body(resp, rest)
		if err != nil {
			if errors.Is(err, errInvalidHLSManifestResponse) {
				writeInvalidHLSManifestResponse(w)
				return
			}
			writeJSON(w, http.StatusBadGateway, map[string]any{"message": err.Error()})
			return
		}
		proxyToken := ""
		if reqCtx := requestContextFrom(r.Context()); reqCtx != nil && !isWebCookieAuth(reqCtx) {
			proxyToken = reqCtx.ProxyToken
		}
		manifestUpstreamURL := upstreamRequestURL
		if manifestUpstreamURL == "" {
			manifestUpstreamURL = actualClient.BuildURL(upstreamPath, query, true)
		}
		if virtualMediaSourceID := r.URL.Query().Get("MediaSourceId"); virtualMediaSourceID != "" && a.IDStore != nil {
			a.IDStore.SetMediaSourceStreamURL(virtualMediaSourceID, manifestUpstreamURL)
		}
		manifest := RewriteM3U8ForItem(string(body), manifestUpstreamURL, virtualItemID, r.URL.Query().Get("MediaSourceId"), proxyToken, r.URL.Query().Get("PlaySessionId"))
		w.Header().Set("Content-Type", "application/x-mpegURL")
		_, _ = io.WriteString(w, manifest)
		return
	}
	if subtitleVTTRequest && resp.StatusCode >= http.StatusOK && resp.StatusCode < http.StatusMultipleChoices {
		body, readErr := io.ReadAll(resp.Body)
		if readErr != nil {
			if a.Logger != nil {
				a.Logger.Warnf("Stream subtitle read error: itemId=%s path=%s err=%v", virtualItemID, requestRest, readErr)
			}
			writeJSON(w, http.StatusBadGateway, map[string]any{"message": readErr.Error()})
			return
		}
		convertedBody := convertSRTBodyToVTT(body)
		if a.Logger != nil {
			a.Logger.Infof("Stream subtitle response: itemId=%s path=%s upstreamStatus=%d fallback=%s output=text/vtt upstreamBytes=%d outputBytes=%d",
				virtualItemID, requestRest, resp.StatusCode, subtitleFallbackKind, len(body), len(convertedBody))
		}
		w.Header().Set("Content-Type", "text/vtt; charset=utf-8")
		w.WriteHeader(resp.StatusCode)
		written, writeErr := w.Write(convertedBody)
		a.logProxyCopyResult("Stream subtitle", virtualItemID, requestRest, resp.StatusCode, int64(written), writeErr)
		return
	}

	if a.Logger != nil {
		a.Logger.Infof("Stream upstream response: Status=%d, Type=%q, Len=%s, Encoding=%q, Range=%q",
			resp.StatusCode, contentType, resp.Header.Get("Content-Length"),
			resp.Header.Get("Content-Encoding"), resp.Header.Get("Content-Range"))
	}

	copyProxyStreamHeaders(w.Header(), resp.Header)

	w.WriteHeader(resp.StatusCode)
	written, copyErr := io.Copy(w, resp.Body)
	a.logProxyCopyResult("Stream", virtualItemID, requestRest, resp.StatusCode, written, copyErr)
}

func (a *App) handleAudioProxy(w http.ResponseWriter, r *http.Request) {
	virtualItemID := r.PathValue("itemId")
	query := cloneValues(r.URL.Query())
	if a.Logger != nil {
		a.Logger.Debugf("Audio stream request: itemId=%s, query=%s", virtualItemID, query.Encode())
	}
	resolved := a.resolveRouteIDForRequest(requestContextFrom(r.Context()), virtualItemID)
	if resolved == nil {
		if a.Logger != nil {
			a.Logger.Warnf("Audio stream: itemId=%s not found in mappings", virtualItemID)
		}
		writeJSON(w, http.StatusNotFound, map[string]any{"message": "Item not found"})
		return
	}
	requestRest := r.PathValue("rest")
	if requestRest == "" {
		writeJSON(w, http.StatusNotFound, map[string]any{"message": "Stream not found"})
		return
	}
	rest := requestRest
	// Resolve virtual MediaSourceId in subtitle/attachment paths
	rest = resolveMediaSourceInPath(rest, a.IDStore)
	actualClient, actualOriginalID, ok := a.resolveProxyMediaSourceTarget(w, r, virtualItemID, resolved, query, "Audio stream")
	if !ok {
		return
	}
	translateProxyStreamPlaySessionQuery(query, a.IDStore)
	playbackQuery := cloneValues(query)
	upstreamPath := "/Audio/" + actualOriginalID + "/" + rest
	upstreamRequestURL := ""
	var registeredTarget MediaSourceProxyTarget
	var registeredTargetKey string
	var hasRegisteredTarget bool
	if !isDirectProxyStreamPath(rest) {
		if target, targetKey, ok := resolveRegisteredPlaybackProxyTarget(a, upstreamPath, r.URL.Query()); ok {
			hasRegisteredTarget = true
			registeredTarget = target
			registeredTargetKey = targetKey
			if target.ServerIndex >= 0 {
				if client := a.Upstream.GetClient(target.ServerIndex); client != nil && client.IsOnline() {
					actualClient = client
				}
			}
			if absoluteURL, path, targetQuery, ok := buildRegisteredPlaybackStreamRequest(target.UpstreamURL, actualClient); ok {
				upstreamRequestURL = absoluteURL
				upstreamPath = path
				query = targetQuery
			} else if parsed, err := url.Parse(target.UpstreamURL); err == nil {
				upstreamPath = parsed.Path
				query = parsed.Query()
			}
		}
	}
	if !a.tryRegisterProxyPlayback(w, r, actualClient.ServerIndex, actualOriginalID, rest, playbackQuery) {
		return
	}
	if upstreamRequestURL == "" {
		// Keep ordinary direct playback on the configured path-based stream route.
		// Non-direct proxy paths such as HLS segments can still reuse the remembered
		// upstream stream host so subsequent requests stay pinned to the same node.
		if !isDirectProxyStreamPath(rest) {
			if virtualMediaSourceID := r.URL.Query().Get("MediaSourceId"); virtualMediaSourceID != "" && a.IDStore != nil {
				if remembered := a.IDStore.GetMediaSourceStreamURL(virtualMediaSourceID); remembered != "" {
					base := actualClient.currentStreamBaseFromAbsolute(remembered)
					if base != "" {
						absoluteURL := resolveAbsolutePlaybackURL(base, upstreamPath)
						if parsed, err := url.Parse(absoluteURL); err == nil {
							query.Del("api_key")
							query.Del("ApiKey")
							if token := actualClient.getAccessToken(); token != "" {
								query.Set("api_key", token)
							}
							parsed.RawQuery = query.Encode()
							upstreamRequestURL = parsed.String()
						}
					}
				}
			}
		}
		if upstreamRequestURL != "" {
			// Keep the remembered absolute target for HLS/subtitle continuation paths.
		} else {
			// Registered playback targets keep using absolute routing above; plain
			// direct stream.* playback stays on the configured path-based route here.
			applyUpstreamStreamAuth(query, actualClient)
		}
	}
	if a.Logger != nil {
		a.Logger.Debugf("Audio stream target resolved: itemId=%s path=%s mediaSourceId=%s playSessionPresent=%t registeredTarget=%t absolute=%t server=[%s] upstreamPath=%s",
			virtualItemID,
			requestRest,
			r.URL.Query().Get("MediaSourceId"),
			query.Get("PlaySessionId") != "",
			hasRegisteredTarget,
			upstreamRequestURL != "",
			actualClient.Name,
			upstreamPath,
		)
	}
	if a.Logger != nil {
		a.Logger.Infof("Stream: /Audio/%s/%s → [%s] %s", virtualItemID, rest, actualClient.Name, upstreamPath)
	}
	playbackMode := actualClient.Config.PlaybackMode
	if playbackMode == "" {
		playbackMode = a.ConfigStore.Snapshot().Playback.Mode
	}
	if playbackMode == "redirect" && !isWebCookieAuth(requestContextFrom(r.Context())) {
		redirectURL := upstreamRequestURL
		if redirectURL == "" {
			redirectURL = actualClient.BuildURL(upstreamPath, query, true)
		}
		if a.Logger != nil {
			a.Logger.Debugf("Stream redirect: /Audio/%s/%s → 302 %s", virtualItemID, rest, redirectURL)
		}
		http.Redirect(w, r, redirectURL, http.StatusFound)
		return
	}
	streamHeaders := buildProxyStreamHeaders(r)
	var resp *http.Response
	var err error
	if upstreamRequestURL != "" {
		resp, err = actualClient.StreamAbsolute(r.Context(), requestContextFrom(r.Context()), a.Identity, upstreamRequestURL, streamHeaders)
	} else {
		resp, err = actualClient.Stream(r.Context(), requestContextFrom(r.Context()), a.Identity, upstreamPath, query, streamHeaders)
	}
	if err != nil && hasRegisteredTarget {
		if fallbackTarget, fallbackURL, ok := tryFallbackRegisteredPlaybackTarget(actualClient, registeredTarget); ok {
			registeredTarget = fallbackTarget
			resp, err = actualClient.StreamAbsolute(r.Context(), requestContextFrom(r.Context()), a.Identity, fallbackURL, streamHeaders)
			if err == nil {
				upstreamRequestURL = fallbackURL
				if registeredTargetKey != "" {
					a.IDStore.SetMediaSourceProxyTarget(registeredTargetKey, registeredTarget)
				}
				if parsed, parseErr := url.Parse(fallbackURL); parseErr == nil {
					upstreamPath = parsed.Path
					query = parsed.Query()
				}
			}
		}
	}
	if err != nil {
		if errors.Is(err, context.Canceled) || errors.Is(err, context.DeadlineExceeded) {
			return
		}
		if a.Logger != nil {
			a.Logger.Errorf("Stream error: /Audio/%s/%s: %s", virtualItemID, rest, err.Error())
		}
		writeJSON(w, http.StatusBadGateway, map[string]any{"message": err.Error()})
		return
	}
	if resp.StatusCode >= http.StatusBadGateway && hasRegisteredTarget {
		if fallbackTarget, fallbackURL, ok := tryFallbackRegisteredPlaybackTarget(actualClient, registeredTarget); ok {
			_ = resp.Body.Close()
			registeredTarget = fallbackTarget
			resp, err = actualClient.StreamAbsolute(r.Context(), requestContextFrom(r.Context()), a.Identity, fallbackURL, streamHeaders)
			if err == nil {
				upstreamRequestURL = fallbackURL
				if registeredTargetKey != "" {
					a.IDStore.SetMediaSourceProxyTarget(registeredTargetKey, registeredTarget)
				}
				if parsed, parseErr := url.Parse(fallbackURL); parseErr == nil {
					upstreamPath = parsed.Path
					query = parsed.Query()
				}
			}
		}
	}
	if err != nil {
		if a.Logger != nil {
			a.Logger.Errorf("Stream error: /Audio/%s/%s: %s", virtualItemID, rest, err.Error())
		}
		writeJSON(w, http.StatusBadGateway, map[string]any{"message": err.Error()})
		return
	}
	defer resp.Body.Close()
	contentType := resp.Header.Get("Content-Type")
	isM3U8 := isM3U8ContentType(contentType) || isM3U8Path(rest)
	if isM3U8 {
		if resp.StatusCode == http.StatusPartialContent {
			writeInvalidHLSManifestResponse(w)
			return
		}
		if resp.StatusCode < http.StatusOK || resp.StatusCode >= http.StatusMultipleChoices {
			copyProxyStreamHeaders(w.Header(), resp.Header)
			w.WriteHeader(resp.StatusCode)
			written, copyErr := io.Copy(w, resp.Body)
			a.logProxyCopyResult("Audio stream", virtualItemID, requestRest, resp.StatusCode, written, copyErr)
			return
		}
		body, err := readProxyM3U8Body(resp, rest)
		if err != nil {
			if errors.Is(err, errInvalidHLSManifestResponse) {
				writeInvalidHLSManifestResponse(w)
				return
			}
			writeJSON(w, http.StatusBadGateway, map[string]any{"message": err.Error()})
			return
		}
		proxyToken := ""
		if reqCtx := requestContextFrom(r.Context()); reqCtx != nil && !isWebCookieAuth(reqCtx) {
			proxyToken = reqCtx.ProxyToken
		}
		manifestUpstreamURL := upstreamRequestURL
		if manifestUpstreamURL == "" {
			manifestUpstreamURL = actualClient.BuildURL(upstreamPath, query, true)
		}
		if virtualMediaSourceID := r.URL.Query().Get("MediaSourceId"); virtualMediaSourceID != "" && a.IDStore != nil {
			a.IDStore.SetMediaSourceStreamURL(virtualMediaSourceID, manifestUpstreamURL)
		}
		manifest := RewriteM3U8ForItem(string(body), manifestUpstreamURL, virtualItemID, r.URL.Query().Get("MediaSourceId"), proxyToken, r.URL.Query().Get("PlaySessionId"))
		w.Header().Set("Content-Type", "application/x-mpegURL")
		_, _ = io.WriteString(w, manifest)
		return
	}

	if a.Logger != nil {
		a.Logger.Infof("Audio stream upstream response: Status=%d, Type=%q, Len=%s",
			resp.StatusCode, contentType, resp.Header.Get("Content-Length"))
	}

	copyProxyStreamHeaders(w.Header(), resp.Header)
	w.WriteHeader(resp.StatusCode)
	written, copyErr := io.Copy(w, resp.Body)
	a.logProxyCopyResult("Audio stream", virtualItemID, requestRest, resp.StatusCode, written, copyErr)
}

func (a *App) handleDeleteActiveEncodings(w http.ResponseWriter, r *http.Request) {
	query := cloneValues(r.URL.Query())
	serverIndex := -1
	if playSessionID := query.Get("PlaySessionId"); playSessionID != "" {
		if resolved := a.IDStore.ResolveVirtualID(playSessionID); resolved != nil {
			query.Set("PlaySessionId", resolved.OriginalID)
			serverIndex = resolved.ServerIndex
		}
	}
	if serverIndex >= 0 {
		if !a.isServerAllowed(requestContextFrom(r.Context()), serverIndex) {
			w.WriteHeader(http.StatusNoContent)
			return
		}
		if client := a.Upstream.GetClient(serverIndex); client != nil && client.IsOnline() {
			_ = a.forwardNoContent(r, client, http.MethodDelete, "/Videos/ActiveEncodings", query, nil)
		}
		w.WriteHeader(http.StatusNoContent)
		return
	}
	for _, client := range a.allowedClients(requestContextFrom(r.Context())) {
		_ = a.forwardNoContent(r, client, http.MethodDelete, "/Videos/ActiveEncodings", query, nil)
	}
	w.WriteHeader(http.StatusNoContent)
}
