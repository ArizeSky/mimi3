package backend

import (
	"encoding/json"
	"fmt"
	"net/http"
	"net/http/httptest"
	"strings"
	"sync/atomic"
	"testing"
)

func TestItemsResumeFallsBackAcrossSeriesInstances(t *testing.T) {
	var primaryCalls atomic.Int32
	var secondaryCalls atomic.Int32

	primary := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch {
		case r.Method == http.MethodPost && r.URL.Path == "/Users/AuthenticateByName":
			_ = json.NewEncoder(w).Encode(map[string]any{
				"AccessToken": "token-a",
				"User":        map[string]any{"Id": "user-a"},
			})
		case r.Method == http.MethodGet && r.URL.Path == "/Users/user-a/Items/Resume":
			primaryCalls.Add(1)
			_ = json.NewEncoder(w).Encode(map[string]any{
				"Items": []map[string]any{{
					"Id":                "wrong-ep-1",
					"SeriesId":          "other-series",
					"ParentId":          "other-season",
					"GrandparentId":     "other-series",
					"SeriesName":        "Re:Zero",
					"ParentIndexNumber": 1,
					"IndexNumber":       1,
					"Source":            "wrong-primary",
				}},
			})
		default:
			http.NotFound(w, r)
		}
	}))
	defer primary.Close()

	secondary := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch {
		case r.Method == http.MethodPost && r.URL.Path == "/Users/AuthenticateByName":
			_ = json.NewEncoder(w).Encode(map[string]any{
				"AccessToken": "token-b",
				"User":        map[string]any{"Id": "user-b"},
			})
		case r.Method == http.MethodGet && r.URL.Path == "/Users/user-b/Items/Resume":
			secondaryCalls.Add(1)
			_ = json.NewEncoder(w).Encode(map[string]any{
				"Items": []map[string]any{{
					"Id":                "right-ep-2",
					"SeriesId":          "series-b",
					"ParentId":          "season-b",
					"GrandparentId":     "series-b",
					"SeriesName":        "Ruri no Houseki",
					"ParentIndexNumber": 1,
					"IndexNumber":       2,
					"Source":            "secondary",
				}},
			})
		default:
			http.NotFound(w, r)
		}
	}))
	defer secondary.Close()

	config := fmt.Sprintf("server:\n  port: 8096\n  name: \"Test Server\"\n  id: \"server-1\"\n\nadmin:\n  username: \"admin\"\n  password: \"secret\"\n\nplayback:\n  mode: \"proxy\"\n\ntimeouts:\n  api: 30000\n  global: 15000\n  login: 10000\n  healthCheck: 10000\n  healthInterval: 60000\n\nproxies: []\nupstream:\n  - name: \"A\"\n    url: %q\n    username: \"u1\"\n    password: \"p1\"\n  - name: \"B\"\n    url: %q\n    username: \"u2\"\n    password: \"p2\"\n", primary.URL, secondary.URL)

	withTempAppConfig(t, config, func(app *App, handler http.Handler) {
		token := loginToken(t, handler, "secret")
		virtualSeries := app.IDStore.GetOrCreateVirtualID("series-a", 0)
		app.IDStore.AssociateAdditionalInstance(virtualSeries, "series-b", 1)

		rr := doJSONRequest(t, handler, http.MethodGet, "/Users/"+app.Auth.ProxyUserID()+"/Items/Resume?ParentId="+virtualSeries, nil, token)
		if rr.Code != http.StatusOK {
			t.Fatalf("resume status = %d, body=%s", rr.Code, rr.Body.String())
		}
		var payload map[string]any
		if err := json.Unmarshal(rr.Body.Bytes(), &payload); err != nil {
			t.Fatalf("unmarshal resume: %v", err)
		}
		items, _ := payload["Items"].([]any)
		if len(items) != 1 {
			t.Fatalf("resume items len = %d, want 1 payload=%#v", len(items), payload)
		}
		item := items[0].(map[string]any)
		if item["Source"] != "secondary" {
			t.Fatalf("unexpected resume source: %#v", item)
		}
		if item["Id"] == "right-ep-2" || item["SeriesId"] == "series-b" {
			t.Fatalf("expected rewritten virtual ids, got %#v", item)
		}
		if primaryCalls.Load() != 1 || secondaryCalls.Load() != 1 {
			t.Fatalf("unexpected upstream call counts: primary=%d secondary=%d", primaryCalls.Load(), secondaryCalls.Load())
		}
	})
}

func TestShowsNextUpUsesPrimarySeriesResultWithoutQueryingSecondary(t *testing.T) {
	var primaryCalls atomic.Int32
	var secondaryCalls atomic.Int32

	primary := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch {
		case r.Method == http.MethodPost && r.URL.Path == "/Users/AuthenticateByName":
			_ = json.NewEncoder(w).Encode(map[string]any{
				"AccessToken": "token-a",
				"User":        map[string]any{"Id": "user-a"},
			})
		case r.Method == http.MethodGet && r.URL.Path == "/Shows/NextUp":
			primaryCalls.Add(1)
			_ = json.NewEncoder(w).Encode(map[string]any{
				"Items": []map[string]any{{
					"Id":            "next-2",
					"SeriesId":      "series-a",
					"ParentId":      "season-a",
					"GrandparentId": "series-a",
					"IndexNumber":   2,
					"Source":        "primary",
				}},
			})
		default:
			http.NotFound(w, r)
		}
	}))
	defer primary.Close()

	secondary := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch {
		case r.Method == http.MethodPost && r.URL.Path == "/Users/AuthenticateByName":
			_ = json.NewEncoder(w).Encode(map[string]any{
				"AccessToken": "token-b",
				"User":        map[string]any{"Id": "user-b"},
			})
		case r.Method == http.MethodGet && r.URL.Path == "/Shows/NextUp":
			secondaryCalls.Add(1)
			_ = json.NewEncoder(w).Encode(map[string]any{
				"Items": []map[string]any{{
					"Id":            "next-bad",
					"SeriesId":      "series-b",
					"ParentId":      "season-b",
					"GrandparentId": "series-b",
					"IndexNumber":   9,
					"Source":        "secondary",
				}},
			})
		default:
			http.NotFound(w, r)
		}
	}))
	defer secondary.Close()

	config := fmt.Sprintf("server:\n  port: 8096\n  name: \"Test Server\"\n  id: \"server-1\"\n\nadmin:\n  username: \"admin\"\n  password: \"secret\"\n\nplayback:\n  mode: \"proxy\"\n\ntimeouts:\n  api: 30000\n  global: 15000\n  login: 10000\n  healthCheck: 10000\n  healthInterval: 60000\n\nproxies: []\nupstream:\n  - name: \"A\"\n    url: %q\n    username: \"u1\"\n    password: \"p1\"\n  - name: \"B\"\n    url: %q\n    username: \"u2\"\n    password: \"p2\"\n", primary.URL, secondary.URL)

	withTempAppConfig(t, config, func(app *App, handler http.Handler) {
		token := loginToken(t, handler, "secret")
		virtualSeries := app.IDStore.GetOrCreateVirtualID("series-a", 0)
		app.IDStore.AssociateAdditionalInstance(virtualSeries, "series-b", 1)

		rr := doJSONRequest(t, handler, http.MethodGet, "/Shows/NextUp?SeriesId="+virtualSeries, nil, token)
		if rr.Code != http.StatusOK {
			t.Fatalf("nextup status = %d, body=%s", rr.Code, rr.Body.String())
		}
		var payload map[string]any
		if err := json.Unmarshal(rr.Body.Bytes(), &payload); err != nil {
			t.Fatalf("unmarshal nextup: %v", err)
		}
		items, _ := payload["Items"].([]any)
		if len(items) != 1 {
			t.Fatalf("nextup items len = %d, want 1 payload=%#v", len(items), payload)
		}
		item := items[0].(map[string]any)
		if item["Source"] != "primary" {
			t.Fatalf("unexpected nextup source: %#v", item)
		}
		if primaryCalls.Load() != 1 || secondaryCalls.Load() != 0 {
			t.Fatalf("unexpected nextup upstream call counts: primary=%d secondary=%d", primaryCalls.Load(), secondaryCalls.Load())
		}
	})
}

func TestLocalNextUpWithSeriesIDUsesAllowedInstanceWhenPrimaryIsUnauthorized(t *testing.T) {
	var primaryEpisodeCalls atomic.Int32
	var secondaryEpisodeCalls atomic.Int32

	primary := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch {
		case r.Method == http.MethodPost && r.URL.Path == "/Users/AuthenticateByName":
			_ = json.NewEncoder(w).Encode(map[string]any{
				"AccessToken": "token-a",
				"User":        map[string]any{"Id": "user-a"},
			})
		case r.Method == http.MethodGet && r.URL.Path == "/Shows/series-a/Episodes":
			primaryEpisodeCalls.Add(1)
			_ = json.NewEncoder(w).Encode(map[string]any{
				"Items": []map[string]any{
					{
						"Id":                "episode-a-1",
						"SeriesId":          "series-a",
						"ParentId":          "season-a",
						"GrandparentId":     "series-a",
						"ParentIndexNumber": 1,
						"IndexNumber":       1,
						"Name":              "Episode 1 from A",
						"Source":            "primary",
					},
					{
						"Id":                "episode-a-2",
						"SeriesId":          "series-a",
						"ParentId":          "season-a",
						"GrandparentId":     "series-a",
						"ParentIndexNumber": 1,
						"IndexNumber":       2,
						"Name":              "Episode 2 from A",
						"Source":            "primary",
					},
				},
			})
		default:
			http.NotFound(w, r)
		}
	}))
	defer primary.Close()

	secondary := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch {
		case r.Method == http.MethodPost && r.URL.Path == "/Users/AuthenticateByName":
			_ = json.NewEncoder(w).Encode(map[string]any{
				"AccessToken": "token-b",
				"User":        map[string]any{"Id": "user-b"},
			})
		case r.Method == http.MethodGet && r.URL.Path == "/Shows/series-b/Episodes":
			secondaryEpisodeCalls.Add(1)
			_ = json.NewEncoder(w).Encode(map[string]any{
				"Items": []map[string]any{
					{
						"Id":                "episode-b-1",
						"SeriesId":          "series-b",
						"ParentId":          "season-b",
						"GrandparentId":     "series-b",
						"ParentIndexNumber": 1,
						"IndexNumber":       1,
						"Name":              "Episode 1 from B",
						"Source":            "secondary",
					},
					{
						"Id":                "episode-b-2",
						"SeriesId":          "series-b",
						"ParentId":          "season-b",
						"GrandparentId":     "series-b",
						"ParentIndexNumber": 1,
						"IndexNumber":       2,
						"Name":              "Episode 2 from B",
						"Source":            "secondary",
					},
				},
			})
		default:
			http.NotFound(w, r)
		}
	}))
	defer secondary.Close()

	withTempAppConfig(t, dualUpstreamConfig(primary.URL, secondary.URL), func(app *App, handler http.Handler) {
		adminToken := loginTokenAs(t, handler, "admin", "secret")
		userToken := createLimitedUserAndToken(t, handler, adminToken, "limited-nextup", "limited123", []int{1})
		user := app.UserStore.GetByUsername("limited-nextup")
		if user == nil {
			t.Fatal("expected limited-nextup user to exist")
		}

		virtualSeries := app.IDStore.GetOrCreateVirtualID("series-a", 0)
		app.IDStore.AssociateAdditionalInstance(virtualSeries, "series-b", 1)
		virtualEpisode := app.IDStore.GetOrCreateVirtualID("episode-a-1", 0)

		if err := app.WatchStore.RecordProgress(&WatchProgress{
			ProxyUserID:       user.ID,
			VirtualItemID:     virtualEpisode,
			ServerIndex:       0,
			OriginalItemID:    "episode-a-1",
			ItemType:          "Episode",
			SeriesVirtualID:   virtualSeries,
			SeriesOriginalID:  "series-a",
			ParentIndexNumber: 1,
			IndexNumber:       1,
			Played:            true,
		}); err != nil {
			t.Fatalf("record progress: %v", err)
		}

		rr := doJSONRequest(t, handler, http.MethodGet, "/Shows/NextUp?SeriesId="+virtualSeries, nil, userToken)
		if rr.Code != http.StatusOK {
			t.Fatalf("nextup status = %d, body=%s", rr.Code, rr.Body.String())
		}

		var payload map[string]any
		if err := json.Unmarshal(rr.Body.Bytes(), &payload); err != nil {
			t.Fatalf("unmarshal nextup: %v", err)
		}
		items, _ := payload["Items"].([]any)
		if len(items) != 1 {
			t.Fatalf("nextup items len = %d, want 1 payload=%#v", len(items), payload)
		}

		item, _ := items[0].(map[string]any)
		if item["Source"] != "secondary" {
			t.Fatalf("expected allowed server item from B, got %#v", item)
		}
		if primaryEpisodeCalls.Load() != 0 {
			t.Fatalf("expected primary episodes endpoint to be skipped, got %d calls", primaryEpisodeCalls.Load())
		}
		if secondaryEpisodeCalls.Load() != 1 {
			t.Fatalf("expected secondary episodes endpoint to be hit once, got %d calls", secondaryEpisodeCalls.Load())
		}
	})
}

func TestVideoStreamFailsExplicitlyWhenMediaSourceTargetServerIsUnavailable(t *testing.T) {
	primary := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch {
		case r.Method == http.MethodPost && r.URL.Path == "/Users/AuthenticateByName":
			_ = json.NewEncoder(w).Encode(map[string]any{"AccessToken": "tok-a", "User": map[string]any{"Id": "user-a"}})
		case r.Method == http.MethodGet && r.URL.Path == "/Items/episode-a/PlaybackInfo":
			_ = json.NewEncoder(w).Encode(map[string]any{
				"MediaSources": []map[string]any{{
					"Id":        "ms-b",
					"Container": "mkv",
				}},
			})
		default:
			http.NotFound(w, r)
		}
	}))
	defer primary.Close()

	secondary := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch {
		case r.Method == http.MethodPost && r.URL.Path == "/Users/AuthenticateByName":
			_ = json.NewEncoder(w).Encode(map[string]any{"AccessToken": "tok-b", "User": map[string]any{"Id": "user-b"}})
		default:
			http.NotFound(w, r)
		}
	}))
	defer secondary.Close()

	config := dualUpstreamConfig(primary.URL, secondary.URL)
	withTempAppConfig(t, config, func(app *App, handler http.Handler) {
		token := loginToken(t, handler, "secret")
		virtualEpisode := app.IDStore.GetOrCreateVirtualID("episode-a", 0)
		virtualMS := app.IDStore.GetOrCreateVirtualID("ms-b", 1)
		app.Upstream.GetClient(1).setOffline("test offline")

		rr := doJSONRequest(t, handler, http.MethodGet, "/Videos/"+virtualEpisode+"/stream.mkv?MediaSourceId="+virtualMS+"&api_key="+token, nil, "")
		if rr.Code == http.StatusOK {
			t.Fatalf("stream unexpectedly succeeded: %s", rr.Body.String())
		}
	})
}

func TestPlaybackInfoAndMasterPlaylistProxy(t *testing.T) {
	upstream := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch {
		case r.Method == http.MethodPost && r.URL.Path == "/Users/AuthenticateByName":
			_ = json.NewEncoder(w).Encode(map[string]any{
				"AccessToken": "upstream-token",
				"User":        map[string]any{"Id": "user-a"},
			})
		case r.Method == http.MethodGet && r.URL.Path == "/Items/episode-1/PlaybackInfo":
			_ = json.NewEncoder(w).Encode(map[string]any{
				"MediaSources": []map[string]any{{
					"Id":             "ms-1",
					"Container":      "ts",
					"TranscodingUrl": "/Videos/episode-1/master.m3u8?MediaSourceId=ms-1&api_key=upstream-token",
				}},
				"PlaySessionId": "play-1",
			})
		case r.Method == http.MethodGet && r.URL.Path == "/Videos/episode-1/master.m3u8":
			w.Header().Set("Content-Type", "application/x-mpegURL")
			_, _ = w.Write([]byte("#EXTM3U\nsegment1.ts\nhttps://cdn.example/Videos/episode-1/hls1/main/seg.ts?foo=1&api_key=upstream-token\n"))
		case r.Method == http.MethodGet && r.URL.Path == "/Videos/episode-1/segment1.ts":
			_, _ = w.Write([]byte("segment-one"))
		case r.Method == http.MethodGet && r.URL.Path == "/Videos/episode-1/hls1/main/seg.ts":
			_, _ = w.Write([]byte("segment-two"))
		default:
			http.NotFound(w, r)
		}
	}))
	defer upstream.Close()

	config := fmt.Sprintf("server:\n  port: 8096\n  name: \"Test Server\"\n  id: \"server-1\"\n\nadmin:\n  username: \"admin\"\n  password: \"secret\"\n\nplayback:\n  mode: \"proxy\"\n\ntimeouts:\n  api: 30000\n  global: 15000\n  login: 10000\n  healthCheck: 10000\n  healthInterval: 60000\n\nproxies: []\nupstream:\n  - name: \"A\"\n    url: %q\n    username: \"u1\"\n    password: \"p1\"\n", upstream.URL)

	withTempAppConfig(t, config, func(app *App, handler http.Handler) {
		token := loginToken(t, handler, "secret")
		virtualEpisode := app.IDStore.GetOrCreateVirtualID("episode-1", 0)

		playbackRR := doJSONRequest(t, handler, http.MethodGet, "/Items/"+virtualEpisode+"/PlaybackInfo", nil, token)
		if playbackRR.Code != http.StatusOK {
			t.Fatalf("playback info status = %d, body=%s", playbackRR.Code, playbackRR.Body.String())
		}
		var payload map[string]any
		if err := json.Unmarshal(playbackRR.Body.Bytes(), &payload); err != nil {
			t.Fatalf("unmarshal playback info: %v", err)
		}
		mediaSources, _ := payload["MediaSources"].([]any)
		if len(mediaSources) != 1 {
			t.Fatalf("media source count = %d payload=%#v", len(mediaSources), payload)
		}
		ms := mediaSources[0].(map[string]any)
		transcodingURL, _ := ms["TranscodingUrl"].(string)
		if !strings.Contains(transcodingURL, virtualEpisode) || !strings.Contains(transcodingURL, "api_key="+token) {
			t.Fatalf("unexpected transcoding url: %q", transcodingURL)
		}
		playSessionID, _ := payload["PlaySessionId"].(string)
		if playSessionID == "" {
			t.Fatalf("expected virtual play session id in playback payload, got %#v", payload)
		}
		mediaSourceID, _ := ms["Id"].(string)
		if mediaSourceID == "" || mediaSourceID == "ms-1" {
			t.Fatalf("expected virtual media source id, got %q", mediaSourceID)
		}

		playlistReq := httptest.NewRequest(http.MethodGet, transcodingURL, nil)
		playlistRR := httptest.NewRecorder()
		handler.ServeHTTP(playlistRR, playlistReq)
		if playlistRR.Code != http.StatusOK {
			t.Fatalf("playlist status = %d, body=%s", playlistRR.Code, playlistRR.Body.String())
		}
		body := playlistRR.Body.String()
		if strings.Contains(strings.ToLower(body), "localhost") {
			t.Fatalf("playlist should not contain localhost: %s", body)
		}
		if !strings.Contains(body, "/Videos/"+virtualEpisode+"/segment1.ts?MediaSourceId="+mediaSourceID+"&PlaySessionId="+playSessionID+"&api_key="+token) {
			t.Fatalf("playlist missing rewritten relative segment path with media source pinning: %s", body)
		}
		if strings.Contains(body, "cdn.example") || strings.Contains(body, "api_key=upstream-token") {
			t.Fatalf("playlist leaked upstream host or token: %s", body)
		}
		if !strings.Contains(body, "/Videos/"+virtualEpisode+"/hls1/main/seg.ts?MediaSourceId="+mediaSourceID+"&PlaySessionId="+playSessionID+"&api_key="+token+"&foo=1") {
			t.Fatalf("playlist missing rewritten absolute segment proxy path with media source pinning: %s", body)
		}

		segmentRR := doJSONRequest(t, handler, http.MethodGet, "/Videos/"+virtualEpisode+"/segment1.ts?MediaSourceId="+mediaSourceID+"&api_key="+token, nil, "")
		if segmentRR.Code != http.StatusOK {
			t.Fatalf("segment status = %d, body=%s", segmentRR.Code, segmentRR.Body.String())
		}
		if segmentRR.Body.String() != "segment-one" {
			t.Fatalf("unexpected segment body: %q", segmentRR.Body.String())
		}
	})
}

func TestPlaybackInfoUsesSelectedMediaSourcePlaySessionAcrossInstances(t *testing.T) {
	var playSessionHitsA atomic.Int32
	var playSessionHitsB atomic.Int32

	primary := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch {
		case r.Method == http.MethodPost && r.URL.Path == "/Users/AuthenticateByName":
			_ = json.NewEncoder(w).Encode(map[string]any{
				"AccessToken": "token-a",
				"User":        map[string]any{"Id": "user-a"},
			})
		case r.Method == http.MethodGet && r.URL.Path == "/Items/item-a/PlaybackInfo":
			playSessionHitsA.Add(1)
			_ = json.NewEncoder(w).Encode(map[string]any{
				"PlaySessionId": "play-a",
				"MediaSources": []map[string]any{{
					"Id":              "ms-a",
					"Name":            "Version A",
					"Container":       "mp4",
					"DirectStreamUrl": "/Videos/item-a/stream-a.mp4?MediaSourceId=ms-a&api_key=token-a",
				}},
			})
		default:
			http.NotFound(w, r)
		}
	}))
	defer primary.Close()

	secondary := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch {
		case r.Method == http.MethodPost && r.URL.Path == "/Users/AuthenticateByName":
			_ = json.NewEncoder(w).Encode(map[string]any{
				"AccessToken": "token-b",
				"User":        map[string]any{"Id": "user-b"},
			})
		case r.Method == http.MethodGet && r.URL.Path == "/Items/item-b/PlaybackInfo":
			playSessionHitsB.Add(1)
			_ = json.NewEncoder(w).Encode(map[string]any{
				"PlaySessionId": "play-b",
				"MediaSources": []map[string]any{{
					"Id":              "ms-b",
					"Name":            "Version B",
					"Container":       "mp4",
					"DirectStreamUrl": "/Videos/item-b/stream-b.mp4?MediaSourceId=ms-b&api_key=token-b",
				}},
			})
		default:
			http.NotFound(w, r)
		}
	}))
	defer secondary.Close()

	withTempAppConfig(t, dualUpstreamConfig(primary.URL, secondary.URL), func(app *App, handler http.Handler) {
		token := loginToken(t, handler, "secret")
		virtualItemID := app.IDStore.GetOrCreateVirtualID("item-a", 0)
		app.IDStore.AssociateAdditionalInstance(virtualItemID, "item-b", 1)
		virtualMediaSourceB := app.IDStore.GetOrCreateVirtualID("ms-b", 1)

		rr := doJSONRequest(t, handler, http.MethodGet, "/Items/"+virtualItemID+"/PlaybackInfo?MediaSourceId="+virtualMediaSourceB, nil, token)
		if rr.Code != http.StatusOK {
			t.Fatalf("playback info status = %d, body=%s", rr.Code, rr.Body.String())
		}

		payload := mustJSONObject(t, rr.Body.Bytes())
		playSessionID := mustJSONString(t, payload["PlaySessionId"])
		resolved := app.IDStore.ResolveVirtualID(playSessionID)
		if resolved == nil {
			t.Fatalf("expected virtual PlaySessionId to resolve, got %q", playSessionID)
		}
		if resolved.ServerIndex != 1 || resolved.OriginalID != "play-b" {
			t.Fatalf("expected selected media source to use server B play session, got server=%d original=%q body=%s", resolved.ServerIndex, resolved.OriginalID, rr.Body.String())
		}
		if selectedID := mustJSONString(t, payload["SelectedMediaSourceId"]); selectedID != virtualMediaSourceB {
			t.Fatalf("SelectedMediaSourceId = %q, want %q", selectedID, virtualMediaSourceB)
		}
		if playSessionHitsA.Load() != 1 || playSessionHitsB.Load() != 1 {
			t.Fatalf("unexpected upstream hits: A=%d B=%d", playSessionHitsA.Load(), playSessionHitsB.Load())
		}
	})
}

func TestPlaybackInfoDirectStreamURLOmitsEmbeddedPlaySessionID(t *testing.T) {
	upstream := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch {
		case r.Method == http.MethodPost && r.URL.Path == "/Users/AuthenticateByName":
			_ = json.NewEncoder(w).Encode(map[string]any{
				"AccessToken": "token-a",
				"User":        map[string]any{"Id": "user-a"},
			})
		case r.Method == http.MethodGet && r.URL.Path == "/Items/item-a/PlaybackInfo":
			_ = json.NewEncoder(w).Encode(map[string]any{
				"PlaySessionId": "play-a",
				"MediaSources": []map[string]any{{
					"Id":              "ms-a",
					"Name":            "Version A",
					"Container":       "mkv",
					"DirectStreamUrl": "/Videos/item-a/stream.mkv?MediaSourceId=ms-a&api_key=token-a",
				}},
			})
		default:
			http.NotFound(w, r)
		}
	}))
	defer upstream.Close()

	withTempAppConfig(t, singleUpstreamConfig(upstream.URL), func(app *App, handler http.Handler) {
		token := loginToken(t, handler, "secret")
		virtualItemID := app.IDStore.GetOrCreateVirtualID("item-a", 0)

		rr := doJSONRequest(t, handler, http.MethodGet, "/Items/"+virtualItemID+"/PlaybackInfo", nil, token)
		if rr.Code != http.StatusOK {
			t.Fatalf("playback info status = %d, body=%s", rr.Code, rr.Body.String())
		}

		payload := mustJSONObject(t, rr.Body.Bytes())
		playSessionID := mustJSONString(t, payload["PlaySessionId"])
		if playSessionID == "" {
			t.Fatalf("expected top-level virtual PlaySessionId, body=%s", rr.Body.String())
		}
		mediaSources := mustJSONArray(t, payload["MediaSources"])
		if len(mediaSources) != 1 {
			t.Fatalf("media source count = %d, body=%s", len(mediaSources), rr.Body.String())
		}
		source := mustJSONMap(t, mediaSources[0])
		directURL := mustJSONString(t, source["DirectStreamUrl"])
		if directURL == "" {
			t.Fatalf("expected direct stream url, body=%s", rr.Body.String())
		}
		if strings.Contains(directURL, "PlaySessionId=") {
			t.Fatalf("expected native direct stream url to omit embedded PlaySessionId, got %q", directURL)
		}
	})
}

func TestPlaybackInfoClearsTopLevelPlaySessionWhenSelectedInstanceHasNone(t *testing.T) {
	primary := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch {
		case r.Method == http.MethodPost && r.URL.Path == "/Users/AuthenticateByName":
			_ = json.NewEncoder(w).Encode(map[string]any{
				"AccessToken": "token-a",
				"User":        map[string]any{"Id": "user-a"},
			})
		case r.Method == http.MethodGet && r.URL.Path == "/Items/item-a/PlaybackInfo":
			_ = json.NewEncoder(w).Encode(map[string]any{
				"PlaySessionId": "play-a",
				"MediaSources": []map[string]any{{
					"Id":              "ms-a",
					"Name":            "Version A",
					"Container":       "mp4",
					"DirectStreamUrl": "/Videos/item-a/stream-a.mp4?MediaSourceId=ms-a&api_key=token-a",
				}},
			})
		default:
			http.NotFound(w, r)
		}
	}))
	defer primary.Close()

	secondary := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch {
		case r.Method == http.MethodPost && r.URL.Path == "/Users/AuthenticateByName":
			_ = json.NewEncoder(w).Encode(map[string]any{
				"AccessToken": "token-b",
				"User":        map[string]any{"Id": "user-b"},
			})
		case r.Method == http.MethodGet && r.URL.Path == "/Items/item-b/PlaybackInfo":
			_ = json.NewEncoder(w).Encode(map[string]any{
				"MediaSources": []map[string]any{{
					"Id":              "ms-b",
					"Name":            "Version B",
					"Container":       "mp4",
					"DirectStreamUrl": "/Videos/item-b/stream-b.mp4?MediaSourceId=ms-b&api_key=token-b",
				}},
			})
		default:
			http.NotFound(w, r)
		}
	}))
	defer secondary.Close()

	withTempAppConfig(t, dualUpstreamConfig(primary.URL, secondary.URL), func(app *App, handler http.Handler) {
		token := loginToken(t, handler, "secret")
		virtualItemID := app.IDStore.GetOrCreateVirtualID("item-a", 0)
		app.IDStore.AssociateAdditionalInstance(virtualItemID, "item-b", 1)
		virtualMediaSourceB := app.IDStore.GetOrCreateVirtualID("ms-b", 1)

		rr := doJSONRequest(t, handler, http.MethodGet, "/Items/"+virtualItemID+"/PlaybackInfo?MediaSourceId="+virtualMediaSourceB, nil, token)
		if rr.Code != http.StatusOK {
			t.Fatalf("playback info status = %d, body=%s", rr.Code, rr.Body.String())
		}

		payload := mustJSONObject(t, rr.Body.Bytes())
		if playSession, ok := payload["PlaySessionId"]; ok && webString(playSession) != "" {
			t.Fatalf("expected selected instance without PlaySessionId to clear top-level session, got %v body=%s", playSession, rr.Body.String())
		}
	})
}
