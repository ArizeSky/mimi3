package backend

import (
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
)

func requireLogContains(t *testing.T, app *App, want string) {
	t.Helper()
	entries := app.Logger.Entries(0)
	for _, entry := range entries {
		if strings.Contains(entry.Message, want) {
			return
		}
	}
	messages := make([]string, 0, len(entries))
	for _, entry := range entries {
		messages = append(messages, entry.Message)
	}
	t.Fatalf("expected logs to contain %q, got %v", want, messages)
}

func TestVideoProxyEmitsCopyCompletionDiagnostics(t *testing.T) {
	upstream := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch r.URL.Path {
		case "/Users/AuthenticateByName":
			_ = json.NewEncoder(w).Encode(map[string]any{"AccessToken": "tok-a", "User": map[string]any{"Id": "user-a"}})
		case "/Videos/item-a/stream.mp4":
			w.Header().Set("Content-Type", "video/mp4")
			_, _ = w.Write([]byte("video-stream"))
		default:
			http.NotFound(w, r)
		}
	}))
	defer upstream.Close()

	withTempAppPrepared(t, singleUpstreamConfig(upstream.URL), nil, func(app *App, handler http.Handler, dir string) {
		token := loginToken(t, handler, "secret")
		virtualItemID := app.IDStore.GetOrCreateVirtualID("item-a", 0)

		rr := doJSONRequest(t, handler, http.MethodGet, "/Videos/"+virtualItemID+"/stream.mp4", nil, token)
		if rr.Code != http.StatusOK {
			t.Fatalf("stream status = %d, body=%s", rr.Code, rr.Body.String())
		}

		requireLogContains(t, app, "Stream proxy copy complete: itemId="+virtualItemID+" path=stream.mp4 status=200 bytes=12")
	})
}

func TestVideoSubtitleProxyEmitsFallbackDiagnostics(t *testing.T) {
	upstream := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch r.URL.Path {
		case "/Users/AuthenticateByName":
			_ = json.NewEncoder(w).Encode(map[string]any{"AccessToken": "tok-a", "User": map[string]any{"Id": "user-a"}})
		case "/Videos/item-a/ms-a/Subtitles/2/Stream.vtt":
			http.NotFound(w, r)
		case "/Videos/item-a/ms-a/Subtitles/2/Stream.srt":
			w.Header().Set("Content-Type", "text/plain; charset=utf-8")
			_, _ = w.Write([]byte("1\r\n00:00:01,000 --> 00:00:02,000\r\n你好\r\n"))
		default:
			http.NotFound(w, r)
		}
	}))
	defer upstream.Close()

	withTempAppPrepared(t, singleUpstreamConfig(upstream.URL), nil, func(app *App, handler http.Handler, dir string) {
		user, err := app.UserStore.Create("alice", "pw-1", []int{0})
		if err != nil {
			t.Fatalf("create user: %v", err)
		}
		itemID := app.IDStore.GetOrCreateVirtualID("item-a", 0)
		mediaSourceID := app.IDStore.GetOrCreateVirtualID("ms-a", 0)
		login := doJSONRequest(t, handler, http.MethodPost, "/web/api/login", map[string]string{"username": user.Username, "password": "pw-1"}, "")
		if login.Code != http.StatusOK {
			t.Fatalf("login status = %d, body=%s", login.Code, login.Body.String())
		}

		req := httptest.NewRequest(http.MethodGet, "/Videos/"+itemID+"/"+mediaSourceID+"/Subtitles/2/Stream.vtt", nil)
		req.AddCookie(login.Result().Cookies()[0])
		rr := httptest.NewRecorder()
		handler.ServeHTTP(rr, req)
		if rr.Code != http.StatusOK {
			t.Fatalf("subtitle vtt proxy status = %d, body=%s", rr.Code, rr.Body.String())
		}

		requireLogContains(t, app, "Stream subtitle response: itemId="+itemID+" path="+mediaSourceID+"/Subtitles/2/Stream.vtt upstreamStatus=200 fallback=srt output=text/vtt")
	})
}

func TestWebPlaybackEmitsSourceSelectionDiagnostics(t *testing.T) {
	upstream := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch r.URL.Path {
		case "/Users/AuthenticateByName":
			_ = json.NewEncoder(w).Encode(map[string]any{"AccessToken": "tok-a", "User": map[string]any{"Id": "user-a"}})
		case "/Users/user-a/Items/item-a":
			_ = json.NewEncoder(w).Encode(map[string]any{"Id": "item-a", "Name": "Movie A", "Type": "Movie"})
		case "/Items/item-a/PlaybackInfo":
			_ = json.NewEncoder(w).Encode(map[string]any{
				"PlaySessionId": "sess-a",
				"MediaSources": []map[string]any{
					{
						"Id":              "ms-a",
						"Name":            "Direct",
						"Container":       "mp4",
						"DirectStreamUrl": "/Videos/item-a/stream.mp4?MediaSourceId=ms-a&api_key=upstream",
					},
					{
						"Id":             "ms-b",
						"Name":           "Transcode",
						"Container":      "mp4",
						"TranscodingUrl": "/Videos/item-a/master.m3u8?MediaSourceId=ms-b&api_key=upstream",
					},
				},
			})
		default:
			http.NotFound(w, r)
		}
	}))
	defer upstream.Close()

	withTempAppPrepared(t, singleUpstreamConfig(upstream.URL), nil, func(app *App, handler http.Handler, dir string) {
		user, err := app.UserStore.Create("alice", "pw-1", []int{0})
		if err != nil {
			t.Fatalf("create user: %v", err)
		}
		itemID := app.IDStore.GetOrCreateVirtualID("item-a", 0)
		selectedMediaSourceID := app.IDStore.GetOrCreateVirtualID("ms-b", 0)
		login := doJSONRequest(t, handler, http.MethodPost, "/web/api/login", map[string]string{"username": user.Username, "password": "pw-1"}, "")
		if login.Code != http.StatusOK {
			t.Fatalf("login status = %d, body=%s", login.Code, login.Body.String())
		}

		req := httptest.NewRequest(http.MethodGet, "/web/api/items/"+itemID+"/playback?mediaSourceId="+selectedMediaSourceID, nil)
		req.AddCookie(login.Result().Cookies()[0])
		rr := httptest.NewRecorder()
		handler.ServeHTTP(rr, req)
		if rr.Code != http.StatusOK {
			t.Fatalf("playback status = %d, body=%s", rr.Code, rr.Body.String())
		}

		requireLogContains(t, app, "Web playback response: itemId="+itemID+" mediaSourceId="+selectedMediaSourceID+" sourceKind=hls sourceStrategy=selected-transcoding")
	})
}

func TestWebSubtitleTextEndpointEmitsDiagnostics(t *testing.T) {
	upstream := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch r.URL.Path {
		case "/Users/AuthenticateByName":
			_ = json.NewEncoder(w).Encode(map[string]any{"AccessToken": "tok-a", "User": map[string]any{"Id": "user-a"}})
		case "/Items/item-a/PlaybackInfo":
			_ = json.NewEncoder(w).Encode(map[string]any{
				"MediaSources": []map[string]any{{
					"Id": "ms-a",
					"MediaStreams": []map[string]any{{
						"Type":        "Subtitle",
						"Index":       2,
						"Codec":       "srt",
						"DeliveryUrl": "/Videos/item-a/ms-a/Subtitles/2/Stream.srt",
					}},
				}},
			})
		case "/Videos/item-a/ms-a/Subtitles/2/Stream.srt":
			w.Header().Set("Content-Type", "text/plain; charset=utf-8")
			_, _ = w.Write([]byte("1\r\n00:00:01,000 --> 00:00:02,000\r\n你好\r\n"))
		default:
			http.NotFound(w, r)
		}
	}))
	defer upstream.Close()

	withTempAppPrepared(t, singleUpstreamConfig(upstream.URL), nil, func(app *App, handler http.Handler, dir string) {
		user, err := app.UserStore.Create("alice", "pw-1", []int{0})
		if err != nil {
			t.Fatalf("create user: %v", err)
		}
		login := doJSONRequest(t, handler, http.MethodPost, "/web/api/login", map[string]string{"username": user.Username, "password": "pw-1"}, "")
		if login.Code != http.StatusOK {
			t.Fatalf("login status = %d, body=%s", login.Code, login.Body.String())
		}
		cookie := login.Result().Cookies()[0]

		virtualItemID := app.IDStore.GetOrCreateVirtualID("item-a", 0)
		virtualMediaSourceID := app.IDStore.GetOrCreateVirtualID("ms-a", 0)
		trackID := encodeWebSubtitleTrackID(webSubtitleRef{
			ItemID:        virtualItemID,
			MediaSourceID: virtualMediaSourceID,
			StreamIndex:   2,
			RendererKind:  "text",
		})

		req := httptest.NewRequest(http.MethodGet, "/web/api/subtitles/"+trackID+"/text", nil)
		req.AddCookie(cookie)
		rr := httptest.NewRecorder()
		handler.ServeHTTP(rr, req)
		if rr.Code != http.StatusOK {
			t.Fatalf("subtitle text status = %d, body=%s", rr.Code, rr.Body.String())
		}

		requireLogContains(t, app, "Web subtitle text response: itemId="+virtualItemID+" mediaSourceId="+virtualMediaSourceID+" streamIndex=2 cues=1")
	})
}
