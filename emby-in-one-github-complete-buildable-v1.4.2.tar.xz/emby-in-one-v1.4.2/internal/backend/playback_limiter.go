package backend

import (
	"sync"
	"time"
)

const playbackHeartbeatTimeout = 3 * time.Minute

type streamEntry struct {
	PlaybackID    string
	UserID        string
	ServerIndex   int
	LastHeartbeat time.Time
}

type PlaybackLimiter struct {
	mu      sync.Mutex
	streams map[string]*streamEntry
}

func NewPlaybackLimiter() *PlaybackLimiter {
	return &PlaybackLimiter{
		streams: make(map[string]*streamEntry),
	}
}

// TryStart attempts to register a playback stream. Returns true if allowed.
// maxConcurrent <= 0 means no limit. The same playback id refreshes/moves instead of stacking.
func (l *PlaybackLimiter) TryStart(userID string, serverIndex int, playbackID string, maxConcurrent int) bool {
	l.mu.Lock()
	defer l.mu.Unlock()

	if maxConcurrent <= 0 || playbackID == "" {
		return true
	}

	now := time.Now()

	// Same playback: refresh heartbeat and allow server migration without double-counting.
	if existing, ok := l.streams[playbackID]; ok {
		targetCount := 0
		for key, entry := range l.streams {
			if key == playbackID {
				continue
			}
			if entry.ServerIndex == serverIndex && now.Sub(entry.LastHeartbeat) < playbackHeartbeatTimeout {
				targetCount++
			}
		}
		if targetCount >= maxConcurrent {
			return false
		}
		existing.UserID = userID
		existing.ServerIndex = serverIndex
		existing.LastHeartbeat = now
		return true
	}

	count := 0
	for _, entry := range l.streams {
		if entry.ServerIndex == serverIndex && now.Sub(entry.LastHeartbeat) < playbackHeartbeatTimeout {
			count++
		}
	}

	if count >= maxConcurrent {
		return false
	}

	l.streams[playbackID] = &streamEntry{
		PlaybackID:    playbackID,
		UserID:        userID,
		ServerIndex:   serverIndex,
		LastHeartbeat: now,
	}
	return true
}

// HeartbeatByPlaybackID refreshes the last heartbeat time for a single playback slot.
func (l *PlaybackLimiter) HeartbeatByPlaybackID(playbackID string) {
	l.mu.Lock()
	defer l.mu.Unlock()

	if entry, ok := l.streams[playbackID]; ok {
		entry.LastHeartbeat = time.Now()
	}
}

// Heartbeat refreshes all active playback slots for a user/server pair.
func (l *PlaybackLimiter) Heartbeat(userID string, serverIndex int) {
	l.mu.Lock()
	defer l.mu.Unlock()

	now := time.Now()
	for _, entry := range l.streams {
		if entry.UserID == userID && entry.ServerIndex == serverIndex {
			entry.LastHeartbeat = now
		}
	}
}

// StopByPlaybackID removes a single playback slot.
func (l *PlaybackLimiter) StopByPlaybackID(playbackID string) {
	l.mu.Lock()
	defer l.mu.Unlock()

	delete(l.streams, playbackID)
}

// Stop removes all playback slots for a user on a server.
func (l *PlaybackLimiter) Stop(userID string, serverIndex int) {
	l.mu.Lock()
	defer l.mu.Unlock()

	for key, entry := range l.streams {
		if entry.UserID == userID && entry.ServerIndex == serverIndex {
			delete(l.streams, key)
		}
	}
}

// CountForServer returns the number of active (non-expired) streams on a server.
func (l *PlaybackLimiter) CountForServer(serverIndex int) int {
	l.mu.Lock()
	defer l.mu.Unlock()

	now := time.Now()
	count := 0
	for _, entry := range l.streams {
		if entry.ServerIndex == serverIndex && now.Sub(entry.LastHeartbeat) < playbackHeartbeatTimeout {
			count++
		}
	}
	return count
}

// Cleanup removes all expired stream entries.
func (l *PlaybackLimiter) Cleanup() {
	l.mu.Lock()
	defer l.mu.Unlock()

	now := time.Now()
	for key, entry := range l.streams {
		if now.Sub(entry.LastHeartbeat) >= playbackHeartbeatTimeout {
			delete(l.streams, key)
		}
	}
}
