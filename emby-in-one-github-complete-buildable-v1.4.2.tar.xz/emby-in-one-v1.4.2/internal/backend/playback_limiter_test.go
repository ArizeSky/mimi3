package backend

import (
	"testing"
	"time"
)

func TestPlaybackLimiterAllowsWithinLimit(t *testing.T) {
	l := NewPlaybackLimiter()
	if !l.TryStart("user1", 0, "item-a", 2) {
		t.Error("user1 should be allowed (limit=2, count=0)")
	}
	if !l.TryStart("user2", 0, "item-b", 2) {
		t.Error("user2 should be allowed (limit=2, count=1)")
	}
}

func TestPlaybackLimiterRejectsBeyondLimit(t *testing.T) {
	l := NewPlaybackLimiter()
	if !l.TryStart("user1", 0, "item-a", 1) {
		t.Error("user1 should be allowed")
	}
	if l.TryStart("user2", 0, "item-b", 1) {
		t.Error("user2 should be rejected (limit=1, count=1)")
	}
}

func TestPlaybackLimiterSameUserDifferentPlaybacksStack(t *testing.T) {
	l := NewPlaybackLimiter()
	if !l.TryStart("user1", 0, "play-a", 2) {
		t.Error("user1 first start should be allowed")
	}
	if !l.TryStart("user1", 0, "play-b", 2) {
		t.Error("user1 second start with a different playback should consume another slot")
	}
	if l.CountForServer(0) != 2 {
		t.Errorf("CountForServer = %d, want 2", l.CountForServer(0))
	}
}

func TestPlaybackLimiterSamePlaybackIDDoesNotStack(t *testing.T) {
	l := NewPlaybackLimiter()
	if !l.TryStart("user1", 0, "play-a", 1) {
		t.Error("user1 first start should be allowed")
	}
	if !l.TryStart("user1", 0, "play-a", 1) {
		t.Error("same playback id should refresh existing slot")
	}
	if l.CountForServer(0) != 1 {
		t.Errorf("CountForServer = %d, want 1", l.CountForServer(0))
	}
}

func TestPlaybackLimiterMovesSamePlaybackAcrossServersWithoutDoubleCounting(t *testing.T) {
	l := NewPlaybackLimiter()
	if !l.TryStart("user1", 0, "play-a", 1) {
		t.Fatal("initial playback should be allowed")
	}
	if !l.TryStart("user1", 1, "play-a", 1) {
		t.Fatal("same playback should be movable to another server")
	}
	if got := l.CountForServer(0); got != 0 {
		t.Fatalf("CountForServer(0) = %d, want 0 after move", got)
	}
	if got := l.CountForServer(1); got != 1 {
		t.Fatalf("CountForServer(1) = %d, want 1 after move", got)
	}
}

func TestPlaybackLimiterHeartbeatRefresh(t *testing.T) {
	l := NewPlaybackLimiter()
	l.TryStart("user1", 0, "item-a", 2)

	// Manually set old heartbeat
	l.mu.Lock()
	entry := l.streams["item-a"]
	entry.LastHeartbeat = time.Now().Add(-2 * time.Minute)
	l.mu.Unlock()

	l.Heartbeat("user1", 0)

	l.mu.Lock()
	refreshed := l.streams["item-a"]
	l.mu.Unlock()

	if time.Since(refreshed.LastHeartbeat) > time.Second {
		t.Error("Heartbeat should refresh to now")
	}
}

func TestPlaybackLimiterStopRemoves(t *testing.T) {
	l := NewPlaybackLimiter()
	l.TryStart("user1", 0, "item-a", 1)
	l.Stop("user1", 0)
	if !l.TryStart("user2", 0, "item-b", 1) {
		t.Error("user2 should be allowed after user1 stopped")
	}
}

func TestPlaybackLimiterExpiry(t *testing.T) {
	l := NewPlaybackLimiter()
	l.TryStart("user1", 0, "item-a", 1)

	// Manually set heartbeat to 4 minutes ago
	l.mu.Lock()
	l.streams["item-a"].LastHeartbeat = time.Now().Add(-4 * time.Minute)
	l.mu.Unlock()

	l.Cleanup()

	if !l.TryStart("user2", 0, "item-b", 1) {
		t.Error("user2 should be allowed after expired cleanup")
	}
}

func TestPlaybackLimiterCountForServer(t *testing.T) {
	l := NewPlaybackLimiter()
	l.TryStart("user1", 0, "item-a", 10)
	l.TryStart("user2", 0, "item-b", 10)
	l.TryStart("user3", 1, "item-c", 10)

	if c := l.CountForServer(0); c != 2 {
		t.Errorf("CountForServer(0) = %d, want 2", c)
	}
	if c := l.CountForServer(1); c != 1 {
		t.Errorf("CountForServer(1) = %d, want 1", c)
	}
}

func TestPlaybackLimiterZeroMeansNoLimit(t *testing.T) {
	l := NewPlaybackLimiter()
	for i := 0; i < 100; i++ {
		if !l.TryStart("user"+string(rune('A'+i)), 0, "item", 0) {
			t.Fatalf("maxConcurrent=0 should mean no limit, failed at %d", i)
		}
	}
}

func TestPlaybackLimiterDifferentServers(t *testing.T) {
	l := NewPlaybackLimiter()
	// Server 0 full (limit 1)
	l.TryStart("user1", 0, "item-a", 1)
	// Server 1 should still accept
	if !l.TryStart("user2", 1, "item-b", 1) {
		t.Error("different server should have independent limit")
	}
}
