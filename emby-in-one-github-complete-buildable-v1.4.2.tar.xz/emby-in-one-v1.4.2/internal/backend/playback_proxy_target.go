package backend

import (
	"net/url"
	"path"
	"strings"
	"time"
)

type MediaSourceProxyTarget struct {
	ServerIndex           int
	OriginalItemID        string
	OriginalMediaSourceID string
	Kind                  string
	UpstreamURL           string
	RequestPath           string
	CreatedAt             time.Time
}

type playbackItemInstance struct {
	OriginalID  string
	ServerIndex int
	Client      *UpstreamClient
}

func resolveAbsolutePlaybackURL(base, rawURL string) string {
	if strings.HasPrefix(rawURL, "http://") || strings.HasPrefix(rawURL, "https://") {
		return rawURL
	}
	baseURL, err := url.Parse(strings.TrimRight(base, "/") + "/")
	if err != nil {
		return rawURL
	}
	resolved, err := url.Parse(rawURL)
	if err != nil {
		return rawURL
	}
	return baseURL.ResolveReference(resolved).String()
}

func proxyPlaybackDirectPath(virtualItemID, virtualMediaSourceID, rawURL, container, proxyToken string) string {
	cleanURL := rawURL
	if qIdx := strings.IndexByte(cleanURL, '?'); qIdx >= 0 {
		cleanURL = cleanURL[:qIdx]
	}
	ext := strings.TrimPrefix(path.Ext(cleanURL), ".")
	if ext == "" {
		ext = container
	}
	if ext == "" {
		ext = "mp4"
	}
	query := url.Values{}
	query.Set("MediaSourceId", virtualMediaSourceID)
	query.Set("Static", "true")
	if proxyToken != "" {
		query.Set("api_key", proxyToken)
	}
	return "/Videos/" + virtualItemID + "/stream." + ext + "?" + query.Encode()
}

func proxyPlaybackURLFromAbsolute(absoluteURL, virtualItemID, virtualMediaSourceID, proxyToken, proxyPlaySessionID string) string {
	parsed, err := url.Parse(absoluteURL)
	if err != nil {
		return ""
	}
	proxyPath := parsed.Path
	segments := strings.Split(strings.TrimPrefix(proxyPath, "/"), "/")
	if len(segments) >= 2 && (segments[0] == "Videos" || segments[0] == "Audio") {
		segments[1] = virtualItemID
		if virtualMediaSourceID != "" && len(segments) >= 4 && (segments[3] == "Subtitles" || segments[3] == "Attachments") {
			segments[2] = virtualMediaSourceID
		}
		proxyPath = "/" + strings.Join(segments, "/")
	}
	queryValues := parsed.Query()
	queryValues.Del("api_key")
	queryValues.Del("ApiKey")
	if virtualMediaSourceID != "" {
		queryValues.Set("MediaSourceId", virtualMediaSourceID)
	}
	if proxyPlaySessionID != "" {
		queryValues.Set("PlaySessionId", proxyPlaySessionID)
	}
	if proxyToken != "" {
		queryValues.Set("api_key", proxyToken)
	}
	if encoded := queryValues.Encode(); encoded != "" {
		return proxyPath + "?" + encoded
	}
	return proxyPath
}

func registerPlaybackProxyTargets(store *IDStore, virtualMediaSourceID string, directTarget, transcodeTarget *MediaSourceProxyTarget) {
	if store == nil || virtualMediaSourceID == "" {
		return
	}
	if directTarget != nil {
		store.SetMediaSourceProxyTarget(virtualMediaSourceID, *directTarget)
	}
	if transcodeTarget != nil {
		store.SetMediaSourceProxyTarget(virtualMediaSourceID+"_transcode", *transcodeTarget)
	}
}

func buildPlaybackProxyTargets(inst playbackItemInstance, originalMediaSourceID, directAbsolute, transcodeAbsolute string) (*MediaSourceProxyTarget, *MediaSourceProxyTarget) {
	var directTarget *MediaSourceProxyTarget
	var transcodeTarget *MediaSourceProxyTarget
	if directAbsolute != "" {
		directTarget = &MediaSourceProxyTarget{
			ServerIndex:           inst.ServerIndex,
			OriginalItemID:        inst.OriginalID,
			OriginalMediaSourceID: originalMediaSourceID,
			Kind:                  "direct",
			UpstreamURL:           directAbsolute,
		}
	}
	if transcodeAbsolute != "" {
		transcodeTarget = &MediaSourceProxyTarget{
			ServerIndex:           inst.ServerIndex,
			OriginalItemID:        inst.OriginalID,
			OriginalMediaSourceID: originalMediaSourceID,
			Kind:                  "transcode",
			UpstreamURL:           transcodeAbsolute,
		}
	}
	return directTarget, transcodeTarget
}

func resolveRegisteredPlaybackProxyTarget(a *App, requestPath string, query url.Values) (MediaSourceProxyTarget, string, bool) {
	if a == nil || a.IDStore == nil {
		return MediaSourceProxyTarget{}, "", false
	}
	virtualMediaSourceID := query.Get("MediaSourceId")
	if virtualMediaSourceID == "" {
		return MediaSourceProxyTarget{}, "", false
	}
	for _, key := range []string{virtualMediaSourceID, virtualMediaSourceID + "_transcode"} {
		target, ok := a.IDStore.GetMediaSourceProxyTarget(key)
		if !ok {
			continue
		}
		if requestPath == "" {
			return target, key, true
		}
		parsed, err := url.Parse(target.UpstreamURL)
		if err != nil || parsed.Path == "" {
			continue
		}
		if path.Base(parsed.Path) == path.Base(requestPath) {
			return target, key, true
		}
	}
	return MediaSourceProxyTarget{}, "", false
}

func normalizePlaybackMediaSource(a *App, reqCtx *RequestContext, inst playbackItemInstance, virtualItemID string, mediaSource map[string]any, proxyPlaySessionID string) map[string]any {
	originalMSID, _ := mediaSource["Id"].(string)
	virtualMSID := originalMSID
	if originalMSID != "" {
		virtualMSID = a.IDStore.GetOrCreateVirtualID(originalMSID, inst.ServerIndex)
		mediaSource["Id"] = virtualMSID
	}
	proxyToken := ""
	if reqCtx != nil && !isWebCookieAuth(reqCtx) {
		proxyToken = reqCtx.ProxyToken
	}
	selectedBase := ""
	if existing, ok := a.IDStore.GetMediaSourceProxyTarget(virtualMSID); ok {
		selectedBase = inst.Client.currentStreamBaseFromAbsolute(existing.UpstreamURL)
	}
	if selectedBase == "" {
		if existing, ok := a.IDStore.GetMediaSourceProxyTarget(virtualMSID + "_transcode"); ok {
			selectedBase = inst.Client.currentStreamBaseFromAbsolute(existing.UpstreamURL)
		}
	}
	directAbsolute := ""
	if directURL, ok := mediaSource["DirectStreamUrl"].(string); ok && directURL != "" {
		directAbsolute = inst.Client.resolveAbsoluteStreamURLWithSelection(selectedBase, directURL)
		if selectedBase == "" {
			selectedBase = inst.Client.currentStreamBaseFromAbsolute(directAbsolute)
		}
		a.IDStore.SetMediaSourceStreamURL(virtualMSID, directAbsolute)
		mediaSource["DirectStreamUrl"] = proxyPlaybackDirectPath(virtualItemID, virtualMSID, directURL, webString(mediaSource["Container"]), proxyToken)
	}
	transcodeAbsolute := ""
	if transcodingURL, ok := mediaSource["TranscodingUrl"].(string); ok && transcodingURL != "" {
		transcodeAbsolute = inst.Client.resolveAbsoluteStreamURLWithSelection(selectedBase, transcodingURL)
		if selectedBase == "" {
			selectedBase = inst.Client.currentStreamBaseFromAbsolute(transcodeAbsolute)
		}
		a.IDStore.SetMediaSourceStreamURL(virtualMSID+"_transcode", transcodeAbsolute)
		mediaSource["TranscodingUrl"] = proxyPlaybackURLFromAbsolute(transcodeAbsolute, virtualItemID, virtualMSID, proxyToken, proxyPlaySessionID)
	}
	directTarget, transcodeTarget := buildPlaybackProxyTargets(inst, originalMSID, directAbsolute, transcodeAbsolute)
	registerPlaybackProxyTargets(a.IDStore, virtualMSID, directTarget, transcodeTarget)
	if protocol, _ := mediaSource["Protocol"].(string); protocol == "Http" {
		if msPath, ok := mediaSource["Path"].(string); ok && msPath != "" {
			msPath = strings.ReplaceAll(msPath, inst.OriginalID, virtualItemID)
			if originalMSID != "" && originalMSID != virtualMSID {
				msPath = strings.ReplaceAll(msPath, originalMSID, virtualMSID)
			}
			mediaSource["Path"] = msPath
		}
	}
	if rawStreams, ok := mediaSource["MediaStreams"].([]any); ok {
		for _, rawStream := range rawStreams {
			stream, ok := rawStream.(map[string]any)
			if !ok {
				continue
			}
			deliveryURL, _ := stream["DeliveryUrl"].(string)
			if deliveryURL == "" {
				continue
			}
			if strings.HasPrefix(deliveryURL, "http://") || strings.HasPrefix(deliveryURL, "https://") {
				stream["DeliveryUrl"] = proxyPlaybackURLFromAbsolute(deliveryURL, virtualItemID, virtualMSID, proxyToken, proxyPlaySessionID)
				continue
			}
			if strings.HasPrefix(deliveryURL, "/") {
				resolved := inst.Client.resolveAbsoluteStreamURLWithSelection(selectedBase, deliveryURL)
				if selectedBase == "" {
					selectedBase = inst.Client.currentStreamBaseFromAbsolute(resolved)
				}
				stream["DeliveryUrl"] = proxyPlaybackURLFromAbsolute(resolved, virtualItemID, virtualMSID, proxyToken, proxyPlaySessionID)
			}
		}
	}
	return mediaSource
}
