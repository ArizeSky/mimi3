package backend

import (
	"net/url"
	"strings"
	"testing"
)

func TestPlaybackProxyTargetChoosesStreamingURLsRoundRobinPerMediaSource(t *testing.T) {
	app := &App{IDStore: &IDStore{virtualToOriginal: map[string]*idEntry{}, originalToVirtual: map[string]string{}, mediaSourceTargets: map[string]mediaSourceProxyTargetEntry{}, streamURLs: map[string]streamURLEntry{}, activeStreamServer: map[string]activeStreamEntry{}}}
	client := &UpstreamClient{Config: UpstreamConfig{StreamingURLs: []string{"https://stream-a.example.com", "https://stream-b.example.com"}}, StreamBaseURL: "https://api.example.com"}

	first := normalizePlaybackMediaSource(app, &RequestContext{}, playbackItemInstance{OriginalID: "item-a", ServerIndex: 0, Client: client}, "virt-item", map[string]any{"Id": "ms-1", "DirectStreamUrl": "/Videos/item-a/stream.mp4"}, "")
	second := normalizePlaybackMediaSource(app, &RequestContext{}, playbackItemInstance{OriginalID: "item-a", ServerIndex: 0, Client: client}, "virt-item", map[string]any{"Id": "ms-2", "DirectStreamUrl": "/Videos/item-a/stream.mp4"}, "")

	firstID, _ := first["Id"].(string)
	secondID, _ := second["Id"].(string)
	firstTarget, ok := app.IDStore.GetMediaSourceProxyTarget(firstID)
	if !ok {
		t.Fatal("first target missing")
	}
	secondTarget, ok := app.IDStore.GetMediaSourceProxyTarget(secondID)
	if !ok {
		t.Fatal("second target missing")
	}
	if !strings.HasPrefix(firstTarget.UpstreamURL, "https://stream-a.example.com/") || !strings.HasPrefix(secondTarget.UpstreamURL, "https://stream-b.example.com/") {
		t.Fatalf("unexpected round-robin targets: first=%q second=%q", firstTarget.UpstreamURL, secondTarget.UpstreamURL)
	}
}

func TestPlaybackProxyTargetKeepsChosenStreamingURLForSameMediaSource(t *testing.T) {
	app := &App{IDStore: &IDStore{virtualToOriginal: map[string]*idEntry{}, originalToVirtual: map[string]string{}, mediaSourceTargets: map[string]mediaSourceProxyTargetEntry{}, streamURLs: map[string]streamURLEntry{}, activeStreamServer: map[string]activeStreamEntry{}}}
	client := &UpstreamClient{Config: UpstreamConfig{StreamingURLs: []string{"https://stream-a.example.com", "https://stream-b.example.com"}}, StreamBaseURL: "https://api.example.com"}

	first := normalizePlaybackMediaSource(app, &RequestContext{}, playbackItemInstance{OriginalID: "item-a", ServerIndex: 0, Client: client}, "virt-item", map[string]any{"Id": "ms-1", "DirectStreamUrl": "/Videos/item-a/stream.mp4"}, "")
	second := normalizePlaybackMediaSource(app, &RequestContext{}, playbackItemInstance{OriginalID: "item-a", ServerIndex: 0, Client: client}, "virt-item", map[string]any{"Id": "ms-1", "DirectStreamUrl": "/Videos/item-a/stream.mp4"}, "")

	firstID, _ := first["Id"].(string)
	secondID, _ := second["Id"].(string)
	if firstID != secondID {
		t.Fatalf("expected same virtual media source id, got %q and %q", firstID, secondID)
	}
	target, ok := app.IDStore.GetMediaSourceProxyTarget(firstID)
	if !ok {
		t.Fatal("target missing")
	}
	if !strings.HasPrefix(target.UpstreamURL, "https://stream-a.example.com/") {
		t.Fatalf("expected pinned first stream base, got %q", target.UpstreamURL)
	}
}

func TestResolveRegisteredPlaybackProxyTargetUsesTranscodeEntryWhenRequestPathMatches(t *testing.T) {
	app := &App{IDStore: &IDStore{virtualToOriginal: map[string]*idEntry{}, originalToVirtual: map[string]string{}, mediaSourceTargets: map[string]mediaSourceProxyTargetEntry{}, streamURLs: map[string]streamURLEntry{}, activeStreamServer: map[string]activeStreamEntry{}}}
	virtualMediaSourceID := "virt-ms-1"
	app.IDStore.SetMediaSourceProxyTarget(virtualMediaSourceID, MediaSourceProxyTarget{
		ServerIndex:           0,
		OriginalItemID:        "item-a",
		OriginalMediaSourceID: "ms-a",
		Kind:                  "direct",
		UpstreamURL:           "https://stream.example.com/Videos/item-a/stream.mp4?MediaSourceId=ms-a&Static=true",
	})
	app.IDStore.SetMediaSourceProxyTarget(virtualMediaSourceID+"_transcode", MediaSourceProxyTarget{
		ServerIndex:           0,
		OriginalItemID:        "item-a",
		OriginalMediaSourceID: "ms-a",
		Kind:                  "transcode",
		UpstreamURL:           "https://stream.example.com/Videos/custom-node/master.m3u8?MediaSourceId=ms-a",
	})

	target, key, ok := resolveRegisteredPlaybackProxyTarget(app, "/Videos/item-a/master.m3u8", url.Values{"MediaSourceId": []string{virtualMediaSourceID}})
	if !ok {
		t.Fatal("expected transcode target match")
	}
	if key != virtualMediaSourceID+"_transcode" {
		t.Fatalf("target key = %q, want transcode slot", key)
	}
	if target.Kind != "transcode" {
		t.Fatalf("target kind = %q, want transcode", target.Kind)
	}
	if !strings.Contains(target.UpstreamURL, "/Videos/custom-node/master.m3u8") {
		t.Fatalf("target upstream = %q, want registered transcode path", target.UpstreamURL)
	}
}

func TestPlaybackInfoRewritesMediaSourcePathWhenProtocolIsHttp(t *testing.T) {
	app := &App{IDStore: &IDStore{virtualToOriginal: map[string]*idEntry{}, originalToVirtual: map[string]string{}, mediaSourceTargets: map[string]mediaSourceProxyTargetEntry{}, streamURLs: map[string]streamURLEntry{}, activeStreamServer: map[string]activeStreamEntry{}}}
	client := &UpstreamClient{Config: UpstreamConfig{StreamingURLs: []string{"https://stream-a.example.com"}}, StreamBaseURL: "https://api.example.com"}

	// Test 1: Path is full HTTP URL with Protocol=Http -> should rewrite IDs (V1.4.3 behavior)
	mediaSourceFullURL := map[string]any{
		"Id":               "ms-1",
		"Protocol":         "Http",
		"Path":             "https://stream.example.com/Videos/item-a/stream.mp4?MediaSourceId=ms-a",
		"DirectStreamUrl":  "/Videos/item-a/stream.mp4",
		"MediaStreams":     []any{},
	}

	resultFullURL := normalizePlaybackMediaSource(app, &RequestContext{}, playbackItemInstance{OriginalID: "item-a", ServerIndex: 0, Client: client}, "virt-item", mediaSourceFullURL, "")

	resultFullURLPath, _ := resultFullURL["Path"].(string)
	if resultFullURLPath == "" {
		t.Fatal("Http Path should not be empty")
	}
	// Should contain virtual item ID
	if !strings.Contains(resultFullURLPath, "virt-item") {
		t.Fatalf("Http Path should contain virtual item ID 'virt-item', got %q", resultFullURLPath)
	}
	// Should NOT contain original item ID
	if strings.Contains(resultFullURLPath, "item-a") {
		t.Fatalf("Http Path should not contain original ID 'item-a', got %q", resultFullURLPath)
	}

	// Test 2: Non-Http protocol -> should not modify Path
	mediaSourceNonHttp := map[string]any{
		"Id":               "ms-2",
		"Protocol":         "File",
		"Path":             "/media/Videos/item-a/stream.mp4",
		"DirectStreamUrl":  "/Videos/item-a/stream.mp4",
		"MediaStreams":     []any{},
	}

	resultNonHttp := normalizePlaybackMediaSource(app, &RequestContext{}, playbackItemInstance{OriginalID: "item-a", ServerIndex: 0, Client: client}, "virt-item", mediaSourceNonHttp, "")

	resultNonHttpPath, _ := resultNonHttp["Path"].(string)
	if resultNonHttpPath != "/media/Videos/item-a/stream.mp4" {
		t.Fatalf("Non-Http Path should remain unchanged, got %q", resultNonHttpPath)
	}
}

func TestResolveAbsolutePlaybackURL(t *testing.T) {
	tests := []struct {
		name string
		base string
		raw  string
		want string
	}{
		{
			name: "absolute url stays absolute",
			base: "https://api.example.com",
			raw:  "https://stream.example.com/Videos/1/stream.mp4?Static=true",
			want: "https://stream.example.com/Videos/1/stream.mp4?Static=true",
		},
		{
			name: "relative url resolves against base",
			base: "https://api.example.com",
			raw:  "/Videos/1/stream.mp4?Static=true",
			want: "https://api.example.com/Videos/1/stream.mp4?Static=true",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := resolveAbsolutePlaybackURL(tt.base, tt.raw); got != tt.want {
				t.Fatalf("resolveAbsolutePlaybackURL() = %q, want %q", got, tt.want)
			}
		})
	}
}
