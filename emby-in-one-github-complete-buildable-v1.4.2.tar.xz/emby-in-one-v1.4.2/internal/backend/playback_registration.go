package backend

import (
	"net/url"
	"strings"
)

func playbackRegistrationID(userID, playSessionID, itemID, mediaSourceID string) string {
	if userID == "" {
		return ""
	}
	if playSessionID != "" {
		return "session:" + userID + ":" + playSessionID
	}
	if itemID != "" && mediaSourceID != "" {
		return "media:" + userID + ":" + itemID + ":" + mediaSourceID
	}
	if itemID != "" {
		return "item:" + userID + ":" + itemID
	}
	return "user:" + userID
}

func playbackRegistrationIDFromQuery(userID, itemID string, query url.Values) string {
	if query == nil {
		return ""
	}
	if query.Get("PlaySessionId") == "" {
		return ""
	}
	return playbackRegistrationID(userID, query.Get("PlaySessionId"), itemID, query.Get("MediaSourceId"))
}

func playbackRegistrationIDFromBody(userID string, body map[string]any) string {
	if body == nil {
		return playbackRegistrationID(userID, "", "", "")
	}
	return playbackRegistrationID(
		userID,
		webString(body["PlaySessionId"]),
		webString(body["ItemId"]),
		webString(body["MediaSourceId"]),
	)
}

func shouldTrackPlaybackProxyRequest(rest string) bool {
	lower := strings.ToLower(rest)
	return !strings.Contains(lower, "/subtitles/") && !strings.Contains(lower, "/attachments/")
}
