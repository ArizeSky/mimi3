package backend

import "net/http"

func (a *App) Handler() http.Handler {
	mux := http.NewServeMux()

	mux.HandleFunc("GET /System/Info/Public", a.handleSystemInfoPublic)
	mux.HandleFunc("GET /System/Info", a.withContext(a.requireAuth(a.handleSystemInfo)))
	mux.HandleFunc("GET /System/Endpoint", a.withContext(a.handleSystemEndpoint))
	mux.HandleFunc("GET /System/Ping", a.withContext(a.handleSystemPing))
	mux.HandleFunc("POST /System/Ping", a.withContext(a.handleSystemPing))

	mux.HandleFunc("POST /Users/AuthenticateByName", a.withContext(a.handleAuthenticateByName))
	mux.HandleFunc("GET /Users/Public", a.withContext(a.handleUsersPublic))
	mux.HandleFunc("GET /Users/{userId}", a.withContext(a.requireAuth(a.handleUserObject)))
	mux.HandleFunc("GET /Users/{userId}/Views", a.withContext(a.requireAuth(a.handleUserViews)))
	mux.HandleFunc("GET /Users/{userId}/GroupingOptions", a.withContext(a.requireAuth(a.handleUserGroupingOptions)))
	mux.HandleFunc("POST /Users/{userId}/Configuration", a.withContext(a.requireAuth(a.handleUserConfiguration)))
	mux.HandleFunc("POST /Users/{userId}/Policy", a.withContext(a.requireAuth(a.handleUserPolicy)))
	a.registerMediaRoutes(mux)
	a.registerLibraryAndImageRoutes(mux)
	a.registerSessionAndUserStateRoutes(mux)
	a.registerWebRoutes(mux)

	a.registerAdminRoutes(mux)
	mux.HandleFunc("GET /favicon.ico", func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(http.StatusNoContent)
	})

	mux.HandleFunc("GET /{$}", a.handleRoot)
	mux.HandleFunc("/", a.withContext(a.requireAuth(a.handleFallbackProxy)))

	return a.bodyLimitMiddleware(a.loggingMiddleware(a.prefixCompatMiddleware(a.corsMiddleware(mux))))
}
