package backend

import (
	"encoding/json"
	"fmt"
	"net/http"
	"net/http/httptest"
	"strings"
	"sync/atomic"
	"testing"
)

func TestAudioProxyPrefersRegisteredMediaSourceProxyTargetOverDerivedItemPath(t *testing.T) {
	var requestedPath string
	var requestedQuery string
	upstream := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch {
		case r.Method == http.MethodPost && r.URL.Path == "/Users/AuthenticateByName":
			_ = json.NewEncoder(w).Encode(map[string]any{"AccessToken": "token-a", "User": map[string]any{"Id": "user-a"}})
		case r.Method == http.MethodGet && r.URL.Path == "/Audio/custom-node/universal":
			requestedPath = r.URL.Path
			requestedQuery = r.URL.RawQuery
			w.Header().Set("Content-Type", "audio/aac")
			_, _ = w.Write([]byte("audio-universal"))
		default:
			http.NotFound(w, r)
		}
	}))
	defer upstream.Close()

	config := fmt.Sprintf("server:\n  port: 8096\n  name: \"Test Server\"\n  id: \"server-1\"\n\nadmin:\n  username: \"admin\"\n  password: \"secret\"\n\nplayback:\n  mode: \"proxy\"\n\ntimeouts:\n  api: 30000\n  global: 15000\n  login: 10000\n  healthCheck: 10000\n  healthInterval: 60000\n\nproxies: []\nupstream:\n  - name: \"A\"\n    url: %q\n    username: \"u1\"\n    password: \"p1\"\n", upstream.URL)

	withTempAppConfig(t, config, func(app *App, handler http.Handler) {
		token := loginToken(t, handler, "secret")
		virtualSong := app.IDStore.GetOrCreateVirtualID("song-a", 0)
		virtualMS := app.IDStore.GetOrCreateVirtualID("ms-a", 0)
		app.IDStore.SetMediaSourceProxyTarget(virtualMS, MediaSourceProxyTarget{
			ServerIndex:           0,
			OriginalItemID:        "song-a",
			OriginalMediaSourceID: "ms-a",
			Kind:                  "direct",
			UpstreamURL:           upstream.URL + "/Audio/custom-node/universal?MediaSourceId=ms-a&Static=true",
		})

		rr := doJSONRequest(t, handler, http.MethodGet, "/Audio/"+virtualSong+"/universal?MediaSourceId="+virtualMS, nil, token)
		if rr.Code != http.StatusOK {
			t.Fatalf("status = %d, body=%s", rr.Code, rr.Body.String())
		}
		if requestedPath != "/Audio/custom-node/universal" {
			t.Fatalf("requested path = %q, want custom registered target", requestedPath)
		}
		if !strings.Contains(requestedQuery, "MediaSourceId=ms-a") {
			t.Fatalf("requested query = %q, want original media source id", requestedQuery)
		}
	})
}

func TestAudioProxyFallsThroughToNextStreamingURLWhenChosenTargetFails(t *testing.T) {
	var apiStreamHits int
	var failedHits int
	var successHits int
	apiUpstream := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch {
		case r.Method == http.MethodPost && r.URL.Path == "/Users/AuthenticateByName":
			_ = json.NewEncoder(w).Encode(map[string]any{"AccessToken": "token-a", "User": map[string]any{"Id": "user-a"}})
		case r.Method == http.MethodGet && r.URL.Path == "/Audio/song-a/universal":
			apiStreamHits++
			http.Error(w, "api stream base should not be used", http.StatusBadGateway)
		default:
			http.NotFound(w, r)
		}
	}))
	defer apiUpstream.Close()
	failedStream := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.Method == http.MethodGet && r.URL.Path == "/Audio/song-a/universal" {
			failedHits++
			http.Error(w, "fail", http.StatusBadGateway)
			return
		}
		http.NotFound(w, r)
	}))
	defer failedStream.Close()
	goodStream := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.Method == http.MethodGet && r.URL.Path == "/Audio/song-a/universal" {
			successHits++
			w.Header().Set("Content-Type", "audio/aac")
			_, _ = w.Write([]byte("audio-universal"))
			return
		}
		http.NotFound(w, r)
	}))
	defer goodStream.Close()

	config := fmt.Sprintf("server:\n  port: 8096\n  name: \"Test Server\"\n  id: \"server-1\"\n\nadmin:\n  username: \"admin\"\n  password: \"secret\"\n\nplayback:\n  mode: \"proxy\"\n\ntimeouts:\n  api: 30000\n  global: 15000\n  login: 10000\n  healthCheck: 10000\n  healthInterval: 60000\n\nproxies: []\nupstream:\n  - name: \"A\"\n    url: %q\n    streamingUrls:\n      - %q\n      - %q\n    username: \"u1\"\n    password: \"p1\"\n", apiUpstream.URL, failedStream.URL, goodStream.URL)

	withTempAppConfig(t, config, func(app *App, handler http.Handler) {
		token := loginToken(t, handler, "secret")
		virtualSong := app.IDStore.GetOrCreateVirtualID("song-a", 0)
		virtualMS := app.IDStore.GetOrCreateVirtualID("ms-a", 0)
		app.IDStore.SetMediaSourceProxyTarget(virtualMS, MediaSourceProxyTarget{ServerIndex: 0, OriginalItemID: "song-a", OriginalMediaSourceID: "ms-a", Kind: "direct", UpstreamURL: failedStream.URL + "/Audio/song-a/universal?MediaSourceId=ms-a&Static=true"})

		rr := doJSONRequest(t, handler, http.MethodGet, "/Audio/"+virtualSong+"/universal?MediaSourceId="+virtualMS, nil, token)
		if rr.Code != http.StatusOK {
			t.Fatalf("status = %d, body=%s", rr.Code, rr.Body.String())
		}
		if apiStreamHits != 0 {
			t.Fatalf("api stream base should stay unused, hits=%d", apiStreamHits)
		}
		if failedHits == 0 || successHits == 0 {
			t.Fatalf("expected audio failover from failed stream host to success host, failedHits=%d successHits=%d", failedHits, successHits)
		}
		target, ok := app.IDStore.GetMediaSourceProxyTarget(virtualMS)
		if !ok {
			t.Fatal("updated media source target missing")
		}
		if !strings.HasPrefix(target.UpstreamURL, goodStream.URL+"/") {
			t.Fatalf("expected stored target to switch to good stream host, got %q", target.UpstreamURL)
		}
	})
}

func TestAudioProxyTranscodeFailoverUpdatesTranscodeSlotOnly(t *testing.T) {
	var failedHits int
	var successHits int
	apiUpstream := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch {
		case r.Method == http.MethodPost && r.URL.Path == "/Users/AuthenticateByName":
			_ = json.NewEncoder(w).Encode(map[string]any{"AccessToken": "token-a", "User": map[string]any{"Id": "user-a"}})
		default:
			http.NotFound(w, r)
		}
	}))
	defer apiUpstream.Close()
	failedStream := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.Method == http.MethodGet && r.URL.Path == "/Audio/custom-node/universal" {
			failedHits++
			http.Error(w, "fail", http.StatusBadGateway)
			return
		}
		http.NotFound(w, r)
	}))
	defer failedStream.Close()
	goodStream := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.Method == http.MethodGet && r.URL.Path == "/Audio/custom-node/universal" {
			successHits++
			w.Header().Set("Content-Type", "audio/aac")
			_, _ = w.Write([]byte("audio-universal"))
			return
		}
		http.NotFound(w, r)
	}))
	defer goodStream.Close()

	config := fmt.Sprintf("server:\n  port: 8096\n  name: \"Test Server\"\n  id: \"server-1\"\n\nadmin:\n  username: \"admin\"\n  password: \"secret\"\n\nplayback:\n  mode: \"proxy\"\n\ntimeouts:\n  api: 30000\n  global: 15000\n  login: 10000\n  healthCheck: 10000\n  healthInterval: 60000\n\nproxies: []\nupstream:\n  - name: \"A\"\n    url: %q\n    streamingUrls:\n      - %q\n      - %q\n    username: \"u1\"\n    password: \"p1\"\n", apiUpstream.URL, failedStream.URL, goodStream.URL)

	withTempAppConfig(t, config, func(app *App, handler http.Handler) {
		token := loginToken(t, handler, "secret")
		virtualSong := app.IDStore.GetOrCreateVirtualID("song-a", 0)
		virtualMS := app.IDStore.GetOrCreateVirtualID("ms-a", 0)
		directURL := apiUpstream.URL + "/Audio/direct-node/stream.mp3?MediaSourceId=ms-a&Static=true"
		app.IDStore.SetMediaSourceProxyTarget(virtualMS, MediaSourceProxyTarget{
			ServerIndex:           0,
			OriginalItemID:        "song-a",
			OriginalMediaSourceID: "ms-a",
			Kind:                  "direct",
			UpstreamURL:           directURL,
		})
		app.IDStore.SetMediaSourceProxyTarget(virtualMS+"_transcode", MediaSourceProxyTarget{
			ServerIndex:           0,
			OriginalItemID:        "song-a",
			OriginalMediaSourceID: "ms-a",
			Kind:                  "transcode",
			UpstreamURL:           failedStream.URL + "/Audio/custom-node/universal?MediaSourceId=ms-a&Static=true",
		})

		rr := doJSONRequest(t, handler, http.MethodGet, "/Audio/"+virtualSong+"/universal?MediaSourceId="+virtualMS, nil, token)
		if rr.Code != http.StatusOK {
			t.Fatalf("status = %d, body=%s", rr.Code, rr.Body.String())
		}
		if failedHits == 0 || successHits == 0 {
			t.Fatalf("expected audio transcode failover to retry on good stream host, failedHits=%d successHits=%d", failedHits, successHits)
		}

		directTarget, ok := app.IDStore.GetMediaSourceProxyTarget(virtualMS)
		if !ok {
			t.Fatal("direct audio slot missing after transcode failover")
		}
		if directTarget.UpstreamURL != directURL {
			t.Fatalf("direct audio slot overwritten: got %q want %q", directTarget.UpstreamURL, directURL)
		}

		transcodeTarget, ok := app.IDStore.GetMediaSourceProxyTarget(virtualMS + "_transcode")
		if !ok {
			t.Fatal("audio transcode slot missing after failover")
		}
		if !strings.HasPrefix(transcodeTarget.UpstreamURL, goodStream.URL+"/") {
			t.Fatalf("expected audio transcode slot to switch to good stream host, got %q", transcodeTarget.UpstreamURL)
		}
	})
}

func TestAudioProxyAndActiveEncodings(t *testing.T) {
	var deletedPlaySession atomic.Value

	upstream := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch {
		case r.Method == http.MethodPost && r.URL.Path == "/Users/AuthenticateByName":
			_ = json.NewEncoder(w).Encode(map[string]any{"AccessToken": "token-a", "User": map[string]any{"Id": "user-a"}})
		case r.Method == http.MethodGet && r.URL.Path == "/Audio/song-a/stream.mp3":
			w.Header().Set("Content-Type", "audio/mpeg")
			_, _ = w.Write([]byte("audio-stream"))
		case r.Method == http.MethodGet && r.URL.Path == "/Audio/song-a/universal":
			w.Header().Set("Content-Type", "audio/aac")
			_, _ = w.Write([]byte("audio-universal"))
		case r.Method == http.MethodDelete && r.URL.Path == "/Videos/ActiveEncodings":
			deletedPlaySession.Store(r.URL.Query().Get("PlaySessionId"))
			w.WriteHeader(http.StatusNoContent)
		default:
			http.NotFound(w, r)
		}
	}))
	defer upstream.Close()

	config := fmt.Sprintf("server:\n  port: 8096\n  name: \"Test Server\"\n  id: \"server-1\"\n\nadmin:\n  username: \"admin\"\n  password: \"secret\"\n\nplayback:\n  mode: \"proxy\"\n\ntimeouts:\n  api: 30000\n  global: 15000\n  login: 10000\n  healthCheck: 10000\n  healthInterval: 60000\n\nproxies: []\nupstream:\n  - name: \"A\"\n    url: %q\n    username: \"u1\"\n    password: \"p1\"\n", upstream.URL)

	withTempAppConfig(t, config, func(app *App, handler http.Handler) {
		token := loginToken(t, handler, "secret")
		virtualSong := app.IDStore.GetOrCreateVirtualID("song-a", 0)
		virtualPlaySession := app.IDStore.GetOrCreateVirtualID("play-a", 0)

		rr := doJSONRequest(t, handler, http.MethodGet, "/Audio/"+virtualSong+"/stream.mp3", nil, token)
		if rr.Code != http.StatusOK {
			t.Fatalf("audio stream status = %d, body=%s", rr.Code, rr.Body.String())
		}
		if rr.Body.String() != "audio-stream" {
			t.Fatalf("unexpected audio stream body: %q", rr.Body.String())
		}
		if got := rr.Header().Get("Content-Type"); got != "audio/mpeg" {
			t.Fatalf("unexpected audio content type: %q", got)
		}

		req := httptest.NewRequest(http.MethodGet, "/emby/Audio/"+virtualSong+"/universal?api_key="+token, nil)
		rr = httptest.NewRecorder()
		handler.ServeHTTP(rr, req)
		if rr.Code != http.StatusOK {
			t.Fatalf("audio universal status = %d, body=%s", rr.Code, rr.Body.String())
		}
		if rr.Body.String() != "audio-universal" {
			t.Fatalf("unexpected audio universal body: %q", rr.Body.String())
		}

		rr = doJSONRequest(t, handler, http.MethodDelete, "/Videos/ActiveEncodings?PlaySessionId="+virtualPlaySession, nil, token)
		if rr.Code != http.StatusNoContent {
			t.Fatalf("active encodings delete status = %d, body=%s", rr.Code, rr.Body.String())
		}
		if got, _ := deletedPlaySession.Load().(string); got != "play-a" {
			t.Fatalf("PlaySessionId translation = %q, want play-a", got)
		}
	})
}
