package backend

import (
	"net/url"
	"strings"
)

func RewriteM3U8(content, upstreamBase, proxyToken string) string {
	baseURL, _ := url.Parse(upstreamBase)
	rewrite := func(raw string) (string, bool) {
		resolved, ok := resolveM3U8Resource(baseURL, raw)
		if !ok {
			return raw, false
		}
		params := resolved.Query()
		deleteM3U8SecretQuery(params)
		if proxyToken != "" {
			params.Set("api_key", proxyToken)
		}
		resolved.RawQuery = params.Encode()
		return resolved.String(), true
	}

	lines := strings.Split(content, "\n")
	for i, line := range lines {
		trimmed := strings.TrimSpace(line)
		if trimmed == "" {
			continue
		}
		if strings.HasPrefix(trimmed, "#") {
			lines[i] = rewriteM3U8URIAttributes(line, rewrite)
			continue
		}
		if rewritten, ok := rewrite(trimmed); ok {
			lines[i] = rewritten
		}
	}
	return strings.Join(lines, "\n")
}

func RewriteM3U8ForItem(content, upstreamBase, proxyItemID, proxyMediaSourceID, proxyToken, proxyPlaySessionID string) string {
	baseURL, _ := url.Parse(upstreamBase)
	baseQuery := url.Values{}
	if baseURL != nil {
		baseQuery = baseURL.Query()
	}
	if proxyMediaSourceID == "" {
		proxyMediaSourceID = baseQuery.Get("MediaSourceId")
	}
	delete(baseQuery, "api_key")
	delete(baseQuery, "ApiKey")
	delete(baseQuery, "PlaySessionId")
	if proxyMediaSourceID != "" {
		baseQuery.Set("MediaSourceId", proxyMediaSourceID)
	}
	if proxyPlaySessionID != "" {
		baseQuery.Set("PlaySessionId", proxyPlaySessionID)
	}
	if proxyToken != "" {
		baseQuery.Set("api_key", proxyToken)
	}
	if baseURL != nil {
		baseURL.RawQuery = baseQuery.Encode()
	}

	rewrite := func(raw string) (string, bool) {
		resolved, ok := resolveM3U8Resource(baseURL, raw)
		if !ok {
			return raw, false
		}
		segments := strings.Split(strings.TrimPrefix(resolved.Path, "/"), "/")
		if len(segments) >= 2 && (segments[0] == "Videos" || segments[0] == "Audio") {
			segments[1] = proxyItemID
			resolved.Path = "/" + strings.Join(segments, "/")
		}
		params := resolved.Query()
		deleteM3U8SecretQuery(params)
		params.Del("PlaySessionId")
		if proxyMediaSourceID != "" {
			params.Set("MediaSourceId", proxyMediaSourceID)
		}
		if proxyPlaySessionID != "" {
			params.Set("PlaySessionId", proxyPlaySessionID)
		}
		if proxyToken != "" {
			params.Set("api_key", proxyToken)
		}
		resolved.RawQuery = params.Encode()

		pathWithQuery := resolved.EscapedPath()
		if pathWithQuery == "" {
			pathWithQuery = resolved.Path
		}
		if resolved.RawQuery != "" {
			pathWithQuery += "?" + resolved.RawQuery
		}
		if resolved.Fragment != "" {
			pathWithQuery += "#" + resolved.EscapedFragment()
		}
		return pathWithQuery, true
	}

	lines := strings.Split(content, "\n")
	for i, line := range lines {
		trimmed := strings.TrimSpace(line)
		if trimmed == "" {
			continue
		}
		if strings.HasPrefix(trimmed, "#") {
			lines[i] = rewriteM3U8URIAttributes(line, rewrite)
			continue
		}
		if rewritten, ok := rewrite(trimmed); ok {
			lines[i] = rewritten
		}
	}
	return strings.Join(lines, "\n")
}

func resolveM3U8Resource(baseURL *url.URL, raw string) (*url.URL, bool) {
	parsed, err := url.Parse(strings.TrimSpace(raw))
	if err != nil {
		return nil, false
	}
	if parsed.IsAbs() {
		if !strings.EqualFold(parsed.Scheme, "http") && !strings.EqualFold(parsed.Scheme, "https") {
			return nil, false
		}
		return parsed, true
	}
	if baseURL == nil {
		return nil, false
	}
	return baseURL.ResolveReference(parsed), true
}

func deleteM3U8SecretQuery(query url.Values) {
	for key := range query {
		switch strings.ToLower(key) {
		case "api_key", "apikey", "access_token", "accesstoken", "x-emby-token":
			query.Del(key)
		}
	}
}

// rewriteM3U8URIAttributes rewrites URI attributes on HLS tags such as
// EXT-X-KEY, MAP, MEDIA, I-FRAME-STREAM-INF, PRELOAD-HINT and
// RENDITION-REPORT. Quoted values may contain commas, so a small scanner is
// used instead of splitting the attribute list.
func rewriteM3U8URIAttributes(line string, rewrite func(string) (string, bool)) string {
	upper := strings.ToUpper(line)
	if !strings.Contains(upper, "URI=") {
		return line
	}

	var out strings.Builder
	last := 0
	for search := 0; search < len(line); {
		rel := strings.Index(strings.ToUpper(line[search:]), "URI=")
		if rel < 0 {
			break
		}
		attr := search + rel
		if attr > 0 {
			previous := line[attr-1]
			if previous != ':' && previous != ',' && previous != ' ' && previous != '\t' {
				search = attr + len("URI=")
				continue
			}
		}
		valueStart := attr + len("URI=")
		if valueStart >= len(line) {
			break
		}

		quoted := line[valueStart] == '"'
		contentStart := valueStart
		valueEnd := valueStart
		if quoted {
			contentStart++
			valueEnd = contentStart
			for valueEnd < len(line) {
				if line[valueEnd] == '"' && (valueEnd == contentStart || line[valueEnd-1] != '\\') {
					break
				}
				valueEnd++
			}
			if valueEnd >= len(line) {
				break
			}
		} else {
			for valueEnd < len(line) && line[valueEnd] != ',' && line[valueEnd] != ' ' && line[valueEnd] != '\t' && line[valueEnd] != '\r' {
				valueEnd++
			}
		}

		rawValue := line[contentStart:valueEnd]
		rewritten, ok := rewrite(rawValue)
		if !ok {
			search = valueEnd
			if quoted {
				search++
			}
			continue
		}
		out.WriteString(line[last:contentStart])
		out.WriteString(rewritten)
		last = valueEnd
		search = valueEnd
		if quoted {
			search++
		}
	}
	if last == 0 {
		return line
	}
	out.WriteString(line[last:])
	return out.String()
}
