package backend

import (
	"encoding/json"
	"fmt"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
)

func TestVideoProxyPrefersRegisteredMediaSourceProxyTargetOverDerivedItemPath(t *testing.T) {
	var requestedPath string
	var requestedQuery string
	upstream := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch {
		case r.Method == http.MethodPost && r.URL.Path == "/Users/AuthenticateByName":
			_ = json.NewEncoder(w).Encode(map[string]any{"AccessToken": "token-a", "User": map[string]any{"Id": "user-a"}})
		case r.Method == http.MethodGet && r.URL.Path == "/Videos/custom-node/master.m3u8":
			requestedPath = r.URL.Path
			requestedQuery = r.URL.RawQuery
			w.Header().Set("Content-Type", "application/x-mpegURL")
			_, _ = w.Write([]byte("#EXTM3U\nsegment1.ts\n"))
		default:
			http.NotFound(w, r)
		}
	}))
	defer upstream.Close()

	config := fmt.Sprintf("server:\n  port: 8096\n  name: \"Test Server\"\n  id: \"server-1\"\n\nadmin:\n  username: \"admin\"\n  password: \"secret\"\n\nplayback:\n  mode: \"proxy\"\n\ntimeouts:\n  api: 30000\n  global: 15000\n  login: 10000\n  healthCheck: 10000\n  healthInterval: 60000\n\nproxies: []\nupstream:\n  - name: \"A\"\n    url: %q\n    username: \"u1\"\n    password: \"p1\"\n", upstream.URL)

	withTempAppConfig(t, config, func(app *App, handler http.Handler) {
		token := loginToken(t, handler, "secret")
		virtualItem := app.IDStore.GetOrCreateVirtualID("item-a", 0)
		virtualMS := app.IDStore.GetOrCreateVirtualID("ms-a", 0)
		app.IDStore.SetMediaSourceProxyTarget(virtualMS, MediaSourceProxyTarget{
			ServerIndex:           0,
			OriginalItemID:        "item-a",
			OriginalMediaSourceID: "ms-a",
			Kind:                  "direct",
			UpstreamURL:           upstream.URL + "/Videos/custom-node/master.m3u8?MediaSourceId=ms-a&Static=true",
		})

		rr := doJSONRequest(t, handler, http.MethodGet, "/Videos/"+virtualItem+"/master.m3u8?MediaSourceId="+virtualMS, nil, token)
		if rr.Code != http.StatusOK {
			t.Fatalf("status = %d, body=%s", rr.Code, rr.Body.String())
		}
		if requestedPath != "/Videos/custom-node/master.m3u8" {
			t.Fatalf("requested path = %q, want custom registered target", requestedPath)
		}
		if !strings.Contains(requestedQuery, "MediaSourceId=ms-a") {
			t.Fatalf("requested query = %q, want original media source id", requestedQuery)
		}
	})
}

func TestWebCookieVideoProxySuppressesRedirectAndOmitsManifestToken(t *testing.T) {
	upstream := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch {
		case r.Method == http.MethodPost && r.URL.Path == "/Users/AuthenticateByName":
			_ = json.NewEncoder(w).Encode(map[string]any{"AccessToken": "token-a", "User": map[string]any{"Id": "user-a"}})
		case r.Method == http.MethodGet && r.URL.Path == "/Videos/item-a/master.m3u8":
			w.Header().Set("Content-Type", "application/x-mpegURL")
			_, _ = w.Write([]byte("#EXTM3U\nsegment1.ts\nhttps://cdn.example/Videos/item-a/hls1/main/seg.ts?foo=1&api_key=upstream-token\n"))
		default:
			http.NotFound(w, r)
		}
	}))
	defer upstream.Close()

	config := fmt.Sprintf(`server:
  port: 8096
  name: "Test Server"
  id: "server-1"
admin:
  username: "admin"
  password: "secret"
playback:
  mode: "redirect"
timeouts:
  api: 30000
  global: 15000
  login: 10000
  healthCheck: 10000
  healthInterval: 60000
proxies: []
upstream:
  - name: "A"
    url: %q
    username: "u1"
    password: "p1"
`, upstream.URL)

	withTempAppPrepared(t, config, nil, func(app *App, handler http.Handler, dir string) {
		if _, err := app.UserStore.Create("alice", "pw-1", []int{0}); err != nil {
			t.Fatalf("create user: %v", err)
		}
		virtualItem := app.IDStore.GetOrCreateVirtualID("item-a", 0)
		virtualMS := app.IDStore.GetOrCreateVirtualID("ms-a", 0)
		login := doJSONRequest(t, handler, http.MethodPost, "/web/api/login", map[string]string{"username": "alice", "password": "pw-1"}, "")
		if login.Code != http.StatusOK {
			t.Fatalf("login status = %d, body=%s", login.Code, login.Body.String())
		}

		req := httptest.NewRequest(http.MethodGet, "/Videos/"+virtualItem+"/master.m3u8?MediaSourceId="+virtualMS, nil)
		req.AddCookie(login.Result().Cookies()[0])
		rr := httptest.NewRecorder()
		handler.ServeHTTP(rr, req)
		if rr.Code != http.StatusOK {
			t.Fatalf("status = %d, body=%s", rr.Code, rr.Body.String())
		}
		if location := rr.Header().Get("Location"); location != "" {
			t.Fatalf("expected web cookie playback to stay proxied instead of redirecting, location=%q", location)
		}
		body := rr.Body.String()
		if strings.Contains(body, "cdn.example") || strings.Contains(body, "api_key=") {
			t.Fatalf("expected rewritten manifest not to leak upstream host or proxy token, body=%s", body)
		}
		if !strings.Contains(body, "/Videos/"+virtualItem+"/segment1.ts?MediaSourceId="+virtualMS) {
			t.Fatalf("expected relative segment to stay on local proxy route with media source pinning, body=%s", body)
		}
		if !strings.Contains(body, "/Videos/"+virtualItem+"/hls1/main/seg.ts") || !strings.Contains(body, "foo=1") {
			t.Fatalf("expected absolute split-host segment to stay on local proxy route, body=%s", body)
		}
	})
}

func TestHeaderTokenVideoProxyPreservesRedirectMode(t *testing.T) {
	upstream := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch {
		case r.Method == http.MethodPost && r.URL.Path == "/Users/AuthenticateByName":
			_ = json.NewEncoder(w).Encode(map[string]any{"AccessToken": "token-a", "User": map[string]any{"Id": "user-a"}})
		case r.Method == http.MethodGet && r.URL.Path == "/Videos/item-a/master.m3u8":
			w.Header().Set("Content-Type", "application/x-mpegURL")
			_, _ = w.Write([]byte("#EXTM3U\nsegment1.ts\n"))
		default:
			http.NotFound(w, r)
		}
	}))
	defer upstream.Close()

	config := fmt.Sprintf(`server:
  port: 8096
  name: "Test Server"
  id: "server-1"
admin:
  username: "admin"
  password: "secret"
playback:
  mode: "redirect"
timeouts:
  api: 30000
  global: 15000
  login: 10000
  healthCheck: 10000
  healthInterval: 60000
proxies: []
upstream:
  - name: "A"
    url: %q
    username: "u1"
    password: "p1"
`, upstream.URL)

	withTempAppConfig(t, config, func(app *App, handler http.Handler) {
		token := loginToken(t, handler, "secret")
		virtualItem := app.IDStore.GetOrCreateVirtualID("item-a", 0)
		virtualMS := app.IDStore.GetOrCreateVirtualID("ms-a", 0)

		rr := doJSONRequest(t, handler, http.MethodGet, "/Videos/"+virtualItem+"/master.m3u8?MediaSourceId="+virtualMS, nil, token)
		if rr.Code != http.StatusFound {
			t.Fatalf("status = %d, want 302 body=%s", rr.Code, rr.Body.String())
		}
		location := rr.Header().Get("Location")
		if !strings.HasPrefix(location, upstream.URL+"/Videos/item-a/master.m3u8") {
			t.Fatalf("redirect location = %q, want upstream master manifest URL", location)
		}
	})
}

func TestVideoProxyFallsThroughToNextStreamingURLWhenChosenTargetFails(t *testing.T) {
	var apiStreamHits int
	var failedHits int
	var successHits int
	var goodSegmentHits int
	apiUpstream := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch {
		case r.Method == http.MethodPost && r.URL.Path == "/Users/AuthenticateByName":
			_ = json.NewEncoder(w).Encode(map[string]any{"AccessToken": "token-a", "User": map[string]any{"Id": "user-a"}})
		case r.Method == http.MethodGet && r.URL.Path == "/Videos/item-a/master.m3u8":
			apiStreamHits++
			http.Error(w, "api stream base should not be used", http.StatusBadGateway)
		default:
			http.NotFound(w, r)
		}
	}))
	defer apiUpstream.Close()
	failedStream := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.Method == http.MethodGet && r.URL.Path == "/Videos/item-a/master.m3u8" {
			failedHits++
			http.Error(w, "fail", http.StatusBadGateway)
			return
		}
		http.NotFound(w, r)
	}))
	defer failedStream.Close()
	goodStream := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch {
		case r.Method == http.MethodGet && r.URL.Path == "/Videos/item-a/master.m3u8":
			successHits++
			w.Header().Set("Content-Type", "application/x-mpegURL")
			_, _ = w.Write([]byte("#EXTM3U\nsegment1.ts\n"))
			return
		case r.Method == http.MethodGet && r.URL.Path == "/Videos/item-a/segment1.ts":
			goodSegmentHits++
			w.Header().Set("Content-Type", "video/mp2t")
			_, _ = w.Write([]byte("segment-ok"))
			return
		}
		http.NotFound(w, r)
	}))
	defer goodStream.Close()

	config := fmt.Sprintf("server:\n  port: 8096\n  name: \"Test Server\"\n  id: \"server-1\"\n\nadmin:\n  username: \"admin\"\n  password: \"secret\"\n\nplayback:\n  mode: \"proxy\"\n\ntimeouts:\n  api: 30000\n  global: 15000\n  login: 10000\n  healthCheck: 10000\n  healthInterval: 60000\n\nproxies: []\nupstream:\n  - name: \"A\"\n    url: %q\n    streamingUrls:\n      - %q\n      - %q\n    username: \"u1\"\n    password: \"p1\"\n", apiUpstream.URL, failedStream.URL, goodStream.URL)

	withTempAppConfig(t, config, func(app *App, handler http.Handler) {
		token := loginToken(t, handler, "secret")
		virtualItem := app.IDStore.GetOrCreateVirtualID("item-a", 0)
		virtualMS := app.IDStore.GetOrCreateVirtualID("ms-a", 0)
		app.IDStore.SetMediaSourceProxyTarget(virtualMS, MediaSourceProxyTarget{ServerIndex: 0, OriginalItemID: "item-a", OriginalMediaSourceID: "ms-a", Kind: "direct", UpstreamURL: failedStream.URL + "/Videos/item-a/master.m3u8?MediaSourceId=ms-a&Static=true"})

		rr := doJSONRequest(t, handler, http.MethodGet, "/Videos/"+virtualItem+"/master.m3u8?MediaSourceId="+virtualMS, nil, token)
		if rr.Code != http.StatusOK {
			t.Fatalf("status = %d, body=%s", rr.Code, rr.Body.String())
		}
		if apiStreamHits != 0 {
			t.Fatalf("api stream base should stay unused, hits=%d", apiStreamHits)
		}
		if failedHits == 0 || successHits == 0 {
			t.Fatalf("expected failover from failed stream host to success host, failedHits=%d successHits=%d", failedHits, successHits)
		}
		if !strings.Contains(rr.Body.String(), "/Videos/"+virtualItem+"/segment1.ts?MediaSourceId="+virtualMS+"&api_key="+token) {
			t.Fatalf("manifest should keep media source pinning on rewritten segment path, got %q", rr.Body.String())
		}

		segmentRR := doJSONRequest(t, handler, http.MethodGet, "/Videos/"+virtualItem+"/segment1.ts?MediaSourceId="+virtualMS+"&api_key="+token, nil, "")
		if segmentRR.Code != http.StatusOK {
			t.Fatalf("segment status = %d, body=%s", segmentRR.Code, segmentRR.Body.String())
		}
		if segmentRR.Body.String() != "segment-ok" {
			t.Fatalf("unexpected segment body: %q", segmentRR.Body.String())
		}
		if goodSegmentHits == 0 {
			t.Fatal("expected segment request to stay on the good stream host")
		}

		target, ok := app.IDStore.GetMediaSourceProxyTarget(virtualMS)
		if !ok {
			t.Fatal("updated media source target missing")
		}
		if !strings.HasPrefix(target.UpstreamURL, goodStream.URL+"/") {
			t.Fatalf("expected stored target to switch to good stream host, got %q", target.UpstreamURL)
		}
	})
}

func TestVideoProxyTranscodeFailoverUpdatesTranscodeSlotOnly(t *testing.T) {
	var failedHits int
	var successHits int
	apiUpstream := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch {
		case r.Method == http.MethodPost && r.URL.Path == "/Users/AuthenticateByName":
			_ = json.NewEncoder(w).Encode(map[string]any{"AccessToken": "token-a", "User": map[string]any{"Id": "user-a"}})
		default:
			http.NotFound(w, r)
		}
	}))
	defer apiUpstream.Close()
	failedStream := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.Method == http.MethodGet && r.URL.Path == "/Videos/custom-node/master.m3u8" {
			failedHits++
			http.Error(w, "fail", http.StatusBadGateway)
			return
		}
		http.NotFound(w, r)
	}))
	defer failedStream.Close()
	goodStream := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.Method == http.MethodGet && r.URL.Path == "/Videos/custom-node/master.m3u8" {
			successHits++
			w.Header().Set("Content-Type", "application/x-mpegURL")
			_, _ = w.Write([]byte("#EXTM3U\nsegment1.ts\n"))
			return
		}
		http.NotFound(w, r)
	}))
	defer goodStream.Close()

	config := fmt.Sprintf("server:\n  port: 8096\n  name: \"Test Server\"\n  id: \"server-1\"\n\nadmin:\n  username: \"admin\"\n  password: \"secret\"\n\nplayback:\n  mode: \"proxy\"\n\ntimeouts:\n  api: 30000\n  global: 15000\n  login: 10000\n  healthCheck: 10000\n  healthInterval: 60000\n\nproxies: []\nupstream:\n  - name: \"A\"\n    url: %q\n    streamingUrls:\n      - %q\n      - %q\n    username: \"u1\"\n    password: \"p1\"\n", apiUpstream.URL, failedStream.URL, goodStream.URL)

	withTempAppConfig(t, config, func(app *App, handler http.Handler) {
		token := loginToken(t, handler, "secret")
		virtualItem := app.IDStore.GetOrCreateVirtualID("item-a", 0)
		virtualMS := app.IDStore.GetOrCreateVirtualID("ms-a", 0)
		directURL := apiUpstream.URL + "/Videos/direct-node/stream.mp4?MediaSourceId=ms-a&Static=true"
		app.IDStore.SetMediaSourceProxyTarget(virtualMS, MediaSourceProxyTarget{
			ServerIndex:           0,
			OriginalItemID:        "item-a",
			OriginalMediaSourceID: "ms-a",
			Kind:                  "direct",
			UpstreamURL:           directURL,
		})
		app.IDStore.SetMediaSourceProxyTarget(virtualMS+"_transcode", MediaSourceProxyTarget{
			ServerIndex:           0,
			OriginalItemID:        "item-a",
			OriginalMediaSourceID: "ms-a",
			Kind:                  "transcode",
			UpstreamURL:           failedStream.URL + "/Videos/custom-node/master.m3u8?MediaSourceId=ms-a&Static=true",
		})

		rr := doJSONRequest(t, handler, http.MethodGet, "/Videos/"+virtualItem+"/master.m3u8?MediaSourceId="+virtualMS, nil, token)
		if rr.Code != http.StatusOK {
			t.Fatalf("status = %d, body=%s", rr.Code, rr.Body.String())
		}
		if failedHits == 0 || successHits == 0 {
			t.Fatalf("expected transcode failover to retry on good stream host, failedHits=%d successHits=%d", failedHits, successHits)
		}

		directTarget, ok := app.IDStore.GetMediaSourceProxyTarget(virtualMS)
		if !ok {
			t.Fatal("direct slot missing after transcode failover")
		}
		if directTarget.UpstreamURL != directURL {
			t.Fatalf("direct slot overwritten: got %q want %q", directTarget.UpstreamURL, directURL)
		}

		transcodeTarget, ok := app.IDStore.GetMediaSourceProxyTarget(virtualMS + "_transcode")
		if !ok {
			t.Fatal("transcode slot missing after failover")
		}
		if !strings.HasPrefix(transcodeTarget.UpstreamURL, goodStream.URL+"/") {
			t.Fatalf("expected transcode slot to switch to good stream host, got %q", transcodeTarget.UpstreamURL)
		}
	})
}

func TestVideoProxyPreservesUpstreamM3U8ErrorStatus(t *testing.T) {
	upstream := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch {
		case r.Method == http.MethodPost && r.URL.Path == "/Users/AuthenticateByName":
			_ = json.NewEncoder(w).Encode(map[string]any{"AccessToken": "token-a", "User": map[string]any{"Id": "user-a"}})
		case r.Method == http.MethodGet && r.URL.Path == "/Videos/item-a/master.m3u8":
			w.Header().Set("Content-Type", "application/x-mpegURL")
			http.Error(w, "upstream timeout", http.StatusGatewayTimeout)
		default:
			http.NotFound(w, r)
		}
	}))
	defer upstream.Close()

	withTempAppConfig(t, singleUpstreamConfig(upstream.URL), func(app *App, handler http.Handler) {
		token := loginToken(t, handler, "secret")
		virtualItemID := app.IDStore.GetOrCreateVirtualID("item-a", 0)

		rr := doJSONRequest(t, handler, http.MethodGet, "/Videos/"+virtualItemID+"/master.m3u8", nil, token)
		if rr.Code != http.StatusGatewayTimeout {
			t.Fatalf("status = %d, want 504, body=%s", rr.Code, rr.Body.String())
		}
		if !strings.Contains(rr.Body.String(), "upstream timeout") {
			t.Fatalf("expected upstream error body to be preserved, got %q", rr.Body.String())
		}
	})
}

func TestAudioProxyPreservesUpstreamM3U8ErrorStatus(t *testing.T) {
	upstream := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch {
		case r.Method == http.MethodPost && r.URL.Path == "/Users/AuthenticateByName":
			_ = json.NewEncoder(w).Encode(map[string]any{"AccessToken": "token-a", "User": map[string]any{"Id": "user-a"}})
		case r.Method == http.MethodGet && r.URL.Path == "/Audio/item-a/master.m3u8":
			w.Header().Set("Content-Type", "application/x-mpegURL")
			http.Error(w, "upstream timeout", http.StatusGatewayTimeout)
		default:
			http.NotFound(w, r)
		}
	}))
	defer upstream.Close()

	withTempAppConfig(t, singleUpstreamConfig(upstream.URL), func(app *App, handler http.Handler) {
		token := loginToken(t, handler, "secret")
		virtualItemID := app.IDStore.GetOrCreateVirtualID("item-a", 0)

		rr := doJSONRequest(t, handler, http.MethodGet, "/Audio/"+virtualItemID+"/master.m3u8", nil, token)
		if rr.Code != http.StatusGatewayTimeout {
			t.Fatalf("status = %d, want 504, body=%s", rr.Code, rr.Body.String())
		}
		if !strings.Contains(rr.Body.String(), "upstream timeout") {
			t.Fatalf("expected upstream error body to be preserved, got %q", rr.Body.String())
		}
	})
}

func TestVideoProxyDirectStreamIgnoresRememberedAbsoluteStreamURL(t *testing.T) {
	var apiHits int
	var rememberedHits int
	apiUpstream := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch {
		case r.Method == http.MethodPost && r.URL.Path == "/Users/AuthenticateByName":
			_ = json.NewEncoder(w).Encode(map[string]any{"AccessToken": "token-a", "User": map[string]any{"Id": "user-a"}})
		case r.Method == http.MethodGet && r.URL.Path == "/Videos/item-a/stream.mkv":
			apiHits++
			w.Header().Set("Content-Type", "video/x-matroska")
			_, _ = w.Write([]byte("api-video"))
		default:
			http.NotFound(w, r)
		}
	}))
	defer apiUpstream.Close()
	rememberedStream := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.Method == http.MethodGet && r.URL.Path == "/Videos/item-a/stream.mkv" {
			rememberedHits++
			w.Header().Set("Content-Type", "video/x-matroska")
			_, _ = w.Write([]byte("remembered-video"))
			return
		}
		http.NotFound(w, r)
	}))
	defer rememberedStream.Close()

	withTempAppConfig(t, singleUpstreamConfig(apiUpstream.URL), func(app *App, handler http.Handler) {
		token := loginToken(t, handler, "secret")
		virtualItemID := app.IDStore.GetOrCreateVirtualID("item-a", 0)
		virtualMSID := app.IDStore.GetOrCreateVirtualID("ms-a", 0)
		app.IDStore.SetMediaSourceStreamURL(virtualMSID, rememberedStream.URL+"/Videos/item-a/stream.mkv?MediaSourceId=ms-a&Static=true")

		rr := doJSONRequest(t, handler, http.MethodGet, "/Videos/"+virtualItemID+"/stream.mkv?MediaSourceId="+virtualMSID, nil, token)
		if rr.Code != http.StatusOK {
			t.Fatalf("status = %d, body=%s", rr.Code, rr.Body.String())
		}
		if rr.Body.String() != "api-video" {
			t.Fatalf("body = %q, want api-video", rr.Body.String())
		}
		if apiHits != 1 {
			t.Fatalf("api upstream hits = %d, want 1", apiHits)
		}
		if rememberedHits != 0 {
			t.Fatalf("remembered absolute stream URL should stay unused, hits=%d", rememberedHits)
		}
	})
}

func TestVideoProxyDirectStreamIgnoresRegisteredDirectProxyTarget(t *testing.T) {
	var apiHits int
	var registeredHits int
	apiUpstream := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch {
		case r.Method == http.MethodPost && r.URL.Path == "/Users/AuthenticateByName":
			_ = json.NewEncoder(w).Encode(map[string]any{"AccessToken": "token-a", "User": map[string]any{"Id": "user-a"}})
		case r.Method == http.MethodGet && r.URL.Path == "/Videos/item-a/stream.mkv":
			apiHits++
			w.Header().Set("Content-Type", "video/x-matroska")
			_, _ = w.Write([]byte("api-video"))
		default:
			http.NotFound(w, r)
		}
	}))
	defer apiUpstream.Close()
	registeredStream := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.Method == http.MethodGet && r.URL.Path == "/Videos/item-a/stream.mkv" {
			registeredHits++
			w.Header().Set("Content-Type", "video/x-matroska")
			_, _ = w.Write([]byte("registered-video"))
			return
		}
		http.NotFound(w, r)
	}))
	defer registeredStream.Close()

	withTempAppConfig(t, singleUpstreamConfig(apiUpstream.URL), func(app *App, handler http.Handler) {
		token := loginToken(t, handler, "secret")
		virtualItemID := app.IDStore.GetOrCreateVirtualID("item-a", 0)
		virtualMSID := app.IDStore.GetOrCreateVirtualID("ms-a", 0)
		app.IDStore.SetMediaSourceProxyTarget(virtualMSID, MediaSourceProxyTarget{
			ServerIndex:           0,
			OriginalItemID:        "item-a",
			OriginalMediaSourceID: "ms-a",
			Kind:                  "direct",
			UpstreamURL:           registeredStream.URL + "/Videos/item-a/stream.mkv?MediaSourceId=ms-a&Static=true",
		})

		rr := doJSONRequest(t, handler, http.MethodGet, "/Videos/"+virtualItemID+"/stream.mkv?MediaSourceId="+virtualMSID, nil, token)
		if rr.Code != http.StatusOK {
			t.Fatalf("status = %d, body=%s", rr.Code, rr.Body.String())
		}
		if rr.Body.String() != "api-video" {
			t.Fatalf("body = %q, want api-video", rr.Body.String())
		}
		if apiHits != 1 {
			t.Fatalf("api upstream hits = %d, want 1", apiHits)
		}
		if registeredHits != 0 {
			t.Fatalf("registered direct target should stay unused for stream.*, hits=%d", registeredHits)
		}
	})
}

func TestAudioProxyDirectStreamIgnoresRememberedAbsoluteStreamURL(t *testing.T) {
	var apiHits int
	var rememberedHits int
	apiUpstream := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch {
		case r.Method == http.MethodPost && r.URL.Path == "/Users/AuthenticateByName":
			_ = json.NewEncoder(w).Encode(map[string]any{"AccessToken": "token-a", "User": map[string]any{"Id": "user-a"}})
		case r.Method == http.MethodGet && r.URL.Path == "/Audio/item-a/stream.mp3":
			apiHits++
			w.Header().Set("Content-Type", "audio/mpeg")
			_, _ = w.Write([]byte("api-audio"))
		default:
			http.NotFound(w, r)
		}
	}))
	defer apiUpstream.Close()
	rememberedStream := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.Method == http.MethodGet && r.URL.Path == "/Audio/item-a/stream.mp3" {
			rememberedHits++
			w.Header().Set("Content-Type", "audio/mpeg")
			_, _ = w.Write([]byte("remembered-audio"))
			return
		}
		http.NotFound(w, r)
	}))
	defer rememberedStream.Close()

	withTempAppConfig(t, singleUpstreamConfig(apiUpstream.URL), func(app *App, handler http.Handler) {
		token := loginToken(t, handler, "secret")
		virtualItemID := app.IDStore.GetOrCreateVirtualID("item-a", 0)
		virtualMSID := app.IDStore.GetOrCreateVirtualID("ms-a", 0)
		app.IDStore.SetMediaSourceStreamURL(virtualMSID, rememberedStream.URL+"/Audio/item-a/stream.mp3?MediaSourceId=ms-a&Static=true")

		rr := doJSONRequest(t, handler, http.MethodGet, "/Audio/"+virtualItemID+"/stream.mp3?MediaSourceId="+virtualMSID, nil, token)
		if rr.Code != http.StatusOK {
			t.Fatalf("status = %d, body=%s", rr.Code, rr.Body.String())
		}
		if rr.Body.String() != "api-audio" {
			t.Fatalf("body = %q, want api-audio", rr.Body.String())
		}
		if apiHits != 1 {
			t.Fatalf("api upstream hits = %d, want 1", apiHits)
		}
		if rememberedHits != 0 {
			t.Fatalf("remembered absolute stream URL should stay unused, hits=%d", rememberedHits)
		}
	})
}

func TestVideoProxyRejectsInvalidPartialContentM3U8Response(t *testing.T) {
	upstream := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch {
		case r.Method == http.MethodPost && r.URL.Path == "/Users/AuthenticateByName":
			_ = json.NewEncoder(w).Encode(map[string]any{"AccessToken": "token-a", "User": map[string]any{"Id": "user-a"}})
		case r.Method == http.MethodGet && r.URL.Path == "/Videos/item-a/master.m3u8":
			w.Header().Set("Content-Type", "video/mp2t")
			w.Header().Set("Content-Range", "bytes 0-10/999999")
			w.WriteHeader(http.StatusPartialContent)
			_, _ = w.Write([]byte("not-a-manifest"))
		default:
			http.NotFound(w, r)
		}
	}))
	defer upstream.Close()

	withTempAppConfig(t, singleUpstreamConfig(upstream.URL), func(app *App, handler http.Handler) {
		token := loginToken(t, handler, "secret")
		virtualItemID := app.IDStore.GetOrCreateVirtualID("item-a", 0)

		rr := doJSONRequest(t, handler, http.MethodGet, "/Videos/"+virtualItemID+"/master.m3u8", nil, token)
		if rr.Code != http.StatusBadGateway {
			t.Fatalf("status = %d, want 502, body=%s", rr.Code, rr.Body.String())
		}
		if !strings.Contains(rr.Body.String(), "Invalid HLS manifest response") {
			t.Fatalf("expected invalid manifest message, got %q", rr.Body.String())
		}
	})
}

func TestAudioProxyRejectsInvalidPartialContentM3U8Response(t *testing.T) {
	upstream := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch {
		case r.Method == http.MethodPost && r.URL.Path == "/Users/AuthenticateByName":
			_ = json.NewEncoder(w).Encode(map[string]any{"AccessToken": "token-a", "User": map[string]any{"Id": "user-a"}})
		case r.Method == http.MethodGet && r.URL.Path == "/Audio/item-a/master.m3u8":
			w.Header().Set("Content-Type", "audio/aac")
			w.Header().Set("Content-Range", "bytes 0-10/999999")
			w.WriteHeader(http.StatusPartialContent)
			_, _ = w.Write([]byte("not-a-manifest"))
		default:
			http.NotFound(w, r)
		}
	}))
	defer upstream.Close()

	withTempAppConfig(t, singleUpstreamConfig(upstream.URL), func(app *App, handler http.Handler) {
		token := loginToken(t, handler, "secret")
		virtualItemID := app.IDStore.GetOrCreateVirtualID("item-a", 0)

		rr := doJSONRequest(t, handler, http.MethodGet, "/Audio/"+virtualItemID+"/master.m3u8", nil, token)
		if rr.Code != http.StatusBadGateway {
			t.Fatalf("status = %d, want 502, body=%s", rr.Code, rr.Body.String())
		}
		if !strings.Contains(rr.Body.String(), "Invalid HLS manifest response") {
			t.Fatalf("expected invalid manifest message, got %q", rr.Body.String())
		}
	})
}

func TestRewriteM3U8ForItemRewritesAbsoluteSplitHostURLsToProxyRoutes(t *testing.T) {
	input := "#EXTM3U\nhttps://stream.example.com/Videos/orig/master/seg1.ts?api_key=upstream\n"
	output := RewriteM3U8ForItem(input, "https://api.example.com/Videos/orig/master.m3u8", "virt-item", "", "proxy-token", "")

	if strings.Contains(output, "stream.example.com") {
		t.Fatalf("rewritten manifest leaked upstream host: %s", output)
	}
	if !strings.Contains(output, "/Videos/virt-item/master/seg1.ts?api_key=proxy-token") {
		t.Fatalf("rewritten manifest missing local proxy route: %s", output)
	}
}

func TestRewriteM3U8ForItemAddsPinnedMediaSourceIDToRelativeSegments(t *testing.T) {
	input := "#EXTM3U\nsegment1.ts\n"
	output := RewriteM3U8ForItem(input, "https://stream.example.com/Videos/orig/master.m3u8?MediaSourceId=orig-ms", "virt-item", "virt-ms", "proxy-token", "")

	if !strings.Contains(output, "/Videos/virt-item/segment1.ts?MediaSourceId=virt-ms&api_key=proxy-token") {
		t.Fatalf("rewritten manifest missing pinned virtual media source id: %s", output)
	}
}

func TestRewriteM3U8UsesRelativeProxyPaths(t *testing.T) {
	input := "#EXTM3U\nsegment1.ts\nhttps://cdn.example/Videos/123/hls1/main/seg.ts?foo=1&api_key=upstream\n"
	output := RewriteM3U8(input, "https://upstream.example/Videos/123/master.m3u8", "proxy-token")

	if !strings.Contains(output, "https://upstream.example/Videos/123/segment1.ts?api_key=proxy-token") {
		t.Fatalf("rewritten output missing absolute segment URL: %s", output)
	}
	if !strings.Contains(output, "https://cdn.example/Videos/123/hls1/main/seg.ts") {
		t.Fatalf("rewritten output missing rewritten absolute path: %s", output)
	}
	if strings.Contains(strings.ToLower(output), "upstream") && strings.Contains(output, "api_key=upstream") {
		t.Fatalf("upstream api_key should have been replaced: %s", output)
	}
}

func TestRewriteM3U8ForItemReplacesUpstreamMediaSourceIDInSubManifests(t *testing.T) {
	// Simulates an upstream master.m3u8 that contains a sub-manifest URL with
	// the upstream's raw MediaSourceId already baked into the query string.
	// Without rewriting, the browser would later request the sub-manifest with
	// that raw upstream ID, which our IDStore cannot resolve.
	input := "#EXTM3U\n#EXT-X-STREAM-INF:BANDWIDTH=1000000\nmain.m3u8?MediaSourceId=mediasource_312289&PlaySessionId=upstream-session\n"
	output := RewriteM3U8ForItem(input, "https://upstream.example/Videos/orig/master.m3u8", "virt-item", "virt-ms", "proxy-token", "virt-session")

	if strings.Contains(output, "MediaSourceId=mediasource_312289") {
		t.Fatalf("rewritten manifest leaked upstream MediaSourceId: %s", output)
	}
	if !strings.Contains(output, "MediaSourceId=virt-ms") {
		t.Fatalf("rewritten manifest missing virtual MediaSourceId: %s", output)
	}
	if !strings.Contains(output, "PlaySessionId=virt-session") {
		t.Fatalf("rewritten manifest missing virtual PlaySessionId: %s", output)
	}
}

func TestRewriteM3U8ForItemRewritesTagURIAttributes(t *testing.T) {
	input := strings.Join([]string{
		"#EXTM3U",
		`#EXT-X-KEY:METHOD=AES-128,URI="keys/key.bin?api_key=upstream"`,
		`#EXT-X-MAP:URI="init.mp4"`,
		`#EXT-X-MEDIA:TYPE=AUDIO,GROUP-ID="audio",URI="audio/main.m3u8?AccessToken=secret"`,
		`#EXT-X-I-FRAME-STREAM-INF:BANDWIDTH=86000,URI="https://cdn.example/Videos/orig/iframe.m3u8"`,
		`#EXT-X-PRELOAD-HINT:TYPE=PART,URI="part-next.m4s"`,
		`#EXT-X-RENDITION-REPORT:URI="../alt/index.m3u8",LAST-MSN=12`,
		"segment.ts",
		"",
	}, "\n")
	output := RewriteM3U8ForItem(input, "https://stream.example/Videos/orig/hls/master.m3u8?MediaSourceId=raw-ms", "virt-item", "virt-ms", "proxy-token", "virt-session")

	for _, secret := range []string{"upstream", "secret", "cdn.example", "raw-ms"} {
		if strings.Contains(output, secret) {
			t.Fatalf("rewritten manifest leaked %q: %s", secret, output)
		}
	}
	for _, expected := range []string{
		`URI="/Videos/virt-item/hls/keys/key.bin?MediaSourceId=virt-ms&PlaySessionId=virt-session&api_key=proxy-token"`,
		`URI="/Videos/virt-item/hls/init.mp4?MediaSourceId=virt-ms&PlaySessionId=virt-session&api_key=proxy-token"`,
		`URI="/Videos/virt-item/hls/audio/main.m3u8?MediaSourceId=virt-ms&PlaySessionId=virt-session&api_key=proxy-token"`,
		`URI="/Videos/virt-item/iframe.m3u8?MediaSourceId=virt-ms&PlaySessionId=virt-session&api_key=proxy-token"`,
		`URI="/Videos/virt-item/hls/part-next.m4s?MediaSourceId=virt-ms&PlaySessionId=virt-session&api_key=proxy-token"`,
		`URI="/Videos/virt-item/alt/index.m3u8?MediaSourceId=virt-ms&PlaySessionId=virt-session&api_key=proxy-token"`,
	} {
		if !strings.Contains(output, expected) {
			t.Fatalf("rewritten manifest missing %q: %s", expected, output)
		}
	}
}

func TestRewriteM3U8ForItemLeavesNonHTTPKeyURIsUntouched(t *testing.T) {
	input := "#EXTM3U\n#EXT-X-KEY:METHOD=SAMPLE-AES,URI=\"skd://license.example/key\"\n"
	output := RewriteM3U8ForItem(input, "https://stream.example/Videos/orig/master.m3u8", "virt-item", "virt-ms", "proxy-token", "virt-session")
	if !strings.Contains(output, `URI="skd://license.example/key"`) {
		t.Fatalf("non-HTTP key URI should remain untouched: %s", output)
	}
}
