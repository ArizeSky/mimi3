package backend

import (
	"encoding/json"
	"fmt"
	"net/http"
	"net/http/httptest"
	"sync/atomic"
	"testing"
)

type authReviewServer struct {
	server     *httptest.Server
	searchHits *atomic.Int32
	detailHits *atomic.Int32
	imageHits  *atomic.Int32
	playHits   *atomic.Int32
}

type authReviewServerOptions struct {
	searchHits *atomic.Int32
	detailHits *atomic.Int32
	imageHits  *atomic.Int32
	playHits   *atomic.Int32
}

func newAuthReviewServer(t *testing.T, serverName, token, userID, itemID, tmdb string, options authReviewServerOptions) *authReviewServer {
	t.Helper()
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch r.URL.Path {
		case "/Users/AuthenticateByName":
			_ = json.NewEncoder(w).Encode(map[string]any{"AccessToken": token, "User": map[string]any{"Id": userID}})
		case "/Search/Hints":
			if options.searchHits != nil {
				options.searchHits.Add(1)
			}
			_ = json.NewEncoder(w).Encode(map[string]any{"SearchHints": []map[string]any{{
				"Id":          itemID,
				"Name":        fmt.Sprintf("%s %s", serverName, itemID),
				"Type":        "Movie",
				"ProviderIds": map[string]any{"Tmdb": tmdb},
				"Overview":    fmt.Sprintf("overview-%s", serverName),
			}}})
		case "/Users/" + userID + "/Items/" + itemID:
			if options.detailHits != nil {
				options.detailHits.Add(1)
			}
			_ = json.NewEncoder(w).Encode(map[string]any{
				"Id":           itemID,
				"Name":         "Detail " + serverName,
				"Type":         "Movie",
				"Overview":     "detail-from-" + serverName,
				"MediaSources": []map[string]any{},
				"UserData":     map[string]any{},
				"RunTimeTicks": 1000,
			})
		case "/Items/" + itemID + "/PlaybackInfo":
			if options.playHits != nil {
				options.playHits.Add(1)
			}
			_ = json.NewEncoder(w).Encode(map[string]any{"PlaySessionId": "sess-" + serverName, "MediaSources": []map[string]any{{
				"Id":        "ms-" + itemID,
				"Name":      "Version " + serverName,
				"Container": "mp4",
				"Protocol":  "File",
			}}})
		case "/Items/" + itemID + "/Images/Primary/0":
			if options.imageHits != nil {
				options.imageHits.Add(1)
			}
			w.Header().Set("Content-Type", "image/jpeg")
			_, _ = w.Write([]byte("image-" + serverName))
		default:
			http.NotFound(w, r)
		}
	}))
	return &authReviewServer{server: srv, searchHits: options.searchHits, detailHits: options.detailHits, imageHits: options.imageHits, playHits: options.playHits}
}

func (s *authReviewServer) Close() {
	if s != nil && s.server != nil {
		s.server.Close()
	}
}

func newAuthPriorityDualServers(t *testing.T, tmdb string, optionsA, optionsB authReviewServerOptions) (*authReviewServer, *authReviewServer) {
	t.Helper()
	serverA := newAuthReviewServer(t, "A", "token-a", "user-a", "item-a", tmdb, optionsA)
	serverB := newAuthReviewServer(t, "B", "token-b", "user-b", "item-b", tmdb, optionsB)
	return serverA, serverB
}

func authPriorityDualConfig(urlA, urlB string) string {
	return fmt.Sprintf("server:\n  port: 8096\n  name: \"Test Server\"\n  id: \"server-1\"\n\nadmin:\n  username: \"admin\"\n  password: \"secret\"\n\nplayback:\n  mode: \"proxy\"\n\ntimeouts:\n  api: 30000\n  global: 15000\n  login: 10000\n  healthCheck: 10000\n  healthInterval: 60000\n  searchGracePeriod: 0\n  metadataGracePeriod: 0\n  latestGracePeriod: 0\n\nproxies: []\nupstream:\n  - name: \"A\"\n    url: %q\n    username: \"u1\"\n    password: \"p1\"\n    priorityMetadata: true\n  - name: \"B\"\n    url: %q\n    username: \"u2\"\n    password: \"p2\"\n", urlA, urlB)
}

func createLimitedUserAndToken(t *testing.T, handler http.Handler, adminToken, username, password string, allowed []int) string {
	t.Helper()
	rr := doAuthJSON(t, handler, http.MethodPost, "/admin/api/users", map[string]any{"username": username, "password": password, "allowedServers": allowed}, adminToken)
	if rr.Code != http.StatusCreated {
		t.Fatalf("create user %s status=%d body=%s", username, rr.Code, rr.Body.String())
	}
	return loginTokenAs(t, handler, username, password)
}

func createLimitedWebUserCookie(t *testing.T, handler http.Handler, username, password string) *http.Cookie {
	t.Helper()
	login := doJSONRequest(t, handler, http.MethodPost, "/web/api/login", map[string]string{"username": username, "password": password}, "")
	if login.Code != http.StatusOK {
		t.Fatalf("web login %s status=%d body=%s", username, login.Code, login.Body.String())
	}
	return login.Result().Cookies()[0]
}

func createMergedVirtualIDThroughSearch(t *testing.T, handler http.Handler, token, term string) string {
	t.Helper()
	rr := doJSONRequest(t, handler, http.MethodGet, "/Search/Hints?SearchTerm="+term, nil, token)
	if rr.Code != http.StatusOK {
		t.Fatalf("search hints status=%d body=%s", rr.Code, rr.Body.String())
	}
	var payload map[string]any
	if err := json.Unmarshal(rr.Body.Bytes(), &payload); err != nil {
		t.Fatalf("unmarshal search hints payload: %v", err)
	}
	hints, _ := payload["SearchHints"].([]any)
	if len(hints) != 1 {
		t.Fatalf("expected merged hint, body=%s", rr.Body.String())
	}
	virtualID, _ := hints[0].(map[string]any)["Id"].(string)
	if virtualID == "" {
		t.Fatalf("missing merged virtual id, body=%s", rr.Body.String())
	}
	return virtualID
}

func createMergedVirtualIDThroughWebSearch(t *testing.T, handler http.Handler, cookie *http.Cookie, term string) string {
	t.Helper()
	req := httptest.NewRequest(http.MethodGet, "/web/api/search?q="+term, nil)
	req.AddCookie(cookie)
	rr := httptest.NewRecorder()
	handler.ServeHTTP(rr, req)
	if rr.Code != http.StatusOK {
		t.Fatalf("web search status=%d body=%s", rr.Code, rr.Body.String())
	}
	var payload map[string]any
	if err := json.Unmarshal(rr.Body.Bytes(), &payload); err != nil {
		t.Fatalf("unmarshal web search payload: %v", err)
	}
	items, _ := payload["items"].([]any)
	if len(items) != 1 {
		t.Fatalf("expected merged web item, body=%s", rr.Body.String())
	}
	virtualID, _ := items[0].(map[string]any)["id"].(string)
	if virtualID == "" {
		t.Fatalf("missing merged web virtual id, body=%s", rr.Body.String())
	}
	return virtualID
}

func createResumeWatchProgress(t *testing.T, app *App, username, password string, allowed []int, primaryID, secondaryID string, positionTicks, runtimeTicks int64) {
	t.Helper()
	user, err := app.UserStore.Create(username, password, allowed)
	if err != nil {
		t.Fatalf("create user %s: %v", username, err)
	}
	virtualID := app.IDStore.GetOrCreateVirtualID(primaryID, 0)
	app.IDStore.AssociateAdditionalInstance(virtualID, secondaryID, 1)
	if err := app.WatchStore.RecordProgress(&WatchProgress{
		ProxyUserID:    user.ID,
		VirtualItemID:  virtualID,
		ServerIndex:    0,
		OriginalItemID: primaryID,
		PositionTicks:  positionTicks,
		RuntimeTicks:   runtimeTicks,
	}); err != nil {
		t.Fatalf("record progress for %s: %v", username, err)
	}
}

func resetAtomicCounters(counters ...*atomic.Int32) {
	for _, counter := range counters {
		if counter != nil {
			counter.Store(0)
		}
	}
}

func TestAuthFixtureBuildsMergedVirtualItemForLimitedUserScenarios(t *testing.T) {
	var searchHitsA atomic.Int32
	var searchHitsB atomic.Int32
	serverA, serverB := newAuthPriorityDualServers(t, "tmdb-helper-fixture", authReviewServerOptions{searchHits: &searchHitsA}, authReviewServerOptions{searchHits: &searchHitsB})
	defer serverA.Close()
	defer serverB.Close()

	withTempAppConfig(t, authPriorityDualConfig(serverA.server.URL, serverB.server.URL), func(app *App, handler http.Handler) {
		adminToken := loginTokenAs(t, handler, "admin", "secret")
		collectorToken := createLimitedUserAndToken(t, handler, adminToken, "collector", "collector123", []int{0, 1})
		virtualID := createMergedVirtualIDThroughSearch(t, handler, collectorToken, "fixture")
		if virtualID == "" {
			t.Fatal("expected merged virtual id")
		}
		if searchHitsA.Load() == 0 || searchHitsB.Load() == 0 {
			t.Fatalf("expected fixture search to touch both servers, got A=%d B=%d", searchHitsA.Load(), searchHitsB.Load())
		}
	})
}
