package backend

import (
	"context"
	"fmt"
	"io"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
)

type testRoundTripper func(*http.Request) (*http.Response, error)

func (fn testRoundTripper) RoundTrip(r *http.Request) (*http.Response, error) {
	return fn(r)
}

func TestStreamAbsoluteRedactsSensitiveQueryValuesFromDebugLogs(t *testing.T) {
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		_, _ = io.WriteString(w, "ok")
	}))
	defer server.Close()
	logger := NewLogger(LogConfig{Level: "error", FileLevel: "error", DataDir: t.TempDir()})
	defer logger.Close()
	client := &UpstreamClient{Name: "A", transport: http.DefaultTransport, logger: logger}
	requestURL := server.URL + "/video.ts?API_KEY=real-api-key&access_token=real-access-token&X-EMBY-TOKEN=real-header-token&safe=value"

	resp, err := client.StreamAbsolute(context.Background(), nil, nil, requestURL)
	if err != nil {
		t.Fatalf("StreamAbsolute: %v", err)
	}
	resp.Body.Close()
	assertUpstreamLogSecretsRedacted(t, logger, "real-api-key", "real-access-token", "real-header-token")
}

func TestStreamAbsoluteRedactsSensitiveQueryValuesFromErrorLogs(t *testing.T) {
	logger := NewLogger(LogConfig{Level: "error", FileLevel: "error", DataDir: t.TempDir()})
	defer logger.Close()
	client := &UpstreamClient{
		Name:   "A",
		logger: logger,
		transport: testRoundTripper(func(r *http.Request) (*http.Response, error) {
			return nil, fmt.Errorf("dial failed for %s", r.URL.String())
		}),
	}
	requestURL := "https://stream.example/video.ts?Api_Key=error-api-key&ACCESS_TOKEN=error-access-token"

	if _, err := client.StreamAbsolute(context.Background(), nil, nil, requestURL); err == nil {
		t.Fatal("expected StreamAbsolute error")
	}
	assertUpstreamLogSecretsRedacted(t, logger, "error-api-key", "error-access-token")
}

func assertUpstreamLogSecretsRedacted(t *testing.T, logger *Logger, secrets ...string) {
	t.Helper()
	var messages strings.Builder
	for _, entry := range logger.Entries(0) {
		messages.WriteString(entry.Message)
		messages.WriteByte('\n')
	}
	logged := messages.String()
	for _, secret := range secrets {
		if strings.Contains(logged, secret) {
			t.Fatalf("log leaked secret %q: %s", secret, logged)
		}
	}
	if !strings.Contains(logged, "redacted") {
		t.Fatalf("expected redaction marker in logs: %s", logged)
	}
}
