package backend

import (
	"context"
	"net/http"
	"strings"
	"time"
)

const webSessionCookieName = "eio_web_session"

type webLoginRequest struct {
	Username string `json:"username"`
	Password string `json:"password"`
}

func (a *App) registerWebAuthRoutes(mux *http.ServeMux) {
	mux.HandleFunc("POST /web/api/login", a.handleWebLogin)
	mux.HandleFunc("POST /web/api/logout", a.withWebContext(a.requireWebUser(a.handleWebLogout)))
	mux.HandleFunc("GET /web/api/me", a.withWebContext(a.requireWebUser(a.handleWebMe)))
}

func (a *App) withWebContext(next http.HandlerFunc) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		token := webSessionToken(r)
		source := authSourceNone
		if token != "" {
			source = authSourceWebCookie
		}
		var proxyUser *tokenInfo
		if token != "" {
			proxyUser = a.Auth.ValidateToken(token)
		}
		if a.Logger != nil {
			role := ""
			if proxyUser != nil {
				role = proxyUser.Role
			}
			a.Logger.Debugf("Web context: path=%s hasSessionCookie=%t hasToken=%t hasProxyUser=%t role=%s",
				r.URL.Path,
				token != "",
				token != "",
				proxyUser != nil,
				role,
			)
		}
		ctx := context.WithValue(r.Context(), requestContextKey{}, &RequestContext{
			Headers:    r.Header.Clone(),
			ProxyToken: token,
			ProxyUser:  proxyUser,
			AuthSource: source,
		})
		next(w, r.WithContext(ctx))
	}
}

func (a *App) requireWebUser(next http.HandlerFunc) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		reqCtx := requestContextFrom(r.Context())
		if reqCtx == nil || reqCtx.ProxyUser == nil {
			if a.Logger != nil {
				a.Logger.Warnf("Web auth rejected: path=%s reason=no-session-user status=401", r.URL.Path)
			}
			writeJSON(w, http.StatusUnauthorized, map[string]any{"message": "Authentication required"})
			return
		}
		if reqCtx.ProxyUser.Role != "user" {
			if a.Logger != nil {
				a.Logger.Warnf("Web auth rejected: path=%s reason=admin-not-supported status=403", r.URL.Path)
			}
			writeJSON(w, http.StatusForbidden, map[string]any{"message": "Administrator accounts are not supported in /web"})
			return
		}
		next(w, r)
	}
}

func webSessionToken(r *http.Request) string {
	cookie, err := r.Cookie(webSessionCookieName)
	if err != nil {
		return ""
	}
	return cookie.Value
}

func webRequestIsHTTPS(r *http.Request) bool {
	if r.TLS != nil {
		return true
	}
	if proto := r.Header.Get("X-Forwarded-Proto"); proto != "" {
		if idx := strings.Index(proto, ","); idx >= 0 {
			proto = proto[:idx]
		}
		return strings.EqualFold(strings.TrimSpace(proto), "https")
	}
	return false
}

func (a *App) handleWebLogin(w http.ResponseWriter, r *http.Request) {
	ip := clientIP(r, a.ConfigStore.Snapshot().Server.TrustProxy)
	if !a.loginLimiter.checkAndRecord(ip) {
		writeJSON(w, http.StatusTooManyRequests, map[string]any{"message": "Too many failed login attempts, please try again later"})
		return
	}

	var body webLoginRequest
	if err := decodeJSONBody(r, &body); err != nil {
		writeJSON(w, http.StatusBadRequest, map[string]any{"message": "Invalid request body"})
		return
	}
	if a.UserStore == nil {
		writeJSON(w, http.StatusServiceUnavailable, map[string]any{"message": "Web viewer requires normal users"})
		return
	}

	if a.Auth.VerifyAdminCredentials(body.Username, body.Password) {
		a.loginLimiter.recordSuccess(ip)
		writeJSON(w, http.StatusForbidden, map[string]any{"message": "Administrator accounts are not supported in /web"})
		return
	}

	user := a.UserStore.Authenticate(body.Username, body.Password)
	if user == nil {
		writeJSON(w, http.StatusUnauthorized, map[string]any{"message": "Invalid username or password"})
		return
	}

	_, token, err := a.Auth.AuthenticateUser(user)
	if err != nil {
		writeJSON(w, http.StatusInternalServerError, map[string]any{"message": err.Error()})
		return
	}

	a.loginLimiter.recordSuccess(ip)

	http.SetCookie(w, &http.Cookie{
		Name:     webSessionCookieName,
		Value:    token,
		Path:     "/",
		HttpOnly: true,
		Secure:   webRequestIsHTTPS(r),
		SameSite: http.SameSiteLaxMode,
		MaxAge:   int((30 * 24 * time.Hour).Seconds()),
	})

	writeJSON(w, http.StatusOK, map[string]any{
		"id":       user.ID,
		"username": user.Username,
	})
}

func (a *App) handleWebLogout(w http.ResponseWriter, r *http.Request) {
	if token := webSessionToken(r); token != "" {
		a.Auth.RevokeToken(token)
	}
	http.SetCookie(w, &http.Cookie{
		Name:     webSessionCookieName,
		Value:    "",
		Path:     "/",
		HttpOnly: true,
		Secure:   webRequestIsHTTPS(r),
		SameSite: http.SameSiteLaxMode,
		MaxAge:   -1,
	})
	w.WriteHeader(http.StatusNoContent)
}

func (a *App) handleWebMe(w http.ResponseWriter, r *http.Request) {
	reqCtx := requestContextFrom(r.Context())
	user := a.UserStore.Get(reqCtx.ProxyUser.UserID)
	if user == nil {
		writeJSON(w, http.StatusUnauthorized, map[string]any{"message": "User no longer exists"})
		return
	}
	writeJSON(w, http.StatusOK, map[string]any{
		"id":             user.ID,
		"username":       user.Username,
		"allowedServers": user.AllowedServers,
	})
}
