package backend

import (
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
)

func tokenCount(app *App) int {
	app.Auth.mu.RLock()
	defer app.Auth.mu.RUnlock()
	return len(app.Auth.tokens)
}

func TestWebLoginSetsCookieForRegularUserAndRejectsAdmin(t *testing.T) {
	withTempApp(t, func(app *App, handler http.Handler) {
		user, err := app.UserStore.Create("alice", "pw-1", []int{0})
		if err != nil {
			t.Fatalf("create user: %v", err)
		}
		if user == nil {
			t.Fatal("expected created user")
		}

		userLogin := doJSONRequest(t, handler, http.MethodPost, "/web/api/login", map[string]string{
			"username": "alice",
			"password": "pw-1",
		}, "")
		if userLogin.Code != http.StatusOK {
			t.Fatalf("user login status = %d, body=%s", userLogin.Code, userLogin.Body.String())
		}
		cookies := userLogin.Result().Cookies()
		if len(cookies) != 1 || cookies[0].Name != webSessionCookieName || !cookies[0].HttpOnly {
			t.Fatalf("unexpected cookies: %#v", cookies)
		}

		adminLogin := doJSONRequest(t, handler, http.MethodPost, "/web/api/login", map[string]string{
			"username": "admin",
			"password": "secret",
		}, "")
		if adminLogin.Code != http.StatusForbidden {
			t.Fatalf("admin login status = %d, body=%s", adminLogin.Code, adminLogin.Body.String())
		}
	})
}

func TestWebLoginAdminAttemptDoesNotCreateOrphanToken(t *testing.T) {
	withTempApp(t, func(app *App, handler http.Handler) {
		before := tokenCount(app)
		rr := doJSONRequest(t, handler, http.MethodPost, "/web/api/login", map[string]string{
			"username": "admin",
			"password": "secret",
		}, "")
		if rr.Code != http.StatusForbidden {
			t.Fatalf("status = %d, want 403 body=%s", rr.Code, rr.Body.String())
		}
		if got := tokenCount(app); got != before {
			t.Fatalf("token count changed: before=%d after=%d", before, got)
		}
	})
}

func TestWebMeUsesCookieAndLogoutRevokesToken(t *testing.T) {
	withTempApp(t, func(app *App, handler http.Handler) {
		user, err := app.UserStore.Create("bob", "pw-2", []int{0})
		if err != nil {
			t.Fatalf("create user: %v", err)
		}
		login := doJSONRequest(t, handler, http.MethodPost, "/web/api/login", map[string]string{
			"username": user.Username,
			"password": "pw-2",
		}, "")
		if login.Code != http.StatusOK {
			t.Fatalf("login status = %d, body=%s", login.Code, login.Body.String())
		}
		cookie := login.Result().Cookies()[0]

		meReq := httptest.NewRequest(http.MethodGet, "/web/api/me", nil)
		meReq.AddCookie(cookie)
		meRR := httptest.NewRecorder()
		handler.ServeHTTP(meRR, meReq)
		if meRR.Code != http.StatusOK {
			t.Fatalf("GET /web/api/me status = %d, body=%s", meRR.Code, meRR.Body.String())
		}
		var payload map[string]any
		if err := json.Unmarshal(meRR.Body.Bytes(), &payload); err != nil {
			t.Fatalf("unmarshal me payload: %v", err)
		}
		if payload["username"] != "bob" {
			t.Fatalf("username = %#v", payload["username"])
		}

		logoutReq := httptest.NewRequest(http.MethodPost, "/web/api/logout", nil)
		logoutReq.AddCookie(cookie)
		logoutRR := httptest.NewRecorder()
		handler.ServeHTTP(logoutRR, logoutReq)
		if logoutRR.Code != http.StatusNoContent {
			t.Fatalf("logout status = %d, body=%s", logoutRR.Code, logoutRR.Body.String())
		}

		meAfter := httptest.NewRequest(http.MethodGet, "/web/api/me", nil)
		meAfter.AddCookie(cookie)
		meAfterRR := httptest.NewRecorder()
		handler.ServeHTTP(meAfterRR, meAfter)
		if meAfterRR.Code != http.StatusUnauthorized {
			t.Fatalf("GET /web/api/me after logout status = %d", meAfterRR.Code)
		}
	})
}

func TestWebLoginRateLimitedAfterFailedAttempts(t *testing.T) {
	withTempApp(t, func(app *App, handler http.Handler) {
		user, err := app.UserStore.Create("eve", "right-pw", []int{0})
		if err != nil {
			t.Fatalf("create user: %v", err)
		}
		if user == nil {
			t.Fatal("expected created user")
		}

		for i := 0; i < loginMaxFailures; i++ {
			rr := doJSONRequest(t, handler, http.MethodPost, "/web/api/login", map[string]string{
				"username": "eve",
				"password": "wrong-pw",
			}, "")
			if rr.Code != http.StatusUnauthorized {
				t.Fatalf("attempt %d status = %d body=%s", i, rr.Code, rr.Body.String())
			}
		}

		rr := doJSONRequest(t, handler, http.MethodPost, "/web/api/login", map[string]string{
			"username": "eve",
			"password": "right-pw",
		}, "")
		if rr.Code != http.StatusTooManyRequests {
			t.Fatalf("rate-limited attempt status = %d, want 429 body=%s", rr.Code, rr.Body.String())
		}
	})
}

func TestWebCookieSecureWhenForwardedProtoHTTPS(t *testing.T) {
	withTempApp(t, func(app *App, handler http.Handler) {
		user, err := app.UserStore.Create("carol", "pw-3", []int{0})
		if err != nil {
			t.Fatalf("create user: %v", err)
		}
		req := httptest.NewRequest(http.MethodPost, "/web/api/login", strings.NewReader(`{"username":"`+user.Username+`","password":"pw-3"}`))
		req.Header.Set("Content-Type", "application/json")
		req.Header.Set("X-Forwarded-Proto", "https")
		rr := httptest.NewRecorder()
		handler.ServeHTTP(rr, req)
		if rr.Code != http.StatusOK {
			t.Fatalf("login status = %d body=%s", rr.Code, rr.Body.String())
		}
		cookies := rr.Result().Cookies()
		if len(cookies) != 1 || !cookies[0].Secure {
			t.Fatalf("cookie not Secure under HTTPS proxy: %#v", cookies)
		}
	})
}

func TestWebCookieNotSecureUnderPlainHTTP(t *testing.T) {
	withTempApp(t, func(app *App, handler http.Handler) {
		user, err := app.UserStore.Create("dave", "pw-4", []int{0})
		if err != nil {
			t.Fatalf("create user: %v", err)
		}
		rr := doJSONRequest(t, handler, http.MethodPost, "/web/api/login", map[string]string{
			"username": user.Username,
			"password": "pw-4",
		}, "")
		if rr.Code != http.StatusOK {
			t.Fatalf("login status = %d body=%s", rr.Code, rr.Body.String())
		}
		cookies := rr.Result().Cookies()
		if len(cookies) != 1 || cookies[0].Secure {
			t.Fatalf("cookie should not be Secure under plain HTTP: %#v", cookies)
		}
	})
}
