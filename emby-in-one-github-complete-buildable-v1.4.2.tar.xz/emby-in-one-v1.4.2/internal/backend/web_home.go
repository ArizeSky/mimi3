package backend

import (
	"fmt"
	"net/http"
	"net/url"
)

type webMediaCard struct {
	ID             string         `json:"id"`
	Name           string         `json:"name"`
	Type           string         `json:"type"`
	Image          string         `json:"image,omitempty"`
	Overview       string         `json:"overview,omitempty"`
	Subtitle       string         `json:"subtitle,omitempty"`
	UserData       map[string]any `json:"userData,omitempty"`
	RuntimeTicks   int64          `json:"runtimeTicks,omitempty"`
	ProductionYear int            `json:"productionYear,omitempty"`
}

type webHomeSection struct {
	ID    string         `json:"id"`
	Name  string         `json:"name"`
	Items []webMediaCard `json:"items"`
}

type webHomeResponse struct {
	User   map[string]any   `json:"user"`
	Resume []webMediaCard   `json:"resume"`
	Views  []webHomeSection `json:"views"`
	Latest []webMediaCard   `json:"latest"`
	NextUp []webMediaCard   `json:"nextUp"`
}

func (a *App) handleWebHome(w http.ResponseWriter, r *http.Request) {
	reqCtx := requestContextFrom(r.Context())
	writeJSON(w, http.StatusOK, webHomeResponse{
		User:   a.webViewerUser(reqCtx),
		Resume: a.webResumeCards(r, reqCtx, 12),
		Views:  a.webHomeViews(r, reqCtx, 12),
		Latest: a.webLatestCards(r, reqCtx, 12),
		NextUp: a.webNextUpCards(r, reqCtx, 12),
	})
}

func (a *App) handleWebResume(w http.ResponseWriter, r *http.Request) {
	reqCtx := requestContextFrom(r.Context())
	writeJSON(w, http.StatusOK, map[string]any{"items": a.webResumeCards(r, reqCtx, 50)})
}

func (a *App) webViewerUser(reqCtx *RequestContext) map[string]any {
	if reqCtx == nil || reqCtx.ProxyUser == nil || a.UserStore == nil {
		return map[string]any{}
	}
	user := a.UserStore.Get(reqCtx.ProxyUser.UserID)
	if user == nil {
		return map[string]any{}
	}
	return map[string]any{
		"id":       user.ID,
		"username": user.Username,
	}
}

func (a *App) webResumeCards(r *http.Request, reqCtx *RequestContext, limit int) []webMediaCard {
	if a.WatchStore == nil || reqCtx == nil || reqCtx.ProxyUser == nil {
		return []webMediaCard{}
	}
	items, err := a.WatchStore.GetResumeItems(reqCtx.ProxyUser.UserID, limit)
	if err != nil || len(items) == 0 {
		return []webMediaCard{}
	}
	cards := make([]webMediaCard, 0, len(items))
	for _, progress := range items {
		card, ok := a.webResumeCard(r, reqCtx, progress)
		if ok {
			cards = append(cards, card)
		}
	}
	return cards
}

func (a *App) webResumeCard(r *http.Request, reqCtx *RequestContext, progress WatchProgress) (webMediaCard, bool) {
	item := a.webResumeDisplayItem(r, reqCtx, progress)
	if item == nil {
		return webMediaCard{}, false
	}
	imageID := webString(item["Id"])
	if progress.ItemType == "Episode" && progress.SeriesVirtualID != "" {
		imageID = progress.SeriesVirtualID
	}
	runtimeTicks := webInt64(item["RunTimeTicks"])
	if runtimeTicks == 0 {
		runtimeTicks = progress.RuntimeTicks
	}
	productionYear := webInt(item["ProductionYear"])
	if productionYear == 0 {
		productionYear = progress.ProductionYear
	}
	return webMediaCard{
		ID:             progress.VirtualItemID,
		Name:           firstNonEmpty(webString(item["Name"]), progress.SeriesName, progress.Name),
		Type:           firstNonEmpty(webString(item["Type"]), progress.ItemType),
		Image:          webImageURL(imageID),
		Overview:       webString(item["Overview"]),
		Subtitle:       webResumeSubtitle(progress),
		UserData:       webResumeUserData(item, progress),
		RuntimeTicks:   runtimeTicks,
		ProductionYear: productionYear,
	}, true
}

func (a *App) webResumeDisplayItem(r *http.Request, reqCtx *RequestContext, progress WatchProgress) map[string]any {
	if progress.ItemType == "Episode" && progress.SeriesVirtualID != "" {
		if resolved := a.resolveRouteIDForRequest(reqCtx, progress.SeriesVirtualID); resolved != nil {
			return a.webResumeFetchItem(r, reqCtx, resolved.Client.UserID, resolved.OriginalID, resolved.ServerIndex, resolved.Client)
		}
	}
	serverIndex, originalID, ok := a.resolveWatchItemServerForRequest(reqCtx, &progress)
	if !ok {
		return nil
	}
	client := a.Upstream.GetClient(serverIndex)
	if client == nil || !client.IsOnline() {
		return nil
	}
	return a.webResumeFetchItem(r, reqCtx, client.UserID, originalID, serverIndex, client)
}

func (a *App) webResumeFetchItem(r *http.Request, reqCtx *RequestContext, userID, originalID string, serverIndex int, client *UpstreamClient) map[string]any {
	payload, err := client.RequestJSON(r.Context(), reqCtx, a.Identity, http.MethodGet, "/Users/"+userID+"/Items/"+originalID, nil, nil)
	if err != nil {
		return nil
	}
	item, ok := payload.(map[string]any)
	if !ok {
		return nil
	}
	rewriteResponseIDs(item, serverIndex, a.IDStore, a.ConfigStore.Snapshot().Server.ID, a.Auth.ProxyUserID())
	return item
}

func webResumeUserData(item map[string]any, progress WatchProgress) map[string]any {
	userData := map[string]any{}
	for key, value := range webMap(item["UserData"]) {
		userData[key] = value
	}
	userData["PlaybackPositionTicks"] = progress.PositionTicks
	userData["Played"] = progress.Played
	userData["IsFavorite"] = progress.IsFavorite
	return userData
}

func webResumeSubtitle(progress WatchProgress) string {
	if progress.ItemType != "Episode" {
		return ""
	}
	label := ""
	if progress.ParentIndexNumber > 0 && progress.IndexNumber > 0 {
		label = fmt.Sprintf("第%d季 第%d集", progress.ParentIndexNumber, progress.IndexNumber)
	} else if progress.IndexNumber > 0 {
		label = fmt.Sprintf("第%d集", progress.IndexNumber)
	}
	if progress.Name == "" {
		return label
	}
	if label == "" {
		return progress.Name
	}
	return label + " · " + progress.Name
}

func (a *App) webHomeViews(r *http.Request, reqCtx *RequestContext, limit int) []webHomeSection {
	views := a.webFetchUserViews(r, reqCtx)
	sections := make([]webHomeSection, 0, len(views))
	for _, view := range views {
		parentID := webString(view["Id"])
		if parentID == "" {
			continue
		}
		query := url.Values{}
		query.Set("ParentId", parentID)
		query.Set("Limit", intToString(limit))
		sections = append(sections, webHomeSection{
			ID:    parentID,
			Name:  webString(view["Name"]),
			Items: a.webCardsFromItems(a.webFetchLatestForParent(r, reqCtx, query)),
		})
	}
	return sections
}

func (a *App) webFetchUserViews(r *http.Request, reqCtx *RequestContext) []map[string]any {
	clients := a.allowedClients(reqCtx)
	cfg := a.ConfigStore.Snapshot()
	allViews := make([]map[string]any, 0)
	multiSource := len(clients) > 1
	for _, client := range clients {
		payload, err := client.RequestJSON(r.Context(), reqCtx, a.Identity, http.MethodGet, "/Users/"+client.UserID+"/Views", nil, nil)
		if err != nil {
			continue
		}
		for _, view := range asItems(payload) {
			rewritten := deepCloneMap(view)
			rewriteResponseIDs(rewritten, client.ServerIndex, a.IDStore, cfg.Server.ID, a.Auth.ProxyUserID())
			if multiSource {
				rewritten["Name"] = webString(rewritten["Name"]) + " (" + client.Name + ")"
			}
			allViews = append(allViews, rewritten)
		}
	}
	return allViews
}

func (a *App) webFetchLatestForParent(r *http.Request, reqCtx *RequestContext, query url.Values) []map[string]any {
	parentID := query.Get("ParentId")
	if parentID == "" {
		return []map[string]any{}
	}
	resolved := a.resolveRouteIDForRequest(reqCtx, parentID)
	if resolved == nil {
		return []map[string]any{}
	}
	upstreamQuery := cloneValues(query)
	upstreamQuery.Set("ParentId", resolved.OriginalID)
	payload, err := resolved.Client.RequestJSON(r.Context(), reqCtx, a.Identity, http.MethodGet, "/Users/"+resolved.Client.UserID+"/Items/Latest", upstreamQuery, nil)
	if err != nil {
		return []map[string]any{}
	}
	items := asItems(payload)
	a.rewriteItems(items, resolved.ServerIndex)
	a.overlayLocalUserDataItems(r, items)
	return items
}

func (a *App) webLatestCards(r *http.Request, reqCtx *RequestContext, limit int) []webMediaCard {
	results := a.fetchItemsAcrossUpstreams(r.Context(), reqCtx, "/Users/%s/Items/Latest", url.Values{"Limit": {intToString(limit)}}, nil)
	merged := a.mergedItemsPayload(results)
	items := asItems(merged)
	a.overlayLocalUserDataItems(r, items)
	return a.webCardsFromItems(items)
}

func (a *App) webNextUpCards(r *http.Request, reqCtx *RequestContext, limit int) []webMediaCard {
	results := a.fetchItemsAcrossUpstreams(r.Context(), reqCtx, "/Shows/NextUp", url.Values{"Limit": {intToString(limit)}}, nil)
	merged := a.mergedItemsPayload(results)
	items := asItems(merged)
	a.overlayLocalUserDataItems(r, items)
	return a.webCardsFromItems(items)
}

func (a *App) webCardsFromItems(items []map[string]any) []webMediaCard {
	cards := make([]webMediaCard, 0, len(items))
	for _, item := range items {
		id := webString(item["Id"])
		cards = append(cards, webMediaCard{
			ID:             id,
			Name:           webString(item["Name"]),
			Type:           webString(item["Type"]),
			Image:          webImageURL(id),
			Overview:       webString(item["Overview"]),
			Subtitle:       webString(item["Subtitle"]),
			UserData:       webMap(item["UserData"]),
			RuntimeTicks:   webInt64(item["RunTimeTicks"]),
			ProductionYear: webInt(item["ProductionYear"]),
		})
	}
	return cards
}

func webImageURL(id string) string {
	if id == "" {
		return ""
	}
	return fmt.Sprintf("/Items/%s/Images/Primary", id)
}

func webString(value any) string {
	if text, ok := value.(string); ok {
		return text
	}
	return ""
}

func webMap(value any) map[string]any {
	if m, ok := value.(map[string]any); ok {
		return m
	}
	return nil
}

func webInt(value any) int {
	switch v := value.(type) {
	case float64:
		return int(v)
	case int:
		return v
	case int64:
		return int(v)
	default:
		return 0
	}
}

func webInt64(value any) int64 {
	switch v := value.(type) {
	case float64:
		return int64(v)
	case int:
		return int64(v)
	case int64:
		return v
	default:
		return 0
	}
}
