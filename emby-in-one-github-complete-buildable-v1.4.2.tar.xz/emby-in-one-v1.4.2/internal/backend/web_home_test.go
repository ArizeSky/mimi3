package backend

import (
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"strings"
	"sync/atomic"
	"testing"
)


func TestWebHomeReturnsResumeViewsAndLatest(t *testing.T) {
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch r.URL.Path {
		case "/Users/AuthenticateByName":
			_ = json.NewEncoder(w).Encode(map[string]any{"AccessToken": "tok-a", "User": map[string]any{"Id": "user-a"}})
		case "/Users/user-a/Views":
			_ = json.NewEncoder(w).Encode(map[string]any{"Items": []map[string]any{{"Id": "view-1", "Name": "电影"}}})
		case "/Users/user-a/Items/Latest":
			_ = json.NewEncoder(w).Encode([]map[string]any{{"Id": "movie-1", "Name": "Movie One", "Type": "Movie"}})
		case "/Shows/NextUp":
			_ = json.NewEncoder(w).Encode(map[string]any{"Items": []map[string]any{{"Id": "ep-1", "Name": "Episode One", "Type": "Episode"}}})
		case "/Items":
			_ = json.NewEncoder(w).Encode(map[string]any{"Items": []map[string]any{{"Id": "movie-1", "Name": "Movie One", "Type": "Movie"}}})
		default:
			http.NotFound(w, r)
		}
	}))
	defer srv.Close()

	withTempAppPrepared(t, singleUpstreamConfig(srv.URL), nil, func(app *App, handler http.Handler, dir string) {
		user, err := app.UserStore.Create("alice", "pw-1", []int{0})
		if err != nil {
			t.Fatalf("create user: %v", err)
		}
		virtualID := app.IDStore.GetOrCreateVirtualID("movie-1", 0)
		if err := app.WatchStore.RecordProgress(&WatchProgress{
			ProxyUserID:    user.ID,
			VirtualItemID:  virtualID,
			ServerIndex:    0,
			OriginalItemID: "movie-1",
			PositionTicks:  100,
			RuntimeTicks:   1000,
		}); err != nil {
			t.Fatalf("record progress: %v", err)
		}

		login := doJSONRequest(t, handler, http.MethodPost, "/web/api/login", map[string]string{"username": "alice", "password": "pw-1"}, "")
		if login.Code != http.StatusOK {
			t.Fatalf("login status = %d, body=%s", login.Code, login.Body.String())
		}

		req := httptest.NewRequest(http.MethodGet, "/web/api/home", nil)
		req.AddCookie(login.Result().Cookies()[0])
		rr := httptest.NewRecorder()
		handler.ServeHTTP(rr, req)
		if rr.Code != http.StatusOK {
			t.Fatalf("GET /web/api/home status = %d, body=%s", rr.Code, rr.Body.String())
		}
		if !strings.Contains(rr.Body.String(), `"resume"`) || !strings.Contains(rr.Body.String(), `"views"`) || !strings.Contains(rr.Body.String(), `"latest"`) {
			t.Fatalf("home payload missing required sections: %s", rr.Body.String())
		}
	})
}

func TestWebResumeRequiresNormalUserCookie(t *testing.T) {
	withTempApp(t, func(app *App, handler http.Handler) {
		rr := doJSONRequest(t, handler, http.MethodGet, "/web/api/resume", nil, "")
		if rr.Code != http.StatusUnauthorized {
			t.Fatalf("GET /web/api/resume status = %d", rr.Code)
		}
	})
}

func TestWebResumeProjectsEpisodeAsSeriesCard(t *testing.T) {
	upstream := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch r.URL.Path {
		case "/Users/AuthenticateByName":
			_ = json.NewEncoder(w).Encode(map[string]any{"AccessToken": "tok-a", "User": map[string]any{"Id": "user-a"}})
		case "/Users/user-a/Items/series-a":
			_ = json.NewEncoder(w).Encode(map[string]any{
				"Id":             "series-a",
				"Name":           "大江大河",
				"Type":           "Series",
				"Overview":       "时代浪潮下的家庭与命运",
				"ProductionYear": 2018,
				"RunTimeTicks":   450000000,
				"UserData":       map[string]any{},
			})
		case "/Users/user-a/Items/episode-a7":
			_ = json.NewEncoder(w).Encode(map[string]any{
				"Id":                "episode-a7",
				"Name":              "第7集",
				"Type":              "Episode",
				"SeriesName":        "大江大河",
				"SeriesId":          "series-a",
				"ParentIndexNumber": 1,
				"IndexNumber":       7,
				"RunTimeTicks":      450000000,
				"UserData":          map[string]any{},
			})
		case "/Items":
			_ = json.NewEncoder(w).Encode(map[string]any{"Items": []map[string]any{{
				"Id":             "episode-a7",
				"Name":           "第7集",
				"Type":           "Episode",
				"SeriesName":     "大江大河",
				"SeriesId":       "series-a",
				"ProductionYear": 2018,
				"RunTimeTicks":   450000000,
				"UserData":       map[string]any{},
			}}})
		default:
			http.NotFound(w, r)
		}
	}))
	defer upstream.Close()

	withTempAppPrepared(t, singleUpstreamConfig(upstream.URL), nil, func(app *App, handler http.Handler, dir string) {
		user, err := app.UserStore.Create("alice", "pw-1", []int{0})
		if err != nil {
			t.Fatalf("create user: %v", err)
		}
		seriesVirtualID := app.IDStore.GetOrCreateVirtualID("series-a", 0)
		episodeVirtualID := app.IDStore.GetOrCreateVirtualID("episode-a7", 0)
		if err := app.WatchStore.RecordProgress(&WatchProgress{
			ProxyUserID:       user.ID,
			VirtualItemID:     episodeVirtualID,
			ServerIndex:       0,
			OriginalItemID:    "episode-a7",
			ItemType:          "Episode",
			SeriesVirtualID:   seriesVirtualID,
			SeriesOriginalID:  "series-a",
			SeriesName:        "大江大河",
			ParentIndexNumber: 1,
			IndexNumber:       7,
			Name:              "第7集",
			PositionTicks:     120,
			RuntimeTicks:      1000,
		}); err != nil {
			t.Fatalf("record progress: %v", err)
		}

		login := doJSONRequest(t, handler, http.MethodPost, "/web/api/login", map[string]string{"username": "alice", "password": "pw-1"}, "")
		if login.Code != http.StatusOK {
			t.Fatalf("login status = %d, body=%s", login.Code, login.Body.String())
		}

		req := httptest.NewRequest(http.MethodGet, "/web/api/resume", nil)
		req.AddCookie(login.Result().Cookies()[0])
		rr := httptest.NewRecorder()
		handler.ServeHTTP(rr, req)
		if rr.Code != http.StatusOK {
			t.Fatalf("GET /web/api/resume status = %d, body=%s", rr.Code, rr.Body.String())
		}

		var payload map[string]any
		if err := json.Unmarshal(rr.Body.Bytes(), &payload); err != nil {
			t.Fatalf("unmarshal resume payload: %v", err)
		}
		items, _ := payload["items"].([]any)
		if len(items) != 1 {
			t.Fatalf("expected one resume item, got %d: %s", len(items), rr.Body.String())
		}
		first, _ := items[0].(map[string]any)
		if first["id"] != episodeVirtualID {
			t.Fatalf("resume id = %v, want episode virtual id %q", first["id"], episodeVirtualID)
		}
		if first["name"] != "大江大河" {
			t.Fatalf("resume name = %v, want series name", first["name"])
		}
		if first["image"] != "/Items/"+seriesVirtualID+"/Images/Primary" {
			t.Fatalf("resume image = %v, want series poster", first["image"])
		}
		subtitle, _ := first["subtitle"].(string)
		if subtitle == "" || !strings.Contains(subtitle, "第7集") {
			t.Fatalf("resume subtitle = %q, want current episode info", subtitle)
		}
		userData, _ := first["userData"].(map[string]any)
		if userData == nil || userData["PlaybackPositionTicks"] != float64(120) {
			t.Fatalf("resume userData missing playback position: %#v", userData)
		}
	})
}

func TestWebResumeDoesNotUseUnauthorizedPrimaryInstance(t *testing.T) {
	var detailHitsA atomic.Int32
	var detailHitsB atomic.Int32

	srvA, srvB := newAuthPriorityDualServers(t, "tmdb-resume-auth",
		authReviewServerOptions{detailHits: &detailHitsA},
		authReviewServerOptions{detailHits: &detailHitsB},
	)
	defer srvA.Close()
	defer srvB.Close()

	withTempAppPrepared(t, authPriorityDualConfig(srvA.server.URL, srvB.server.URL), nil, func(app *App, handler http.Handler, dir string) {
		createResumeWatchProgress(t, app, "bob", "bob123", []int{1}, "item-a", "item-b", 120, 1000)
		login := doJSONRequest(t, handler, http.MethodPost, "/web/api/login", map[string]string{"username": "bob", "password": "bob123"}, "")
		if login.Code != http.StatusOK {
			t.Fatalf("login status=%d body=%s", login.Code, login.Body.String())
		}

		resetAtomicCounters(&detailHitsA, &detailHitsB)
		req := httptest.NewRequest(http.MethodGet, "/web/api/resume", nil)
		req.AddCookie(login.Result().Cookies()[0])
		rr := httptest.NewRecorder()
		handler.ServeHTTP(rr, req)
		if rr.Code != http.StatusOK {
			t.Fatalf("GET /web/api/resume status=%d body=%s", rr.Code, rr.Body.String())
		}
		if detailHitsA.Load() != 0 {
			t.Fatalf("expected resume enrichment not to hit unauthorized server A, got A=%d body=%s", detailHitsA.Load(), rr.Body.String())
		}
		if detailHitsB.Load() == 0 {
			t.Fatalf("expected resume enrichment to hit allowed server B, got B=%d", detailHitsB.Load())
		}
	})
}
