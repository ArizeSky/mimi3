package backend

import (
	"encoding/json"
	"fmt"
	"net/http"
	"net/http/httptest"
	"net/url"
	"path"
	"sort"
	"strconv"
	"strings"
)

type webItemResponse struct {
	Item             map[string]any     `json:"item"`
	Seasons          []map[string]any   `json:"seasons"`
	Episodes         []map[string]any   `json:"episodes"`
	Versions         []map[string]any   `json:"versions"`
	AudioTracks      []map[string]any   `json:"audioTracks"`
	SubtitleTracks   []webSubtitleTrack `json:"subtitleTracks"`
	ResumePosition   int64              `json:"resumePosition"`
	DefaultSelection map[string]any     `json:"defaultSelection"`
}

type webPlaybackInfoResult struct {
	Payload map[string]any
	Status  int
	Message string
}

func (a *App) handleWebItem(w http.ResponseWriter, r *http.Request) {
	itemID := r.PathValue("itemId")
	if a.Logger != nil {
		reqCtx := requestContextFrom(r.Context())
		a.Logger.Debugf("Web item request: itemId=%s hasProxyUser=%t", itemID, reqCtx != nil && reqCtx.ProxyUser != nil)
	}
	item := a.webLoadItemDetail(r, itemID)
	if item == nil {
		if a.Logger != nil {
			a.Logger.Warnf("Web item request failed: itemId=%s reason=item-not-found", itemID)
		}
		writeJSON(w, http.StatusNotFound, map[string]any{"message": "Item not found"})
		return
	}
	playback := a.webLoadPlaybackInfo(r, itemID)
	writeJSON(w, http.StatusOK, webItemResponse{
		Item:             sanitizeWebItem(item),
		Seasons:          sanitizeWebItems(a.webLoadSeasons(r, itemID, item)),
		Episodes:         sanitizeWebItems(a.webLoadEpisodes(r, itemID, item)),
		Versions:         a.webVersionOptions(playback),
		AudioTracks:      a.webAudioOptions(playback),
		SubtitleTracks:   a.webSubtitleOptions(itemID, playback),
		ResumePosition:   a.webResumePosition(r, itemID),
		DefaultSelection: a.webDefaultSelection(playback),
	})
}

func (a *App) webLoadItemDetail(r *http.Request, itemID string) map[string]any {
	reqCtx := requestContextFrom(r.Context())
	resolved := a.resolveRouteIDForRequest(reqCtx, itemID)
	if resolved == nil {
		return nil
	}
	payload, err := resolved.Client.RequestJSON(r.Context(), requestContextFrom(r.Context()), a.Identity, http.MethodGet, "/Users/"+resolved.Client.UserID+"/Items/"+resolved.OriginalID, nil, nil)
	if err != nil {
		return nil
	}
	item, ok := payload.(map[string]any)
	if !ok {
		return nil
	}
	rewriteResponseIDs(item, resolved.ServerIndex, a.IDStore, a.ConfigStore.Snapshot().Server.ID, a.Auth.ProxyUserID())
	a.overlayLocalUserData(r, itemID, item)
	return sanitizeWebItem(item)
}

func (a *App) webLoadSeasons(r *http.Request, itemID string, item map[string]any) []map[string]any {
	if webString(item["Type"]) != "Series" {
		return []map[string]any{}
	}
	reqCtx := requestContextFrom(r.Context())
	resolved := a.resolveRouteIDForRequest(reqCtx, itemID)
	if resolved == nil {
		return []map[string]any{}
	}
	payload, err := resolved.Client.RequestJSON(r.Context(), requestContextFrom(r.Context()), a.Identity, http.MethodGet, "/Shows/"+resolved.OriginalID+"/Seasons", url.Values{}, nil)
	if err != nil {
		return []map[string]any{}
	}
	items := asItems(payload)
	a.rewriteItems(items, resolved.ServerIndex)
	return sanitizeWebItems(items)
}

func (a *App) webLoadEpisodes(r *http.Request, itemID string, item map[string]any) []map[string]any {
	if webString(item["Type"]) != "Series" {
		return []map[string]any{}
	}
	reqCtx := requestContextFrom(r.Context())
	resolved := a.resolveRouteIDForRequest(reqCtx, itemID)
	if resolved == nil {
		return []map[string]any{}
	}
	payload, err := resolved.Client.RequestJSON(r.Context(), requestContextFrom(r.Context()), a.Identity, http.MethodGet, "/Shows/"+resolved.OriginalID+"/Episodes", url.Values{"UserId": {resolved.Client.UserID}}, nil)
	if err != nil {
		return []map[string]any{}
	}
	items := asItems(payload)
	a.rewriteItems(items, resolved.ServerIndex)
	return sanitizeWebItems(items)
}

func (a *App) webLoadPlaybackInfo(r *http.Request, itemID string) map[string]any {
	result := a.webRequestPlaybackInfo(r, itemID, a.webSelectionFromRequest(r))
	if result.Status != http.StatusOK {
		return map[string]any{}
	}
	return result.Payload
}

func (a *App) webRequestPlaybackInfo(r *http.Request, itemID string, selection webSelection) webPlaybackInfoResult {
	return a.webRequestPlaybackInfoWithIntent(r, itemID, selection, false)
}

func (a *App) webRequestPlaybackInfoForPlayback(r *http.Request, itemID string, selection webSelection) webPlaybackInfoResult {
	return a.webRequestPlaybackInfoWithIntent(r, itemID, selection, true)
}

func (a *App) webRequestPlaybackInfoWithIntent(r *http.Request, itemID string, selection webSelection, startsPlayback bool) webPlaybackInfoResult {
	req := r.Clone(r.Context())
	req.Method = http.MethodGet
	if startsPlayback {
		req = withPlaybackInfoIntent(req, playbackInfoIntentStart)
	} else {
		req = withPlaybackInfoIntent(req, playbackInfoIntentProbe)
	}
	query := req.URL.Query()
	for _, key := range []string{"episodeId", "mediaSourceId", "audioStreamIndex", "subtitleStreamIndex"} {
		query.Del(key)
	}
	if selection.MediaSourceID != "" {
		query.Set("MediaSourceId", selection.MediaSourceID)
	}
	if selection.AudioStreamIndex >= 0 {
		query.Set("AudioStreamIndex", strconv.Itoa(selection.AudioStreamIndex))
	}
	if selection.SubtitleStreamIndex >= 0 {
		query.Set("SubtitleStreamIndex", strconv.Itoa(selection.SubtitleStreamIndex))
	}
	req.URL.RawQuery = query.Encode()
	req.SetPathValue("itemId", itemID)
	rr := httptest.NewRecorder()
	a.handlePlaybackInfo(rr, req)
	if rr.Code != http.StatusOK {
		return webPlaybackInfoResult{
			Payload: map[string]any{},
			Status:  rr.Code,
			Message: webPlaybackErrorMessage(rr.Body.Bytes(), rr.Code),
		}
	}
	var payload map[string]any
	if err := json.Unmarshal(rr.Body.Bytes(), &payload); err != nil {
		return webPlaybackInfoResult{
			Payload: map[string]any{},
			Status:  http.StatusBadGateway,
			Message: "Unable to load playback info",
		}
	}
	return webPlaybackInfoResult{
		Payload: payload,
		Status:  http.StatusOK,
	}
}

func webPlaybackErrorMessage(body []byte, status int) string {
	var payload map[string]any
	if err := json.Unmarshal(body, &payload); err == nil {
		if message := webString(payload["message"]); message != "" {
			return message
		}
	}
	if text := strings.TrimSpace(string(body)); text != "" {
		return text
	}
	if statusText := http.StatusText(status); statusText != "" {
		return statusText
	}
	return "Unable to load playback info"
}

func (a *App) webSelectionFromRequest(r *http.Request) webSelection {
	return webSelection{
		EpisodeID:           r.URL.Query().Get("episodeId"),
		MediaSourceID:       r.URL.Query().Get("mediaSourceId"),
		AudioStreamIndex:    atoiDefault(r.URL.Query().Get("audioStreamIndex"), -1),
		SubtitleStreamIndex: atoiDefault(r.URL.Query().Get("subtitleStreamIndex"), -1),
	}
}

func (a *App) webItemIDFromRequest(r *http.Request) string {
	selection := a.webSelectionFromRequest(r)
	if selection.EpisodeID != "" {
		return selection.EpisodeID
	}
	return r.PathValue("itemId")
}

func (a *App) webVersionOptions(playback map[string]any) []map[string]any {
	mediaSources := asItems(map[string]any{"Items": playback["MediaSources"]})
	versions := make([]map[string]any, 0, len(mediaSources))
	for _, source := range mediaSources {
		virtualID := webString(source["Id"])
		versions = append(versions, map[string]any{
			"id":         virtualID,
			"name":       webString(source["Name"]),
			"bitrate":    webInt(source["Bitrate"]),
			"serverName": a.upstreamNameForVirtualID(virtualID),
		})
	}
	return versions
}

func (a *App) upstreamNameForVirtualID(virtualID string) string {
	if a == nil || a.IDStore == nil || virtualID == "" {
		return ""
	}
	resolved := a.IDStore.ResolveVirtualID(virtualID)
	if resolved == nil {
		return ""
	}
	if a.ConfigStore == nil {
		return ""
	}
	cfg := a.ConfigStore.Snapshot()
	if resolved.ServerIndex < 0 || resolved.ServerIndex >= len(cfg.Upstream) {
		return ""
	}
	return cfg.Upstream[resolved.ServerIndex].Name
}

func (a *App) webAudioOptions(playback map[string]any, mediaSourceIDs ...string) []map[string]any {
	return a.webTrackOptions(playback, "Audio", mediaSourceIDs...)
}

func (a *App) webSubtitleOptions(itemID string, playback map[string]any) []webSubtitleTrack {
	tracks := webSubtitleTracks(playback, itemID, false)
	return tracks
}

func (a *App) webPlaybackSubtitleOptions(itemID string, playback map[string]any, mediaSourceIDs ...string) []webSubtitleTrack {
	return webSubtitleTracks(playback, itemID, true, mediaSourceIDs...)
}

func webBrowserSubtitleURL(rawURL string) string {
	if rawURL == "" {
		return ""
	}
	parsed, err := url.Parse(rawURL)
	if err != nil {
		return rawURL
	}
	if !strings.Contains(parsed.Path, "/Subtitles/") {
		return rawURL
	}
	if strings.EqualFold(path.Ext(parsed.Path), ".srt") {
		parsed.Path = strings.TrimSuffix(parsed.Path, path.Ext(parsed.Path)) + ".vtt"
		return parsed.String()
	}
	return rawURL
}

func webBrowserSubtitleProxyURL(itemID, mediaSourceID string, index int) string {
	if itemID == "" || mediaSourceID == "" || index < 0 {
		return ""
	}
	return fmt.Sprintf("/Videos/%s/%s/Subtitles/%d/Stream.vtt", itemID, mediaSourceID, index)
}

func (a *App) webTrackOptions(playback map[string]any, trackType string, mediaSourceIDs ...string) []map[string]any {
	mediaSources := asItems(map[string]any{"Items": playback["MediaSources"]})
	tracks := make([]map[string]any, 0)
	mediaSourceFilter := firstNonEmpty(mediaSourceIDs...)
	for _, source := range mediaSources {
		mediaSourceID := webString(source["Id"])
		if mediaSourceFilter != "" && mediaSourceID != mediaSourceFilter {
			continue
		}
		streams, _ := source["MediaStreams"].([]any)
		for _, raw := range streams {
			stream, ok := raw.(map[string]any)
			if !ok || webString(stream["Type"]) != trackType {
				continue
			}
			tracks = append(tracks, map[string]any{
				"index":         webInt(stream["Index"]),
				"mediaSourceId": mediaSourceID,
				"name":          firstNonEmpty(webString(stream["DisplayTitle"]), webString(stream["Title"])),
			})
		}
	}
	return tracks
}

func webSubtitleTracks(playback map[string]any, itemID string, includeURL bool, mediaSourceIDs ...string) []webSubtitleTrack {
	mediaSources := asItems(map[string]any{"Items": playback["MediaSources"]})
	tracks := make([]webSubtitleTrack, 0)
	mediaSourceFilter := firstNonEmpty(mediaSourceIDs...)
	for _, source := range mediaSources {
		streams, _ := source["MediaStreams"].([]any)
		mediaSourceID := webString(source["Id"])
		if mediaSourceFilter != "" && mediaSourceID != mediaSourceFilter {
			continue
		}
		for _, raw := range streams {
			stream, ok := raw.(map[string]any)
			if !ok || webString(stream["Type"]) != "Subtitle" {
				continue
			}
			track := webSubtitleTrack{
				ID:            webSubtitleTrackID(itemID, mediaSourceID, webInt(stream["Index"]), webSubtitleRendererKind(stream)),
				Index:         webInt(stream["Index"]),
				MediaSourceID: mediaSourceID,
				Name:          firstNonEmpty(webString(stream["DisplayTitle"]), webString(stream["Title"])),
				Language:      webSubtitleLanguage(stream),
				Codec:         webSubtitleCodec(stream),
				RendererKind:  webSubtitleRendererKind(stream),
				IsDefault:     webSubtitleBool(stream, "IsDefault", "Default"),
				IsForced:      webSubtitleBool(stream, "IsForced", "Forced"),
				IsExternal:    webSubtitleBool(stream, "External", "IsExternal"),
			}
			if includeURL {
				if rawURL := webString(stream["DeliveryUrl"]); rawURL != "" {
					track.URL = webBrowserSubtitleURL(rawURL)
				} else if track.RendererKind == "text" {
					// text subtitles are served via /web/api/subtitles/{id}/text + overlay
					// no browser <track> URL needed
					track.URL = ""
				} else if track.RendererKind == "ass" || track.RendererKind == "bitmap" {
					track.URL = webBrowserSubtitleProxyURL(itemID, mediaSourceID, track.Index)
				}
			}
			tracks = append(tracks, track)
		}
	}
	return tracks
}

func webSubtitleRuntimeFromTracks(tracks []webSubtitleTrack) webSubtitleRuntime {
	runtime := webSubtitleRuntime{}
	if len(tracks) == 0 {
		return runtime
	}
	runtime.BurninSupported = true
	runtime.DefaultTrackID = tracks[0].ID
	renderers := make(map[string]struct{})
	for _, track := range tracks {
		if track.IsDefault {
			runtime.DefaultTrackID = track.ID
		}
		if track.RendererKind != "" {
			renderers[track.RendererKind] = struct{}{}
		}
	}
	if len(renderers) > 0 {
		runtime.AvailableRenderers = make([]string, 0, len(renderers))
		for renderer := range renderers {
			runtime.AvailableRenderers = append(runtime.AvailableRenderers, renderer)
		}
		sort.Strings(runtime.AvailableRenderers)
	}
	return runtime
}

func webSubtitleCodec(stream map[string]any) string {
	return firstNonEmpty(webString(stream["Codec"]), webString(stream["CodecTag"]))
}

func webSubtitleLanguage(stream map[string]any) string {
	return firstNonEmpty(webString(stream["Language"]), webString(stream["LanguageTag"]))
}

func webSubtitleBool(stream map[string]any, keys ...string) bool {
	for _, key := range keys {
		if webBool(stream[key]) {
			return true
		}
	}
	return false
}

func webBool(value any) bool {
	switch v := value.(type) {
	case bool:
		return v
	case string:
		parsed, err := strconv.ParseBool(v)
		return err == nil && parsed
	case float64:
		return v != 0
	case int:
		return v != 0
	case int64:
		return v != 0
	default:
		return false
	}
}

func webSubtitleRendererKind(stream map[string]any) string {
	codec := strings.ToLower(webSubtitleCodec(stream))
	switch codec {
	case "ass", "ssa", "pgs", "sup", "hdmv_pgs_subtitle", "pgs_subtitle", "dvd_subtitle", "dvdsub", "vobsub", "dvb_subtitle", "dvbsub", "xsub":
		// The current web player does not mount ASS or bitmap overlays. Keep the
		// codec metadata, but advertise the only reliable public path: burn-in.
		return "burnin"
	case "srt", "vtt", "subrip", "webvtt":
		return "text"
	case "":
		if deliveryKind := webSubtitleRendererKindFromDeliveryURL(webString(stream["DeliveryUrl"])); deliveryKind != "" {
			return deliveryKind
		}
		return "text"
	default:
		return "text"
	}
}

func webSubtitleRendererKindFromDeliveryURL(rawURL string) string {
	if rawURL == "" {
		return ""
	}
	parsed, err := url.Parse(rawURL)
	if err != nil {
		return ""
	}
	switch strings.ToLower(path.Ext(parsed.Path)) {
	case ".srt", ".vtt", ".webvtt":
		return "text"
	case ".ass", ".ssa", ".sup", ".sub", ".idx", ".pgs":
		return "burnin"
	default:
		return ""
	}
}

func (a *App) webResumePosition(r *http.Request, itemID string) int64 {
	reqCtx := requestContextFrom(r.Context())
	if a.WatchStore == nil || reqCtx == nil || reqCtx.ProxyUser == nil {
		return 0
	}
	progress := a.WatchStore.GetProgress(reqCtx.ProxyUser.UserID, itemID)
	if progress == nil {
		return 0
	}
	return progress.PositionTicks
}

func (a *App) webDefaultSelection(playback map[string]any) map[string]any {
	versions := a.webVersionOptions(playback)
	selection := map[string]any{}
	if len(versions) > 0 {
		selection["mediaSourceId"] = versions[0]["id"]
	}
	return selection
}
