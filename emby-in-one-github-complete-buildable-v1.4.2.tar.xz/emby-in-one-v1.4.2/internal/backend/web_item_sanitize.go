package backend

func sanitizeWebItem(item map[string]any) map[string]any {
	sanitizeWebValue(item)
	return item
}

func sanitizeWebItems(items []map[string]any) []map[string]any {
	for _, item := range items {
		sanitizeWebItem(item)
	}
	return items
}

func sanitizeWebValue(value any) {
	switch typed := value.(type) {
	case map[string]any:
		delete(typed, "Path")
		for _, nested := range typed {
			sanitizeWebValue(nested)
		}
	case []any:
		for _, nested := range typed {
			sanitizeWebValue(nested)
		}
	case []map[string]any:
		for _, nested := range typed {
			sanitizeWebValue(nested)
		}
	}
}
