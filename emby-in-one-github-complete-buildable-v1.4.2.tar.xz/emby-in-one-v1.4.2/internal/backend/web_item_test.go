package backend

import (
	"encoding/json"
	"fmt"
	"net/http"
	"net/http/httptest"
	"strings"
	"sync/atomic"
	"testing"
	"time"
)

func TestWebItemReturnsSeriesEpisodesAndVersionMetadata(t *testing.T) {
	upstream := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch r.URL.Path {
		case "/Users/AuthenticateByName":
			_ = json.NewEncoder(w).Encode(map[string]any{"AccessToken": "tok-a", "User": map[string]any{"Id": "user-a"}})
		case "/Users/user-a/Items/item-a":
			_ = json.NewEncoder(w).Encode(map[string]any{
				"Id":           "item-a",
				"Name":         "Series A",
				"Type":         "Series",
				"MediaSources": []map[string]any{{"Id": "ms-a", "Name": "1080p", "Bitrate": 1000}},
			})
		case "/Items/item-a/PlaybackInfo":
			_ = json.NewEncoder(w).Encode(map[string]any{"MediaSources": []map[string]any{{
				"Id":      "ms-a",
				"Name":    "1080p",
				"Bitrate": 1000,
				"MediaStreams": []map[string]any{
					{"Type": "Audio", "Index": 1, "DisplayTitle": "AAC 2.0"},
					{"Type": "Subtitle", "Index": 2, "DisplayTitle": "中文字幕"},
				},
			}}})
		case "/Shows/item-a/Seasons":
			_ = json.NewEncoder(w).Encode(map[string]any{"Items": []map[string]any{{"Id": "season-a", "Name": "Season 1", "IndexNumber": 1}}})
		case "/Shows/item-a/Episodes":
			_ = json.NewEncoder(w).Encode(map[string]any{"Items": []map[string]any{{"Id": "ep-a", "Name": "Episode 1", "ParentIndexNumber": 1, "IndexNumber": 1}}})
		default:
			http.NotFound(w, r)
		}
	}))
	defer upstream.Close()

	withTempAppPrepared(t, singleUpstreamConfig(upstream.URL), nil, func(app *App, handler http.Handler, dir string) {
		user, err := app.UserStore.Create("alice", "pw-1", []int{0})
		if err != nil {
			t.Fatalf("create user: %v", err)
		}
		virtualID := app.IDStore.GetOrCreateVirtualID("item-a", 0)
		login := doJSONRequest(t, handler, http.MethodPost, "/web/api/login", map[string]string{"username": user.Username, "password": "pw-1"}, "")
		if login.Code != http.StatusOK {
			t.Fatalf("login status = %d, body=%s", login.Code, login.Body.String())
		}

		req := httptest.NewRequest(http.MethodGet, "/web/api/items/"+virtualID, nil)
		req.AddCookie(login.Result().Cookies()[0])
		rr := httptest.NewRecorder()
		handler.ServeHTTP(rr, req)
		if rr.Code != http.StatusOK {
			t.Fatalf("GET /web/api/items/:id status = %d, body=%s", rr.Code, rr.Body.String())
		}
		if !strings.Contains(rr.Body.String(), `"episodes"`) || !strings.Contains(rr.Body.String(), `"versions"`) || !strings.Contains(rr.Body.String(), `"audioTracks"`) {
			t.Fatalf("detail payload missing expected fields: %s", rr.Body.String())
		}
	})
}

func TestWebItemStripsSensitivePathFields(t *testing.T) {
	upstream := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch r.URL.Path {
		case "/Users/AuthenticateByName":
			_ = json.NewEncoder(w).Encode(map[string]any{"AccessToken": "tok-a", "User": map[string]any{"Id": "user-a"}})
		case "/Users/user-a/Items/series-a":
			_ = json.NewEncoder(w).Encode(map[string]any{
				"Id":   "series-a",
				"Name": "Series A",
				"Type": "Series",
				"Path": "D:/media/series-a",
				"MediaSources": []map[string]any{{
					"Id":   "ms-a",
					"Path": "D:/media/series-a/file.mkv",
					"MediaStreams": []map[string]any{
						{"Type": "Video", "Path": "D:/media/series-a/file.mkv"},
					},
				}},
			})
		case "/Items/series-a/PlaybackInfo":
			_ = json.NewEncoder(w).Encode(map[string]any{"MediaSources": []map[string]any{}})
		case "/Shows/series-a/Seasons":
			_ = json.NewEncoder(w).Encode(map[string]any{"Items": []map[string]any{{
				"Id":   "season-a",
				"Name": "Season 1",
				"Path": "D:/media/series-a/Season 1",
			}}})
		case "/Shows/series-a/Episodes":
			_ = json.NewEncoder(w).Encode(map[string]any{"Items": []map[string]any{{
				"Id":   "ep-a",
				"Name": "Episode 1",
				"Path": "D:/media/series-a/Season 1/Episode 1.mkv",
				"MediaSources": []map[string]any{{
					"Id":   "ep-ms-a",
					"Path": "D:/media/series-a/Season 1/Episode 1.mkv",
					"MediaStreams": []map[string]any{
						{"Type": "Video", "Path": "D:/media/series-a/Season 1/Episode 1.mkv"},
					},
				}},
			}}})
		default:
			http.NotFound(w, r)
		}
	}))
	defer upstream.Close()

	withTempAppPrepared(t, singleUpstreamConfig(upstream.URL), nil, func(app *App, handler http.Handler, dir string) {
		if _, err := app.UserStore.Create("alice", "pw-1", []int{0}); err != nil {
			t.Fatalf("create user: %v", err)
		}
		itemID := app.IDStore.GetOrCreateVirtualID("series-a", 0)
		login := doJSONRequest(t, handler, http.MethodPost, "/web/api/login", map[string]string{"username": "alice", "password": "pw-1"}, "")
		if login.Code != http.StatusOK {
			t.Fatalf("login status = %d, body=%s", login.Code, login.Body.String())
		}

		req := httptest.NewRequest(http.MethodGet, "/web/api/items/"+itemID, nil)
		req.AddCookie(login.Result().Cookies()[0])
		rr := httptest.NewRecorder()
		handler.ServeHTTP(rr, req)
		if rr.Code != http.StatusOK {
			t.Fatalf("GET /web/api/items/:id status = %d, body=%s", rr.Code, rr.Body.String())
		}
		body := rr.Body.String()
		if strings.Contains(body, `"Path"`) || strings.Contains(body, "D:/media/") {
			t.Fatalf("expected web item detail response to strip sensitive path fields, body=%s", body)
		}
	})
}

func TestWebItemSubtitleTracksReuseSharedManifestWithoutURL(t *testing.T) {
	upstream := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch r.URL.Path {
		case "/Users/AuthenticateByName":
			_ = json.NewEncoder(w).Encode(map[string]any{"AccessToken": "tok-a", "User": map[string]any{"Id": "user-a"}})
		case "/Users/user-a/Items/item-a":
			_ = json.NewEncoder(w).Encode(map[string]any{
				"Id":   "item-a",
				"Name": "Movie A",
				"Type": "Movie",
			})
		case "/Items/item-a/PlaybackInfo":
			_ = json.NewEncoder(w).Encode(map[string]any{"MediaSources": []map[string]any{{
				"Id":       "ms-a",
				"Name":     "1080p",
				"Bitrate":  1000,
				"Protocol": "File",
				"MediaStreams": []map[string]any{
					{"Type": "Subtitle", "Index": 2, "DisplayTitle": "中文字幕", "Language": "chi", "Codec": "", "DeliveryUrl": "/Videos/item-a/ms-a/Subtitles/2/Stream.srt"},
				},
			}}})
		default:
			http.NotFound(w, r)
		}
	}))
	defer upstream.Close()

	withTempAppPrepared(t, singleUpstreamConfig(upstream.URL), nil, func(app *App, handler http.Handler, dir string) {
		if _, err := app.UserStore.Create("alice", "pw-1", []int{0}); err != nil {
			t.Fatalf("create user: %v", err)
		}
		itemID := app.IDStore.GetOrCreateVirtualID("item-a", 0)
		login := doJSONRequest(t, handler, http.MethodPost, "/web/api/login", map[string]string{"username": "alice", "password": "pw-1"}, "")
		if login.Code != http.StatusOK {
			t.Fatalf("login status = %d, body=%s", login.Code, login.Body.String())
		}

		req := httptest.NewRequest(http.MethodGet, "/web/api/items/"+itemID, nil)
		req.AddCookie(login.Result().Cookies()[0])
		rr := httptest.NewRecorder()
		handler.ServeHTTP(rr, req)
		if rr.Code != http.StatusOK {
			t.Fatalf("GET /web/api/items/:id status = %d, body=%s", rr.Code, rr.Body.String())
		}

		var payload map[string]any
		if err := json.Unmarshal(rr.Body.Bytes(), &payload); err != nil {
			t.Fatalf("unmarshal item payload: %v", err)
		}
		tracks, ok := payload["subtitleTracks"].([]any)
		if !ok || len(tracks) != 1 {
			t.Fatalf("expected 1 subtitle track, got %v body=%s", payload["subtitleTracks"], rr.Body.String())
		}
		track, ok := tracks[0].(map[string]any)
		if !ok {
			t.Fatalf("expected subtitle track object, got %T", tracks[0])
		}
		for _, key := range []string{"id", "index", "mediaSourceId", "name", "codec", "rendererKind", "isDefault", "isForced", "isExternal"} {
			if _, ok := track[key]; !ok {
				t.Fatalf("expected item subtitle track to include %q, got %v", key, track)
			}
		}
		if _, ok := track["url"]; ok {
			t.Fatalf("expected item subtitle track not to include url when includeURL=false, got %v", track)
		}
		if got := webString(track["codec"]); got != "" {
			t.Fatalf("expected empty codec, got %q", got)
		}
		if got := webString(track["rendererKind"]); got != "text" {
			t.Fatalf("expected rendererKind=text, got %q", got)
		}
		if webBool(track["isDefault"]) || webBool(track["isForced"]) || webBool(track["isExternal"]) {
			t.Fatalf("expected false subtitle flags, got %v", track)
		}
	})
}

func TestWebItemDoesNotUseUnauthorizedPriorityPrimaryInstance(t *testing.T) {
	var listHitsA atomic.Int32
	var detailHitsA atomic.Int32
	var listHitsB atomic.Int32
	var detailHitsB atomic.Int32
	var listHitsC atomic.Int32
	var detailHitsC atomic.Int32

	makeServer := func(serverName, token, userID, itemID, itemName string, listHits, detailHits *atomic.Int32) *httptest.Server {
		return httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			switch r.URL.Path {
			case "/Users/AuthenticateByName":
				_ = json.NewEncoder(w).Encode(map[string]any{"AccessToken": token, "User": map[string]any{"Id": userID}})
			case "/Search/Hints":
				listHits.Add(1)
				_ = json.NewEncoder(w).Encode(map[string]any{
					"SearchHints": []map[string]any{{
						"Id":          itemID,
						"Name":        itemName,
						"Type":        "Movie",
						"ProviderIds": map[string]any{"Tmdb": "tmdb-shared-1"},
						"Overview":    fmt.Sprintf("overview-from-%s", serverName),
					}},
				})
			case "/Users/" + userID + "/Items":
				listHits.Add(1)
				_ = json.NewEncoder(w).Encode(map[string]any{
					"Items": []map[string]any{{
						"Id":          itemID,
						"Name":        itemName,
						"Type":        "Movie",
						"ProviderIds": map[string]any{"Tmdb": "tmdb-shared-1"},
						"Overview":    fmt.Sprintf("overview-from-%s", serverName),
					}},
				})
			case "/Users/" + userID + "/Items/" + itemID:
				detailHits.Add(1)
				_ = json.NewEncoder(w).Encode(map[string]any{
					"Id":          itemID,
					"Name":        itemName,
					"Type":        "Movie",
					"ProviderIds": map[string]any{"Tmdb": "tmdb-shared-1"},
					"Overview":    fmt.Sprintf("detail-from-%s", serverName),
				})
			case "/Items/" + itemID + "/PlaybackInfo":
				_ = json.NewEncoder(w).Encode(map[string]any{"MediaSources": []map[string]any{{
					"Id":   "ms-" + itemID,
					"Name": serverName + " version",
				}}})
			default:
				http.NotFound(w, r)
			}
		}))
	}

	srvA := makeServer("A", "tok-a", "user-a", "item-a", "Shared Movie A", &listHitsA, &detailHitsA)
	defer srvA.Close()
	srvB := makeServer("B", "tok-b", "user-b", "item-b", "Shared Movie B", &listHitsB, &detailHitsB)
	defer srvB.Close()
	srvC := makeServer("C", "tok-c", "user-c", "item-c", "Shared Movie C", &listHitsC, &detailHitsC)
	defer srvC.Close()

	config := fmt.Sprintf(`server:
  port: 8096
  name: "Test"
  id: "svr"
admin:
  username: "admin"
  password: "secret"
playback:
  mode: "proxy"
timeouts:
  api: 30000
  global: 15000
  login: 10000
  healthCheck: 10000
  healthInterval: 60000
  searchGracePeriod: 0
  metadataGracePeriod: 0
  latestGracePeriod: 0
proxies: []
upstream:
  - name: "A"
    url: %q
    username: "u1"
    password: "p1"
    priorityMetadata: true
  - name: "B"
    url: %q
    username: "u2"
    password: "p2"
  - name: "C"
    url: %q
    username: "u3"
    password: "p3"
`, srvA.URL, srvB.URL, srvC.URL)

	withTempAppPrepared(t, config, nil, func(app *App, handler http.Handler, dir string) {
		adminToken := loginTokenAs(t, handler, "admin", "secret")

		createFullUser := doAuthJSON(t, handler, http.MethodPost, "/admin/api/users", map[string]any{
			"username":       "collector",
			"password":       "collector123",
			"allowedServers": []int{0, 1, 2},
		}, adminToken)
		if createFullUser.Code != http.StatusCreated {
			t.Fatalf("create collector status = %d body=%s", createFullUser.Code, createFullUser.Body.String())
		}

		collectorLogin := doJSONRequest(t, handler, http.MethodPost, "/web/api/login", map[string]string{"username": "collector", "password": "collector123"}, "")
		if collectorLogin.Code != http.StatusOK {
			t.Fatalf("collector login status = %d, body=%s", collectorLogin.Code, collectorLogin.Body.String())
		}
		collectorCookie := collectorLogin.Result().Cookies()[0]

		adminSearchReq := httptest.NewRequest(http.MethodGet, "/web/api/search?q=shared", nil)
		adminSearchReq.AddCookie(collectorCookie)
		adminSearch := httptest.NewRecorder()
		handler.ServeHTTP(adminSearch, adminSearchReq)
		if adminSearch.Code != http.StatusOK {
			t.Fatalf("collector search status = %d, body=%s", adminSearch.Code, adminSearch.Body.String())
		}
		waitForCondition(t, time.Second, func() bool {
			return listHitsA.Load() > 0 && listHitsB.Load() > 0 && listHitsC.Load() > 0
		}, "collector search should touch all upstreams")

		var adminPayload map[string]any
		if err := json.Unmarshal(adminSearch.Body.Bytes(), &adminPayload); err != nil {
			t.Fatalf("unmarshal collector search: %v", err)
		}
		items, _ := adminPayload["items"].([]any)
		if len(items) != 1 {
			t.Fatalf("expected 1 merged item, got %d body=%s", len(items), adminSearch.Body.String())
		}
		firstItem, _ := items[0].(map[string]any)
		if firstItem == nil {
			t.Fatalf("expected first merged item object, body=%s", adminSearch.Body.String())
		}
		if !strings.Contains(adminSearch.Body.String(), "overview-from-A") {
			t.Fatalf("expected priority metadata from A to win during collector search, body=%s", adminSearch.Body.String())
		}

		virtualID, _ := firstItem["id"].(string)
		if virtualID == "" {
			t.Fatalf("missing virtual id in collector search payload: %s", adminSearch.Body.String())
		}

		createUser := doAuthJSON(t, handler, http.MethodPost, "/admin/api/users", map[string]any{
			"username":       "bob",
			"password":       "bob123",
			"allowedServers": []int{1, 2},
		}, adminToken)
		if createUser.Code != http.StatusCreated {
			t.Fatalf("create user status = %d body=%s", createUser.Code, createUser.Body.String())
		}

		bobLogin := doJSONRequest(t, handler, http.MethodPost, "/web/api/login", map[string]string{"username": "bob", "password": "bob123"}, "")
		if bobLogin.Code != http.StatusOK {
			t.Fatalf("bob login status = %d, body=%s", bobLogin.Code, bobLogin.Body.String())
		}
		bobCookie := bobLogin.Result().Cookies()[0]

		listHitsA.Store(0)
		listHitsB.Store(0)
		listHitsC.Store(0)
		detailHitsA.Store(0)
		detailHitsB.Store(0)
		detailHitsC.Store(0)

		searchReq := httptest.NewRequest(http.MethodGet, "/web/api/search?q=shared", nil)
		searchReq.AddCookie(bobCookie)
		searchRR := httptest.NewRecorder()
		handler.ServeHTTP(searchRR, searchReq)
		if searchRR.Code != http.StatusOK {
			t.Fatalf("bob web search status = %d body=%s", searchRR.Code, searchRR.Body.String())
		}
		if listHitsA.Load() != 0 {
			t.Fatalf("expected bob web search not to hit server A, got %d", listHitsA.Load())
		}
		if listHitsB.Load() == 0 || listHitsC.Load() == 0 {
			t.Fatalf("expected bob web search to hit servers B and C, got B=%d C=%d", listHitsB.Load(), listHitsC.Load())
		}

		detailReq := httptest.NewRequest(http.MethodGet, "/web/api/items/"+virtualID, nil)
		detailReq.AddCookie(bobCookie)
		detailRR := httptest.NewRecorder()
		handler.ServeHTTP(detailRR, detailReq)
		if detailRR.Code != http.StatusOK {
			t.Fatalf("bob web item detail status = %d body=%s", detailRR.Code, detailRR.Body.String())
		}
		if detailHitsA.Load() != 0 {
			t.Fatalf("expected bob detail not to hit server A, got A=%d body=%s", detailHitsA.Load(), detailRR.Body.String())
		}
		if detailHitsB.Load()+detailHitsC.Load() == 0 {
			t.Fatalf("expected bob detail to hit B or C, got B=%d C=%d", detailHitsB.Load(), detailHitsC.Load())
		}
		if strings.Contains(detailRR.Body.String(), "detail-from-A") {
			t.Fatalf("detail payload leaked unauthorized server A metadata: %s", detailRR.Body.String())
		}
	})
}

func TestWebVersionOptionsExposesUpstreamServerName(t *testing.T) {
	upstreamA := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path == "/Users/AuthenticateByName" {
			_ = json.NewEncoder(w).Encode(map[string]any{"AccessToken": "tok-a", "User": map[string]any{"Id": "user-a"}})
			return
		}
		http.NotFound(w, r)
	}))
	defer upstreamA.Close()
	upstreamB := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path == "/Users/AuthenticateByName" {
			_ = json.NewEncoder(w).Encode(map[string]any{"AccessToken": "tok-b", "User": map[string]any{"Id": "user-b"}})
			return
		}
		http.NotFound(w, r)
	}))
	defer upstreamB.Close()

	cfg := fmt.Sprintf("server:\n  port: 8096\n  name: \"Test\"\n  id: \"server-1\"\n\nadmin:\n  username: \"admin\"\n  password: \"secret\"\n\nplayback:\n  mode: \"proxy\"\n\ntimeouts:\n  api: 30000\n  global: 15000\n  login: 10000\n  healthCheck: 10000\n  healthInterval: 60000\n\nproxies: []\nupstream:\n  - name: \"服务器A\"\n    url: %q\n    username: \"u1\"\n    password: \"p1\"\n  - name: \"服务器B\"\n    url: %q\n    username: \"u2\"\n    password: \"p2\"\n", upstreamA.URL, upstreamB.URL)

	withTempAppPrepared(t, cfg, nil, func(app *App, _ http.Handler, _ string) {
		virtualA := app.IDStore.GetOrCreateVirtualID("ms-a", 0)
		virtualB := app.IDStore.GetOrCreateVirtualID("ms-b", 1)
		playback := map[string]any{
			"MediaSources": []any{
				map[string]any{"Id": virtualA, "Name": "1080P", "Bitrate": 1000},
				map[string]any{"Id": virtualB, "Name": "2160P", "Bitrate": 2000},
			},
		}
		versions := app.webVersionOptions(playback)
		if len(versions) != 2 {
			t.Fatalf("versions count = %d, want 2", len(versions))
		}
		if got := versions[0]["serverName"]; got != "服务器A" {
			t.Fatalf("versions[0].serverName = %v, want 服务器A", got)
		}
		if got := versions[1]["serverName"]; got != "服务器B" {
			t.Fatalf("versions[1].serverName = %v, want 服务器B", got)
		}
	})
}

func TestWebVersionOptionsLeavesServerNameEmptyWhenUnresolved(t *testing.T) {
	upstream := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path == "/Users/AuthenticateByName" {
			_ = json.NewEncoder(w).Encode(map[string]any{"AccessToken": "tok-a", "User": map[string]any{"Id": "user-a"}})
			return
		}
		http.NotFound(w, r)
	}))
	defer upstream.Close()

	withTempAppPrepared(t, singleUpstreamConfig(upstream.URL), nil, func(app *App, _ http.Handler, _ string) {
		playback := map[string]any{
			"MediaSources": []any{
				map[string]any{"Id": "this-virtual-id-does-not-exist", "Name": "1080P"},
			},
		}
		versions := app.webVersionOptions(playback)
		if len(versions) != 1 {
			t.Fatalf("versions count = %d, want 1", len(versions))
		}
		if got, _ := versions[0]["serverName"].(string); got != "" {
			t.Fatalf("versions[0].serverName = %q, want empty string", got)
		}
	})
}

func TestWebVersionOptionsHandlesMissingIDStore(t *testing.T) {
	app := &App{}
	playback := map[string]any{
		"MediaSources": []any{
			map[string]any{"Id": "any-id", "Name": "1080P"},
		},
	}
	versions := app.webVersionOptions(playback)
	if len(versions) != 1 {
		t.Fatalf("versions count = %d, want 1", len(versions))
	}
	if got, _ := versions[0]["serverName"].(string); got != "" {
		t.Fatalf("versions[0].serverName = %q, want empty string", got)
	}
}
