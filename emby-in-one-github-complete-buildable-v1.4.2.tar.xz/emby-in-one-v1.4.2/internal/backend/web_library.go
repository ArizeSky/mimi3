package backend

import (
	"net/http"
	"strconv"
)

type webLibraryResponse struct {
	ID      string         `json:"id"`
	Name    string         `json:"name"`
	Items   []webMediaCard `json:"items"`
	Total   int            `json:"total"`
	Offset  int            `json:"offset"`
	Limit   int            `json:"limit"`
	HasMore bool           `json:"hasMore"`
}

func (a *App) handleWebLibrary(w http.ResponseWriter, r *http.Request) {
	reqCtx := requestContextFrom(r.Context())
	libraryID := r.PathValue("libraryId")
	offset, limit := webLibraryPagination(r)
	name, items, total, ok := a.webLibraryItems(r, reqCtx, libraryID, offset, limit)
	if !ok {
		writeJSON(w, http.StatusNotFound, map[string]any{"message": "Library not found"})
		return
	}
	writeJSON(w, http.StatusOK, webLibraryResponse{
		ID:      libraryID,
		Name:    name,
		Items:   a.webCardsFromItems(items),
		Total:   total,
		Offset:  offset,
		Limit:   limit,
		HasMore: offset+len(items) < total,
	})
}

func (a *App) webLibraryItems(r *http.Request, reqCtx *RequestContext, libraryID string, offset, limit int) (string, []map[string]any, int, bool) {
	resolved := a.resolveRouteIDForRequest(reqCtx, libraryID)
	if resolved == nil {
		return "", nil, 0, false
	}
	view := a.webLibraryView(r, reqCtx, libraryID)
	if view == nil {
		return "", nil, 0, false
	}
	query := map[string][]string{
		"ParentId":   {resolved.OriginalID},
		"Recursive":  {"true"},
		"StartIndex": {strconv.Itoa(offset)},
		"Limit":      {strconv.Itoa(limit)},
	}
	if includeType := webLibraryIncludeType(view); includeType != "" {
		query["IncludeItemTypes"] = []string{includeType}
	}
	payload, err := resolved.Client.RequestJSON(r.Context(), reqCtx, a.Identity, http.MethodGet, "/Users/"+resolved.Client.UserID+"/Items", query, nil)
	if err != nil {
		return "", nil, 0, false
	}
	items := asItems(payload)
	items = webLibraryDisplayItems(items)
	total := webLibraryTotalCount(payload, offset, len(items))
	a.rewriteItems(items, resolved.ServerIndex)
	a.overlayLocalUserDataItems(r, items)
	return webString(view["Name"]), items, total, true
}

func webLibraryPagination(r *http.Request) (int, int) {
	offset := webLibraryPositiveInt(r.URL.Query().Get("offset"), 0)
	limit := webLibraryPositiveInt(r.URL.Query().Get("limit"), 50)
	if limit > 100 {
		limit = 100
	}
	return offset, limit
}

func webLibraryPositiveInt(raw string, fallback int) int {
	if raw == "" {
		return fallback
	}
	parsed, err := strconv.Atoi(raw)
	if err != nil || parsed < 0 {
		return fallback
	}
	if parsed == 0 && fallback > 0 {
		return fallback
	}
	return parsed
}

func webLibraryTotalCount(payload any, offset, count int) int {
	block, _ := payload.(map[string]any)
	if block == nil {
		return offset + count
	}
	total := webInt(block["TotalRecordCount"])
	if total > 0 {
		return total
	}
	return offset + count
}

func webLibraryDisplayItems(items []map[string]any) []map[string]any {
	filtered := make([]map[string]any, 0, len(items))
	for _, item := range items {
		if !webLibraryAllowedType(webString(item["Type"])) {
			continue
		}
		filtered = append(filtered, item)
	}
	return filtered
}

func webLibraryAllowedType(itemType string) bool {
	switch itemType {
	case "Series", "Movie", "BoxSet":
		return true
	default:
		return false
	}
}

func (a *App) webLibraryView(r *http.Request, reqCtx *RequestContext, libraryID string) map[string]any {
	for _, view := range a.webFetchUserViews(r, reqCtx) {
		if webString(view["Id"]) == libraryID {
			return view
		}
	}
	return nil
}

func webLibraryIncludeType(view map[string]any) string {
	switch webString(view["CollectionType"]) {
	case "tvshows":
		return "Series"
	case "movies":
		return "Movie"
	case "boxsets":
		return "BoxSet"
	default:
		return ""
	}
}
