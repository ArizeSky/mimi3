package backend

import (
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"testing"
)

func TestWebLibraryReturnsSeriesItemsForTVView(t *testing.T) {
	upstream := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch r.URL.Path {
		case "/Users/AuthenticateByName":
			_ = json.NewEncoder(w).Encode(map[string]any{"AccessToken": "tok-a", "User": map[string]any{"Id": "user-a"}})
		case "/Users/user-a/Views":
			_ = json.NewEncoder(w).Encode(map[string]any{"Items": []map[string]any{{"Id": "view-1", "Name": "电视剧", "CollectionType": "tvshows"}}})
		case "/Users/user-a/Items":
			if r.URL.Query().Get("ParentId") != "view-1" {
				t.Fatalf("expected ParentId=view-1, query=%s", r.URL.RawQuery)
			}
			if r.URL.Query().Get("Recursive") != "true" {
				t.Fatalf("expected Recursive=true, query=%s", r.URL.RawQuery)
			}
			if r.URL.Query().Get("IncludeItemTypes") != "Series" {
				t.Fatalf("expected IncludeItemTypes=Series, query=%s", r.URL.RawQuery)
			}
			_ = json.NewEncoder(w).Encode(map[string]any{"Items": []map[string]any{
				{"Id": "series-1", "Name": "Series One", "Type": "Series"},
				{"Id": "series-2", "Name": "Series Two", "Type": "Series"},
			}})
		default:
			http.NotFound(w, r)
		}
	}))
	defer upstream.Close()

	withTempAppPrepared(t, singleUpstreamConfig(upstream.URL), nil, func(app *App, handler http.Handler, dir string) {
		if _, err := app.UserStore.Create("alice", "pw-1", []int{0}); err != nil {
			t.Fatalf("create user: %v", err)
		}
		viewVirtualID := app.IDStore.GetOrCreateVirtualID("view-1", 0)
		login := doJSONRequest(t, handler, http.MethodPost, "/web/api/login", map[string]string{"username": "alice", "password": "pw-1"}, "")
		if login.Code != http.StatusOK {
			t.Fatalf("login status = %d, body=%s", login.Code, login.Body.String())
		}

		req := httptest.NewRequest(http.MethodGet, "/web/api/libraries/"+viewVirtualID, nil)
		req.AddCookie(login.Result().Cookies()[0])
		rr := httptest.NewRecorder()
		handler.ServeHTTP(rr, req)
		if rr.Code != http.StatusOK {
			t.Fatalf("GET /web/api/libraries/:libraryId status = %d, body=%s", rr.Code, rr.Body.String())
		}

		var payload map[string]any
		if err := json.Unmarshal(rr.Body.Bytes(), &payload); err != nil {
			t.Fatalf("unmarshal payload: %v", err)
		}
		items, _ := payload["items"].([]any)
		if len(items) != 2 {
			t.Fatalf("expected 2 series items, body=%s", rr.Body.String())
		}
		first, _ := items[0].(map[string]any)
		if first["type"] != "Series" || first["name"] != "Series One" {
			t.Fatalf("expected series-level items only, body=%s", rr.Body.String())
		}
	})
}

func TestWebLibraryReturnsMovieItemsForMovieView(t *testing.T) {
	upstream := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch r.URL.Path {
		case "/Users/AuthenticateByName":
			_ = json.NewEncoder(w).Encode(map[string]any{"AccessToken": "tok-a", "User": map[string]any{"Id": "user-a"}})
		case "/Users/user-a/Views":
			_ = json.NewEncoder(w).Encode(map[string]any{"Items": []map[string]any{{"Id": "view-2", "Name": "电影", "CollectionType": "movies"}}})
		case "/Users/user-a/Items":
			if r.URL.Query().Get("IncludeItemTypes") != "Movie" {
				t.Fatalf("expected IncludeItemTypes=Movie, query=%s", r.URL.RawQuery)
			}
			_ = json.NewEncoder(w).Encode(map[string]any{"Items": []map[string]any{{"Id": "movie-1", "Name": "Movie One", "Type": "Movie"}}})
		default:
			http.NotFound(w, r)
		}
	}))
	defer upstream.Close()

	withTempAppPrepared(t, singleUpstreamConfig(upstream.URL), nil, func(app *App, handler http.Handler, dir string) {
		if _, err := app.UserStore.Create("alice", "pw-1", []int{0}); err != nil {
			t.Fatalf("create user: %v", err)
		}
		viewVirtualID := app.IDStore.GetOrCreateVirtualID("view-2", 0)
		login := doJSONRequest(t, handler, http.MethodPost, "/web/api/login", map[string]string{"username": "alice", "password": "pw-1"}, "")
		if login.Code != http.StatusOK {
			t.Fatalf("login status = %d, body=%s", login.Code, login.Body.String())
		}
		req := httptest.NewRequest(http.MethodGet, "/web/api/libraries/"+viewVirtualID, nil)
		req.AddCookie(login.Result().Cookies()[0])
		rr := httptest.NewRecorder()
		handler.ServeHTTP(rr, req)
		if rr.Code != http.StatusOK {
			t.Fatalf("GET /web/api/libraries/:libraryId status = %d, body=%s", rr.Code, rr.Body.String())
		}
	})
}

func TestWebLibraryKeepsSeriesItemsWhenIsFolderTrue(t *testing.T) {
	upstream := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch r.URL.Path {
		case "/Users/AuthenticateByName":
			_ = json.NewEncoder(w).Encode(map[string]any{"AccessToken": "tok-a", "User": map[string]any{"Id": "user-a"}})
		case "/Users/user-a/Views":
			_ = json.NewEncoder(w).Encode(map[string]any{"Items": []map[string]any{{"Id": "view-3", "Name": "电视剧", "CollectionType": "tvshows"}}})
		case "/Users/user-a/Items":
			_ = json.NewEncoder(w).Encode(map[string]any{"Items": []map[string]any{
				{"Id": "series-1", "Name": "Series One", "Type": "Series", "IsFolder": true},
				{"Id": "folder-1", "Name": "Folder One", "Type": "Folder", "IsFolder": true},
			}})
		default:
			http.NotFound(w, r)
		}
	}))
	defer upstream.Close()

	withTempAppPrepared(t, singleUpstreamConfig(upstream.URL), nil, func(app *App, handler http.Handler, dir string) {
		if _, err := app.UserStore.Create("alice", "pw-1", []int{0}); err != nil {
			t.Fatalf("create user: %v", err)
		}
		viewVirtualID := app.IDStore.GetOrCreateVirtualID("view-3", 0)
		login := doJSONRequest(t, handler, http.MethodPost, "/web/api/login", map[string]string{"username": "alice", "password": "pw-1"}, "")
		if login.Code != http.StatusOK {
			t.Fatalf("login status = %d, body=%s", login.Code, login.Body.String())
		}

		req := httptest.NewRequest(http.MethodGet, "/web/api/libraries/"+viewVirtualID, nil)
		req.AddCookie(login.Result().Cookies()[0])
		rr := httptest.NewRecorder()
		handler.ServeHTTP(rr, req)
		if rr.Code != http.StatusOK {
			t.Fatalf("GET /web/api/libraries/:libraryId status = %d, body=%s", rr.Code, rr.Body.String())
		}

		var payload map[string]any
		if err := json.Unmarshal(rr.Body.Bytes(), &payload); err != nil {
			t.Fatalf("unmarshal payload: %v", err)
		}
		items, _ := payload["items"].([]any)
		if len(items) != 1 {
			t.Fatalf("expected 1 series item, body=%s", rr.Body.String())
		}
		first, _ := items[0].(map[string]any)
		if first["type"] != "Series" || first["name"] != "Series One" {
			t.Fatalf("expected series item to be kept, body=%s", rr.Body.String())
		}
	})
}

func TestWebLibraryKeepsBoxSetItemsWhenIsFolderTrue(t *testing.T) {
	upstream := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch r.URL.Path {
		case "/Users/AuthenticateByName":
			_ = json.NewEncoder(w).Encode(map[string]any{"AccessToken": "tok-a", "User": map[string]any{"Id": "user-a"}})
		case "/Users/user-a/Views":
			_ = json.NewEncoder(w).Encode(map[string]any{"Items": []map[string]any{{"Id": "view-4", "Name": "合集", "CollectionType": "boxsets"}}})
		case "/Users/user-a/Items":
			_ = json.NewEncoder(w).Encode(map[string]any{"Items": []map[string]any{
				{"Id": "box-1", "Name": "Collection One", "Type": "BoxSet", "IsFolder": true},
				{"Id": "folder-1", "Name": "Folder One", "Type": "Folder", "IsFolder": true},
			}})
		default:
			http.NotFound(w, r)
		}
	}))
	defer upstream.Close()

	withTempAppPrepared(t, singleUpstreamConfig(upstream.URL), nil, func(app *App, handler http.Handler, dir string) {
		if _, err := app.UserStore.Create("alice", "pw-1", []int{0}); err != nil {
			t.Fatalf("create user: %v", err)
		}
		viewVirtualID := app.IDStore.GetOrCreateVirtualID("view-4", 0)
		login := doJSONRequest(t, handler, http.MethodPost, "/web/api/login", map[string]string{"username": "alice", "password": "pw-1"}, "")
		if login.Code != http.StatusOK {
			t.Fatalf("login status = %d, body=%s", login.Code, login.Body.String())
		}

		req := httptest.NewRequest(http.MethodGet, "/web/api/libraries/"+viewVirtualID, nil)
		req.AddCookie(login.Result().Cookies()[0])
		rr := httptest.NewRecorder()
		handler.ServeHTTP(rr, req)
		if rr.Code != http.StatusOK {
			t.Fatalf("GET /web/api/libraries/:libraryId status = %d, body=%s", rr.Code, rr.Body.String())
		}

		var payload map[string]any
		if err := json.Unmarshal(rr.Body.Bytes(), &payload); err != nil {
			t.Fatalf("unmarshal payload: %v", err)
		}
		items, _ := payload["items"].([]any)
		if len(items) != 1 {
			t.Fatalf("expected 1 boxset item, body=%s", rr.Body.String())
		}
		first, _ := items[0].(map[string]any)
		if first["type"] != "BoxSet" || first["name"] != "Collection One" {
			t.Fatalf("expected boxset item to be kept, body=%s", rr.Body.String())
		}
	})
}

func TestWebLibraryKeepsMoviesAndFiltersNonWhitelistedTypes(t *testing.T) {
	upstream := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch r.URL.Path {
		case "/Users/AuthenticateByName":
			_ = json.NewEncoder(w).Encode(map[string]any{"AccessToken": "tok-a", "User": map[string]any{"Id": "user-a"}})
		case "/Users/user-a/Views":
			_ = json.NewEncoder(w).Encode(map[string]any{"Items": []map[string]any{{"Id": "view-5", "Name": "电影", "CollectionType": "movies"}}})
		case "/Users/user-a/Items":
			_ = json.NewEncoder(w).Encode(map[string]any{"Items": []map[string]any{
				{"Id": "movie-1", "Name": "Movie One", "Type": "Movie", "IsFolder": false},
				{"Id": "person-1", "Name": "Actor One", "Type": "Person", "IsFolder": false},
				{"Id": "folder-1", "Name": "Folder One", "Type": "Folder", "IsFolder": true},
			}})
		default:
			http.NotFound(w, r)
		}
	}))
	defer upstream.Close()

	withTempAppPrepared(t, singleUpstreamConfig(upstream.URL), nil, func(app *App, handler http.Handler, dir string) {
		if _, err := app.UserStore.Create("alice", "pw-1", []int{0}); err != nil {
			t.Fatalf("create user: %v", err)
		}
		viewVirtualID := app.IDStore.GetOrCreateVirtualID("view-5", 0)
		login := doJSONRequest(t, handler, http.MethodPost, "/web/api/login", map[string]string{"username": "alice", "password": "pw-1"}, "")
		if login.Code != http.StatusOK {
			t.Fatalf("login status = %d, body=%s", login.Code, login.Body.String())
		}

		req := httptest.NewRequest(http.MethodGet, "/web/api/libraries/"+viewVirtualID, nil)
		req.AddCookie(login.Result().Cookies()[0])
		rr := httptest.NewRecorder()
		handler.ServeHTTP(rr, req)
		if rr.Code != http.StatusOK {
			t.Fatalf("GET /web/api/libraries/:libraryId status = %d, body=%s", rr.Code, rr.Body.String())
		}

		var payload map[string]any
		if err := json.Unmarshal(rr.Body.Bytes(), &payload); err != nil {
			t.Fatalf("unmarshal payload: %v", err)
		}
		items, _ := payload["items"].([]any)
		if len(items) != 1 {
			t.Fatalf("expected only whitelisted movie item, body=%s", rr.Body.String())
		}
		first, _ := items[0].(map[string]any)
		if first["type"] != "Movie" || first["name"] != "Movie One" {
			t.Fatalf("expected movie item to be kept, body=%s", rr.Body.String())
		}
	})
}

func TestWebLibrarySupportsPaginationMetadata(t *testing.T) {
	upstream := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch r.URL.Path {
		case "/Users/AuthenticateByName":
			_ = json.NewEncoder(w).Encode(map[string]any{"AccessToken": "tok-a", "User": map[string]any{"Id": "user-a"}})
		case "/Users/user-a/Views":
			_ = json.NewEncoder(w).Encode(map[string]any{"Items": []map[string]any{{"Id": "view-6", "Name": "电影", "CollectionType": "movies"}}})
		case "/Users/user-a/Items":
			if r.URL.Query().Get("StartIndex") != "50" {
				t.Fatalf("expected StartIndex=50, query=%s", r.URL.RawQuery)
			}
			if r.URL.Query().Get("Limit") != "50" {
				t.Fatalf("expected Limit=50, query=%s", r.URL.RawQuery)
			}
			items := make([]map[string]any, 0, 50)
			for i := 0; i < 50; i++ {
				items = append(items, map[string]any{"Id": "movie-p-" + intToString(i), "Name": "Movie", "Type": "Movie"})
			}
			_ = json.NewEncoder(w).Encode(map[string]any{"Items": items, "TotalRecordCount": 120, "StartIndex": 50})
		default:
			http.NotFound(w, r)
		}
	}))
	defer upstream.Close()

	withTempAppPrepared(t, singleUpstreamConfig(upstream.URL), nil, func(app *App, handler http.Handler, dir string) {
		if _, err := app.UserStore.Create("alice", "pw-1", []int{0}); err != nil {
			t.Fatalf("create user: %v", err)
		}
		viewVirtualID := app.IDStore.GetOrCreateVirtualID("view-6", 0)
		login := doJSONRequest(t, handler, http.MethodPost, "/web/api/login", map[string]string{"username": "alice", "password": "pw-1"}, "")
		if login.Code != http.StatusOK {
			t.Fatalf("login status = %d, body=%s", login.Code, login.Body.String())
		}

		req := httptest.NewRequest(http.MethodGet, "/web/api/libraries/"+viewVirtualID+"?offset=50&limit=50", nil)
		req.AddCookie(login.Result().Cookies()[0])
		rr := httptest.NewRecorder()
		handler.ServeHTTP(rr, req)
		if rr.Code != http.StatusOK {
			t.Fatalf("GET /web/api/libraries/:libraryId status = %d, body=%s", rr.Code, rr.Body.String())
		}

		var payload map[string]any
		if err := json.Unmarshal(rr.Body.Bytes(), &payload); err != nil {
			t.Fatalf("unmarshal payload: %v", err)
		}
		items, _ := payload["items"].([]any)
		if len(items) != 50 {
			t.Fatalf("expected 50 items, body=%s", rr.Body.String())
		}
		if payload["total"] != float64(120) {
			t.Fatalf("expected total=120, body=%s", rr.Body.String())
		}
		if payload["offset"] != float64(50) {
			t.Fatalf("expected offset=50, body=%s", rr.Body.String())
		}
		if payload["limit"] != float64(50) {
			t.Fatalf("expected limit=50, body=%s", rr.Body.String())
		}
	})
}

func TestWebLibraryNormalizesInvalidPaginationQuery(t *testing.T) {
	upstream := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch r.URL.Path {
		case "/Users/AuthenticateByName":
			_ = json.NewEncoder(w).Encode(map[string]any{"AccessToken": "tok-a", "User": map[string]any{"Id": "user-a"}})
		case "/Users/user-a/Views":
			_ = json.NewEncoder(w).Encode(map[string]any{"Items": []map[string]any{{"Id": "view-7", "Name": "电影", "CollectionType": "movies"}}})
		case "/Users/user-a/Items":
			if r.URL.Query().Get("StartIndex") != "0" {
				t.Fatalf("expected StartIndex=0, query=%s", r.URL.RawQuery)
			}
			if r.URL.Query().Get("Limit") != "50" {
				t.Fatalf("expected Limit=50, query=%s", r.URL.RawQuery)
			}
			_ = json.NewEncoder(w).Encode(map[string]any{"Items": []map[string]any{}, "TotalRecordCount": 0, "StartIndex": 0})
		default:
			http.NotFound(w, r)
		}
	}))
	defer upstream.Close()

	withTempAppPrepared(t, singleUpstreamConfig(upstream.URL), nil, func(app *App, handler http.Handler, dir string) {
		if _, err := app.UserStore.Create("alice", "pw-1", []int{0}); err != nil {
			t.Fatalf("create user: %v", err)
		}
		viewVirtualID := app.IDStore.GetOrCreateVirtualID("view-7", 0)
		login := doJSONRequest(t, handler, http.MethodPost, "/web/api/login", map[string]string{"username": "alice", "password": "pw-1"}, "")
		if login.Code != http.StatusOK {
			t.Fatalf("login status = %d, body=%s", login.Code, login.Body.String())
		}

		req := httptest.NewRequest(http.MethodGet, "/web/api/libraries/"+viewVirtualID+"?offset=-1&limit=0", nil)
		req.AddCookie(login.Result().Cookies()[0])
		rr := httptest.NewRecorder()
		handler.ServeHTTP(rr, req)
		if rr.Code != http.StatusOK {
			t.Fatalf("GET /web/api/libraries/:libraryId status = %d, body=%s", rr.Code, rr.Body.String())
		}
	})
}

func TestWebLibraryReturnsNotFoundForUnknownView(t *testing.T) {
	withTempApp(t, func(app *App, handler http.Handler) {
		if _, err := app.UserStore.Create("alice", "pw-1", []int{}); err != nil {
			t.Fatalf("create user: %v", err)
		}
		login := doJSONRequest(t, handler, http.MethodPost, "/web/api/login", map[string]string{"username": "alice", "password": "pw-1"}, "")
		if login.Code != http.StatusOK {
			t.Fatalf("login status = %d, body=%s", login.Code, login.Body.String())
		}
		req := httptest.NewRequest(http.MethodGet, "/web/api/libraries/unknown-view", nil)
		req.AddCookie(login.Result().Cookies()[0])
		rr := httptest.NewRecorder()
		handler.ServeHTTP(rr, req)
		if rr.Code != http.StatusNotFound {
			t.Fatalf("expected 404 for unknown library, got %d body=%s", rr.Code, rr.Body.String())
		}
	})
}
