package backend

import (
	"encoding/json"
	"fmt"
	"net/http"
	"net/url"
	"strconv"
	"strings"
)

type webSelection struct {
	EpisodeID           string `json:"episodeId"`
	MediaSourceID       string `json:"mediaSourceId"`
	AudioStreamIndex    int    `json:"audioStreamIndex"`
	SubtitleStreamIndex int    `json:"subtitleStreamIndex"`
}

// UnmarshalJSON preserves the distinction between an omitted stream selection
// and an explicit selection of stream index 0. The zero value of an int cannot
// represent both states, so omitted indexes are normalized to -1.
func (s *webSelection) UnmarshalJSON(data []byte) error {
	type selectionPayload struct {
		EpisodeID           string `json:"episodeId"`
		MediaSourceID       string `json:"mediaSourceId"`
		AudioStreamIndex    *int   `json:"audioStreamIndex"`
		SubtitleStreamIndex *int   `json:"subtitleStreamIndex"`
	}
	var payload selectionPayload
	if err := json.Unmarshal(data, &payload); err != nil {
		return err
	}
	s.EpisodeID = payload.EpisodeID
	s.MediaSourceID = payload.MediaSourceID
	s.AudioStreamIndex = -1
	s.SubtitleStreamIndex = -1
	if payload.AudioStreamIndex != nil {
		s.AudioStreamIndex = *payload.AudioStreamIndex
	}
	if payload.SubtitleStreamIndex != nil {
		s.SubtitleStreamIndex = *payload.SubtitleStreamIndex
	}
	return nil
}

type webSubtitleTrack struct {
	ID            string `json:"id"`
	Index         int    `json:"index"`
	MediaSourceID string `json:"mediaSourceId"`
	Name          string `json:"name"`
	Language      string `json:"language"`
	Codec         string `json:"codec"`
	RendererKind  string `json:"rendererKind"`
	IsDefault     bool   `json:"isDefault"`
	IsForced      bool   `json:"isForced"`
	IsExternal    bool   `json:"isExternal"`
	URL           string `json:"url,omitempty"`
}

type webSubtitleRuntime struct {
	DefaultTrackID     string   `json:"defaultTrackId,omitempty"`
	AvailableRenderers []string `json:"availableRenderers,omitempty"`
	BurninSupported    bool     `json:"burninSupported"`
}

type webPlaybackResponse struct {
	SessionID           string             `json:"sessionId"`
	ItemID              string             `json:"itemId"`
	Title               string             `json:"title,omitempty"`
	SeriesName          string             `json:"seriesName,omitempty"`
	EpisodeLabel        string             `json:"episodeLabel,omitempty"`
	PreviousEpisode     map[string]any     `json:"previousEpisode,omitempty"`
	NextEpisode         map[string]any     `json:"nextEpisode,omitempty"`
	Selection           webSelection       `json:"selection"`
	Versions            []map[string]any   `json:"versions"`
	AudioTracks         []map[string]any   `json:"audioTracks"`
	SubtitleTracks      []webSubtitleTrack `json:"subtitleTracks"`
	SubtitleRuntime     webSubtitleRuntime `json:"subtitleRuntime"`
	ResumePosition      int64              `json:"resumePosition"`
	ResumePositionTicks int64              `json:"resumePositionTicks"`
	Source              map[string]any     `json:"source"`
	Sources             []map[string]any   `json:"sources"`
}

type webPlaybackContext struct {
	Title           string
	SeriesName      string
	EpisodeLabel    string
	PreviousEpisode map[string]any
	NextEpisode     map[string]any
}

type webPreferredSourceDecision struct {
	Source        map[string]any
	Sources       []map[string]any
	MediaSourceID string
	Strategy      string
}

func webEnsurePlaySessionID(rawURL, playSessionID string) string {
	if rawURL == "" || playSessionID == "" {
		return rawURL
	}
	parsed, err := url.Parse(rawURL)
	if err != nil {
		return rawURL
	}
	query := parsed.Query()
	if query.Get("PlaySessionId") == "" {
		query.Set("PlaySessionId", playSessionID)
		parsed.RawQuery = query.Encode()
	}
	return parsed.String()
}

func (a *App) webPlaybackDisplayContext(r *http.Request, itemID string) webPlaybackContext {
	item := a.webLoadItemDetail(r, itemID)
	if item == nil {
		return webPlaybackContext{}
	}
	ctx := webPlaybackContext{
		Title:      webString(item["Name"]),
		SeriesName: webString(item["SeriesName"]),
	}
	if webString(item["Type"]) != "Episode" {
		return ctx
	}
	ctx.EpisodeLabel = webEpisodeLabel(item)
	seriesVirtualID := webString(item["SeriesId"])
	if seriesVirtualID == "" {
		return ctx
	}
	reqCtx := requestContextFrom(r.Context())
	if resolved := a.resolveRouteIDForRequest(reqCtx, seriesVirtualID); resolved == nil {
		return ctx
	}
	episodes := a.webLoadEpisodes(r, seriesVirtualID, map[string]any{"Type": "Series"})
	for i, episode := range episodes {
		if webString(episode["Id"]) != itemID {
			continue
		}
		if i > 0 {
			ctx.PreviousEpisode = map[string]any{"id": webString(episodes[i-1]["Id"]), "name": webString(episodes[i-1]["Name"])}
		}
		if i+1 < len(episodes) {
			ctx.NextEpisode = map[string]any{"id": webString(episodes[i+1]["Id"]), "name": webString(episodes[i+1]["Name"])}
		}
		break
	}
	return ctx
}

func (a *App) webEpisodeSeriesVirtualID(itemID, seriesID string, reqCtx *RequestContext) string {
	resolved := a.resolveRouteIDForRequest(reqCtx, itemID)
	if resolved == nil || seriesID == "" {
		return ""
	}
	return a.IDStore.GetOrCreateVirtualID(seriesID, resolved.ServerIndex)
}

func webEpisodeLabel(item map[string]any) string {
	seasonNumber := webInt(item["ParentIndexNumber"])
	indexNumber := webInt(item["IndexNumber"])
	if seasonNumber > 0 && indexNumber > 0 {
		return fmt.Sprintf("第%d季 第%d集", seasonNumber, indexNumber)
	}
	if indexNumber > 0 {
		return fmt.Sprintf("第%d集", indexNumber)
	}
	return ""
}

func (a *App) handleWebSelection(w http.ResponseWriter, r *http.Request) {
	var selection webSelection
	if err := decodeJSONBody(r, &selection); err != nil {
		writeJSON(w, http.StatusBadRequest, map[string]any{"message": "Invalid request body"})
		return
	}
	if selection.EpisodeID != "" && selection.EpisodeID != r.PathValue("itemId") {
		selection.MediaSourceID = ""
		selection.AudioStreamIndex = -1
		selection.SubtitleStreamIndex = -1
	}
	itemID := r.PathValue("itemId")
	if selection.EpisodeID != "" {
		itemID = selection.EpisodeID
	}
	query := url.Values{}
	if selection.MediaSourceID != "" {
		query.Set("mediaSourceId", selection.MediaSourceID)
	}
	if selection.AudioStreamIndex >= 0 {
		query.Set("audioStreamIndex", strconv.Itoa(selection.AudioStreamIndex))
	}
	if selection.SubtitleStreamIndex >= 0 {
		query.Set("subtitleStreamIndex", strconv.Itoa(selection.SubtitleStreamIndex))
	}
	writeJSON(w, http.StatusOK, map[string]any{
		"itemId":    itemID,
		"selection": selection,
		"playPath":  fmt.Sprintf("/web/play/%s?%s", itemID, query.Encode()),
	})
}

func (a *App) handleWebPlayback(w http.ResponseWriter, r *http.Request) {
	selection := webSelection{
		EpisodeID:           r.URL.Query().Get("episodeId"),
		MediaSourceID:       r.URL.Query().Get("mediaSourceId"),
		AudioStreamIndex:    atoiDefault(r.URL.Query().Get("audioStreamIndex"), -1),
		SubtitleStreamIndex: atoiDefault(r.URL.Query().Get("subtitleStreamIndex"), -1),
	}
	itemID := r.PathValue("itemId")
	if selection.EpisodeID != "" {
		itemID = selection.EpisodeID
	}
	if a.Logger != nil {
		reqCtx := requestContextFrom(r.Context())
		a.Logger.Debugf("Web playback request: routeItemId=%s effectiveItemId=%s hasProxyUser=%t mediaSourceId=%s audioIndex=%d subtitleIndex=%d",
			r.PathValue("itemId"),
			itemID,
			reqCtx != nil && reqCtx.ProxyUser != nil,
			selection.MediaSourceID,
			selection.AudioStreamIndex,
			selection.SubtitleStreamIndex,
		)
	}
	item := a.webLoadItemDetail(r, itemID)
	if item == nil {
		if a.Logger != nil {
			a.Logger.Warnf("Web playback request failed: itemId=%s reason=item-not-found", itemID)
		}
		writeJSON(w, http.StatusNotFound, map[string]any{"message": "Item not found"})
		return
	}
	if selection.EpisodeID == "" && !webItemDirectlyPlayable(item) {
		if a.Logger != nil {
			a.Logger.Warnf("Web playback request rejected: itemId=%s reason=not-directly-playable type=%s", itemID, webString(item["Type"]))
		}
		writeJSON(w, http.StatusBadRequest, map[string]any{"message": "Item is not directly playable"})
		return
	}
	playbackResult := a.webRequestPlaybackInfoForPlayback(r, itemID, selection)
	if playbackResult.Status != http.StatusOK {
		writeJSON(w, playbackResult.Status, map[string]any{"message": playbackResult.Message})
		return
	}
	playback := playbackResult.Payload
	playback["__WebItemId"] = itemID
	ctx := a.webPlaybackDisplayContext(r, itemID)
	if ctx.Title == "" {
		ctx.Title = webString(item["Name"])
	}
	if ctx.SeriesName == "" {
		ctx.SeriesName = webString(item["SeriesName"])
	}
	sourceDecision := a.webPreferredSourceDecision(r, playback)
	if sourceDecision.MediaSourceID != "" {
		selection.MediaSourceID = sourceDecision.MediaSourceID
	}
	versions := a.webVersionOptions(playback)
	audioTracks := a.webAudioOptions(playback, sourceDecision.MediaSourceID)
	subtitleTracks := a.webPlaybackSubtitleOptions(itemID, playback, sourceDecision.MediaSourceID)
	resumePosition := a.webResumePosition(r, itemID)
	if a.Logger != nil {
		a.Logger.Infof("Web playback response: itemId=%s mediaSourceId=%s sourceKind=%s sourceStrategy=%s sessionId=%s versions=%d audioTracks=%d subtitleTracks=%d",
			itemID,
			sourceDecision.MediaSourceID,
			webString(sourceDecision.Source["kind"]),
			sourceDecision.Strategy,
			webString(playback["PlaySessionId"]),
			len(versions),
			len(audioTracks),
			len(subtitleTracks),
		)
	}
	writeJSON(w, http.StatusOK, webPlaybackResponse{
		SessionID:           webString(playback["PlaySessionId"]),
		ItemID:              itemID,
		Title:               ctx.Title,
		SeriesName:          ctx.SeriesName,
		EpisodeLabel:        ctx.EpisodeLabel,
		PreviousEpisode:     ctx.PreviousEpisode,
		NextEpisode:         ctx.NextEpisode,
		Selection:           selection,
		Versions:            versions,
		AudioTracks:         audioTracks,
		SubtitleTracks:      subtitleTracks,
		SubtitleRuntime:     webSubtitleRuntimeFromTracks(subtitleTracks),
		ResumePosition:      resumePosition,
		ResumePositionTicks: resumePosition,
		Source:              sourceDecision.Source,
		Sources:             sourceDecision.Sources,
	})
}

func webItemDirectlyPlayable(item map[string]any) bool {
	switch webString(item["Type"]) {
	case "Movie", "Episode", "Video", "Audio":
		return true
	default:
		return false
	}
}

func (a *App) webPreferredSource(r *http.Request, playback map[string]any) map[string]any {
	return a.webPreferredSourceDecision(r, playback).Source
}

func (a *App) webPreferredSourceDecision(r *http.Request, playback map[string]any) webPreferredSourceDecision {
	mediaSources := asItems(map[string]any{"Items": playback["MediaSources"]})
	playSessionID := webString(playback["PlaySessionId"])
	if len(mediaSources) == 0 {
		return webPreferredSourceDecision{
			Source:   map[string]any{},
			Sources:  []map[string]any{},
			Strategy: "no-media-source",
		}
	}
	requestedMediaSourceID := r.URL.Query().Get("mediaSourceId")
	selectedMediaSourceID := firstNonEmpty(webString(playback["SelectedMediaSourceId"]), requestedMediaSourceID)
	selectedSource := map[string]any(nil)
	if selectedMediaSourceID != "" {
		for _, source := range mediaSources {
			if webString(source["Id"]) == selectedMediaSourceID {
				selectedSource = source
				break
			}
		}
	}
	if selectedSource == nil {
		selectedSource = mediaSources[0]
		selectedMediaSourceID = webString(selectedSource["Id"])
	}
	prefix := "fallback"
	if requestedMediaSourceID != "" && requestedMediaSourceID == selectedMediaSourceID {
		prefix = "selected"
	}
	return a.webSourceDecisionForMediaSource(r, playback, selectedSource, playSessionID, prefix)
}

func (a *App) webSourceDecisionForMediaSource(r *http.Request, playback, mediaSource map[string]any, playSessionID, strategyPrefix string) webPreferredSourceDecision {
	mediaSourceID := webString(mediaSource["Id"])
	sources := make([]map[string]any, 0, 3)
	hasUsableTranscodingSource := false
	if transcoding := webString(mediaSource["TranscodingUrl"]); transcoding != "" {
		if kind := webTranscodingSourceKind(mediaSource, transcoding); kind == "hls" {
			sources = append(sources, webPlaybackSourceDescriptor(mediaSource, kind, transcoding, strategyPrefix+"-transcoding"))
			hasUsableTranscodingSource = true
		}
	}
	if direct := webString(mediaSource["DirectStreamUrl"]); direct != "" {
		sources = append(sources, webPlaybackSourceDescriptor(mediaSource, "direct", webEnsurePlaySessionID(direct, playSessionID), strategyPrefix+"-direct"))
	}
	itemID := webString(playback["__WebItemId"])
	if itemID == "" {
		itemID = webString(playback["ItemId"])
	}
	if itemID == "" {
		itemID = webString(mediaSource["ItemId"])
	}
	selection := a.webSelectionFromRequest(r)
	selection.MediaSourceID = mediaSourceID
	if webBool(mediaSource["SupportsTranscoding"]) && itemID != "" && mediaSourceID != "" && !hasUsableTranscodingSource {
		compatURL := webCompatibilityHLSURL(itemID, selection, playSessionID)
		compat := webPlaybackSourceDescriptor(mediaSource, "hls", compatURL, "local-compat-transcoding")
		compat["container"] = "m3u8"
		compat["mimeType"] = "application/vnd.apple.mpegurl"
		compat["videoCodec"] = "h264"
		compat["audioCodec"] = "aac"
		sources = append(sources, compat)
	}
	if len(sources) == 0 && itemID != "" && mediaSourceID != "" {
		container := firstNonEmpty(webString(mediaSource["Container"]), "mp4")
		query := url.Values{}
		query.Set("MediaSourceId", mediaSourceID)
		query.Set("Static", "true")
		if playSessionID != "" {
			query.Set("PlaySessionId", playSessionID)
		}
		sources = append(sources, webPlaybackSourceDescriptor(mediaSource, "direct", "/Videos/"+itemID+"/stream."+container+"?"+query.Encode(), "proxy-generated"))
	}
	if len(sources) == 0 {
		return webPreferredSourceDecision{
			Source:        map[string]any{"kind": "direct", "url": "", "mediaSourceId": mediaSourceID},
			Sources:       []map[string]any{},
			MediaSourceID: mediaSourceID,
			Strategy:      "missing-proxy-fallback-context",
		}
	}
	return webPreferredSourceDecision{
		Source:        sources[0],
		Sources:       sources,
		MediaSourceID: mediaSourceID,
		Strategy:      webString(sources[0]["strategy"]),
	}
}

func webTranscodingSourceKind(mediaSource map[string]any, rawURL string) string {
	parsed, err := url.Parse(rawURL)
	if err == nil {
		path := strings.ToLower(parsed.Path)
		switch {
		case strings.HasSuffix(path, ".m3u8"):
			return "hls"
		case strings.HasSuffix(path, ".mpd"):
			return "dash"
		}
	}
	protocol := strings.ToLower(webString(mediaSource["TranscodingProtocol"]))
	switch protocol {
	case "hls":
		return "hls"
	case "dash":
		return "dash"
	default:
		return ""
	}
}

func webCompatibilityHLSURL(itemID string, selection webSelection, playSessionID string) string {
	query := url.Values{}
	query.Set("MediaSourceId", selection.MediaSourceID)
	if selection.AudioStreamIndex >= 0 {
		query.Set("AudioStreamIndex", strconv.Itoa(selection.AudioStreamIndex))
	}
	if selection.SubtitleStreamIndex >= 0 {
		query.Set("SubtitleStreamIndex", strconv.Itoa(selection.SubtitleStreamIndex))
	}
	if playSessionID != "" {
		query.Set("PlaySessionId", playSessionID)
	}
	query.Set("EnableDirectPlay", "false")
	query.Set("EnableDirectStream", "false")
	query.Set("EnableTranscoding", "true")
	query.Set("TranscodingContainer", "ts")
	query.Set("TranscodingProtocol", "hls")
	query.Set("VideoCodec", "h264")
	query.Set("AudioCodec", "aac")
	return "/Videos/" + itemID + "/master.m3u8?" + query.Encode()
}

func webPlaybackSourceDescriptor(mediaSource map[string]any, kind, sourceURL, strategy string) map[string]any {
	container := webString(mediaSource["Container"])
	videoCodec, audioCodec := webMediaSourceCodecs(mediaSource)
	descriptor := map[string]any{
		"kind":          kind,
		"url":           sourceURL,
		"strategy":      strategy,
		"mediaSourceId": webString(mediaSource["Id"]),
		"container":     container,
	}
	if mimeType := webPlaybackMIMEType(kind, container); mimeType != "" {
		descriptor["mimeType"] = mimeType
	}
	if videoCodec != "" {
		descriptor["videoCodec"] = videoCodec
	}
	if audioCodec != "" {
		descriptor["audioCodec"] = audioCodec
	}
	return descriptor
}

func webMediaSourceCodecs(mediaSource map[string]any) (string, string) {
	videoCodec := ""
	audioCodec := ""
	streams, _ := mediaSource["MediaStreams"].([]any)
	for _, raw := range streams {
		stream, ok := raw.(map[string]any)
		if !ok {
			continue
		}
		switch webString(stream["Type"]) {
		case "Video":
			if videoCodec == "" {
				videoCodec = strings.ToLower(webString(stream["Codec"]))
			}
		case "Audio":
			if audioCodec == "" {
				audioCodec = strings.ToLower(webString(stream["Codec"]))
			}
		}
	}
	return videoCodec, audioCodec
}

func webPlaybackMIMEType(kind, container string) string {
	if kind == "hls" {
		return "application/vnd.apple.mpegurl"
	}
	switch strings.ToLower(container) {
	case "mp4", "m4v":
		return "video/mp4"
	case "webm":
		return "video/webm"
	case "ogg", "ogv":
		return "video/ogg"
	case "mp3":
		return "audio/mpeg"
	case "m4a", "aac":
		return "audio/mp4"
	case "flac":
		return "audio/flac"
	default:
		return ""
	}
}

func atoiDefault(value string, fallback int) int {
	if value == "" {
		return fallback
	}
	parsed, err := strconv.Atoi(value)
	if err != nil {
		return fallback
	}
	return parsed
}
