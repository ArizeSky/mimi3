package backend

import (
	"encoding/json"
	"fmt"
	"net/http"
	"net/http/httptest"
	"strings"
	"sync"
	"sync/atomic"
	"testing"
)

func limitedPlaybackConfig(upstreamURL string) string {
	return fmt.Sprintf(`server:
  port: 8096
  name: "Test"
  id: "svr"
admin:
  username: "admin"
  password: "secret"
playback:
  mode: "proxy"
timeouts:
  api: 30000
  global: 15000
  login: 10000
  healthCheck: 10000
  healthInterval: 60000
proxies: []
upstream:
  - name: "A"
    url: %q
    username: "u1"
    password: "p1"
    maxConcurrent: 1
`, upstreamURL)
}

func TestWebItemPlaybackProbeDoesNotReserveLimiter(t *testing.T) {
	var playbackInfoHits atomic.Int32
	upstream := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch {
		case r.Method == http.MethodPost && r.URL.Path == "/Users/AuthenticateByName":
			_ = json.NewEncoder(w).Encode(map[string]any{"AccessToken": "tok-a", "User": map[string]any{"Id": "user-a"}})
		case r.Method == http.MethodGet && r.URL.Path == "/Users/user-a/Items/movie-a":
			_ = json.NewEncoder(w).Encode(map[string]any{"Id": "movie-a", "Name": "Movie A", "Type": "Movie"})
		case r.Method == http.MethodGet && r.URL.Path == "/Items/movie-a/PlaybackInfo":
			hit := playbackInfoHits.Add(1)
			_ = json.NewEncoder(w).Encode(map[string]any{
				"PlaySessionId": fmt.Sprintf("sess-%d", hit),
				"MediaSources": []map[string]any{{
					"Id":                  "ms-a",
					"Name":                "Movie A",
					"Container":           "mkv",
					"SupportsTranscoding": true,
					"DirectStreamUrl":     "/Videos/movie-a/stream.mkv?MediaSourceId=ms-a&api_key=upstream",
					"MediaStreams": []any{
						map[string]any{"Type": "Video", "Index": 0, "Codec": "hevc"},
						map[string]any{"Type": "Audio", "Index": 1, "Codec": "dts", "DisplayTitle": "DTS"},
					},
				}},
			})
		default:
			http.NotFound(w, r)
		}
	}))
	defer upstream.Close()

	withTempAppConfig(t, limitedPlaybackConfig(upstream.URL), func(app *App, handler http.Handler) {
		user, err := app.UserStore.Create("alice", "pw-1", []int{0})
		if err != nil {
			t.Fatalf("create user: %v", err)
		}
		itemID := app.IDStore.GetOrCreateVirtualID("movie-a", 0)
		if err := app.WatchStore.RecordProgress(&WatchProgress{
			ProxyUserID:    user.ID,
			VirtualItemID:  itemID,
			ServerIndex:    0,
			OriginalItemID: "movie-a",
			PositionTicks:  123456789,
			RuntimeTicks:   900000000,
		}); err != nil {
			t.Fatalf("record progress: %v", err)
		}
		login := doJSONRequest(t, handler, http.MethodPost, "/web/api/login", map[string]string{"username": "alice", "password": "pw-1"}, "")
		if login.Code != http.StatusOK {
			t.Fatalf("login status = %d body=%s", login.Code, login.Body.String())
		}
		cookie := login.Result().Cookies()[0]

		itemReq := httptest.NewRequest(http.MethodGet, "/web/api/items/"+itemID, nil)
		itemReq.AddCookie(cookie)
		itemRR := httptest.NewRecorder()
		handler.ServeHTTP(itemRR, itemReq)
		if itemRR.Code != http.StatusOK {
			t.Fatalf("item status = %d body=%s", itemRR.Code, itemRR.Body.String())
		}
		if got := app.PlaybackLimiter.CountForServer(0); got != 0 {
			t.Fatalf("read-only item PlaybackInfo reserved %d limiter slot(s), want 0", got)
		}

		playReq := httptest.NewRequest(http.MethodGet, "/web/api/items/"+itemID+"/playback", nil)
		playReq.AddCookie(cookie)
		playRR := httptest.NewRecorder()
		handler.ServeHTTP(playRR, playReq)
		if playRR.Code != http.StatusOK {
			t.Fatalf("playback status = %d body=%s", playRR.Code, playRR.Body.String())
		}
		if got := app.PlaybackLimiter.CountForServer(0); got != 1 {
			t.Fatalf("formal playback limiter slots = %d, want 1", got)
		}
		var payload map[string]any
		if err := json.Unmarshal(playRR.Body.Bytes(), &payload); err != nil {
			t.Fatalf("decode playback: %v", err)
		}
		if got := int64(payload["resumePositionTicks"].(float64)); got != 123456789 {
			t.Fatalf("resumePositionTicks = %d, want 123456789", got)
		}
		selection := payload["selection"].(map[string]any)
		selectedMediaSourceID := webString(selection["mediaSourceId"])
		if selectedMediaSourceID == "" {
			t.Fatalf("playback selection did not expose selected media source: %s", playRR.Body.String())
		}
		sources := asItems(map[string]any{"Items": payload["sources"]})
		if len(sources) != 2 {
			t.Fatalf("sources = %d, want direct + compatibility HLS: %s", len(sources), playRR.Body.String())
		}
		for _, source := range sources {
			if webString(source["mediaSourceId"]) != selectedMediaSourceID {
				t.Fatalf("source mediaSourceId = %q, want %q", webString(source["mediaSourceId"]), selectedMediaSourceID)
			}
		}
		if webString(sources[1]["kind"]) != "hls" || !strings.Contains(webString(sources[1]["url"]), "PlaySessionId=") {
			t.Fatalf("compatibility source missing HLS/session contract: %#v", sources[1])
		}
		audioTracks := asItems(map[string]any{"Items": payload["audioTracks"]})
		if len(audioTracks) != 1 || webString(audioTracks[0]["mediaSourceId"]) != selectedMediaSourceID {
			t.Fatalf("audio tracks are not scoped to selected media source: %#v", audioTracks)
		}

		secondItemReq := httptest.NewRequest(http.MethodGet, "/web/api/items/"+itemID, nil)
		secondItemReq.AddCookie(cookie)
		secondItemRR := httptest.NewRecorder()
		handler.ServeHTTP(secondItemRR, secondItemReq)
		if secondItemRR.Code != http.StatusOK {
			t.Fatalf("item probe while playback active status = %d body=%s", secondItemRR.Code, secondItemRR.Body.String())
		}
		if got := app.PlaybackLimiter.CountForServer(0); got != 1 {
			t.Fatalf("item probe changed limiter slots to %d, want 1", got)
		}
	})
}

func TestWebSourceDecisionUsesSelectedMediaSourceAndSkipsDASH(t *testing.T) {
	req := httptest.NewRequest(http.MethodGet, "/web/api/items/item/playback", nil)
	playback := map[string]any{
		"__WebItemId":           "item",
		"PlaySessionId":         "play-session",
		"SelectedMediaSourceId": "ms-a",
		"MediaSources": []any{
			map[string]any{
				"Id":              "ms-a",
				"Container":       "mkv",
				"DirectStreamUrl": "/Videos/item/stream.mkv?MediaSourceId=ms-a",
			},
			map[string]any{
				"Id":                  "ms-b",
				"Container":           "mkv",
				"SupportsTranscoding": true,
				"DirectStreamUrl":     "/Videos/item/stream-b.mkv?MediaSourceId=ms-b",
				"TranscodingUrl":      "/Videos/item/master.mpd?MediaSourceId=ms-b",
				"TranscodingProtocol": "hls",
			},
		},
	}
	decision := (&App{}).webPreferredSourceDecision(req, playback)
	if decision.MediaSourceID != "ms-a" || webString(decision.Source["mediaSourceId"]) != "ms-a" {
		t.Fatalf("default decision escaped selected media source: %#v", decision)
	}
	if !strings.Contains(webString(decision.Source["url"]), "PlaySessionId=play-session") {
		t.Fatalf("selected direct source does not carry selected play session: %#v", decision.Source)
	}

	playback["SelectedMediaSourceId"] = "ms-b"
	decision = (&App{}).webPreferredSourceDecision(req, playback)
	if len(decision.Sources) != 2 {
		t.Fatalf("DASH decision sources = %#v, want direct + local HLS", decision.Sources)
	}
	for _, source := range decision.Sources {
		if webString(source["kind"]) == "dash" || strings.Contains(webString(source["url"]), ".mpd") {
			t.Fatalf("unsupported DASH source leaked to browser candidates: %#v", decision.Sources)
		}
	}
	if webString(decision.Sources[1]["kind"]) != "hls" || webString(decision.Sources[1]["strategy"]) != "local-compat-transcoding" {
		t.Fatalf("missing local compatibility HLS fallback: %#v", decision.Sources)
	}
	if kind := webTranscodingSourceKind(map[string]any{"TranscodingProtocol": "dash"}, "/Videos/item/master.m3u8"); kind != "hls" {
		t.Fatalf("explicit .m3u8 extension should override conflicting protocol, got %q", kind)
	}
}

func TestPlaybackInfoIntentCannotBeForgedByPublicHeader(t *testing.T) {
	post := httptest.NewRequest(http.MethodPost, "/Items/item/PlaybackInfo", nil)
	post.Header.Set("X-Emby-In-One-Playback-Intent", "probe")
	if !playbackInfoStartsPlayback(post) {
		t.Fatal("public probe header bypassed POST playback semantics")
	}

	internalProbe := withPlaybackInfoIntent(post, playbackInfoIntentProbe)
	if playbackInfoStartsPlayback(internalProbe) {
		t.Fatal("internal probe context was not honored")
	}

	get := httptest.NewRequest(http.MethodGet, "/Items/item/PlaybackInfo", nil)
	get.Header.Set("X-Emby-In-One-Playback-Intent", "start")
	if playbackInfoStartsPlayback(get) {
		t.Fatal("public start header overrode GET probe semantics")
	}
	if !playbackInfoStartsPlayback(withPlaybackInfoIntent(get, playbackInfoIntentStart)) {
		t.Fatal("internal start context was not honored")
	}
}

func TestWebSessionLifecycleRoutesMergedItemToPlaySessionServer(t *testing.T) {
	var hitsA atomic.Int32
	var mu sync.Mutex
	pathsB := make([]string, 0, 3)
	payloadsB := make([]map[string]any, 0, 3)

	serverA := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch {
		case r.Method == http.MethodPost && r.URL.Path == "/Users/AuthenticateByName":
			_ = json.NewEncoder(w).Encode(map[string]any{"AccessToken": "tok-a", "User": map[string]any{"Id": "user-a"}})
		case strings.HasPrefix(r.URL.Path, "/Sessions/Playing"):
			hitsA.Add(1)
			w.WriteHeader(http.StatusNoContent)
		default:
			http.NotFound(w, r)
		}
	}))
	defer serverA.Close()

	serverB := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch {
		case r.Method == http.MethodPost && r.URL.Path == "/Users/AuthenticateByName":
			_ = json.NewEncoder(w).Encode(map[string]any{"AccessToken": "tok-b", "User": map[string]any{"Id": "user-b"}})
		case r.Method == http.MethodGet && r.URL.Path == "/Users/user-b/Items/item-b":
			_ = json.NewEncoder(w).Encode(map[string]any{"Id": "item-b", "Name": "Movie B", "Type": "Movie"})
		case r.Method == http.MethodPost && strings.HasPrefix(r.URL.Path, "/Sessions/Playing"):
			var payload map[string]any
			_ = json.NewDecoder(r.Body).Decode(&payload)
			mu.Lock()
			pathsB = append(pathsB, r.URL.Path)
			payloadsB = append(payloadsB, payload)
			mu.Unlock()
			w.WriteHeader(http.StatusNoContent)
		default:
			http.NotFound(w, r)
		}
	}))
	defer serverB.Close()

	withTempAppConfig(t, dualUpstreamConfig(serverA.URL, serverB.URL), func(app *App, handler http.Handler) {
		if _, err := app.UserStore.Create("alice", "pw-1", []int{0, 1}); err != nil {
			t.Fatalf("create user: %v", err)
		}
		itemID := app.IDStore.GetOrCreateVirtualID("item-a", 0)
		app.IDStore.AssociateAdditionalInstance(itemID, "item-b", 1)
		mediaSourceID := app.IDStore.GetOrCreateVirtualID("ms-b", 1)
		playSessionID := app.IDStore.GetOrCreateVirtualID("sess-b", 1)
		login := doJSONRequest(t, handler, http.MethodPost, "/web/api/login", map[string]string{"username": "alice", "password": "pw-1"}, "")
		if login.Code != http.StatusOK {
			t.Fatalf("login status = %d body=%s", login.Code, login.Body.String())
		}
		cookie := login.Result().Cookies()[0]
		body := map[string]any{
			"itemId":        itemID,
			"mediaSourceId": mediaSourceID,
			"playSessionId": playSessionID,
			"positionTicks": 95000000,
			"runTimeTicks":  100000000,
		}
		for _, event := range []struct {
			path      string
			eventName string
			isEnded   bool
		}{
			{path: "/web/api/sessions/" + playSessionID + "/started", eventName: "playing"},
			{path: "/web/api/sessions/" + playSessionID + "/progress", eventName: "seeked"},
			{path: "/web/api/sessions/" + playSessionID + "/stop", eventName: "ended", isEnded: true},
		} {
			body["eventName"] = event.eventName
			body["isEnded"] = event.isEnded
			encoded, _ := json.Marshal(body)
			request := httptest.NewRequest(http.MethodPost, event.path, strings.NewReader(string(encoded)))
			request.Header.Set("Content-Type", "application/json")
			request.AddCookie(cookie)
			response := httptest.NewRecorder()
			handler.ServeHTTP(response, request)
			if response.Code != http.StatusNoContent {
				t.Fatalf("%s status = %d body=%s", event.path, response.Code, response.Body.String())
			}
		}

		if got := hitsA.Load(); got != 0 {
			t.Fatalf("session lifecycle was sent to primary server A %d time(s)", got)
		}
		mu.Lock()
		defer mu.Unlock()
		wantPaths := []string{"/Sessions/Playing", "/Sessions/Playing/Progress", "/Sessions/Playing/Stopped"}
		if len(pathsB) != len(wantPaths) {
			t.Fatalf("server B lifecycle paths = %#v, want %#v", pathsB, wantPaths)
		}
		for i, wantPath := range wantPaths {
			if pathsB[i] != wantPath {
				t.Fatalf("path[%d] = %q, want %q", i, pathsB[i], wantPath)
			}
			payload := payloadsB[i]
			if webString(payload["ItemId"]) != "item-b" || webString(payload["MediaSourceId"]) != "ms-b" || webString(payload["PlaySessionId"]) != "sess-b" {
				t.Fatalf("translated payload[%d] = %#v", i, payload)
			}
		}
	})
}
