package backend

import (
	"bytes"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"strings"
	"sync/atomic"
	"testing"
)

func mustJSONObject(t *testing.T, body []byte) map[string]any {
	t.Helper()
	var payload map[string]any
	if err := json.Unmarshal(body, &payload); err != nil {
		t.Fatalf("unmarshal response: %v", err)
	}
	return payload
}

func mustJSONArray(t *testing.T, value any) []any {
	t.Helper()
	items, ok := value.([]any)
	if !ok {
		t.Fatalf("expected JSON array, got %T", value)
	}
	return items
}

func mustJSONMap(t *testing.T, value any) map[string]any {
	t.Helper()
	item, ok := value.(map[string]any)
	if !ok {
		t.Fatalf("expected JSON object, got %T", value)
	}
	return item
}

func mustJSONString(t *testing.T, value any) string {
	t.Helper()
	text, ok := value.(string)
	if !ok {
		t.Fatalf("expected string, got %T", value)
	}
	return text
}

func requireTrackKeys(t *testing.T, track map[string]any, keys ...string) {
	t.Helper()
	for _, key := range keys {
		if _, ok := track[key]; !ok {
			t.Fatalf("expected subtitle track to include %q, got %v", key, track)
		}
	}
}

func getSubtitleTrackByRendererKind(t *testing.T, tracks []any, rendererKind string) map[string]any {
	t.Helper()
	for _, raw := range tracks {
		track := mustJSONMap(t, raw)
		if mustJSONString(t, track["rendererKind"]) == rendererKind {
			return track
		}
	}
	t.Fatalf("rendererKind %q not found in tracks: %v", rendererKind, tracks)
	return nil
}

func TestWebSelectionNormalizesRequestedVersionAndEpisode(t *testing.T) {
	withTempApp(t, func(app *App, handler http.Handler) {
		if _, err := app.UserStore.Create("alice", "pw-1", []int{0}); err != nil {
			t.Fatalf("create user: %v", err)
		}
		login := doJSONRequest(t, handler, http.MethodPost, "/web/api/login", map[string]string{"username": "alice", "password": "pw-1"}, "")
		if login.Code != http.StatusOK {
			t.Fatalf("login status = %d, body=%s", login.Code, login.Body.String())
		}

		req := httptest.NewRequest(http.MethodPost, "/web/api/items/virt-1/select", bytes.NewBufferString(`{"episodeId":"ep-1","mediaSourceId":"ms-1","audioStreamIndex":1,"subtitleStreamIndex":2}`))
		req.Header.Set("Content-Type", "application/json")
		req.AddCookie(login.Result().Cookies()[0])
		rr := httptest.NewRecorder()
		handler.ServeHTTP(rr, req)
		if rr.Code != http.StatusOK {
			t.Fatalf("POST /web/api/items/:id/select status = %d, body=%s", rr.Code, rr.Body.String())
		}
		if !strings.Contains(rr.Body.String(), `"playPath"`) {
			t.Fatalf("selection payload missing playPath: %s", rr.Body.String())
		}
	})
}

func TestWebSelectionDistinguishesMissingIndexesFromExplicitZero(t *testing.T) {
	var omitted webSelection
	if err := json.Unmarshal([]byte(`{"episodeId":"ep-1"}`), &omitted); err != nil {
		t.Fatalf("unmarshal omitted selection: %v", err)
	}
	if omitted.AudioStreamIndex != -1 || omitted.SubtitleStreamIndex != -1 {
		t.Fatalf("omitted indexes = audio:%d subtitle:%d, want -1/-1", omitted.AudioStreamIndex, omitted.SubtitleStreamIndex)
	}

	var explicitZero webSelection
	if err := json.Unmarshal([]byte(`{"audioStreamIndex":0,"subtitleStreamIndex":0}`), &explicitZero); err != nil {
		t.Fatalf("unmarshal explicit-zero selection: %v", err)
	}
	if explicitZero.AudioStreamIndex != 0 || explicitZero.SubtitleStreamIndex != 0 {
		t.Fatalf("explicit indexes = audio:%d subtitle:%d, want 0/0", explicitZero.AudioStreamIndex, explicitZero.SubtitleStreamIndex)
	}
}

func TestWebSelectionClearsMediaSourceWhenSwitchingEpisodes(t *testing.T) {
	withTempApp(t, func(app *App, handler http.Handler) {
		if _, err := app.UserStore.Create("alice", "pw-1", []int{0}); err != nil {
			t.Fatalf("create user: %v", err)
		}
		login := doJSONRequest(t, handler, http.MethodPost, "/web/api/login", map[string]string{"username": "alice", "password": "pw-1"}, "")
		if login.Code != http.StatusOK {
			t.Fatalf("login status = %d, body=%s", login.Code, login.Body.String())
		}

		req := httptest.NewRequest(http.MethodPost, "/web/api/items/ep-2/select", bytes.NewBufferString(`{"episodeId":"ep-3","mediaSourceId":"ms-2","audioStreamIndex":1,"subtitleStreamIndex":2}`))
		req.Header.Set("Content-Type", "application/json")
		req.AddCookie(login.Result().Cookies()[0])
		rr := httptest.NewRecorder()
		handler.ServeHTTP(rr, req)
		if rr.Code != http.StatusOK {
			t.Fatalf("POST /web/api/items/:id/select status = %d, body=%s", rr.Code, rr.Body.String())
		}
		var payload map[string]any
		if err := json.Unmarshal(rr.Body.Bytes(), &payload); err != nil {
			t.Fatalf("unmarshal selection payload: %v", err)
		}
		playPath, _ := payload["playPath"].(string)
		if playPath == "" {
			t.Fatalf("selection payload missing playPath: %s", rr.Body.String())
		}
		if strings.Contains(playPath, "mediaSourceId=") {
			t.Fatalf("expected episode switch playPath to drop stale mediaSourceId, got %q", playPath)
		}
		if strings.Contains(playPath, "audioStreamIndex=") || strings.Contains(playPath, "subtitleStreamIndex=") {
			t.Fatalf("expected episode switch playPath to drop stale stream indexes, got %q", playPath)
		}
		if !strings.HasPrefix(playPath, "/web/play/ep-3") {
			t.Fatalf("expected episode switch playPath to target next episode, got %q", playPath)
		}
	})
}

func TestWebPlaybackFallsBackToProxyStreamWhenURLsAreMissing(t *testing.T) {
	upstream := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch r.URL.Path {
		case "/Users/AuthenticateByName":
			_ = json.NewEncoder(w).Encode(map[string]any{"AccessToken": "tok-a", "User": map[string]any{"Id": "user-a"}})
		case "/Users/user-a/Items/item-file":
			_ = json.NewEncoder(w).Encode(map[string]any{"Id": "item-file", "Name": "File Movie", "Type": "Movie"})
		case "/Items/item-file/PlaybackInfo":
			_ = json.NewEncoder(w).Encode(map[string]any{"PlaySessionId": "sess-file", "MediaSources": []map[string]any{{
				"Id":        "ms-file",
				"Name":      "File Version",
				"Container": "mp4",
				"Protocol":  "File",
				"MediaStreams": []map[string]any{
					{"Type": "Audio", "Index": 1, "DisplayTitle": "AAC"},
				},
			}}})
		default:
			http.NotFound(w, r)
		}
	}))
	defer upstream.Close()

	withTempAppPrepared(t, singleUpstreamConfig(upstream.URL), nil, func(app *App, handler http.Handler, dir string) {
		if _, err := app.UserStore.Create("alice", "pw-1", []int{0}); err != nil {
			t.Fatalf("create user: %v", err)
		}
		itemID := app.IDStore.GetOrCreateVirtualID("item-file", 0)
		login := doJSONRequest(t, handler, http.MethodPost, "/web/api/login", map[string]string{"username": "alice", "password": "pw-1"}, "")
		if login.Code != http.StatusOK {
			t.Fatalf("login status = %d, body=%s", login.Code, login.Body.String())
		}

		req := httptest.NewRequest(http.MethodGet, "/web/api/items/"+itemID+"/playback", nil)
		req.AddCookie(login.Result().Cookies()[0])
		rr := httptest.NewRecorder()
		handler.ServeHTTP(rr, req)
		if rr.Code != http.StatusOK {
			t.Fatalf("GET /web/api/items/:id/playback status = %d, body=%s", rr.Code, rr.Body.String())
		}
		body := rr.Body.String()
		if !strings.Contains(body, `"url":"/Videos/`+itemID+`/stream.mp4?MediaSourceId=`) {
			t.Fatalf("expected proxy stream fallback url, body=%s", rr.Body.String())
		}
		payload := mustJSONObject(t, rr.Body.Bytes())
		sessionID := mustJSONString(t, payload["sessionId"])
		if !strings.Contains(body, `PlaySessionId=`+sessionID) {
			t.Fatalf("expected proxy stream fallback url to retain response sessionId %q, body=%s", sessionID, body)
		}
	})
}

func TestWebPlaybackSubtitleTracksIncludeRuntimeMetadata(t *testing.T) {
	upstream := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch r.URL.Path {
		case "/Users/AuthenticateByName":
			_ = json.NewEncoder(w).Encode(map[string]any{"AccessToken": "tok-a", "User": map[string]any{"Id": "user-a"}})
		case "/Users/user-a/Items/item-a":
			_ = json.NewEncoder(w).Encode(map[string]any{"Id": "item-a", "Name": "Movie A", "Type": "Movie"})
		case "/Items/item-a/PlaybackInfo":
			_ = json.NewEncoder(w).Encode(map[string]any{
				"PlaySessionId": "sess-1",
				"MediaSources": []map[string]any{{
					"Id":        "ms-a",
					"Name":      "Version A",
					"Container": "mp4",
					"Protocol":  "File",
					"MediaStreams": []map[string]any{
						{"Type": "Audio", "Index": 1, "DisplayTitle": "AAC"},
						{"Type": "Subtitle", "Index": 2, "DisplayTitle": "English", "Title": "English", "Language": "eng", "Codec": "srt", "External": true, "IsDefault": true, "DeliveryUrl": "/Videos/item-a/ms-a/Subtitles/2/Stream.srt"},
						{"Type": "Subtitle", "Index": 3, "DisplayTitle": "Chinese ASS", "Title": "Chinese ASS", "Language": "chi", "Codec": "ass", "IsForced": true, "DeliveryUrl": "/Videos/item-a/ms-a/Subtitles/3/Stream.ass"},
						{"Type": "Subtitle", "Index": 4, "DisplayTitle": "Japanese PGS", "Title": "Japanese PGS", "Language": "jpn", "Codec": "pgs", "DeliveryUrl": "/Videos/item-a/ms-a/Subtitles/4/Stream.sup"},
						{"Type": "Subtitle", "Index": 5, "DisplayTitle": "Fallback Text", "Title": "Fallback Text", "Language": "eng", "Codec": "", "DeliveryUrl": "/Videos/item-a/ms-a/Subtitles/5/Stream.srt"},
					},
				}},
			})
		default:
			http.NotFound(w, r)
		}
	}))
	defer upstream.Close()

	withTempAppPrepared(t, singleUpstreamConfig(upstream.URL), nil, func(app *App, handler http.Handler, dir string) {
		if _, err := app.UserStore.Create("alice", "pw-1", []int{0}); err != nil {
			t.Fatalf("create user: %v", err)
		}
		itemID := app.IDStore.GetOrCreateVirtualID("item-a", 0)
		login := doJSONRequest(t, handler, http.MethodPost, "/web/api/login", map[string]string{"username": "alice", "password": "pw-1"}, "")
		if login.Code != http.StatusOK {
			t.Fatalf("login status = %d, body=%s", login.Code, login.Body.String())
		}

		req := httptest.NewRequest(http.MethodGet, "/web/api/items/"+itemID+"/playback", nil)
		req.AddCookie(login.Result().Cookies()[0])
		rr := httptest.NewRecorder()
		handler.ServeHTTP(rr, req)
		if rr.Code != http.StatusOK {
			t.Fatalf("GET /web/api/items/:id/playback status = %d, body=%s", rr.Code, rr.Body.String())
		}

		payload := mustJSONObject(t, rr.Body.Bytes())
		tracks := mustJSONArray(t, payload["subtitleTracks"])
		if len(tracks) != 4 {
			t.Fatalf("expected 4 subtitle tracks, got %d: %s", len(tracks), rr.Body.String())
		}

		textTrack := mustJSONMap(t, tracks[0])
		requireTrackKeys(t, textTrack, "id", "index", "mediaSourceId", "name", "codec", "rendererKind", "isDefault", "isExternal")
		if got := mustJSONString(t, textTrack["rendererKind"]); got != "text" {
			t.Fatalf("expected text track rendererKind=text, got %q", got)
		}
		if got := mustJSONString(t, textTrack["id"]); got == "" {
			t.Fatalf("expected text track id to be populated")
		}

		assTrack := mustJSONMap(t, tracks[1])
		requireTrackKeys(t, assTrack, "id", "index", "mediaSourceId", "name", "codec", "rendererKind", "isForced")
		if got := mustJSONString(t, assTrack["rendererKind"]); got != "burnin" {
			t.Fatalf("expected ASS track to advertise reliable rendererKind=burnin, got %q", got)
		}

		bitmapTrack := mustJSONMap(t, tracks[2])
		requireTrackKeys(t, bitmapTrack, "id", "index", "mediaSourceId", "name", "codec", "rendererKind")
		if got := mustJSONString(t, bitmapTrack["rendererKind"]); got != "burnin" {
			t.Fatalf("expected bitmap track to advertise reliable rendererKind=burnin, got %q", got)
		}

		emptyCodecTrack := mustJSONMap(t, tracks[3])
		requireTrackKeys(t, emptyCodecTrack, "id", "index", "mediaSourceId", "name", "codec", "rendererKind", "isDefault", "isForced", "isExternal")
		if got := webInt(emptyCodecTrack["index"]); got != 5 {
			t.Fatalf("expected empty-codec track index=5, got %d", got)
		}
		if got := webString(emptyCodecTrack["codec"]); got != "" {
			t.Fatalf("expected empty-codec track codec to be empty, got %q", got)
		}
		if webBool(emptyCodecTrack["isDefault"]) || webBool(emptyCodecTrack["isForced"]) || webBool(emptyCodecTrack["isExternal"]) {
			t.Fatalf("expected empty-codec track boolean flags to be false, got %+v", emptyCodecTrack)
		}

		runtime := mustJSONMap(t, payload["subtitleRuntime"])
		if got := mustJSONString(t, runtime["defaultTrackId"]); got != mustJSONString(t, textTrack["id"]) {
			t.Fatalf("expected defaultTrackId to match default subtitle track, got %q want %q", got, mustJSONString(t, textTrack["id"]))
		}
		renderers := mustJSONArray(t, runtime["availableRenderers"])
		if len(renderers) != 2 {
			t.Fatalf("expected only reliable text/burnin renderers, got %v", renderers)
		}
		gotRenderers := map[string]bool{}
		for _, raw := range renderers {
			gotRenderers[mustJSONString(t, raw)] = true
		}
		for _, want := range []string{"text", "burnin"} {
			if !gotRenderers[want] {
				t.Fatalf("expected availableRenderers to include %q, got %v", want, renderers)
			}
		}
		if burnin, ok := runtime["burninSupported"].(bool); !ok || !burnin {
			t.Fatalf("expected burninSupported=true, got %v", runtime["burninSupported"])
		}
	})
}

func TestWebPlaybackClassifiesSubtitleRendererKindByCodec(t *testing.T) {
	cases := []struct {
		name        string
		codec       string
		deliveryURL string
		want        string
	}{
		{name: "ass", codec: "ass", deliveryURL: "/Videos/item-a/ms-a/Subtitles/1/Stream.ass", want: "burnin"},
		{name: "ssa", codec: "ssa", deliveryURL: "/Videos/item-a/ms-a/Subtitles/1/Stream.ass", want: "burnin"},
		{name: "pgs", codec: "pgs", deliveryURL: "/Videos/item-a/ms-a/Subtitles/1/Stream.sup", want: "burnin"},
		{name: "hdmv_pgs_subtitle", codec: "hdmv_pgs_subtitle", deliveryURL: "/Videos/item-a/ms-a/Subtitles/1/Stream.sup", want: "burnin"},
		{name: "dvb_subtitle", codec: "dvb_subtitle", deliveryURL: "/Videos/item-a/ms-a/Subtitles/1/Stream.sub", want: "burnin"},
		{name: "dvd_subtitle", codec: "dvd_subtitle", deliveryURL: "/Videos/item-a/ms-a/Subtitles/1/Stream.sub", want: "burnin"},
		{name: "vobsub", codec: "vobsub", deliveryURL: "/Videos/item-a/ms-a/Subtitles/1/Stream.sub", want: "burnin"},
		{name: "srt", codec: "srt", deliveryURL: "/Videos/item-a/ms-a/Subtitles/1/Stream.srt", want: "text"},
		{name: "vtt", codec: "vtt", deliveryURL: "/Videos/item-a/ms-a/Subtitles/1/Stream.vtt", want: "text"},
		{name: "delivery-url-text-with-empty-codec", codec: "", deliveryURL: "/Videos/item-a/ms-a/Subtitles/1/Stream.srt", want: "text"},
		{name: "delivery-url-bitmap-sup-with-empty-codec", codec: "", deliveryURL: "/Videos/item-a/ms-a/Subtitles/1/Stream.sup", want: "burnin"},
		{name: "delivery-url-bitmap-sub-with-empty-codec", codec: "", deliveryURL: "/Videos/item-a/ms-a/Subtitles/1/Stream.sub", want: "burnin"},
	}

	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			upstream := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
				switch r.URL.Path {
				case "/Users/AuthenticateByName":
					_ = json.NewEncoder(w).Encode(map[string]any{"AccessToken": "tok-a", "User": map[string]any{"Id": "user-a"}})
				case "/Users/user-a/Items/item-a":
					_ = json.NewEncoder(w).Encode(map[string]any{"Id": "item-a", "Name": "Movie A", "Type": "Movie"})
				case "/Items/item-a/PlaybackInfo":
					_ = json.NewEncoder(w).Encode(map[string]any{
						"PlaySessionId": "sess-1",
						"MediaSources": []map[string]any{{
							"Id":        "ms-a",
							"Name":      "Version A",
							"Container": "mp4",
							"Protocol":  "File",
							"MediaStreams": []map[string]any{
								{"Type": "Subtitle", "Index": 1, "DisplayTitle": "Subtitle", "Title": "Subtitle", "Language": "eng", "Codec": tc.codec, "DeliveryUrl": tc.deliveryURL},
							},
						}},
					})
				default:
					http.NotFound(w, r)
				}
			}))
			defer upstream.Close()

			withTempAppPrepared(t, singleUpstreamConfig(upstream.URL), nil, func(app *App, handler http.Handler, dir string) {
				if _, err := app.UserStore.Create("alice", "pw-1", []int{0}); err != nil {
					t.Fatalf("create user: %v", err)
				}
				itemID := app.IDStore.GetOrCreateVirtualID("item-a", 0)
				login := doJSONRequest(t, handler, http.MethodPost, "/web/api/login", map[string]string{"username": "alice", "password": "pw-1"}, "")
				if login.Code != http.StatusOK {
					t.Fatalf("login status = %d, body=%s", login.Code, login.Body.String())
				}

				req := httptest.NewRequest(http.MethodGet, "/web/api/items/"+itemID+"/playback", nil)
				req.AddCookie(login.Result().Cookies()[0])
				rr := httptest.NewRecorder()
				handler.ServeHTTP(rr, req)
				if rr.Code != http.StatusOK {
					t.Fatalf("GET /web/api/items/:id/playback status = %d, body=%s", rr.Code, rr.Body.String())
				}

				payload := mustJSONObject(t, rr.Body.Bytes())
				tracks := mustJSONArray(t, payload["subtitleTracks"])
				if len(tracks) != 1 {
					t.Fatalf("expected exactly one subtitle track, got %d", len(tracks))
				}
				track := mustJSONMap(t, tracks[0])
				if got := mustJSONString(t, track["rendererKind"]); got != tc.want {
					t.Fatalf("expected rendererKind=%q, got %q body=%s", tc.want, got, rr.Body.String())
				}
			})
		})
	}
}

func TestWebPlaybackPrefersTranscodingManifestWhenAvailable(t *testing.T) {
	upstream := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch r.URL.Path {
		case "/Users/AuthenticateByName":
			_ = json.NewEncoder(w).Encode(map[string]any{"AccessToken": "tok-a", "User": map[string]any{"Id": "user-a"}})
		case "/Users/user-a/Items/item-a":
			_ = json.NewEncoder(w).Encode(map[string]any{"Id": "item-a", "Name": "Movie A", "Type": "Movie"})
		case "/Items/item-a/PlaybackInfo":
			_ = json.NewEncoder(w).Encode(map[string]any{"PlaySessionId": "sess-1", "MediaSources": []map[string]any{{
				"Id":              "ms-a",
				"Name":            "Version A",
				"Container":       "mp4",
				"TranscodingUrl":  "/Videos/item-a/master.m3u8?MediaSourceId=ms-a&api_key=upstream",
				"DirectStreamUrl": "/Videos/item-a/stream.mp4?MediaSourceId=ms-a&api_key=upstream",
				"MediaStreams": []map[string]any{
					{"Type": "Audio", "Index": 1, "DisplayTitle": "AAC"},
					{"Type": "Subtitle", "Index": 2, "DisplayTitle": "中文字幕", "DeliveryUrl": "/Videos/item-a/ms-a/Subtitles/2/Stream.vtt"},
				},
			}}})
		default:
			http.NotFound(w, r)
		}
	}))
	defer upstream.Close()

	withTempAppPrepared(t, singleUpstreamConfig(upstream.URL), nil, func(app *App, handler http.Handler, dir string) {
		if _, err := app.UserStore.Create("alice", "pw-1", []int{0}); err != nil {
			t.Fatalf("create user: %v", err)
		}
		itemID := app.IDStore.GetOrCreateVirtualID("item-a", 0)
		login := doJSONRequest(t, handler, http.MethodPost, "/web/api/login", map[string]string{"username": "alice", "password": "pw-1"}, "")
		if login.Code != http.StatusOK {
			t.Fatalf("login status = %d, body=%s", login.Code, login.Body.String())
		}

		req := httptest.NewRequest(http.MethodGet, "/web/api/items/"+itemID+"/playback?subtitleStreamIndex=2", nil)
		req.AddCookie(login.Result().Cookies()[0])
		rr := httptest.NewRecorder()
		handler.ServeHTTP(rr, req)
		if rr.Code != http.StatusOK {
			t.Fatalf("GET /web/api/items/:id/playback status = %d, body=%s", rr.Code, rr.Body.String())
		}
		body := rr.Body.String()
		if !strings.Contains(body, `"kind":"hls"`) {
			t.Fatalf("expected HLS playback preference, body=%s", body)
		}
		if !strings.Contains(body, `"subtitleTracks":[`) || !strings.Contains(body, `"url":"/Videos/`+itemID+`/`) {
			t.Fatalf("expected subtitle track url in payload, body=%s", body)
		}
		if !strings.Contains(body, `/Subtitles/2/Stream.vtt`) {
			t.Fatalf("expected subtitle delivery url to be rewritten, body=%s", body)
		}
	})
}

func TestWebPlaybackCookieSessionOmitsProxyTokenFromPlaybackAndSubtitleURLs(t *testing.T) {
	upstream := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch r.URL.Path {
		case "/Users/AuthenticateByName":
			_ = json.NewEncoder(w).Encode(map[string]any{"AccessToken": "tok-a", "User": map[string]any{"Id": "user-a"}})
		case "/Users/user-a/Items/item-a":
			_ = json.NewEncoder(w).Encode(map[string]any{"Id": "item-a", "Name": "Movie A", "Type": "Movie"})
		case "/Items/item-a/PlaybackInfo":
			_ = json.NewEncoder(w).Encode(map[string]any{"PlaySessionId": "sess-1", "MediaSources": []map[string]any{{
				"Id":              "ms-a",
				"Name":            "Version A",
				"Container":       "mp4",
				"TranscodingUrl":  "/Videos/item-a/master.m3u8?MediaSourceId=ms-a&api_key=upstream-token",
				"DirectStreamUrl": "/Videos/item-a/stream.mp4?MediaSourceId=ms-a&api_key=upstream-token",
				"MediaStreams": []map[string]any{
					{"Type": "Subtitle", "Index": 2, "DisplayTitle": "中文字幕", "Codec": "srt", "DeliveryUrl": "/Videos/item-a/ms-a/Subtitles/2/Stream.srt?api_key=upstream-token"},
				},
			}}})
		default:
			http.NotFound(w, r)
		}
	}))
	defer upstream.Close()

	withTempAppPrepared(t, singleUpstreamConfig(upstream.URL), nil, func(app *App, handler http.Handler, dir string) {
		if _, err := app.UserStore.Create("alice", "pw-1", []int{0}); err != nil {
			t.Fatalf("create user: %v", err)
		}
		itemID := app.IDStore.GetOrCreateVirtualID("item-a", 0)
		login := doJSONRequest(t, handler, http.MethodPost, "/web/api/login", map[string]string{"username": "alice", "password": "pw-1"}, "")
		if login.Code != http.StatusOK {
			t.Fatalf("login status = %d, body=%s", login.Code, login.Body.String())
		}

		req := httptest.NewRequest(http.MethodGet, "/web/api/items/"+itemID+"/playback?subtitleStreamIndex=2", nil)
		req.AddCookie(login.Result().Cookies()[0])
		rr := httptest.NewRecorder()
		handler.ServeHTTP(rr, req)
		if rr.Code != http.StatusOK {
			t.Fatalf("GET /web/api/items/:id/playback status = %d, body=%s", rr.Code, rr.Body.String())
		}
		body := rr.Body.String()
		if !strings.Contains(body, `/Videos/`+itemID+`/master.m3u8`) {
			t.Fatalf("expected proxied playback source URL, body=%s", body)
		}
		if !strings.Contains(body, `/Subtitles/2/Stream.vtt`) {
			t.Fatalf("expected proxied browser subtitle URL, body=%s", body)
		}
		if strings.Contains(body, "api_key=") {
			t.Fatalf("expected web playback response to omit proxy token from browser URLs, body=%s", body)
		}
	})
}

func TestWebPlaybackSynthesizesBrowserSubtitleURLWhenTextTrackDeliveryURLIsMissing(t *testing.T) {
	upstream := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch r.URL.Path {
		case "/Users/AuthenticateByName":
			_ = json.NewEncoder(w).Encode(map[string]any{"AccessToken": "tok-a", "User": map[string]any{"Id": "user-a"}})
		case "/Users/user-a/Items/item-a":
			_ = json.NewEncoder(w).Encode(map[string]any{"Id": "item-a", "Name": "Movie A", "Type": "Movie"})
		case "/Items/item-a/PlaybackInfo":
			_ = json.NewEncoder(w).Encode(map[string]any{"PlaySessionId": "sess-1", "MediaSources": []map[string]any{{
				"Id":              "ms-a",
				"Name":            "Version A",
				"Container":       "mp4",
				"DirectStreamUrl": "/Videos/item-a/stream.mp4?MediaSourceId=ms-a&api_key=upstream",
				"MediaStreams": []map[string]any{
					{"Type": "Subtitle", "Index": 2, "DisplayTitle": "中文字幕", "Codec": "srt"},
				},
			}}})
		default:
			http.NotFound(w, r)
		}
	}))
	defer upstream.Close()

	withTempAppPrepared(t, singleUpstreamConfig(upstream.URL), nil, func(app *App, handler http.Handler, dir string) {
		if _, err := app.UserStore.Create("alice", "pw-1", []int{0}); err != nil {
			t.Fatalf("create user: %v", err)
		}
		itemID := app.IDStore.GetOrCreateVirtualID("item-a", 0)
		login := doJSONRequest(t, handler, http.MethodPost, "/web/api/login", map[string]string{"username": "alice", "password": "pw-1"}, "")
		if login.Code != http.StatusOK {
			t.Fatalf("login status = %d, body=%s", login.Code, login.Body.String())
		}

		req := httptest.NewRequest(http.MethodGet, "/web/api/items/"+itemID+"/playback?subtitleStreamIndex=2", nil)
		req.AddCookie(login.Result().Cookies()[0])
		rr := httptest.NewRecorder()
		handler.ServeHTTP(rr, req)
		if rr.Code != http.StatusOK {
			t.Fatalf("GET /web/api/items/:id/playback status = %d, body=%s", rr.Code, rr.Body.String())
		}

		payload := mustJSONObject(t, rr.Body.Bytes())
		tracks := mustJSONArray(t, payload["subtitleTracks"])
		if len(tracks) != 1 {
			t.Fatalf("expected exactly one subtitle track, got %d body=%s", len(tracks), rr.Body.String())
		}
		track := mustJSONMap(t, tracks[0])
		if got := mustJSONString(t, track["rendererKind"]); got != "text" {
			t.Fatalf("expected rendererKind=text, got %q body=%s", got, rr.Body.String())
		}
		if _, hasURL := track["url"]; hasURL {
			t.Fatalf("expected no url for text subtitle track (overlay path), got %q body=%s", track["url"], rr.Body.String())
		}
	})
}

func TestWebPlaybackPrefersRequestedMediaSourceOverFirstSource(t *testing.T) {
	upstream := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch r.URL.Path {
		case "/Users/AuthenticateByName":
			_ = json.NewEncoder(w).Encode(map[string]any{"AccessToken": "tok-a", "User": map[string]any{"Id": "user-a"}})
		case "/Users/user-a/Items/item-a":
			_ = json.NewEncoder(w).Encode(map[string]any{"Id": "item-a", "Name": "Movie A", "Type": "Movie"})
		case "/Items/item-a/PlaybackInfo":
			_ = json.NewEncoder(w).Encode(map[string]any{"PlaySessionId": "sess-1", "MediaSources": []map[string]any{
				{
					"Id":              "ms-a",
					"Name":            "Version A",
					"Container":       "mp4",
					"TranscodingUrl":  "/Videos/item-a/master-a.m3u8?MediaSourceId=ms-a&api_key=upstream",
					"DirectStreamUrl": "/Videos/item-a/stream-a.mp4?MediaSourceId=ms-a&api_key=upstream",
				},
				{
					"Id":              "ms-b",
					"Name":            "Version B",
					"Container":       "mp4",
					"TranscodingUrl":  "/Videos/item-a/master-b.m3u8?MediaSourceId=ms-b&api_key=upstream",
					"DirectStreamUrl": "/Videos/item-a/stream-b.mp4?MediaSourceId=ms-b&api_key=upstream",
				},
			}})
		default:
			http.NotFound(w, r)
		}
	}))
	defer upstream.Close()

	withTempAppPrepared(t, singleUpstreamConfig(upstream.URL), nil, func(app *App, handler http.Handler, dir string) {
		if _, err := app.UserStore.Create("alice", "pw-1", []int{0}); err != nil {
			t.Fatalf("create user: %v", err)
		}
		itemID := app.IDStore.GetOrCreateVirtualID("item-a", 0)
		virtualMediaSourceB := app.IDStore.GetOrCreateVirtualID("ms-b", 0)
		login := doJSONRequest(t, handler, http.MethodPost, "/web/api/login", map[string]string{"username": "alice", "password": "pw-1"}, "")
		if login.Code != http.StatusOK {
			t.Fatalf("login status = %d, body=%s", login.Code, login.Body.String())
		}

		req := httptest.NewRequest(http.MethodGet, "/web/api/items/"+itemID+"/playback?mediaSourceId="+virtualMediaSourceB, nil)
		req.AddCookie(login.Result().Cookies()[0])
		rr := httptest.NewRecorder()
		handler.ServeHTTP(rr, req)
		if rr.Code != http.StatusOK {
			t.Fatalf("GET /web/api/items/:id/playback status = %d, body=%s", rr.Code, rr.Body.String())
		}

		payload := mustJSONObject(t, rr.Body.Bytes())
		source := mustJSONMap(t, payload["source"])
		sourceURL := mustJSONString(t, source["url"])
		if !strings.Contains(sourceURL, "MediaSourceId="+virtualMediaSourceB) {
			t.Fatalf("expected playback source to honor selected media source %q, got %q", virtualMediaSourceB, sourceURL)
		}
	})
}

func TestWebPlaybackRewritesAbsoluteSubtitleDeliveryURLs(t *testing.T) {
	upstream := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch r.URL.Path {
		case "/Users/AuthenticateByName":
			_ = json.NewEncoder(w).Encode(map[string]any{"AccessToken": "tok-a", "User": map[string]any{"Id": "user-a"}})
		case "/Users/user-a/Items/item-a":
			_ = json.NewEncoder(w).Encode(map[string]any{"Id": "item-a", "Name": "Movie A", "Type": "Movie"})
		case "/Items/item-a/PlaybackInfo":
			_ = json.NewEncoder(w).Encode(map[string]any{"PlaySessionId": "sess-1", "MediaSources": []map[string]any{{
				"Id":              "ms-a",
				"Name":            "Version A",
				"Container":       "mp4",
				"DirectStreamUrl": "/Videos/item-a/stream.mp4?MediaSourceId=ms-a&api_key=upstream",
				"MediaStreams": []map[string]any{
					{"Type": "Subtitle", "Index": 2, "DisplayTitle": "中文字幕", "DeliveryUrl": "https://delivery.example.com/Videos/item-a/ms-a/Subtitles/2/Stream.vtt?api_key=upstream"},
				},
			}}})
		default:
			http.NotFound(w, r)
		}
	}))
	defer upstream.Close()

	withTempAppPrepared(t, singleUpstreamConfig(upstream.URL), nil, func(app *App, handler http.Handler, dir string) {
		if _, err := app.UserStore.Create("alice", "pw-1", []int{0}); err != nil {
			t.Fatalf("create user: %v", err)
		}
		itemID := app.IDStore.GetOrCreateVirtualID("item-a", 0)
		login := doJSONRequest(t, handler, http.MethodPost, "/web/api/login", map[string]string{"username": "alice", "password": "pw-1"}, "")
		if login.Code != http.StatusOK {
			t.Fatalf("login status = %d, body=%s", login.Code, login.Body.String())
		}

		req := httptest.NewRequest(http.MethodGet, "/web/api/items/"+itemID+"/playback", nil)
		req.AddCookie(login.Result().Cookies()[0])
		rr := httptest.NewRecorder()
		handler.ServeHTTP(rr, req)
		if rr.Code != http.StatusOK {
			t.Fatalf("GET /web/api/items/:id/playback status = %d, body=%s", rr.Code, rr.Body.String())
		}
		body := rr.Body.String()
		if !strings.Contains(body, `"url":"/Videos/`+itemID+`/`) {
			t.Fatalf("expected local subtitle url, body=%s", body)
		}
		if strings.Contains(body, `delivery.example.com`) || strings.Contains(body, `upstream`) {
			t.Fatalf("expected no upstream subtitle host/token leakage, body=%s", body)
		}
	})
}

func TestWebPlaybackPrefersVTTSubtitleTrackURLsForBrowserPlayback(t *testing.T) {
	upstream := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch r.URL.Path {
		case "/Users/AuthenticateByName":
			_ = json.NewEncoder(w).Encode(map[string]any{"AccessToken": "tok-a", "User": map[string]any{"Id": "user-a"}})
		case "/Users/user-a/Items/item-a":
			_ = json.NewEncoder(w).Encode(map[string]any{"Id": "item-a", "Name": "Movie A", "Type": "Movie"})
		case "/Items/item-a/PlaybackInfo":
			_ = json.NewEncoder(w).Encode(map[string]any{"PlaySessionId": "sess-1", "MediaSources": []map[string]any{{
				"Id":              "ms-a",
				"Name":            "Version A",
				"Container":       "mp4",
				"DirectStreamUrl": "/Videos/item-a/stream.mp4?MediaSourceId=ms-a&api_key=upstream",
				"MediaStreams": []map[string]any{
					{"Type": "Subtitle", "Index": 2, "DisplayTitle": "中文字幕", "DeliveryUrl": "/Videos/item-a/ms-a/Subtitles/2/Stream.srt"},
				},
			}}})
		default:
			http.NotFound(w, r)
		}
	}))
	defer upstream.Close()

	withTempAppPrepared(t, singleUpstreamConfig(upstream.URL), nil, func(app *App, handler http.Handler, dir string) {
		if _, err := app.UserStore.Create("alice", "pw-1", []int{0}); err != nil {
			t.Fatalf("create user: %v", err)
		}
		itemID := app.IDStore.GetOrCreateVirtualID("item-a", 0)
		login := doJSONRequest(t, handler, http.MethodPost, "/web/api/login", map[string]string{"username": "alice", "password": "pw-1"}, "")
		if login.Code != http.StatusOK {
			t.Fatalf("login status = %d, body=%s", login.Code, login.Body.String())
		}

		req := httptest.NewRequest(http.MethodGet, "/web/api/items/"+itemID+"/playback?subtitleStreamIndex=2", nil)
		req.AddCookie(login.Result().Cookies()[0])
		rr := httptest.NewRecorder()
		handler.ServeHTTP(rr, req)
		if rr.Code != http.StatusOK {
			t.Fatalf("GET /web/api/items/:id/playback status = %d, body=%s", rr.Code, rr.Body.String())
		}
		body := rr.Body.String()
		if !strings.Contains(body, `/Subtitles/2/Stream.vtt`) {
			t.Fatalf("expected browser-friendly VTT subtitle url, body=%s", body)
		}
		if strings.Contains(body, `/Subtitles/2/Stream.srt`) {
			t.Fatalf("expected playback payload not to expose raw SRT subtitle url, body=%s", body)
		}
	})
}

func TestVideoSubtitleTrackRequestFallsBackToSRTAndConvertsToVTT(t *testing.T) {
	var vttHits atomic.Int32
	var srtHits atomic.Int32
	upstream := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch r.URL.Path {
		case "/Users/AuthenticateByName":
			_ = json.NewEncoder(w).Encode(map[string]any{"AccessToken": "tok-a", "User": map[string]any{"Id": "user-a"}})
		case "/Videos/item-a/ms-a/Subtitles/2/Stream.vtt":
			vttHits.Add(1)
			http.NotFound(w, r)
		case "/Videos/item-a/ms-a/Subtitles/2/Stream.srt":
			srtHits.Add(1)
			w.Header().Set("Content-Type", "text/plain; charset=utf-8")
			_, _ = w.Write([]byte("1\r\n00:00:01,000 --> 00:00:02,000\r\n你好\r\n"))
		default:
			http.NotFound(w, r)
		}
	}))
	defer upstream.Close()

	withTempAppPrepared(t, singleUpstreamConfig(upstream.URL), nil, func(app *App, handler http.Handler, dir string) {
		if _, err := app.UserStore.Create("alice", "pw-1", []int{0}); err != nil {
			t.Fatalf("create user: %v", err)
		}
		itemID := app.IDStore.GetOrCreateVirtualID("item-a", 0)
		mediaSourceID := app.IDStore.GetOrCreateVirtualID("ms-a", 0)
		login := doJSONRequest(t, handler, http.MethodPost, "/web/api/login", map[string]string{"username": "alice", "password": "pw-1"}, "")
		if login.Code != http.StatusOK {
			t.Fatalf("login status = %d, body=%s", login.Code, login.Body.String())
		}

		req := httptest.NewRequest(http.MethodGet, "/Videos/"+itemID+"/"+mediaSourceID+"/Subtitles/2/Stream.vtt", nil)
		req.AddCookie(login.Result().Cookies()[0])
		rr := httptest.NewRecorder()
		handler.ServeHTTP(rr, req)
		if rr.Code != http.StatusOK {
			t.Fatalf("subtitle vtt proxy status = %d, body=%s", rr.Code, rr.Body.String())
		}
		if !strings.Contains(strings.ToLower(rr.Header().Get("Content-Type")), "text/vtt") {
			t.Fatalf("expected text/vtt content type, got %q", rr.Header().Get("Content-Type"))
		}
		body := rr.Body.String()
		if !strings.HasPrefix(body, "WEBVTT") {
			t.Fatalf("expected WEBVTT header, body=%q", body)
		}
		if !strings.Contains(body, "00:00:01.000 --> 00:00:02.000") {
			t.Fatalf("expected converted VTT timestamps, body=%q", body)
		}
		if vttHits.Load() == 0 || srtHits.Load() == 0 {
			t.Fatalf("expected proxy to try .vtt then fall back to .srt, got vttHits=%d srtHits=%d", vttHits.Load(), srtHits.Load())
		}
	})
}

func TestWebPlaybackForwardsSelectedAudioAndSubtitleIndexesToPlaybackInfo(t *testing.T) {
	var gotAudio string
	var gotSubtitle string
	upstream := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch r.URL.Path {
		case "/Users/AuthenticateByName":
			_ = json.NewEncoder(w).Encode(map[string]any{"AccessToken": "tok-a", "User": map[string]any{"Id": "user-a"}})
		case "/Users/user-a/Items/item-a":
			_ = json.NewEncoder(w).Encode(map[string]any{"Id": "item-a", "Name": "Movie A", "Type": "Movie"})
		case "/Items/item-a/PlaybackInfo":
			gotAudio = r.URL.Query().Get("AudioStreamIndex")
			gotSubtitle = r.URL.Query().Get("SubtitleStreamIndex")
			_ = json.NewEncoder(w).Encode(map[string]any{"PlaySessionId": "sess-1", "MediaSources": []map[string]any{{
				"Id":              "ms-a",
				"Name":            "Version A",
				"Container":       "mp4",
				"DirectStreamUrl": "/Videos/item-a/stream.mp4?MediaSourceId=ms-a&api_key=upstream",
			}}})
		default:
			http.NotFound(w, r)
		}
	}))
	defer upstream.Close()

	withTempAppPrepared(t, singleUpstreamConfig(upstream.URL), nil, func(app *App, handler http.Handler, dir string) {
		if _, err := app.UserStore.Create("alice", "pw-1", []int{0}); err != nil {
			t.Fatalf("create user: %v", err)
		}
		itemID := app.IDStore.GetOrCreateVirtualID("item-a", 0)
		login := doJSONRequest(t, handler, http.MethodPost, "/web/api/login", map[string]string{"username": "alice", "password": "pw-1"}, "")
		if login.Code != http.StatusOK {
			t.Fatalf("login status = %d, body=%s", login.Code, login.Body.String())
		}

		req := httptest.NewRequest(http.MethodGet, "/web/api/items/"+itemID+"/playback?audioStreamIndex=1&subtitleStreamIndex=2", nil)
		req.AddCookie(login.Result().Cookies()[0])
		rr := httptest.NewRecorder()
		handler.ServeHTTP(rr, req)
		if rr.Code != http.StatusOK {
			t.Fatalf("GET /web/api/items/:id/playback status = %d, body=%s", rr.Code, rr.Body.String())
		}
		if gotAudio != "1" || gotSubtitle != "2" {
			t.Fatalf("expected AudioStreamIndex=1 and SubtitleStreamIndex=2, got audio=%q subtitle=%q", gotAudio, gotSubtitle)
		}
	})
}

func TestWebPlaybackIncludesEpisodeNavigationContext(t *testing.T) {
	upstream := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch r.URL.Path {
		case "/Users/AuthenticateByName":
			_ = json.NewEncoder(w).Encode(map[string]any{"AccessToken": "tok-a", "User": map[string]any{"Id": "user-a"}})
		case "/Items/ep-2/PlaybackInfo":
			_ = json.NewEncoder(w).Encode(map[string]any{"PlaySessionId": "sess-2", "MediaSources": []map[string]any{{
				"Id":        "ms-2",
				"Name":      "Main",
				"Container": "mp4",
				"Protocol":  "File",
			}}})
		case "/Users/user-a/Items/ep-2":
			_ = json.NewEncoder(w).Encode(map[string]any{
				"Id":                "ep-2",
				"Name":              "第2集",
				"Type":              "Episode",
				"SeriesName":        "大江大河",
				"SeriesId":          "series-a",
				"ParentIndexNumber": 1,
				"IndexNumber":       2,
			})
		case "/Shows/series-a/Episodes":
			if r.URL.Query().Get("UserId") != "user-a" {
				t.Fatalf("expected UserId=user-a, query=%s", r.URL.RawQuery)
			}
			_ = json.NewEncoder(w).Encode(map[string]any{"Items": []map[string]any{
				{"Id": "ep-1", "Name": "第1集", "Type": "Episode", "IndexNumber": 1, "ParentIndexNumber": 1},
				{"Id": "ep-2", "Name": "第2集", "Type": "Episode", "IndexNumber": 2, "ParentIndexNumber": 1},
				{"Id": "ep-3", "Name": "第3集", "Type": "Episode", "IndexNumber": 3, "ParentIndexNumber": 1},
			}})
		case "/Users/user-a/Items/series-a":
			_ = json.NewEncoder(w).Encode(map[string]any{"Id": "series-a", "Name": "大江大河", "Type": "Series"})
		default:
			http.NotFound(w, r)
		}
	}))
	defer upstream.Close()

	withTempAppPrepared(t, singleUpstreamConfig(upstream.URL), nil, func(app *App, handler http.Handler, dir string) {
		if _, err := app.UserStore.Create("alice", "pw-1", []int{0}); err != nil {
			t.Fatalf("create user: %v", err)
		}
		_ = app.IDStore.GetOrCreateVirtualID("series-a", 0)
		itemID := app.IDStore.GetOrCreateVirtualID("ep-2", 0)
		login := doJSONRequest(t, handler, http.MethodPost, "/web/api/login", map[string]string{"username": "alice", "password": "pw-1"}, "")
		if login.Code != http.StatusOK {
			t.Fatalf("login status = %d, body=%s", login.Code, login.Body.String())
		}

		req := httptest.NewRequest(http.MethodGet, "/web/api/items/"+itemID+"/playback", nil)
		req.AddCookie(login.Result().Cookies()[0])
		rr := httptest.NewRecorder()
		handler.ServeHTTP(rr, req)
		if rr.Code != http.StatusOK {
			t.Fatalf("GET /web/api/items/:id/playback status = %d, body=%s", rr.Code, rr.Body.String())
		}
		body := rr.Body.String()
		if !strings.Contains(body, `"seriesName":"大江大河"`) || !strings.Contains(body, `"title":"第2集"`) {
			t.Fatalf("expected title and series context, body=%s", body)
		}
		if !strings.Contains(body, `"previousEpisode":{"id":"`) || !strings.Contains(body, `"nextEpisode":{"id":"`) {
			t.Fatalf("expected previousEpisode and nextEpisode context, body=%s", body)
		}
	})
}

func TestWebPlaybackLeavesEpisodeNavigationEmptyForMovie(t *testing.T) {
	upstream := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch r.URL.Path {
		case "/Users/AuthenticateByName":
			_ = json.NewEncoder(w).Encode(map[string]any{"AccessToken": "tok-a", "User": map[string]any{"Id": "user-a"}})
		case "/Items/movie-a/PlaybackInfo":
			_ = json.NewEncoder(w).Encode(map[string]any{"PlaySessionId": "sess-movie", "MediaSources": []map[string]any{{
				"Id":        "ms-movie",
				"Name":      "Movie",
				"Container": "mp4",
				"Protocol":  "File",
			}}})
		case "/Users/user-a/Items/movie-a":
			_ = json.NewEncoder(w).Encode(map[string]any{
				"Id":   "movie-a",
				"Name": "Movie A",
				"Type": "Movie",
			})
		default:
			http.NotFound(w, r)
		}
	}))
	defer upstream.Close()

	withTempAppPrepared(t, singleUpstreamConfig(upstream.URL), nil, func(app *App, handler http.Handler, dir string) {
		if _, err := app.UserStore.Create("alice", "pw-1", []int{0}); err != nil {
			t.Fatalf("create user: %v", err)
		}
		itemID := app.IDStore.GetOrCreateVirtualID("movie-a", 0)
		login := doJSONRequest(t, handler, http.MethodPost, "/web/api/login", map[string]string{"username": "alice", "password": "pw-1"}, "")
		if login.Code != http.StatusOK {
			t.Fatalf("login status = %d, body=%s", login.Code, login.Body.String())
		}

		req := httptest.NewRequest(http.MethodGet, "/web/api/items/"+itemID+"/playback", nil)
		req.AddCookie(login.Result().Cookies()[0])
		rr := httptest.NewRecorder()
		handler.ServeHTTP(rr, req)
		if rr.Code != http.StatusOK {
			t.Fatalf("GET /web/api/items/:id/playback status = %d, body=%s", rr.Code, rr.Body.String())
		}
		body := rr.Body.String()
		if strings.Contains(body, `"previousEpisode"`) || strings.Contains(body, `"nextEpisode"`) {
			t.Fatalf("movie playback should not expose episode navigation, body=%s", body)
		}
	})
}

func TestWebPlaybackRejectsNonPlayableSeriesItems(t *testing.T) {
	upstream := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch r.URL.Path {
		case "/Users/AuthenticateByName":
			_ = json.NewEncoder(w).Encode(map[string]any{"AccessToken": "tok-a", "User": map[string]any{"Id": "user-a"}})
		case "/Users/user-a/Items/series-a":
			_ = json.NewEncoder(w).Encode(map[string]any{"Id": "series-a", "Name": "Series A", "Type": "Series"})
		default:
			http.NotFound(w, r)
		}
	}))
	defer upstream.Close()

	withTempAppPrepared(t, singleUpstreamConfig(upstream.URL), nil, func(app *App, handler http.Handler, dir string) {
		if _, err := app.UserStore.Create("alice", "pw-1", []int{0}); err != nil {
			t.Fatalf("create user: %v", err)
		}
		itemID := app.IDStore.GetOrCreateVirtualID("series-a", 0)
		login := doJSONRequest(t, handler, http.MethodPost, "/web/api/login", map[string]string{"username": "alice", "password": "pw-1"}, "")
		if login.Code != http.StatusOK {
			t.Fatalf("login status = %d, body=%s", login.Code, login.Body.String())
		}

		req := httptest.NewRequest(http.MethodGet, "/web/api/items/"+itemID+"/playback", nil)
		req.AddCookie(login.Result().Cookies()[0])
		rr := httptest.NewRecorder()
		handler.ServeHTTP(rr, req)
		if rr.Code != http.StatusBadRequest {
			t.Fatalf("GET /web/api/items/:id/playback status = %d, body=%s", rr.Code, rr.Body.String())
		}
		if !strings.Contains(rr.Body.String(), "Item is not directly playable") {
			t.Fatalf("unexpected body: %s", rr.Body.String())
		}
	})
}

func TestWebPlaybackUsesAllowedInstanceWhenPrimaryIsUnauthorized(t *testing.T) {
	var playbackHitsA atomic.Int32
	var playbackHitsB atomic.Int32
	var searchHitsA atomic.Int32
	var searchHitsB atomic.Int32

	srvA, srvB := newAuthPriorityDualServers(t, "tmdb-web-playback",
		authReviewServerOptions{searchHits: &searchHitsA, playHits: &playbackHitsA},
		authReviewServerOptions{searchHits: &searchHitsB, playHits: &playbackHitsB},
	)
	defer srvA.Close()
	defer srvB.Close()

	withTempAppPrepared(t, authPriorityDualConfig(srvA.server.URL, srvB.server.URL), nil, func(app *App, handler http.Handler, dir string) {
		adminToken := loginTokenAs(t, handler, "admin", "secret")
		_ = createLimitedUserAndToken(t, handler, adminToken, "collector", "collector123", []int{0, 1})
		collectorCookie := createLimitedWebUserCookie(t, handler, "collector", "collector123")
		itemID := createMergedVirtualIDThroughWebSearch(t, handler, collectorCookie, "movie")
		_ = createLimitedUserAndToken(t, handler, adminToken, "bob", "bob123", []int{1})
		bobCookie := createLimitedWebUserCookie(t, handler, "bob", "bob123")

		resetAtomicCounters(&playbackHitsA, &playbackHitsB)
		req := httptest.NewRequest(http.MethodGet, "/web/api/items/"+itemID+"/playback", nil)
		req.AddCookie(bobCookie)
		rr := httptest.NewRecorder()
		handler.ServeHTTP(rr, req)
		if rr.Code != http.StatusOK {
			t.Fatalf("GET /web/api/items/:id/playback status = %d, body=%s", rr.Code, rr.Body.String())
		}
		if playbackHitsA.Load() != 0 {
			t.Fatalf("expected playback not to hit unauthorized server A, got A=%d body=%s", playbackHitsA.Load(), rr.Body.String())
		}
		if playbackHitsB.Load() == 0 {
			t.Fatalf("expected playback to hit allowed server B, got B=%d", playbackHitsB.Load())
		}
	})
}

func TestWebPlaybackPropagatesConcurrentLimitError(t *testing.T) {
	upstream := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch r.URL.Path {
		case "/Users/AuthenticateByName":
			_ = json.NewEncoder(w).Encode(map[string]any{"AccessToken": "tok-a", "User": map[string]any{"Id": "user-a"}})
		case "/Users/user-a/Items/movie-a":
			_ = json.NewEncoder(w).Encode(map[string]any{"Id": "movie-a", "Name": "Movie A", "Type": "Movie"})
		case "/Items/movie-a/PlaybackInfo":
			_ = json.NewEncoder(w).Encode(map[string]any{
				"PlaySessionId": "sess-1",
				"MediaSources": []map[string]any{{
					"Id":              "ms-a",
					"Name":            "Movie",
					"Container":       "mp4",
					"DirectStreamUrl": "/Videos/movie-a/stream.mp4?MediaSourceId=ms-a&api_key=upstream",
				}},
			})
		default:
			http.NotFound(w, r)
		}
	}))
	defer upstream.Close()

	config := `server:
  port: 8096
  name: "Test"
  id: "svr"
admin:
  username: "admin"
  password: "secret"
playback:
  mode: "proxy"
timeouts:
  api: 30000
  global: 15000
  login: 10000
  healthCheck: 10000
  healthInterval: 60000
proxies: []
upstream:
  - name: "A"
    url: "` + upstream.URL + `"
    username: "u1"
    password: "p1"
    maxConcurrent: 1
`

	withTempAppPrepared(t, config, nil, func(app *App, handler http.Handler, dir string) {
		if _, err := app.UserStore.Create("alice", "pw-1", []int{0}); err != nil {
			t.Fatalf("create user: %v", err)
		}
		if !app.PlaybackLimiter.TryStart("other-user", 0, "session:other-user:busy", 1) {
			t.Fatalf("expected to seed busy playback slot")
		}
		itemID := app.IDStore.GetOrCreateVirtualID("movie-a", 0)
		login := doJSONRequest(t, handler, http.MethodPost, "/web/api/login", map[string]string{"username": "alice", "password": "pw-1"}, "")
		if login.Code != http.StatusOK {
			t.Fatalf("login status = %d, body=%s", login.Code, login.Body.String())
		}

		req := httptest.NewRequest(http.MethodGet, "/web/api/items/"+itemID+"/playback", nil)
		req.AddCookie(login.Result().Cookies()[0])
		rr := httptest.NewRecorder()
		handler.ServeHTTP(rr, req)
		if rr.Code != http.StatusTooManyRequests {
			t.Fatalf("GET /web/api/items/:id/playback status = %d, want 429 body=%s", rr.Code, rr.Body.String())
		}
		if !strings.Contains(rr.Body.String(), "已达到最大同时播放数限制") {
			t.Fatalf("expected concurrent limit message, body=%s", rr.Body.String())
		}
	})
}

func TestWebPlaybackPropagatesMissingPlaySessionError(t *testing.T) {
	upstream := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch r.URL.Path {
		case "/Users/AuthenticateByName":
			_ = json.NewEncoder(w).Encode(map[string]any{"AccessToken": "tok-a", "User": map[string]any{"Id": "user-a"}})
		case "/Users/user-a/Items/movie-a":
			_ = json.NewEncoder(w).Encode(map[string]any{"Id": "movie-a", "Name": "Movie A", "Type": "Movie"})
		case "/Items/movie-a/PlaybackInfo":
			_ = json.NewEncoder(w).Encode(map[string]any{
				"MediaSources": []map[string]any{{
					"Id":              "ms-a",
					"Name":            "Movie",
					"Container":       "mp4",
					"DirectStreamUrl": "/Videos/movie-a/stream.mp4?MediaSourceId=ms-a&api_key=upstream",
				}},
			})
		default:
			http.NotFound(w, r)
		}
	}))
	defer upstream.Close()

	config := `server:
  port: 8096
  name: "Test"
  id: "svr"
admin:
  username: "admin"
  password: "secret"
playback:
  mode: "proxy"
timeouts:
  api: 30000
  global: 15000
  login: 10000
  healthCheck: 10000
  healthInterval: 60000
proxies: []
upstream:
  - name: "A"
    url: "` + upstream.URL + `"
    username: "u1"
    password: "p1"
    maxConcurrent: 1
`

	withTempAppPrepared(t, config, nil, func(app *App, handler http.Handler, dir string) {
		if _, err := app.UserStore.Create("alice", "pw-1", []int{0}); err != nil {
			t.Fatalf("create user: %v", err)
		}
		itemID := app.IDStore.GetOrCreateVirtualID("movie-a", 0)
		login := doJSONRequest(t, handler, http.MethodPost, "/web/api/login", map[string]string{"username": "alice", "password": "pw-1"}, "")
		if login.Code != http.StatusOK {
			t.Fatalf("login status = %d, body=%s", login.Code, login.Body.String())
		}

		req := httptest.NewRequest(http.MethodGet, "/web/api/items/"+itemID+"/playback", nil)
		req.AddCookie(login.Result().Cookies()[0])
		rr := httptest.NewRecorder()
		handler.ServeHTTP(rr, req)
		if rr.Code != http.StatusBadGateway {
			t.Fatalf("GET /web/api/items/:id/playback status = %d, want 502 body=%s", rr.Code, rr.Body.String())
		}
		if !strings.Contains(rr.Body.String(), "Playback session unavailable") {
			t.Fatalf("expected missing session message, body=%s", rr.Body.String())
		}
	})
}
