package backend

import (
	"io/fs"
	"net/http"
	"os"

	publicfs "emby-in-one/public"
)

func (a *App) registerWebRoutes(mux *http.ServeMux) {
	a.registerWebAuthRoutes(mux)
	mux.HandleFunc("GET /web/api/home", a.withWebContext(a.requireWebUser(a.handleWebHome)))
	mux.HandleFunc("GET /web/api/resume", a.withWebContext(a.requireWebUser(a.handleWebResume)))
	mux.HandleFunc("GET /web/api/search", a.withWebContext(a.requireWebUser(a.handleWebSearch)))
	mux.HandleFunc("GET /web/api/libraries/{libraryId}", a.withWebContext(a.requireWebUser(a.handleWebLibrary)))
	mux.HandleFunc("GET /web/api/items/{itemId}", a.withWebContext(a.requireWebUser(a.handleWebItem)))
	mux.HandleFunc("GET /web/api/items/{itemId}/playback", a.withWebContext(a.requireWebUser(a.handleWebPlayback)))
	mux.HandleFunc("POST /web/api/items/{itemId}/select", a.withWebContext(a.requireWebUser(a.handleWebSelection)))
	mux.HandleFunc("POST /web/api/items/{itemId}/started", a.withWebContext(a.requireWebUser(a.handleWebItemStarted)))
	mux.HandleFunc("POST /web/api/items/{itemId}/progress", a.withWebContext(a.requireWebUser(a.handleWebItemProgress)))
	mux.HandleFunc("POST /web/api/items/{itemId}/stop", a.withWebContext(a.requireWebUser(a.handleWebItemStop)))
	mux.HandleFunc("GET /web/api/subtitles/{trackId}/text", a.withWebContext(a.requireWebUser(a.handleWebSubtitleText)))
	mux.HandleFunc("GET /web/api/subtitles/{trackId}/webvtt", a.withWebContext(a.requireWebUser(a.handleWebSubtitleWebVTT)))
	mux.HandleFunc("GET /web/api/subtitles/{trackId}/ass", a.withWebContext(a.requireWebUser(a.handleWebSubtitleAss)))
	mux.HandleFunc("GET /web/api/subtitles/{trackId}/bitmap", a.withWebContext(a.requireWebUser(a.handleWebSubtitleBitmap)))
	mux.HandleFunc("POST /web/api/items/{itemId}/subtitles/{trackId}/fallback-stream", a.withWebContext(a.requireWebUser(a.handleWebSubtitleFallbackStream)))
	mux.HandleFunc("POST /web/api/sessions/{sessionId}/subtitle-mode", a.withWebContext(a.requireWebUser(a.handleWebSessionSubtitleMode)))
	mux.HandleFunc("POST /web/api/sessions/{sessionId}/started", a.withWebContext(a.requireWebUser(a.handleWebSessionStarted)))
	mux.HandleFunc("POST /web/api/sessions/{sessionId}/progress", a.withWebContext(a.requireWebUser(a.handleWebSessionProgress)))
	mux.HandleFunc("POST /web/api/sessions/{sessionId}/stop", a.withWebContext(a.requireWebUser(a.handleWebSessionStop)))

	mux.Handle("/web/app/", a.webStaticHandler())
	mux.Handle("/web/assets/", a.webStaticHandler())
	mux.Handle("/web/styles/", a.webStaticHandler())
	mux.Handle("/web/styles.css", a.webStaticHandler())

	mux.HandleFunc("GET /web", a.handleWebShell)
	mux.HandleFunc("GET /web/login", a.handleWebShell)
	mux.HandleFunc("GET /web/search", a.handleWebShell)
	mux.HandleFunc("GET /web/resume", a.handleWebShell)
	mux.HandleFunc("GET /web/library/{libraryId}", a.handleWebShell)
	mux.HandleFunc("GET /web/item/{itemId}", a.handleWebShell)
	mux.HandleFunc("GET /web/play/{itemId}", a.handleWebShell)
}

func (a *App) handleWebShell(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "text/html; charset=utf-8")
	http.ServeFileFS(w, r, a.webFS(), "web/index.html")
}

func (a *App) webStaticHandler() http.Handler {
	return http.StripPrefix("/", http.FileServer(http.FS(a.webFS())))
}

func (a *App) webFS() fs.FS {
	if dir := detectPublicPath("web/index.html"); dir != "" {
		return os.DirFS(dir)
	}
	sub, _ := fs.Sub(publicfs.Assets, ".")
	return sub
}
