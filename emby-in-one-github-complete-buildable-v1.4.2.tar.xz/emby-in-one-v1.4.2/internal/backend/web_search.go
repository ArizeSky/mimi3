package backend

import "net/http"

type webSearchResponse struct {
	Query string         `json:"query"`
	Items []webMediaCard `json:"items"`
}

func (a *App) handleWebSearch(w http.ResponseWriter, r *http.Request) {
	reqCtx := requestContextFrom(r.Context())
	writeJSON(w, http.StatusOK, webSearchResponse{
		Query: firstNonEmpty(r.URL.Query().Get("SearchTerm"), r.URL.Query().Get("q")),
		Items: a.webCardsFromItems(a.webSearchItems(r, reqCtx)),
	})
}

func (a *App) webSearchItems(r *http.Request, reqCtx *RequestContext) []map[string]any {
	cfg := a.ConfigStore.Snapshot()
	clients := a.allowedClients(reqCtx)
	type serverHints struct {
		ServerIndex int
		Items       []map[string]any
	}
	allResults := make([]serverHints, 0, len(clients))
	for _, client := range clients {
		query := cloneValues(r.URL.Query())
		query.Set("UserId", client.UserID)
		payload, err := client.RequestJSON(r.Context(), reqCtx, a.Identity, http.MethodGet, "/Search/Hints", query, nil)
		if err != nil {
			continue
		}
		block, _ := payload.(map[string]any)
		items := asItems(map[string]any{"Items": block["SearchHints"]})
		if len(items) == 0 {
			items = asItems(payload)
		}
		if len(items) == 0 {
			fallbackQuery := cloneValues(r.URL.Query())
			fallbackQuery.Set("Recursive", "true")
			fallbackPayload, fallbackErr := client.RequestJSON(r.Context(), reqCtx, a.Identity, http.MethodGet, "/Users/"+client.UserID+"/Items", fallbackQuery, nil)
			if fallbackErr == nil {
				items = asItems(fallbackPayload)
			}
		}
		allResults = append(allResults, serverHints{ServerIndex: client.ServerIndex, Items: items})
	}

	merged := make([]map[string]any, 0)
	type seenEntry struct {
		virtualID   string
		mergedIndex int
		serverIndex int
	}
	seen := map[string]*seenEntry{}
	maxLen := 0
	for _, result := range allResults {
		if len(result.Items) > maxLen {
			maxLen = len(result.Items)
		}
	}

	for i := 0; i < maxLen; i++ {
		for _, result := range allResults {
			if i >= len(result.Items) {
				continue
			}
			item := deepCloneMap(result.Items[i])
			key := getItemKey(item)
			if key != "" {
				if entry, ok := seen[key]; ok {
					if originalID, idOK := item["Id"].(string); idOK && originalID != "" {
						a.IDStore.AssociateAdditionalInstance(entry.virtualID, originalID, result.ServerIndex)
					}
					if isBetterMetadata(merged[entry.mergedIndex], entry.serverIndex, item, result.ServerIndex, cfg) {
						delete(item, "Id")
						rewriteResponseIDs(item, result.ServerIndex, a.IDStore, cfg.Server.ID, a.Auth.ProxyUserID())
						item["Id"] = entry.virtualID
						merged[entry.mergedIndex] = item
						entry.serverIndex = result.ServerIndex
					}
					continue
				}
				if originalID, idOK := item["Id"].(string); idOK && originalID != "" {
					virtualID := a.IDStore.GetOrCreateVirtualID(originalID, result.ServerIndex)
					seen[key] = &seenEntry{virtualID: virtualID, mergedIndex: len(merged), serverIndex: result.ServerIndex}
					delete(item, "Id")
					rewriteResponseIDs(item, result.ServerIndex, a.IDStore, cfg.Server.ID, a.Auth.ProxyUserID())
					item["Id"] = virtualID
					merged = append(merged, item)
					continue
				}
			}
			rewriteResponseIDs(item, result.ServerIndex, a.IDStore, cfg.Server.ID, a.Auth.ProxyUserID())
			merged = append(merged, item)
		}
	}
	return merged
}

func firstNonEmpty(values ...string) string {
	for _, value := range values {
		if value != "" {
			return value
		}
	}
	return ""
}
