package backend

import (
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
)

func TestWebSearchUsesRecursiveItemsWhenSearchHintsAreEmpty(t *testing.T) {
	upstream := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch r.URL.Path {
		case "/Users/AuthenticateByName":
			_ = json.NewEncoder(w).Encode(map[string]any{"AccessToken": "tok-a", "User": map[string]any{"Id": "user-a"}})
		case "/Search/Hints":
			_ = json.NewEncoder(w).Encode(map[string]any{"SearchHints": []map[string]any{}})
		case "/Users/user-a/Items":
			if r.URL.Query().Get("Recursive") != "true" {
				t.Fatalf("expected Recursive=true, query=%s", r.URL.RawQuery)
			}
			_ = json.NewEncoder(w).Encode(map[string]any{"Items": []map[string]any{{
				"Id":             "series-a",
				"Name":           "大江大河",
				"Type":           "Series",
				"ProductionYear": 2018,
			}}})
		default:
			http.NotFound(w, r)
		}
	}))
	defer upstream.Close()

	withTempAppPrepared(t, singleUpstreamConfig(upstream.URL), nil, func(app *App, handler http.Handler, dir string) {
		if _, err := app.UserStore.Create("alice", "pw-1", []int{0}); err != nil {
			t.Fatalf("create user: %v", err)
		}
		login := doJSONRequest(t, handler, http.MethodPost, "/web/api/login", map[string]string{"username": "alice", "password": "pw-1"}, "")
		if login.Code != http.StatusOK {
			t.Fatalf("login status = %d, body=%s", login.Code, login.Body.String())
		}

		req := httptest.NewRequest(http.MethodGet, "/web/api/search?SearchTerm=%E5%A4%A7%E6%B1%9F%E5%A4%A7%E6%B2%B3", nil)
		req.AddCookie(login.Result().Cookies()[0])
		rr := httptest.NewRecorder()
		handler.ServeHTTP(rr, req)
		if rr.Code != http.StatusOK {
			t.Fatalf("GET /web/api/search status = %d, body=%s", rr.Code, rr.Body.String())
		}
		var payload map[string]any
		if err := json.Unmarshal(rr.Body.Bytes(), &payload); err != nil {
			t.Fatalf("unmarshal search payload: %v", err)
		}
		items, _ := payload["items"].([]any)
		if len(items) != 1 {
			t.Fatalf("expected one recursive items search result, body=%s", rr.Body.String())
		}
		first, _ := items[0].(map[string]any)
		if first["name"] != "大江大河" {
			t.Fatalf("unexpected first item: %#v", first)
		}
	})
}

func TestWebSearchAggregatesDuplicateMovieAcrossUpstreams(t *testing.T) {
	upstreamA := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch r.URL.Path {
		case "/Users/AuthenticateByName":
			_ = json.NewEncoder(w).Encode(map[string]any{"AccessToken": "tok-a", "User": map[string]any{"Id": "user-a"}})
		case "/Search/Hints":
			_ = json.NewEncoder(w).Encode(map[string]any{"SearchHints": []map[string]any{{
				"Id":             "movie-a",
				"Name":           "Duplicated Movie",
				"Type":           "Movie",
				"ProductionYear": 2024,
				"ProviderIds":    map[string]any{"Tmdb": "123"},
			}}})
		default:
			http.NotFound(w, r)
		}
	}))
	defer upstreamA.Close()

	upstreamB := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch r.URL.Path {
		case "/Users/AuthenticateByName":
			_ = json.NewEncoder(w).Encode(map[string]any{"AccessToken": "tok-b", "User": map[string]any{"Id": "user-b"}})
		case "/Search/Hints":
			_ = json.NewEncoder(w).Encode(map[string]any{"SearchHints": []map[string]any{{
				"Id":             "movie-b",
				"Name":           "Duplicated Movie",
				"Type":           "Movie",
				"ProductionYear": 2024,
				"ProviderIds":    map[string]any{"Tmdb": "123"},
			}}})
		default:
			http.NotFound(w, r)
		}
	}))
	defer upstreamB.Close()

	withTempAppPrepared(t, dualUpstreamConfig(upstreamA.URL, upstreamB.URL), nil, func(app *App, handler http.Handler, dir string) {
		if _, err := app.UserStore.Create("alice", "pw-1", []int{0, 1}); err != nil {
			t.Fatalf("create user: %v", err)
		}
		login := doJSONRequest(t, handler, http.MethodPost, "/web/api/login", map[string]string{"username": "alice", "password": "pw-1"}, "")
		if login.Code != http.StatusOK {
			t.Fatalf("login status = %d, body=%s", login.Code, login.Body.String())
		}

		req := httptest.NewRequest(http.MethodGet, "/web/api/search?SearchTerm=Duplicated", nil)
		req.AddCookie(login.Result().Cookies()[0])
		rr := httptest.NewRecorder()
		handler.ServeHTTP(rr, req)
		if rr.Code != http.StatusOK {
			t.Fatalf("GET /web/api/search status = %d, body=%s", rr.Code, rr.Body.String())
		}
		if strings.Count(rr.Body.String(), "Duplicated Movie") != 1 {
			t.Fatalf("expected merged search result, body=%s", rr.Body.String())
		}
	})
}
