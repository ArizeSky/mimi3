package backend

import "net/http"

type webSessionRequest struct {
	ItemID        string `json:"itemId"`
	MediaSourceID string `json:"mediaSourceId"`
	PositionTicks int64  `json:"positionTicks"`
	RunTimeTicks  int64  `json:"runTimeTicks"`
	PlaySessionID string `json:"playSessionId"`
	EventName     string `json:"eventName,omitempty"`
	IsEnded       bool   `json:"isEnded,omitempty"`
}

func webSessionPayload(body webSessionRequest, fallbackSessionID string) map[string]any {
	payload := map[string]any{
		"ItemId":        body.ItemID,
		"MediaSourceId": body.MediaSourceID,
		"PositionTicks": body.PositionTicks,
		"RunTimeTicks":  body.RunTimeTicks,
		"PlaySessionId": firstNonEmpty(body.PlaySessionID, fallbackSessionID),
	}
	if body.EventName != "" {
		payload["EventName"] = body.EventName
	}
	if body.IsEnded {
		payload["IsEnded"] = true
	}
	return payload
}

func (a *App) handleWebSessionStarted(w http.ResponseWriter, r *http.Request) {
	var body webSessionRequest
	if err := decodeJSONBody(r, &body); err != nil {
		writeJSON(w, http.StatusBadRequest, map[string]any{"message": "Invalid request body"})
		return
	}
	status := a.forwardWebSessionEvent(r, "/Sessions/Playing", webSessionPayload(body, r.PathValue("sessionId")), body.ItemID, false)
	w.WriteHeader(status)
}

func (a *App) handleWebSessionProgress(w http.ResponseWriter, r *http.Request) {
	var body webSessionRequest
	if err := decodeJSONBody(r, &body); err != nil {
		if a.Logger != nil {
			a.Logger.Warnf("Web session progress rejected: sessionId=%s reason=invalid-body", r.PathValue("sessionId"))
		}
		writeJSON(w, http.StatusBadRequest, map[string]any{"message": "Invalid request body"})
		return
	}
	if a.Logger != nil {
		reqCtx := requestContextFrom(r.Context())
		a.Logger.Debugf("Web session progress: sessionId=%s itemId=%s hasProxyUser=%t", r.PathValue("sessionId"), body.ItemID, reqCtx != nil && reqCtx.ProxyUser != nil)
	}
	payload := webSessionPayload(body, r.PathValue("sessionId"))
	status := a.forwardWebSessionEvent(r, "/Sessions/Playing/Progress", payload, body.ItemID, false)
	w.WriteHeader(status)
}

func (a *App) handleWebSessionStop(w http.ResponseWriter, r *http.Request) {
	var body webSessionRequest
	if err := decodeJSONBody(r, &body); err != nil {
		if a.Logger != nil {
			a.Logger.Warnf("Web session stop rejected: sessionId=%s reason=invalid-body", r.PathValue("sessionId"))
		}
		writeJSON(w, http.StatusBadRequest, map[string]any{"message": "Invalid request body"})
		return
	}
	if a.Logger != nil {
		reqCtx := requestContextFrom(r.Context())
		a.Logger.Debugf("Web session stop: sessionId=%s itemId=%s hasProxyUser=%t", r.PathValue("sessionId"), body.ItemID, reqCtx != nil && reqCtx.ProxyUser != nil)
	}
	payload := webSessionPayload(body, r.PathValue("sessionId"))
	status := a.forwardWebSessionEvent(r, "/Sessions/Playing/Stopped", payload, body.ItemID, true)
	w.WriteHeader(status)
}

func (a *App) handleWebItemProgress(w http.ResponseWriter, r *http.Request) {
	var body webSessionRequest
	if err := decodeJSONBody(r, &body); err != nil {
		if a.Logger != nil {
			a.Logger.Warnf("Web item progress rejected: itemId=%s reason=invalid-body", r.PathValue("itemId"))
		}
		writeJSON(w, http.StatusBadRequest, map[string]any{"message": "Invalid request body"})
		return
	}
	if body.ItemID == "" {
		body.ItemID = r.PathValue("itemId")
	}
	if a.Logger != nil {
		reqCtx := requestContextFrom(r.Context())
		a.Logger.Debugf("Web item progress: itemId=%s mediaSourceId=%s sessionId=%s hasProxyUser=%t",
			body.ItemID, body.MediaSourceID, body.PlaySessionID, reqCtx != nil && reqCtx.ProxyUser != nil)
	}
	payload := webSessionPayload(body, "")
	status := a.forwardWebSessionEvent(r, "/Sessions/Playing/Progress", payload, body.ItemID, false)
	w.WriteHeader(status)
}

func (a *App) handleWebItemStarted(w http.ResponseWriter, r *http.Request) {
	var body webSessionRequest
	if err := decodeJSONBody(r, &body); err != nil {
		writeJSON(w, http.StatusBadRequest, map[string]any{"message": "Invalid request body"})
		return
	}
	if body.ItemID == "" {
		body.ItemID = r.PathValue("itemId")
	}
	status := a.forwardWebSessionEvent(r, "/Sessions/Playing", webSessionPayload(body, ""), body.ItemID, false)
	w.WriteHeader(status)
}

func (a *App) handleWebItemStop(w http.ResponseWriter, r *http.Request) {
	var body webSessionRequest
	if err := decodeJSONBody(r, &body); err != nil {
		if a.Logger != nil {
			a.Logger.Warnf("Web item stop rejected: itemId=%s reason=invalid-body", r.PathValue("itemId"))
		}
		writeJSON(w, http.StatusBadRequest, map[string]any{"message": "Invalid request body"})
		return
	}
	if body.ItemID == "" {
		body.ItemID = r.PathValue("itemId")
	}
	if a.Logger != nil {
		reqCtx := requestContextFrom(r.Context())
		a.Logger.Debugf("Web item stop: itemId=%s mediaSourceId=%s sessionId=%s hasProxyUser=%t",
			body.ItemID, body.MediaSourceID, body.PlaySessionID, reqCtx != nil && reqCtx.ProxyUser != nil)
	}
	payload := webSessionPayload(body, "")
	status := a.forwardWebSessionEvent(r, "/Sessions/Playing/Stopped", payload, body.ItemID, true)
	w.WriteHeader(status)
}

func (a *App) forwardWebSessionEvent(r *http.Request, path string, body map[string]any, virtualItemID string, isStopped bool) int {
	serverIndex, found := a.translateSessionBodyIDsForRequest(requestContextFrom(r.Context()), body)
	if !found {
		if a.Logger != nil {
			a.Logger.Warnf("Web session forward skipped: path=%s itemId=%s reason=target-not-found", path, virtualItemID)
		}
		return http.StatusNoContent
	}
	client := a.Upstream.GetClient(serverIndex)
	if client == nil || !client.IsOnline() {
		if a.Logger != nil {
			a.Logger.Warnf("Web session forward skipped: path=%s itemId=%s serverIndex=%d reason=server-offline", path, virtualItemID, serverIndex)
		}
		return http.StatusNoContent
	}
	_ = a.forwardNoContent(r, client, http.MethodPost, path, nil, body)
	a.recordSessionToWatchStore(r, virtualItemID, body, serverIndex, isStopped)
	if a.PlaybackLimiter != nil {
		if reqCtx := requestContextFrom(r.Context()); reqCtx != nil && reqCtx.ProxyUser != nil && reqCtx.ProxyUser.Role != "admin" {
			if playbackID := playbackRegistrationIDFromBody(reqCtx.ProxyUser.UserID, body); playbackID != "" {
				if isStopped {
					a.PlaybackLimiter.StopByPlaybackID(playbackID)
				} else {
					a.PlaybackLimiter.HeartbeatByPlaybackID(playbackID)
				}
			}
		}
	}
	if a.Logger != nil {
		a.Logger.Debugf("Web session forward: path=%s itemId=%s server=[%s] stopped=%t", path, virtualItemID, client.Name, isStopped)
	}
	return http.StatusNoContent
}
