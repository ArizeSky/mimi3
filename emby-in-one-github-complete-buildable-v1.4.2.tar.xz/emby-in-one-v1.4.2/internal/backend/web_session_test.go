package backend

import (
	"bytes"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"testing"
)

func TestWebSessionProgressUpdatesWatchStore(t *testing.T) {
	upstream := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch r.URL.Path {
		case "/Users/AuthenticateByName":
			_ = json.NewEncoder(w).Encode(map[string]any{"AccessToken": "tok-a", "User": map[string]any{"Id": "user-a"}})
		case "/Sessions/Playing/Progress":
			w.WriteHeader(http.StatusNoContent)
		case "/Users/user-a/Items/movie-a":
			_ = json.NewEncoder(w).Encode(map[string]any{"Id": "movie-a", "Name": "Movie A", "Type": "Movie", "RunTimeTicks": 1000})
		default:
			http.NotFound(w, r)
		}
	}))
	defer upstream.Close()

	withTempAppPrepared(t, singleUpstreamConfig(upstream.URL), nil, func(app *App, handler http.Handler, dir string) {
		user, err := app.UserStore.Create("alice", "pw-1", []int{0})
		if err != nil {
			t.Fatalf("create user: %v", err)
		}
		virtualID := app.IDStore.GetOrCreateVirtualID("movie-a", 0)
		login := doJSONRequest(t, handler, http.MethodPost, "/web/api/login", map[string]string{"username": user.Username, "password": "pw-1"}, "")
		if login.Code != http.StatusOK {
			t.Fatalf("login status = %d, body=%s", login.Code, login.Body.String())
		}

		body := map[string]any{"itemId": virtualID, "positionTicks": 500, "runTimeTicks": 1000, "playSessionId": "sess-1"}
		reqBody, _ := json.Marshal(body)
		req := httptest.NewRequest(http.MethodPost, "/web/api/sessions/sess-1/progress", bytes.NewReader(reqBody))
		req.Header.Set("Content-Type", "application/json")
		req.AddCookie(login.Result().Cookies()[0])
		rr := httptest.NewRecorder()
		handler.ServeHTTP(rr, req)
		if rr.Code != http.StatusNoContent {
			t.Fatalf("progress status = %d, body=%s", rr.Code, rr.Body.String())
		}
		progress := app.WatchStore.GetProgress(user.ID, virtualID)
		if progress == nil || progress.PositionTicks != 500 {
			t.Fatalf("progress was not persisted: %#v", progress)
		}
	})
}

func TestWebSessionStopReleasesPlaybackLimiterSlot(t *testing.T) {
	upstream := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch r.URL.Path {
		case "/Users/AuthenticateByName":
			_ = json.NewEncoder(w).Encode(map[string]any{"AccessToken": "tok-a", "User": map[string]any{"Id": "user-a"}})
		case "/Users/user-a/Items/movie-a":
			_ = json.NewEncoder(w).Encode(map[string]any{"Id": "movie-a", "Name": "Movie A", "Type": "Movie", "RunTimeTicks": 1000})
		case "/Items/movie-a/PlaybackInfo":
			_ = json.NewEncoder(w).Encode(map[string]any{
				"PlaySessionId": "sess-1",
				"MediaSources": []map[string]any{{
					"Id":              "ms-a",
					"Name":            "Version A",
					"Container":       "mp4",
					"DirectStreamUrl": "/Videos/movie-a/stream.mp4?MediaSourceId=ms-a&api_key=upstream-token",
				}},
			})
		case "/Sessions/Playing/Stopped":
			w.WriteHeader(http.StatusNoContent)
		default:
			http.NotFound(w, r)
		}
	}))
	defer upstream.Close()

	config := `server:
  port: 8096
  name: "Test"
  id: "svr"
admin:
  username: "admin"
  password: "secret"
playback:
  mode: "proxy"
timeouts:
  api: 30000
  global: 15000
  login: 10000
  healthCheck: 10000
  healthInterval: 60000
proxies: []
upstream:
  - name: "A"
    url: "` + upstream.URL + `"
    username: "u1"
    password: "p1"
    maxConcurrent: 1
`

	withTempAppPrepared(t, config, nil, func(app *App, handler http.Handler, dir string) {
		if _, err := app.UserStore.Create("alice", "pw-1", []int{0}); err != nil {
			t.Fatalf("create user: %v", err)
		}
		virtualID := app.IDStore.GetOrCreateVirtualID("movie-a", 0)
		login := doJSONRequest(t, handler, http.MethodPost, "/web/api/login", map[string]string{"username": "alice", "password": "pw-1"}, "")
		if login.Code != http.StatusOK {
			t.Fatalf("login status = %d, body=%s", login.Code, login.Body.String())
		}
		cookie := login.Result().Cookies()[0]

		playbackReq := httptest.NewRequest(http.MethodGet, "/web/api/items/"+virtualID+"/playback", nil)
		playbackReq.AddCookie(cookie)
		playbackRR := httptest.NewRecorder()
		handler.ServeHTTP(playbackRR, playbackReq)
		if playbackRR.Code != http.StatusOK {
			t.Fatalf("playback status = %d, body=%s", playbackRR.Code, playbackRR.Body.String())
		}
		if got := app.PlaybackLimiter.CountForServer(0); got != 1 {
			t.Fatalf("CountForServer(0) after playback = %d, want 1", got)
		}

		sessionID := mustJSONString(t, mustJSONObject(t, playbackRR.Body.Bytes())["sessionId"])
		stopBody := map[string]any{"itemId": virtualID, "positionTicks": 0, "runTimeTicks": 1000, "playSessionId": sessionID}
		reqBody, _ := json.Marshal(stopBody)
		stopReq := httptest.NewRequest(http.MethodPost, "/web/api/sessions/"+sessionID+"/stop", bytes.NewReader(reqBody))
		stopReq.Header.Set("Content-Type", "application/json")
		stopReq.AddCookie(cookie)
		stopRR := httptest.NewRecorder()
		handler.ServeHTTP(stopRR, stopReq)
		if stopRR.Code != http.StatusNoContent {
			t.Fatalf("stop status = %d, body=%s", stopRR.Code, stopRR.Body.String())
		}
		if got := app.PlaybackLimiter.CountForServer(0); got != 0 {
			t.Fatalf("CountForServer(0) after stop = %d, want 0", got)
		}
	})
}

func TestWebItemScopedSessionProgressUpdatesWatchStoreWithoutSessionID(t *testing.T) {
	upstream := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch r.URL.Path {
		case "/Users/AuthenticateByName":
			_ = json.NewEncoder(w).Encode(map[string]any{"AccessToken": "tok-a", "User": map[string]any{"Id": "user-a"}})
		case "/Sessions/Playing/Progress":
			var payload map[string]any
			if err := json.NewDecoder(r.Body).Decode(&payload); err != nil {
				t.Fatalf("decode upstream progress payload: %v", err)
			}
			if text, _ := payload["PlaySessionId"].(string); text != "" {
				t.Fatalf("expected empty PlaySessionId for item-scoped progress, got %q", text)
			}
			w.WriteHeader(http.StatusNoContent)
		case "/Users/user-a/Items/movie-a":
			_ = json.NewEncoder(w).Encode(map[string]any{"Id": "movie-a", "Name": "Movie A", "Type": "Movie", "RunTimeTicks": 1000})
		default:
			http.NotFound(w, r)
		}
	}))
	defer upstream.Close()

	withTempAppPrepared(t, singleUpstreamConfig(upstream.URL), nil, func(app *App, handler http.Handler, dir string) {
		user, err := app.UserStore.Create("alice", "pw-1", []int{0})
		if err != nil {
			t.Fatalf("create user: %v", err)
		}
		virtualID := app.IDStore.GetOrCreateVirtualID("movie-a", 0)
		login := doJSONRequest(t, handler, http.MethodPost, "/web/api/login", map[string]string{"username": user.Username, "password": "pw-1"}, "")
		if login.Code != http.StatusOK {
			t.Fatalf("login status = %d, body=%s", login.Code, login.Body.String())
		}

		body := map[string]any{"positionTicks": 500, "runTimeTicks": 1000}
		reqBody, _ := json.Marshal(body)
		req := httptest.NewRequest(http.MethodPost, "/web/api/items/"+virtualID+"/progress", bytes.NewReader(reqBody))
		req.Header.Set("Content-Type", "application/json")
		req.AddCookie(login.Result().Cookies()[0])
		rr := httptest.NewRecorder()
		handler.ServeHTTP(rr, req)
		if rr.Code != http.StatusNoContent {
			t.Fatalf("progress status = %d, body=%s", rr.Code, rr.Body.String())
		}
		progress := app.WatchStore.GetProgress(user.ID, virtualID)
		if progress == nil || progress.PositionTicks != 500 {
			t.Fatalf("progress was not persisted: %#v", progress)
		}
	})
}

func TestWebItemScopedSessionStopUpdatesWatchStoreWithoutSessionID(t *testing.T) {
	upstream := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch r.URL.Path {
		case "/Users/AuthenticateByName":
			_ = json.NewEncoder(w).Encode(map[string]any{"AccessToken": "tok-a", "User": map[string]any{"Id": "user-a"}})
		case "/Sessions/Playing/Stopped":
			var payload map[string]any
			if err := json.NewDecoder(r.Body).Decode(&payload); err != nil {
				t.Fatalf("decode upstream stop payload: %v", err)
			}
			if text, _ := payload["PlaySessionId"].(string); text != "" {
				t.Fatalf("expected empty PlaySessionId for item-scoped stop, got %q", text)
			}
			w.WriteHeader(http.StatusNoContent)
		case "/Users/user-a/Items/movie-a":
			_ = json.NewEncoder(w).Encode(map[string]any{"Id": "movie-a", "Name": "Movie A", "Type": "Movie", "RunTimeTicks": 1000})
		default:
			http.NotFound(w, r)
		}
	}))
	defer upstream.Close()

	withTempAppPrepared(t, singleUpstreamConfig(upstream.URL), nil, func(app *App, handler http.Handler, dir string) {
		user, err := app.UserStore.Create("alice", "pw-1", []int{0})
		if err != nil {
			t.Fatalf("create user: %v", err)
		}
		virtualID := app.IDStore.GetOrCreateVirtualID("movie-a", 0)
		login := doJSONRequest(t, handler, http.MethodPost, "/web/api/login", map[string]string{"username": user.Username, "password": "pw-1"}, "")
		if login.Code != http.StatusOK {
			t.Fatalf("login status = %d, body=%s", login.Code, login.Body.String())
		}

		body := map[string]any{"positionTicks": 950, "runTimeTicks": 1000}
		reqBody, _ := json.Marshal(body)
		req := httptest.NewRequest(http.MethodPost, "/web/api/items/"+virtualID+"/stop", bytes.NewReader(reqBody))
		req.Header.Set("Content-Type", "application/json")
		req.AddCookie(login.Result().Cookies()[0])
		rr := httptest.NewRecorder()
		handler.ServeHTTP(rr, req)
		if rr.Code != http.StatusNoContent {
			t.Fatalf("stop status = %d, body=%s", rr.Code, rr.Body.String())
		}
		progress := app.WatchStore.GetProgress(user.ID, virtualID)
		if progress == nil || !progress.Played || progress.PositionTicks != 0 {
			t.Fatalf("stop was not persisted as played: %#v", progress)
		}
	})
}
