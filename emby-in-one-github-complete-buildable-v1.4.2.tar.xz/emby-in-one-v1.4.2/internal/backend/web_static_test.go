package backend

import (
	"net/http"
	"strings"
	"testing"
)

func TestWebRoutesServeViewerShell(t *testing.T) {
	withTempApp(t, func(app *App, handler http.Handler) {
		shell := doJSONRequest(t, handler, http.MethodGet, "/web", nil, "")
		if shell.Code != http.StatusOK {
			t.Fatalf("GET /web status = %d, body=%s", shell.Code, shell.Body.String())
		}
		if got := shell.Header().Get("Content-Type"); !strings.Contains(got, "text/html") {
			t.Fatalf("GET /web Content-Type = %q", got)
		}
		if !strings.Contains(shell.Body.String(), `id="web-app"`) {
			t.Fatalf("GET /web did not serve viewer shell: %s", shell.Body.String())
		}

		deepLink := doJSONRequest(t, handler, http.MethodGet, "/web/item/item-123", nil, "")
		if deepLink.Code != http.StatusOK {
			t.Fatalf("GET /web/item/item-123 status = %d, body=%s", deepLink.Code, deepLink.Body.String())
		}
		if !strings.Contains(deepLink.Body.String(), `<script type="module" src="/web/app/index.js"></script>`) {
			t.Fatalf("deep link did not serve web shell")
		}

		styles := doJSONRequest(t, handler, http.MethodGet, "/web/styles/layout.css", nil, "")
		if styles.Code != http.StatusOK {
			t.Fatalf("GET /web/styles/layout.css status = %d, body=%s", styles.Code, styles.Body.String())
		}
		if got := styles.Header().Get("Content-Type"); !strings.Contains(got, "text/css") {
			t.Fatalf("GET /web/styles/layout.css Content-Type = %q", got)
		}
		if !strings.Contains(styles.Body.String(), ".topbar") {
			t.Fatalf("GET /web/styles/layout.css did not serve layout stylesheet: %s", styles.Body.String())
		}

		admin := doJSONRequest(t, handler, http.MethodGet, "/admin", nil, "")
		if admin.Code != http.StatusFound {
			t.Fatalf("GET /admin status = %d", admin.Code)
		}
	})
}

func TestWebPathsHaveStrictCSP(t *testing.T) {
	withTempApp(t, func(app *App, handler http.Handler) {
		shell := doJSONRequest(t, handler, http.MethodGet, "/web", nil, "")
		if shell.Code != http.StatusOK {
			t.Fatalf("GET /web status = %d, body=%s", shell.Code, shell.Body.String())
		}
		if got := shell.Header().Get("Content-Security-Policy"); !strings.Contains(got, "default-src 'self'") {
			t.Fatalf("GET /web Content-Security-Policy = %q", got)
		}
		if got := shell.Header().Get("X-Content-Type-Options"); got != "nosniff" {
			t.Fatalf("GET /web X-Content-Type-Options = %q, want nosniff", got)
		}
		if got := shell.Header().Get("X-Frame-Options"); got != "SAMEORIGIN" {
			t.Fatalf("GET /web X-Frame-Options = %q, want SAMEORIGIN", got)
		}
		if got := shell.Header().Get("Referrer-Policy"); got != "same-origin" {
			t.Fatalf("GET /web Referrer-Policy = %q, want same-origin", got)
		}

		login := doJSONRequest(t, handler, http.MethodPost, "/web/api/login", map[string]string{
			"username": "viewer",
			"password": "wrong",
		}, "")
		if got := login.Header().Get("Content-Security-Policy"); !strings.Contains(got, "default-src 'self'") {
			t.Fatalf("POST /web/api/login Content-Security-Policy = %q", got)
		}
		if got := login.Header().Get("X-Content-Type-Options"); got != "nosniff" {
			t.Fatalf("POST /web/api/login X-Content-Type-Options = %q, want nosniff", got)
		}

		public := doJSONRequest(t, handler, http.MethodGet, "/System/Info/Public", nil, "")
		if got := public.Header().Get("Content-Security-Policy"); got != "" {
			t.Fatalf("GET /System/Info/Public Content-Security-Policy = %q, want empty", got)
		}
	})
}
