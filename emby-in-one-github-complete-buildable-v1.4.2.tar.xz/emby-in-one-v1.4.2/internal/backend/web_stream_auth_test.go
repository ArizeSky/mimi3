package backend

import (
	"encoding/json"
	"fmt"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
)

func TestWebCookieCanAccessVideoProxy(t *testing.T) {
	upstream := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch {
		case r.Method == http.MethodPost && r.URL.Path == "/Users/AuthenticateByName":
			_ = json.NewEncoder(w).Encode(map[string]any{"AccessToken": "tok-a", "User": map[string]any{"Id": "user-a"}})
		case r.Method == http.MethodGet && r.URL.Path == "/Users/user-a/Items/item-a":
			_ = json.NewEncoder(w).Encode(map[string]any{"Id": "item-a", "Name": "Movie A", "Type": "Movie"})
		case r.Method == http.MethodGet && r.URL.Path == "/Items/item-a/PlaybackInfo":
			_ = json.NewEncoder(w).Encode(map[string]any{"PlaySessionId": "sess-a", "MediaSources": []map[string]any{{
				"Id":              "ms-a",
				"Name":            "Version A",
				"Container":       "mp4",
				"DirectStreamUrl": "/Videos/item-a/stream.mp4?MediaSourceId=ms-a&api_key=upstream-token",
				"MediaStreams":    []map[string]any{{"Type": "Audio", "Index": 1, "DisplayTitle": "AAC"}},
			}}})
		case r.Method == http.MethodGet && r.URL.Path == "/Videos/item-a/stream.mp4":
			w.Header().Set("Content-Type", "video/mp4")
			_, _ = w.Write([]byte("mp4-data"))
		default:
			http.NotFound(w, r)
		}
	}))
	defer upstream.Close()

	withTempAppPrepared(t, singleUpstreamConfig(upstream.URL), nil, func(app *App, handler http.Handler, dir string) {
		if _, err := app.UserStore.Create("alice", "pw-1", []int{0}); err != nil {
			t.Fatalf("create user: %v", err)
		}
		itemID := app.IDStore.GetOrCreateVirtualID("item-a", 0)
		login := doJSONRequest(t, handler, http.MethodPost, "/web/api/login", map[string]string{"username": "alice", "password": "pw-1"}, "")
		if login.Code != http.StatusOK {
			t.Fatalf("login status = %d, body=%s", login.Code, login.Body.String())
		}
		cookie := login.Result().Cookies()[0]

		playbackReq := httptest.NewRequest(http.MethodGet, "/web/api/items/"+itemID+"/playback", nil)
		playbackReq.AddCookie(cookie)
		playbackRR := httptest.NewRecorder()
		handler.ServeHTTP(playbackRR, playbackReq)
		if playbackRR.Code != http.StatusOK {
			t.Fatalf("playback status = %d, body=%s", playbackRR.Code, playbackRR.Body.String())
		}
		var payload map[string]any
		if err := json.Unmarshal(playbackRR.Body.Bytes(), &payload); err != nil {
			t.Fatalf("unmarshal playback payload: %v", err)
		}
		source, _ := payload["source"].(map[string]any)
		url, _ := source["url"].(string)
		if url == "" {
			t.Fatalf("expected playback source url, payload=%s", playbackRR.Body.String())
		}
		if !strings.Contains(url, "PlaySessionId=") {
			t.Fatalf("expected playback source url to carry PlaySessionId, got %q", url)
		}

		streamReq := httptest.NewRequest(http.MethodGet, url, nil)
		streamReq.AddCookie(cookie)
		streamRR := httptest.NewRecorder()
		handler.ServeHTTP(streamRR, streamReq)
		if streamRR.Code != http.StatusOK {
			t.Fatalf("stream status = %d, body=%s", streamRR.Code, streamRR.Body.String())
		}
		if got := streamRR.Header().Get("Content-Type"); got != "video/mp4" {
			t.Fatalf("stream content-type = %q", got)
		}
	})
}

func TestVideoProxyAppliesConcurrentLimitWithoutPlaybackInfoHandshake(t *testing.T) {
	upstream := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch {
		case r.Method == http.MethodPost && r.URL.Path == "/Users/AuthenticateByName":
			_ = json.NewEncoder(w).Encode(map[string]any{"AccessToken": "token-a", "User": map[string]any{"Id": "user-a"}})
		case r.Method == http.MethodGet && r.URL.Path == "/Videos/item-a/stream.mp4":
			w.Header().Set("Content-Type", "video/mp4")
			_, _ = w.Write([]byte("mp4-data"))
		default:
			http.NotFound(w, r)
		}
	}))
	defer upstream.Close()

	config := fmt.Sprintf(`server:
  port: 8096
  name: "Test"
  id: "svr"
admin:
  username: "admin"
  password: "secret"
playback:
  mode: "proxy"
timeouts:
  api: 30000
  global: 15000
  login: 10000
  healthCheck: 10000
  healthInterval: 60000
proxies: []
upstream:
  - name: "A"
    url: %q
    username: "u1"
    password: "p1"
    maxConcurrent: 1
`, upstream.URL)

	withTempAppPrepared(t, config, nil, func(app *App, handler http.Handler, dir string) {
		adminToken := loginTokenAs(t, handler, "admin", "secret")
		_ = createLimitedUserAndToken(t, handler, adminToken, "alice", "pw-1", []int{0})
		bobToken := createLimitedUserAndToken(t, handler, adminToken, "bob", "pw-2", []int{0})

		itemID := app.IDStore.GetOrCreateVirtualID("item-a", 0)
		mediaSourceID := app.IDStore.GetOrCreateVirtualID("ms-a", 0)
		playSessionA := app.IDStore.GetOrCreateVirtualID("play-a", 0)
		playSessionB := app.IDStore.GetOrCreateVirtualID("play-b", 0)

		rr := doJSONRequest(t, handler, http.MethodGet, "/Videos/"+itemID+"/stream.mp4?MediaSourceId="+mediaSourceID+"&PlaySessionId="+playSessionA, nil, loginTokenAs(t, handler, "alice", "pw-1"))
		if rr.Code != http.StatusOK {
			t.Fatalf("first direct stream status = %d, body=%s", rr.Code, rr.Body.String())
		}

		rr = doJSONRequest(t, handler, http.MethodGet, "/Videos/"+itemID+"/stream.mp4?MediaSourceId="+mediaSourceID+"&PlaySessionId="+playSessionB, nil, bobToken)
		if rr.Code != http.StatusTooManyRequests {
			t.Fatalf("second direct stream status = %d, want 429 body=%s", rr.Code, rr.Body.String())
		}
	})
}

func TestVideoProxyRejectsTrackedPlaybackWithoutPlaySessionID(t *testing.T) {
	upstream := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch {
		case r.Method == http.MethodPost && r.URL.Path == "/Users/AuthenticateByName":
			_ = json.NewEncoder(w).Encode(map[string]any{"AccessToken": "token-a", "User": map[string]any{"Id": "user-a"}})
		case r.Method == http.MethodGet && r.URL.Path == "/Videos/item-a/stream.mp4":
			w.Header().Set("Content-Type", "video/mp4")
			_, _ = w.Write([]byte("mp4-data"))
		default:
			http.NotFound(w, r)
		}
	}))
	defer upstream.Close()

	config := fmt.Sprintf(`server:
  port: 8096
  name: "Test"
  id: "svr"
admin:
  username: "admin"
  password: "secret"
playback:
  mode: "proxy"
timeouts:
  api: 30000
  global: 15000
  login: 10000
  healthCheck: 10000
  healthInterval: 60000
proxies: []
upstream:
  - name: "A"
    url: %q
    username: "u1"
    password: "p1"
    maxConcurrent: 1
`, upstream.URL)

	withTempAppPrepared(t, config, nil, func(app *App, handler http.Handler, dir string) {
		adminToken := loginTokenAs(t, handler, "admin", "secret")
		userToken := createLimitedUserAndToken(t, handler, adminToken, "alice", "pw-1", []int{0})

		itemID := app.IDStore.GetOrCreateVirtualID("item-a", 0)
		mediaSourceID := app.IDStore.GetOrCreateVirtualID("ms-a", 0)

		rr := doJSONRequest(t, handler, http.MethodGet, "/Videos/"+itemID+"/stream.mp4?MediaSourceId="+mediaSourceID, nil, userToken)
		if rr.Code != http.StatusBadRequest {
			t.Fatalf("stream without PlaySessionId status = %d, want 400 body=%s", rr.Code, rr.Body.String())
		}
	})
}
