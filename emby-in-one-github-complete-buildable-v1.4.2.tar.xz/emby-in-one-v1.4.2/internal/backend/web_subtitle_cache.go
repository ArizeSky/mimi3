package backend

import (
	"fmt"
	"sync"
	"time"
)

type webSubtitleCache struct {
	mu    sync.Mutex
	items map[string]webSubtitleCacheEntry
	ttl   time.Duration
	next  uint64
}

type webSubtitleCacheEntry struct {
	Value       any
	CreatedAt   time.Time
	expireToken uint64
	expireTimer *time.Timer
}

func newWebSubtitleCache() *webSubtitleCache {
	return newWebSubtitleCacheWithTTL(0)
}

func newWebSubtitleCacheWithTTL(ttl time.Duration) *webSubtitleCache {
	return &webSubtitleCache{
		items: make(map[string]webSubtitleCacheEntry),
		ttl:   ttl,
	}
}

func webSubtitleCacheKey(ref webSubtitleRef, profile string) string {
	return fmt.Sprintf("%s|%s|%d|%s|%s", ref.ItemID, ref.MediaSourceID, ref.StreamIndex, ref.RendererKind, profile)
}

func (c *webSubtitleCache) Get(key string, ttl time.Duration) (any, bool) {
	if c == nil {
		return nil, false
	}
	ttl = c.resolveTTL(ttl)
	now := time.Now()
	c.mu.Lock()
	defer c.mu.Unlock()
	entry, ok := c.items[key]
	if !ok {
		return nil, false
	}
	if ttl > 0 && now.Sub(entry.CreatedAt) >= ttl {
		c.removeEntryLocked(key, entry)
		return nil, false
	}
	return entry.Value, true
}

func (c *webSubtitleCache) Set(key string, value any) {
	if c == nil {
		return
	}
	c.mu.Lock()
	defer c.mu.Unlock()
	if existing, ok := c.items[key]; ok {
		c.stopEntryTimerLocked(existing)
	}
	c.next++
	entry := webSubtitleCacheEntry{
		Value:       value,
		CreatedAt:   time.Now(),
		expireToken: c.next,
	}
	if c.ttl > 0 {
		token := entry.expireToken
		entry.expireTimer = time.AfterFunc(c.ttl, func() {
			c.expireIdleEntry(key, token)
		})
	}
	c.items[key] = entry
}

func (c *webSubtitleCache) Cleanup(ttl time.Duration) {
	if c == nil {
		return
	}
	ttl = c.resolveTTL(ttl)
	if ttl <= 0 {
		return
	}
	cutoff := time.Now().Add(-ttl)
	c.mu.Lock()
	defer c.mu.Unlock()
	for key, entry := range c.items {
		if !entry.CreatedAt.After(cutoff) {
			c.removeEntryLocked(key, entry)
		}
	}
}

func (c *webSubtitleCache) resolveTTL(ttl time.Duration) time.Duration {
	if ttl > 0 {
		return ttl
	}
	return c.ttl
}

func (c *webSubtitleCache) expireIdleEntry(key string, token uint64) {
	c.mu.Lock()
	defer c.mu.Unlock()
	entry, ok := c.items[key]
	if !ok || entry.expireToken != token {
		return
	}
	delete(c.items, key)
}

func (c *webSubtitleCache) removeEntryLocked(key string, entry webSubtitleCacheEntry) {
	c.stopEntryTimerLocked(entry)
	delete(c.items, key)
}

func (c *webSubtitleCache) stopEntryTimerLocked(entry webSubtitleCacheEntry) {
	if entry.expireTimer != nil {
		entry.expireTimer.Stop()
	}
}
