package backend

import (
	"fmt"
	"sync"
	"time"
)

type webTextSubtitleCacheKey struct {
	UpstreamKey    string
	ItemID         string
	MediaSourceID  string
	StreamIndex    int
	Codec          string
	SourceRevision string
}

func (k webTextSubtitleCacheKey) String() string {
	return fmt.Sprintf("%s|%s|%s|%d|%s|%s",
		k.UpstreamKey, k.ItemID, k.MediaSourceID, k.StreamIndex, k.Codec, k.SourceRevision)
}

type webTextSubtitleCacheEntry struct {
	Payload             webTextSubtitlePayload
	CreatedAt           time.Time
	SourceCandidateKind string
	Err                 error
	FailedAt            time.Time
}

type inflightCall struct {
	wg  sync.WaitGroup
	val webTextSubtitlePayload
	err error
}

type webTextSubtitleCacheStore struct {
	mu       sync.Mutex
	items    map[string]webTextSubtitleCacheEntry
	inflight map[string]*inflightCall

	successTTL time.Duration
	failureTTL time.Duration
}

func newWebTextSubtitleCacheStore() *webTextSubtitleCacheStore {
	return &webTextSubtitleCacheStore{
		items:      make(map[string]webTextSubtitleCacheEntry),
		inflight:   make(map[string]*inflightCall),
		successTTL: 15 * time.Minute,
		failureTTL: 15 * time.Second,
	}
}

func (c *webTextSubtitleCacheStore) GetOrLoad(
	key webTextSubtitleCacheKey,
	loader func() (webTextSubtitlePayload, string, error),
) (webTextSubtitlePayload, error) {
	k := key.String()

	// check cache
	c.mu.Lock()
	if entry, ok := c.items[k]; ok {
		now := time.Now()
		if entry.Err != nil {
			if now.Sub(entry.FailedAt) < c.failureTTL {
				c.mu.Unlock()
				return webTextSubtitlePayload{}, entry.Err
			}
			// failure TTL expired — remove stale entry, re-load below
			delete(c.items, k)
		} else if now.Sub(entry.CreatedAt) < c.successTTL {
			c.mu.Unlock()
			return entry.Payload, nil
		} else {
			// success TTL expired, remove stale entry
			delete(c.items, k)
		}
	}

	// singleflight: check if another goroutine already loading this key
	if inflight, ok := c.inflight[k]; ok {
		c.mu.Unlock()
		inflight.wg.Wait()
		return inflight.val, inflight.err
	}

	call := &inflightCall{}
	call.wg.Add(1)
	c.inflight[k] = call
	c.mu.Unlock()

	// execute loader
	payload, candidateKind, err := loader()

	c.mu.Lock()
	delete(c.inflight, k)
	if err != nil {
		c.items[k] = webTextSubtitleCacheEntry{
			Err:      err,
			FailedAt: time.Now(),
		}
	} else {
		c.items[k] = webTextSubtitleCacheEntry{
			Payload:             payload,
			CreatedAt:           time.Now(),
			SourceCandidateKind: candidateKind,
		}
	}
	c.mu.Unlock()

	call.val = payload
	call.err = err
	call.wg.Done()
	return payload, err
}

func (c *webTextSubtitleCacheStore) Cleanup(maxAge time.Duration) {
	if maxAge <= 0 {
		return
	}
	cutoff := time.Now().Add(-maxAge)
	c.mu.Lock()
	defer c.mu.Unlock()
	for k, entry := range c.items {
		// Clean expired success entries
		if !entry.CreatedAt.After(cutoff) && entry.FailedAt.IsZero() {
			delete(c.items, k)
			continue
		}
		// Clean expired failure entries
		if !entry.FailedAt.IsZero() && !entry.FailedAt.After(cutoff) {
			delete(c.items, k)
		}
	}
}

func (c *webTextSubtitleCacheStore) CleanupExpired() {
	if c == nil {
		return
	}
	now := time.Now()
	c.mu.Lock()
	defer c.mu.Unlock()
	for k, entry := range c.items {
		if entry.Err != nil {
			if !entry.FailedAt.IsZero() && now.Sub(entry.FailedAt) >= c.failureTTL {
				delete(c.items, k)
			}
			continue
		}
		if !entry.CreatedAt.IsZero() && now.Sub(entry.CreatedAt) >= c.successTTL {
			delete(c.items, k)
		}
	}
}
