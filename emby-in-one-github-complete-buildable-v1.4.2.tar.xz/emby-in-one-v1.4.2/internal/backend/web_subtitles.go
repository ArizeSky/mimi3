package backend

import (
	"encoding/base64"
	"encoding/json"
	"errors"
	"fmt"
	"net/http"
	"net/url"
	"strconv"
	"strings"
)

type webSubtitleRef struct {
	ItemID        string `json:"itemId,omitempty"`
	MediaSourceID string `json:"mediaSourceId"`
	StreamIndex   int    `json:"streamIndex"`
	RendererKind  string `json:"rendererKind"`
}

var errWebSubtitleUnsupportedFormat = errors.New("unsupported web subtitle format")

func encodeWebSubtitleTrackID(ref webSubtitleRef) string {
	payload, _ := json.Marshal(ref)
	return "sub-" + base64.RawURLEncoding.EncodeToString(payload)
}

func webSubtitleTrackID(itemID, mediaSourceID string, index int, rendererKind string) string {
	return encodeWebSubtitleTrackID(webSubtitleRef{
		ItemID:        itemID,
		MediaSourceID: mediaSourceID,
		StreamIndex:   index,
		RendererKind:  rendererKind,
	})
}

func decodeWebSubtitleTrackID(trackID string) (webSubtitleRef, error) {
	if trackID == "" {
		return webSubtitleRef{}, newWebSubtitleResolveError(http.StatusBadRequest, "invalid web subtitle track id", nil)
	}
	if !strings.HasPrefix(trackID, "sub-") {
		return webSubtitleRef{}, newWebSubtitleResolveError(http.StatusBadRequest, "invalid web subtitle track id", nil)
	}
	raw, err := base64.RawURLEncoding.DecodeString(strings.TrimPrefix(trackID, "sub-"))
	if err != nil {
		return webSubtitleRef{}, newWebSubtitleResolveError(http.StatusBadRequest, "invalid web subtitle track id", err)
	}
	var ref webSubtitleRef
	if err := json.Unmarshal(raw, &ref); err != nil {
		return webSubtitleRef{}, newWebSubtitleResolveError(http.StatusBadRequest, "invalid web subtitle track id", err)
	}
	if err := validateWebSubtitleRef(ref); err != nil {
		return webSubtitleRef{}, err
	}
	return ref, nil
}

func (a *App) resolveWebSubtitleTrack(r *http.Request, trackID string) (*webSubtitleRef, error) {
	ref, err := decodeWebSubtitleTrackID(trackID)
	if err != nil {
		return nil, err
	}
	if pathItemID := r.PathValue("itemId"); pathItemID != "" {
		if ref.ItemID != "" && ref.ItemID != pathItemID {
			return nil, newWebSubtitleResolveError(http.StatusNotFound, "subtitle track not found", nil)
		}
		ref.ItemID = pathItemID
	}
	if ref.ItemID == "" {
		return nil, newWebSubtitleResolveError(http.StatusBadRequest, "invalid web subtitle track id", nil)
	}
	// Do not call PlaybackInfo here. Every concrete loader resolves the virtual
	// item/media source and validates the exact stream once. Calling the formal
	// playback endpoint during both ID validation and loading creates redundant
	// upstream play sessions and used to consume concurrency slots.
	return &ref, nil
}

func (a *App) handleWebSubtitleAss(w http.ResponseWriter, r *http.Request) {
	ref, err := a.resolveWebSubtitleTrack(r, r.PathValue("trackId"))
	if err != nil {
		if a.Logger != nil {
			a.Logger.Warnf("Web subtitle ass failed: trackId=%s err=%v", r.PathValue("trackId"), err)
		}
		writeWebSubtitleResolveError(w, err)
		return
	}
	if err := requireWebSubtitleRenderer(*ref, "ass"); err != nil {
		writeWebSubtitleLoadError(w, "ass", err)
		return
	}
	profile := webSubtitleProfileFromRequest(r)
	if a.Logger != nil {
		a.Logger.Debugf("Web subtitle ass request: itemId=%s mediaSourceId=%s streamIndex=%d profile=%s", ref.ItemID, ref.MediaSourceID, ref.StreamIndex, profile)
	}
	payload, err := a.webLoadASSPayload(r, *ref, profile)
	if err != nil {
		if a.Logger != nil {
			a.Logger.Warnf("Web subtitle ass load failed: itemId=%s mediaSourceId=%s streamIndex=%d err=%v", ref.ItemID, ref.MediaSourceID, ref.StreamIndex, err)
		}
		writeWebSubtitleLoadError(w, "ass", err)
		return
	}
	if a.Logger != nil {
		a.Logger.Infof("Web subtitle ass response: itemId=%s mediaSourceId=%s streamIndex=%d requiredFonts=%d fontAssets=%d profiles=%d", ref.ItemID, ref.MediaSourceID, ref.StreamIndex, len(payload.RequiredFonts), len(payload.FontAssets), len(payload.Profiles))
	}
	writeJSON(w, http.StatusOK, payload)
}

func webSubtitleProfileFromRequest(r *http.Request) string {
	profile := strings.ToLower(strings.TrimSpace(r.URL.Query().Get("profile")))
	switch profile {
	case "", "full":
		return "full"
	case "lite":
		return "lite"
	default:
		return "full"
	}
}

func validateWebSubtitleRef(ref webSubtitleRef) error {
	if ref.ItemID == "" {
		return newWebSubtitleResolveError(http.StatusBadRequest, "invalid web subtitle track id", nil)
	}
	if ref.MediaSourceID == "" {
		return newWebSubtitleResolveError(http.StatusBadRequest, "invalid web subtitle track id", nil)
	}
	if ref.StreamIndex < 0 {
		return newWebSubtitleResolveError(http.StatusBadRequest, "invalid web subtitle track id", nil)
	}
	switch ref.RendererKind {
	case "text", "ass", "bitmap", "burnin":
		return nil
	default:
		return newWebSubtitleResolveError(http.StatusBadRequest, "invalid web subtitle track id", nil)
	}
}

func requireWebSubtitleRenderer(ref webSubtitleRef, expected string) error {
	if ref.RendererKind != expected {
		return fmt.Errorf("%w: track renderer %q cannot be loaded as %s", errWebSubtitleUnsupportedFormat, ref.RendererKind, expected)
	}
	return nil
}

func writeWebSubtitleLoadError(w http.ResponseWriter, resource string, err error) {
	if errors.Is(err, errWebSubtitleUnsupportedFormat) {
		writeJSON(w, http.StatusUnsupportedMediaType, map[string]any{
			"message":  "Unsupported subtitle format",
			"resource": resource,
			"fallback": "burnin",
		})
		return
	}
	writeJSON(w, http.StatusBadGateway, map[string]any{"message": "Unable to load subtitle " + resource})
}

type webSubtitleResolveError struct {
	status  int
	message string
	cause   error
}

func (e *webSubtitleResolveError) Error() string {
	if e == nil {
		return ""
	}
	if e.cause != nil {
		return e.message + ": " + e.cause.Error()
	}
	return e.message
}

func (e *webSubtitleResolveError) Unwrap() error {
	if e == nil {
		return nil
	}
	return e.cause
}

func newWebSubtitleResolveError(status int, message string, cause error) error {
	return &webSubtitleResolveError{status: status, message: message, cause: cause}
}

func webSubtitleResolveErrorStatus(err error) (int, bool) {
	var target *webSubtitleResolveError
	if errors.As(err, &target) {
		return target.status, true
	}
	return 0, false
}

func (a *App) webLoadPlaybackInfoForSubtitleResolution(r *http.Request, itemID string) (map[string]any, error) {
	return a.webLoadPlaybackInfoForSelection(r, itemID, a.webSelectionFromRequest(r))
}

func (a *App) webLoadPlaybackInfoForSelection(r *http.Request, itemID string, selection webSelection) (map[string]any, error) {
	result := a.webRequestPlaybackInfo(r, itemID, selection)
	switch result.Status {
	case http.StatusOK:
		return result.Payload, nil
	case http.StatusNotFound:
		return nil, newWebSubtitleResolveError(http.StatusNotFound, "subtitle track not found", nil)
	case http.StatusTooManyRequests:
		return nil, newWebSubtitleResolveError(http.StatusTooManyRequests, "playback info unavailable", nil)
	default:
		if result.Status >= http.StatusInternalServerError {
			return nil, newWebSubtitleResolveError(http.StatusBadGateway, "unable to load playback info", fmt.Errorf("status %d", result.Status))
		}
		return nil, newWebSubtitleResolveError(http.StatusBadGateway, "unable to load playback info", fmt.Errorf("status %d", result.Status))
	}
}

func webSubtitleSelectionForRef(r *http.Request, ref webSubtitleRef) webSelection {
	selection := webSelectionFromURLValues(r.URL.Query())
	selection.MediaSourceID = ref.MediaSourceID
	selection.SubtitleStreamIndex = ref.StreamIndex
	return selection
}

func webSelectionFromURLValues(values url.Values) webSelection {
	return webSelection{
		EpisodeID:           values.Get("episodeId"),
		MediaSourceID:       values.Get("mediaSourceId"),
		AudioStreamIndex:    atoiDefault(values.Get("audioStreamIndex"), -1),
		SubtitleStreamIndex: atoiDefault(values.Get("subtitleStreamIndex"), -1),
	}
}

func webPlayPath(itemID string, selection webSelection) string {
	query := url.Values{}
	if selection.MediaSourceID != "" {
		query.Set("mediaSourceId", selection.MediaSourceID)
	}
	if selection.AudioStreamIndex >= 0 {
		query.Set("audioStreamIndex", strconv.Itoa(selection.AudioStreamIndex))
	}
	if selection.SubtitleStreamIndex >= 0 {
		query.Set("subtitleStreamIndex", strconv.Itoa(selection.SubtitleStreamIndex))
	}
	if selection.EpisodeID != "" {
		query.Set("episodeId", selection.EpisodeID)
	}
	if encoded := query.Encode(); encoded != "" {
		return fmt.Sprintf("/web/play/%s?%s", itemID, encoded)
	}
	return "/web/play/" + itemID
}

func writeWebSubtitleResolveError(w http.ResponseWriter, err error) {
	status, ok := webSubtitleResolveErrorStatus(err)
	if !ok || status == 0 {
		status = http.StatusInternalServerError
	}
	message := "Unable to resolve subtitle track"
	switch status {
	case http.StatusBadRequest:
		message = "Invalid subtitle track id"
	case http.StatusNotFound:
		message = "Subtitle track not found"
	case http.StatusTooManyRequests:
		message = "Playback info unavailable"
	case http.StatusBadGateway:
		message = "Unable to load playback info"
	}
	writeJSON(w, status, map[string]any{"message": message})
}
