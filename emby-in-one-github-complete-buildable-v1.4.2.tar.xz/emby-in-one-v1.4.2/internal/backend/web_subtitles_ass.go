package backend

import (
	"fmt"
	"net/http"
	"net/url"
	"sort"
	"strings"
)

type webFontAsset struct {
	Name     string `json:"name"`
	URL      string `json:"url"`
	MIMEType string `json:"mimeType"`
}

type webASSPayload struct {
	Renderer      string          `json:"renderer"`
	Script        string          `json:"script,omitempty"`
	ScriptURL     string          `json:"scriptUrl,omitempty"`
	RequiredFonts []string        `json:"requiredFonts,omitempty"`
	FontAssets    []webFontAsset  `json:"fontAssets,omitempty"`
	Profiles      map[string]bool `json:"profiles"`
}

func (a *App) webLoadASSPayload(r *http.Request, ref webSubtitleRef, profile string) (webASSPayload, error) {
	cacheKey := webSubtitleCacheKey(ref, profile)
	if cached, ok := a.webSubtitleCache.Get(cacheKey, a.webSubtitleCacheTTL); ok {
		if payload, ok := cached.(webASSPayload); ok {
			return payload, nil
		}
	}

	reqCtx := requestContextFrom(r.Context())
	resolved, rawMediaSourceID, err := a.resolveWebSubtitleTextTarget(r, ref)
	if err != nil {
		return webASSPayload{}, err
	}
	query := url.Values{}
	if rawMediaSourceID != "" {
		query.Set("MediaSourceId", rawMediaSourceID)
	}
	playbackValue, err := resolved.Client.RequestJSON(r.Context(), reqCtx, a.Identity, http.MethodGet, "/Items/"+resolved.OriginalID+"/PlaybackInfo", query, nil)
	if err != nil {
		return webASSPayload{}, err
	}
	playback, ok := playbackValue.(map[string]any)
	if !ok {
		return webASSPayload{}, fmt.Errorf("unexpected playback info payload")
	}
	_, deliveryURL, err := webSubtitleRawASSStream(playback, rawMediaSourceID, ref.StreamIndex)
	if err != nil {
		return webASSPayload{}, err
	}
	script, err := webLoadASSScript(r, reqCtx, a.Identity, resolved, rawMediaSourceID, ref.StreamIndex, deliveryURL)
	if err != nil {
		return webASSPayload{}, err
	}
	payload := webASSPayload{
		Renderer:      "ass",
		Script:        script,
		RequiredFonts: webParseASSFonts(script),
		FontAssets:    webASSFontAssets(playback, rawMediaSourceID, ref),
		Profiles: map[string]bool{
			"full": true,
			"lite": true,
		},
	}
	a.webSubtitleCache.Set(cacheKey, payload)
	return payload, nil
}

func webLoadASSScript(r *http.Request, reqCtx *RequestContext, identity *ClientIdentityService, resolved *routeResolution, rawMediaSourceID string, streamIndex int, deliveryURL string) (string, error) {
	body, err := webLoadASSBody(r, reqCtx, identity, resolved, rawMediaSourceID, streamIndex, deliveryURL)
	if err != nil {
		return "", err
	}
	script, err := webDecodeSubtitleText(body)
	if err != nil {
		return "", err
	}
	script = strings.ReplaceAll(script, "\r\n", "\n")
	lower := strings.ToLower(script)
	if !strings.Contains(lower, "[events]") || !strings.Contains(lower, "dialogue:") {
		return "", fmt.Errorf("%w: invalid ASS/SSA script", errWebSubtitleUnsupportedFormat)
	}
	return script, nil
}

func webLoadASSBody(r *http.Request, reqCtx *RequestContext, identity *ClientIdentityService, resolved *routeResolution, rawMediaSourceID string, streamIndex int, deliveryURL string) ([]byte, error) {
	if deliveryURL != "" {
		return webLoadSubtitleBody(r.Context(), reqCtx, resolved.Client, identity, deliveryURL)
	}
	extractedURL := fmt.Sprintf("/Videos/%s/%s/Subtitles/%d/Stream.ass", resolved.OriginalID, rawMediaSourceID, streamIndex)
	return webLoadSubtitleBody(r.Context(), reqCtx, resolved.Client, identity, extractedURL)
}

func webParseASSFonts(script string) []string {
	lines := strings.Split(strings.ReplaceAll(script, "\r\n", "\n"), "\n")
	inStyles := false
	fontIndex := 1
	seen := make(map[string]struct{})
	fonts := make([]string, 0)
	for _, rawLine := range lines {
		line := strings.TrimSpace(rawLine)
		if line == "" {
			continue
		}
		if strings.HasPrefix(line, "[") && strings.HasSuffix(line, "]") {
			section := strings.ToLower(line)
			inStyles = section == "[v4+ styles]" || section == "[v4 styles]"
			continue
		}
		if !inStyles {
			continue
		}
		switch {
		case strings.HasPrefix(strings.ToLower(line), "format:"):
			fields := webParseASSCSV(strings.TrimSpace(line[len("Format:"):]))
			for i, field := range fields {
				if strings.EqualFold(strings.TrimSpace(field), "Fontname") {
					fontIndex = i
					break
				}
			}
		case strings.HasPrefix(strings.ToLower(line), "style:"):
			fields := webParseASSCSV(strings.TrimSpace(line[len("Style:"):]))
			if fontIndex >= len(fields) {
				continue
			}
			fontName := strings.TrimSpace(fields[fontIndex])
			if fontName == "" {
				continue
			}
			if _, ok := seen[fontName]; ok {
				continue
			}
			seen[fontName] = struct{}{}
			fonts = append(fonts, fontName)
		}
	}
	sort.Strings(fonts)
	return fonts
}

func webASSFontAssets(playback map[string]any, rawMediaSourceID string, ref webSubtitleRef) []webFontAsset {
	sources := asItems(map[string]any{"Items": playback["MediaSources"]})
	assets := make([]webFontAsset, 0)
	seen := make(map[string]struct{})
	for _, source := range sources {
		if rawMediaSourceID != "" && webString(source["Id"]) != rawMediaSourceID {
			continue
		}
		// Direct upstream PlaybackInfo uses the original media-source ID, while
		// the browser-facing attachment URL must retain the virtual ref ID.
		streams, _ := source["MediaStreams"].([]any)
		for _, raw := range streams {
			stream, ok := raw.(map[string]any)
			if !ok || !strings.EqualFold(webString(stream["Type"]), "Attachment") {
				continue
			}
			codec := strings.ToLower(strings.TrimSpace(webSubtitleCodec(stream)))
			fileName := firstNonEmpty(webString(stream["FileName"]), webString(stream["DisplayTitle"]), webString(stream["Title"]))
			mimeType := webASSFontMIMEType(codec, fileName)
			if mimeType == "" {
				continue
			}
			index := webInt(stream["Index"])
			key := fmt.Sprintf("%d|%s", index, fileName)
			if _, ok := seen[key]; ok {
				continue
			}
			seen[key] = struct{}{}
			if fileName == "" {
				fileName = fmt.Sprintf("font-%d.%s", index, firstNonEmpty(codec, "ttf"))
			}
			assets = append(assets, webFontAsset{
				Name:     fileName,
				URL:      fmt.Sprintf("/Videos/%s/%s/Attachments/%d", url.PathEscape(ref.ItemID), url.PathEscape(ref.MediaSourceID), index),
				MIMEType: mimeType,
			})
		}
		break
	}
	sort.Slice(assets, func(i, j int) bool { return assets[i].Name < assets[j].Name })
	return assets
}

func webASSFontMIMEType(codec, fileName string) string {
	codec = strings.TrimPrefix(strings.ToLower(strings.TrimSpace(codec)), "font/")
	ext := ""
	if dot := strings.LastIndexByte(fileName, '.'); dot >= 0 {
		ext = strings.ToLower(fileName[dot+1:])
	}
	switch firstNonEmpty(codec, ext) {
	case "ttf", "truetype":
		return "font/ttf"
	case "otf", "opentype":
		return "font/otf"
	case "woff":
		return "font/woff"
	case "woff2":
		return "font/woff2"
	default:
		return ""
	}
}

func webParseASSCSV(raw string) []string {
	parts := strings.Split(raw, ",")
	for i := range parts {
		parts[i] = strings.TrimSpace(parts[i])
	}
	return parts
}

func webSubtitleRawASSStream(playback map[string]any, mediaSourceID string, streamIndex int) (map[string]any, string, error) {
	sources := asItems(map[string]any{"Items": playback["MediaSources"]})
	for _, source := range sources {
		if webString(source["Id"]) != mediaSourceID {
			continue
		}
		streams, _ := source["MediaStreams"].([]any)
		for _, raw := range streams {
			stream, ok := raw.(map[string]any)
			if !ok || webString(stream["Type"]) != "Subtitle" || webInt(stream["Index"]) != streamIndex {
				continue
			}
			if !webIsASSSubtitleStream(stream) {
				return nil, "", fmt.Errorf("%w: codec %q is not ASS/SSA", errWebSubtitleUnsupportedFormat, webSubtitleCodec(stream))
			}
			return stream, webString(stream["DeliveryUrl"]), nil
		}
	}
	return nil, "", fmt.Errorf("subtitle stream not found")
}

func webIsASSSubtitleStream(stream map[string]any) bool {
	switch strings.ToLower(strings.TrimSpace(webSubtitleCodec(stream))) {
	case "ass", "ssa":
		return true
	case "":
		parsed, err := url.Parse(webString(stream["DeliveryUrl"]))
		if err != nil {
			return false
		}
		ext := strings.ToLower(parsed.Path)
		return strings.HasSuffix(ext, ".ass") || strings.HasSuffix(ext, ".ssa")
	default:
		return false
	}
}
