package backend

import (
	"bytes"
	"encoding/base64"
	"encoding/binary"
	"fmt"
	"image"
	"image/color"
	"image/draw"
	"image/png"
	"net/http"
	"net/url"
	"path"
	"strings"
)

type webBitmapFrame struct {
	StartMs  int64  `json:"startMs"`
	EndMs    int64  `json:"endMs"`
	X        int    `json:"x"`
	Y        int    `json:"y"`
	Width    int    `json:"width"`
	Height   int    `json:"height"`
	AssetURL string `json:"assetUrl"`
}

type webBitmapSubtitlePayload struct {
	Renderer      string           `json:"renderer"`
	Profile       string           `json:"profile"`
	AssetStrategy string           `json:"assetStrategy"`
	Frames        []webBitmapFrame `json:"frames"`
	Profiles      map[string]bool  `json:"profiles"`
}

type webBitmapDisplayObject struct {
	ObjectID   uint16
	X          int
	Y          int
	Cropped    bool
	CropX      int
	CropY      int
	CropWidth  int
	CropHeight int
}

type webBitmapDisplaySet struct {
	StartMs          int64
	PaletteID        byte
	CompositionState byte
	Objects          []webBitmapDisplayObject
}

type webBitmapRenderedSet struct {
	StartMs int64
	Frames  []webBitmapFrame
}

type webBitmapObjectData struct {
	Width  int
	Height int
	Data   []byte
}

type webBitmapObjectAssembly struct {
	Width       int
	Height      int
	ExpectedLen int
	Data        []byte
}

type webBitmapPalette map[byte]color.NRGBA

func (a *App) handleWebSubtitleBitmap(w http.ResponseWriter, r *http.Request) {
	ref, err := a.resolveWebSubtitleTrack(r, r.PathValue("trackId"))
	if err != nil {
		if a.Logger != nil {
			a.Logger.Warnf("Web subtitle bitmap failed: trackId=%s err=%v", r.PathValue("trackId"), err)
		}
		writeWebSubtitleResolveError(w, err)
		return
	}
	if err := requireWebSubtitleRenderer(*ref, "bitmap"); err != nil {
		writeWebSubtitleLoadError(w, "bitmap", err)
		return
	}
	profile := webSubtitleProfileFromRequest(r)
	if a.Logger != nil {
		a.Logger.Debugf("Web subtitle bitmap request: itemId=%s mediaSourceId=%s streamIndex=%d profile=%s", ref.ItemID, ref.MediaSourceID, ref.StreamIndex, profile)
	}
	payload, err := a.webLoadBitmapPayload(r, *ref, profile)
	if err != nil {
		if a.Logger != nil {
			a.Logger.Warnf("Web subtitle bitmap load failed: itemId=%s mediaSourceId=%s streamIndex=%d err=%v", ref.ItemID, ref.MediaSourceID, ref.StreamIndex, err)
		}
		writeWebSubtitleLoadError(w, "bitmap", err)
		return
	}
	if a.Logger != nil {
		a.Logger.Infof("Web subtitle bitmap response: itemId=%s mediaSourceId=%s streamIndex=%d profile=%s frames=%d strategy=%s",
			ref.ItemID, ref.MediaSourceID, ref.StreamIndex, payload.Profile, len(payload.Frames), payload.AssetStrategy)
	}
	writeJSON(w, http.StatusOK, payload)
}

func (a *App) webLoadBitmapPayload(r *http.Request, ref webSubtitleRef, profile string) (webBitmapSubtitlePayload, error) {
	cacheKey := webSubtitleCacheKey(ref, profile)
	if cached, ok := a.webSubtitleCache.Get(cacheKey, a.webSubtitleCacheTTL); ok {
		if payload, ok := cached.(webBitmapSubtitlePayload); ok {
			return payload, nil
		}
	}

	reqCtx := requestContextFrom(r.Context())
	resolved, rawMediaSourceID, err := a.resolveWebSubtitleTextTarget(r, ref)
	if err != nil {
		return webBitmapSubtitlePayload{}, err
	}
	query := url.Values{}
	if rawMediaSourceID != "" {
		query.Set("MediaSourceId", rawMediaSourceID)
	}
	query.Set("SubtitleStreamIndex", fmt.Sprintf("%d", ref.StreamIndex))
	playbackValue, err := resolved.Client.RequestJSON(r.Context(), reqCtx, a.Identity, http.MethodGet, "/Items/"+resolved.OriginalID+"/PlaybackInfo", query, nil)
	if err != nil {
		return webBitmapSubtitlePayload{}, err
	}
	playback, ok := playbackValue.(map[string]any)
	if !ok {
		return webBitmapSubtitlePayload{}, fmt.Errorf("unexpected playback info payload")
	}
	_, deliveryURL, err := webSubtitleRawBitmapStream(playback, rawMediaSourceID, ref.StreamIndex)
	if err != nil {
		return webBitmapSubtitlePayload{}, err
	}
	if deliveryURL == "" {
		deliveryURL = fmt.Sprintf("/Videos/%s/%s/Subtitles/%d/Stream.sup", resolved.OriginalID, rawMediaSourceID, ref.StreamIndex)
	}
	body, err := webLoadSubtitleBody(r.Context(), reqCtx, resolved.Client, a.Identity, deliveryURL)
	if err != nil {
		return webBitmapSubtitlePayload{}, err
	}

	payload, err := webBuildBitmapSubtitlePayload(profile, body)
	if err != nil {
		return webBitmapSubtitlePayload{}, err
	}
	a.webSubtitleCache.Set(cacheKey, payload)
	return payload, nil
}

func webSubtitleRawBitmapStream(playback map[string]any, mediaSourceID string, streamIndex int) (map[string]any, string, error) {
	sources := asItems(map[string]any{"Items": playback["MediaSources"]})
	for _, source := range sources {
		if webString(source["Id"]) != mediaSourceID {
			continue
		}
		streams, _ := source["MediaStreams"].([]any)
		for _, raw := range streams {
			stream, ok := raw.(map[string]any)
			if !ok || webString(stream["Type"]) != "Subtitle" || webInt(stream["Index"]) != streamIndex {
				continue
			}
			if !webIsPGSSubtitleStream(stream) {
				return nil, "", fmt.Errorf("%w: codec %q is not a supported PGS subtitle", errWebSubtitleUnsupportedFormat, webSubtitleCodec(stream))
			}
			return stream, webString(stream["DeliveryUrl"]), nil
		}
	}
	return nil, "", fmt.Errorf("subtitle stream not found")
}

func webIsPGSSubtitleStream(stream map[string]any) bool {
	switch strings.ToLower(strings.TrimSpace(webSubtitleCodec(stream))) {
	case "pgs", "sup", "hdmv_pgs_subtitle", "pgs_subtitle":
		return true
	case "":
		parsed, err := url.Parse(webString(stream["DeliveryUrl"]))
		if err != nil {
			return false
		}
		ext := strings.ToLower(path.Ext(parsed.Path))
		return ext == ".sup" || ext == ".pgs"
	default:
		return false
	}
}

func webBuildBitmapSubtitlePayload(profile string, body []byte) (webBitmapSubtitlePayload, error) {
	fullFrames, err := webParsePGSBitmapFrames(body)
	if err != nil {
		return webBitmapSubtitlePayload{}, err
	}
	if len(fullFrames) == 0 {
		return webBitmapSubtitlePayload{}, fmt.Errorf("bitmap subtitle stream did not yield any frames")
	}

	payload := webBitmapSubtitlePayload{
		Renderer: "bitmap",
		Profile:  profile,
		Profiles: map[string]bool{
			"full": true,
			"lite": true,
		},
	}
	if profile == "lite" {
		payload.AssetStrategy = "merged"
		payload.Frames = webMergeBitmapFrames(fullFrames)
		return payload, nil
	}
	payload.AssetStrategy = "timeline"
	payload.Frames = fullFrames
	return payload, nil
}

func webParsePGSBitmapFrames(body []byte) ([]webBitmapFrame, error) {
	renderedSets := make([]webBitmapRenderedSet, 0)
	objects := make(map[uint16]webBitmapObjectData)
	assemblies := make(map[uint16]webBitmapObjectAssembly)
	palettes := make(map[byte]webBitmapPalette)
	var current *webBitmapDisplaySet
	finishCurrent := func() error {
		if current == nil {
			return nil
		}
		rendered := webBitmapRenderedSet{StartMs: current.StartMs}
		if len(current.Objects) > 0 {
			palette := webBitmapPaletteForID(palettes, current.PaletteID)
			if len(palette) == 0 {
				return fmt.Errorf("bitmap subtitle stream missing palette")
			}
			rendered.Frames = make([]webBitmapFrame, 0, len(current.Objects))
			for _, displayObject := range current.Objects {
				object, ok := objects[displayObject.ObjectID]
				if !ok || object.Width <= 0 || object.Height <= 0 {
					return fmt.Errorf("bitmap subtitle stream missing object %d", displayObject.ObjectID)
				}
				assetURL, width, height, err := webBitmapPNGDataURLForDisplay(object, palette, displayObject)
				if err != nil {
					return err
				}
				rendered.Frames = append(rendered.Frames, webBitmapFrame{
					StartMs:  current.StartMs,
					X:        displayObject.X,
					Y:        displayObject.Y,
					Width:    width,
					Height:   height,
					AssetURL: assetURL,
				})
			}
		}
		renderedSets = append(renderedSets, rendered)
		current = nil
		return nil
	}

	offset := 0
	for offset+13 <= len(body) {
		if body[offset] != 'P' || body[offset+1] != 'G' {
			return nil, fmt.Errorf("%w: expected PGS segment header", errWebSubtitleUnsupportedFormat)
		}
		pts90k := binary.BigEndian.Uint32(body[offset+2 : offset+6])
		segmentType := body[offset+10]
		payloadLen := int(binary.BigEndian.Uint16(body[offset+11 : offset+13]))
		offset += 13
		if offset+payloadLen > len(body) {
			return nil, fmt.Errorf("truncated bitmap subtitle stream")
		}
		payload := body[offset : offset+payloadLen]
		offset += payloadLen

		switch segmentType {
		case 0x14:
			paletteID, palette, ok := webParsePGSPaletteSegment(payload)
			if !ok {
				return nil, fmt.Errorf("invalid bitmap palette segment")
			}
			palettes[paletteID] = webMergeBitmapPalette(palettes[paletteID], palette)
		case 0x16:
			if err := finishCurrent(); err != nil {
				return nil, err
			}
			displaySet, ok := webParsePGSDisplaySet(pts90k, payload)
			if !ok {
				return nil, fmt.Errorf("invalid bitmap composition segment")
			}
			if displaySet.CompositionState&0x80 != 0 {
				objects = make(map[uint16]webBitmapObjectData)
				assemblies = make(map[uint16]webBitmapObjectAssembly)
				palettes = make(map[byte]webBitmapPalette)
			}
			current = &displaySet
		case 0x15:
			objectID, objectData, nextAssembly, complete, ok := webParsePGSObjectSegment(payload, assemblies)
			if !ok {
				return nil, fmt.Errorf("invalid bitmap object segment")
			}
			if nextAssembly == nil {
				delete(assemblies, objectID)
			} else {
				assemblies[objectID] = *nextAssembly
			}
			if complete != nil {
				objects[objectID] = *complete
			} else if objectData != nil {
				objects[objectID] = *objectData
			}
		case 0x80:
			if err := finishCurrent(); err != nil {
				return nil, err
			}
		}
	}
	if offset != len(body) {
		return nil, fmt.Errorf("truncated bitmap subtitle stream")
	}
	if err := finishCurrent(); err != nil {
		return nil, err
	}
	if len(renderedSets) == 0 {
		return nil, fmt.Errorf("bitmap subtitle stream did not contain any display sets")
	}

	frames := make([]webBitmapFrame, 0)
	for i, set := range renderedSets {
		endMs := set.StartMs + 2000
		if i+1 < len(renderedSets) {
			endMs = renderedSets[i+1].StartMs
		}
		if endMs <= set.StartMs {
			endMs = set.StartMs + 1
		}
		for _, frame := range set.Frames {
			frame.EndMs = endMs
			frames = append(frames, frame)
		}
	}
	if len(frames) == 0 {
		return nil, fmt.Errorf("bitmap subtitle stream did not yield any renderable objects")
	}
	return frames, nil
}

func webMergeBitmapPalette(previous, update webBitmapPalette) webBitmapPalette {
	merged := make(webBitmapPalette, len(previous)+len(update))
	for index, rgba := range previous {
		merged[index] = rgba
	}
	for index, rgba := range update {
		merged[index] = rgba
	}
	return merged
}

func webParsePGSDisplaySet(pts90k uint32, payload []byte) (webBitmapDisplaySet, bool) {
	if len(payload) < 11 {
		return webBitmapDisplaySet{}, false
	}
	paletteID := payload[9]
	objectCount := int(payload[10])
	offset := 11
	objects := make([]webBitmapDisplayObject, 0, objectCount)
	for i := 0; i < objectCount; i++ {
		if offset+8 > len(payload) {
			return webBitmapDisplaySet{}, false
		}
		objectID := binary.BigEndian.Uint16(payload[offset : offset+2])
		compositionFlags := payload[offset+3]
		x := int(binary.BigEndian.Uint16(payload[offset+4 : offset+6]))
		y := int(binary.BigEndian.Uint16(payload[offset+6 : offset+8]))
		offset += 8
		object := webBitmapDisplayObject{
			ObjectID: objectID,
			X:        x,
			Y:        y,
		}
		if compositionFlags&0x80 != 0 {
			if offset+8 > len(payload) {
				return webBitmapDisplaySet{}, false
			}
			object.Cropped = true
			object.CropX = int(binary.BigEndian.Uint16(payload[offset : offset+2]))
			object.CropY = int(binary.BigEndian.Uint16(payload[offset+2 : offset+4]))
			object.CropWidth = int(binary.BigEndian.Uint16(payload[offset+4 : offset+6]))
			object.CropHeight = int(binary.BigEndian.Uint16(payload[offset+6 : offset+8]))
			offset += 8
		}
		objects = append(objects, object)
	}
	return webBitmapDisplaySet{
		StartMs:          int64(pts90k / 90),
		PaletteID:        paletteID,
		CompositionState: payload[7],
		Objects:          objects,
	}, true
}

func webParsePGSPaletteSegment(payload []byte) (byte, webBitmapPalette, bool) {
	if len(payload) < 2 || (len(payload)-2)%5 != 0 {
		return 0, nil, false
	}
	palette := make(webBitmapPalette)
	for offset := 2; offset+5 <= len(payload); offset += 5 {
		index := payload[offset]
		y := payload[offset+1]
		cr := payload[offset+2]
		cb := payload[offset+3]
		alpha := payload[offset+4]
		palette[index] = webBitmapYCbCrToNRGBA(y, cb, cr, alpha)
	}
	return payload[0], palette, true
}

func webParsePGSObjectSegment(payload []byte, assemblies map[uint16]webBitmapObjectAssembly) (uint16, *webBitmapObjectData, *webBitmapObjectAssembly, *webBitmapObjectData, bool) {
	if len(payload) < 4 {
		return 0, nil, nil, nil, false
	}
	objectID := binary.BigEndian.Uint16(payload[0:2])
	sequenceFlags := payload[3]
	first := sequenceFlags&0x80 != 0
	last := sequenceFlags&0x40 != 0

	var assembly webBitmapObjectAssembly
	var ok bool
	var dataOffset int

	if first {
		if len(payload) < 11 {
			return 0, nil, nil, nil, false
		}
		objectDataLength := int(payload[4])<<16 | int(payload[5])<<8 | int(payload[6])
		assembly = webBitmapObjectAssembly{
			Width:       int(binary.BigEndian.Uint16(payload[7:9])),
			Height:      int(binary.BigEndian.Uint16(payload[9:11])),
			ExpectedLen: webMaxInt(objectDataLength-4, 0),
			Data:        make([]byte, 0, webMaxInt(objectDataLength-4, 0)),
		}
		dataOffset = 11
	} else {
		assembly, ok = assemblies[objectID]
		if !ok {
			return 0, nil, nil, nil, false
		}
		dataOffset = 4
	}

	assembly.Data = append(assembly.Data, payload[dataOffset:]...)
	if assembly.ExpectedLen > 0 && len(assembly.Data) > assembly.ExpectedLen {
		return 0, nil, nil, nil, false
	}
	if !last {
		return objectID, nil, &assembly, nil, true
	}

	if assembly.ExpectedLen > 0 && len(assembly.Data) != assembly.ExpectedLen {
		return 0, nil, nil, nil, false
	}
	objectData := &webBitmapObjectData{
		Width:  assembly.Width,
		Height: assembly.Height,
		Data:   append([]byte(nil), assembly.Data...),
	}
	return objectID, objectData, nil, objectData, true
}

func webBitmapPaletteForID(palettes map[byte]webBitmapPalette, paletteID byte) webBitmapPalette {
	if palette, ok := palettes[paletteID]; ok {
		return palette
	}
	if len(palettes) == 1 {
		for _, palette := range palettes {
			return palette
		}
	}
	return nil
}

func webBitmapPNGDataURL(object webBitmapObjectData, palette webBitmapPalette) (string, error) {
	img, err := webDecodePGSBitmapImage(object, palette)
	if err != nil {
		return "", err
	}
	return webBitmapImageDataURL(img)
}

func webBitmapPNGDataURLForDisplay(object webBitmapObjectData, palette webBitmapPalette, display webBitmapDisplayObject) (string, int, int, error) {
	img, err := webDecodePGSBitmapImage(object, palette)
	if err != nil {
		return "", 0, 0, err
	}
	width, height := object.Width, object.Height
	if display.Cropped {
		if display.CropWidth <= 0 || display.CropHeight <= 0 || display.CropX < 0 || display.CropY < 0 || display.CropX+display.CropWidth > object.Width || display.CropY+display.CropHeight > object.Height {
			return "", 0, 0, fmt.Errorf("invalid bitmap crop rectangle")
		}
		cropped := image.NewNRGBA(image.Rect(0, 0, display.CropWidth, display.CropHeight))
		draw.Draw(cropped, cropped.Bounds(), img, image.Point{X: display.CropX, Y: display.CropY}, draw.Src)
		img = cropped
		width, height = display.CropWidth, display.CropHeight
	}
	assetURL, err := webBitmapImageDataURL(img)
	return assetURL, width, height, err
}

func webBitmapImageDataURL(img image.Image) (string, error) {
	var buf bytes.Buffer
	if err := png.Encode(&buf, img); err != nil {
		return "", err
	}
	return "data:image/png;base64," + base64.StdEncoding.EncodeToString(buf.Bytes()), nil
}

func webDecodePGSBitmapImage(object webBitmapObjectData, palette webBitmapPalette) (*image.NRGBA, error) {
	pixelIndexes, err := webDecodePGSPixelIndexes(object.Data, object.Width, object.Height)
	if err != nil {
		return nil, err
	}
	img := image.NewNRGBA(image.Rect(0, 0, object.Width, object.Height))
	for y := 0; y < object.Height; y++ {
		for x := 0; x < object.Width; x++ {
			index := pixelIndexes[y*object.Width+x]
			if rgba, ok := palette[index]; ok {
				img.SetNRGBA(x, y, rgba)
				continue
			}
			img.SetNRGBA(x, y, color.NRGBA{})
		}
	}
	return img, nil
}

func webDecodePGSPixelIndexes(data []byte, width, height int) ([]byte, error) {
	if width <= 0 || height <= 0 {
		return nil, fmt.Errorf("invalid bitmap dimensions")
	}
	pixels := make([]byte, width*height)
	x, y := 0, 0

	for offset := 0; offset < len(data) && y < height; {
		paletteIndex := data[offset]
		offset++
		runLength := 1
		if paletteIndex == 0 {
			if offset >= len(data) {
				return nil, fmt.Errorf("truncated bitmap run")
			}
			flags := data[offset]
			offset++
			runLength = int(flags & 0x3f)
			if flags&0x40 != 0 {
				if offset >= len(data) {
					return nil, fmt.Errorf("truncated bitmap run length")
				}
				runLength = (runLength << 8) | int(data[offset])
				offset++
			}
			if flags&0x80 != 0 {
				if offset >= len(data) {
					return nil, fmt.Errorf("truncated bitmap palette index")
				}
				paletteIndex = data[offset]
				offset++
			}
		}
		if runLength == 0 {
			x = 0
			y++
			continue
		}
		if x+runLength > width {
			return nil, fmt.Errorf("bitmap run exceeds row width")
		}
		rowOffset := y * width
		for i := 0; i < runLength; i++ {
			pixels[rowOffset+x+i] = paletteIndex
		}
		x += runLength
	}

	if y < height-1 || (y == height-1 && x < width) {
		return nil, fmt.Errorf("bitmap pixel data truncated")
	}
	return pixels, nil
}

func webBitmapYCbCrToNRGBA(y, cb, cr, alpha byte) color.NRGBA {
	yy := int(y) - 16
	if yy < 0 {
		yy = 0
	}
	cbDiff := int(cb) - 128
	crDiff := int(cr) - 128
	r := webBitmapClamp8((298*yy + 409*crDiff + 128) >> 8)
	g := webBitmapClamp8((298*yy - 100*cbDiff - 208*crDiff + 128) >> 8)
	b := webBitmapClamp8((298*yy + 516*cbDiff + 128) >> 8)
	return color.NRGBA{R: r, G: g, B: b, A: alpha}
}

func webBitmapClamp8(value int) uint8 {
	switch {
	case value < 0:
		return 0
	case value > 255:
		return 255
	default:
		return uint8(value)
	}
}

func webMergeBitmapFrames(frames []webBitmapFrame) []webBitmapFrame {
	if len(frames) == 0 {
		return nil
	}
	merged := make([]webBitmapFrame, 0, len(frames))
	for _, frame := range frames {
		if len(merged) == 0 {
			merged = append(merged, frame)
			continue
		}
		last := &merged[len(merged)-1]
		if last.AssetURL == frame.AssetURL && last.X == frame.X && last.Y == frame.Y && last.Width == frame.Width && last.Height == frame.Height {
			if frame.EndMs > last.EndMs {
				last.EndMs = frame.EndMs
			}
			continue
		}
		merged = append(merged, frame)
	}
	return merged
}

func webMaxInt(a, b int) int {
	if a > b {
		return a
	}
	return b
}
