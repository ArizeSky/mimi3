package backend

import (
	"fmt"
	"net/http"
	"net/url"
	"strconv"
	"strings"
)

type webSubtitleModeRequest struct {
	Mode string `json:"mode"`
}

type webFallbackStreamRequest struct {
	Reason           string `json:"reason"`
	SessionID        string `json:"sessionId"`
	AudioStreamIndex *int   `json:"audioStreamIndex,omitempty"`
}

var webSubtitleModeWhitelist = map[string]struct{}{
	"text-full":   {},
	"ass-full":    {},
	"ass-lite":    {},
	"bitmap-full": {},
	"bitmap-lite": {},
	"burnin":      {},
}

var webSubtitleFallbackReasonWhitelist = map[string]struct{}{
	"text-cue-load-failed":                      {},
	"text-cue-parse-failed":                     {},
	"ios-native-webvtt-load-failed":             {},
	"ios-native-track-error":                    {},
	"ios-native-fullscreen-overlay-unavailable": {},
	"pip-airplay-overlay-unavailable":           {},
	"renderer-disposed-before-ready":            {},
	"unknown-subtitle-render-failure":           {},
}

func normalizeFallbackReason(raw string) string {
	reason := strings.ToLower(strings.TrimSpace(raw))
	if _, ok := webSubtitleFallbackReasonWhitelist[reason]; ok {
		return reason
	}
	return "unknown-subtitle-render-failure"
}

func (a *App) handleWebSubtitleFallbackStream(w http.ResponseWriter, r *http.Request) {
	ref, err := a.resolveWebSubtitleTrack(r, r.PathValue("trackId"))
	if err != nil {
		writeWebSubtitleResolveError(w, err)
		return
	}

	var body webFallbackStreamRequest
	decodeJSONBody(r, &body) // ignore error — reason is optional

	selection := webSubtitleSelectionForRef(r, *ref)
	if body.AudioStreamIndex != nil {
		if *body.AudioStreamIndex < 0 {
			writeJSON(w, http.StatusBadRequest, map[string]any{"message": "Invalid audio stream index"})
			return
		}
		selection.AudioStreamIndex = *body.AudioStreamIndex
	}
	reason := normalizeFallbackReason(body.Reason)
	requestedSessionID := firstNonEmpty(
		strings.TrimSpace(body.SessionID),
		strings.TrimSpace(r.URL.Query().Get("sessionId")),
		strings.TrimSpace(r.URL.Query().Get("PlaySessionId")),
	)
	sessionID := ""
	sessionReused := a.webSubtitleSessionMatchesRef(requestedSessionID, *ref)
	var source map[string]any
	if sessionReused {
		sessionID = requestedSessionID
		source = map[string]any{
			"kind":     "hls",
			"url":      webBurninCompatibilityURL(ref.ItemID, selection, sessionID),
			"strategy": "existing-session-compat",
		}
	} else {
		playback, loadErr := a.webLoadPlaybackInfoForSelection(r, ref.ItemID, selection)
		if loadErr != nil {
			writeWebSubtitleResolveError(w, loadErr)
			return
		}
		if !webPlaybackContainsSubtitleRef(playback, *ref) {
			writeWebSubtitleResolveError(w, newWebSubtitleResolveError(http.StatusNotFound, "subtitle track not found", nil))
			return
		}
		sessionID = webString(playback["PlaySessionId"])
		if sessionID == "" {
			writeJSON(w, http.StatusBadGateway, map[string]any{"message": "Playback session unavailable"})
			return
		}
		if err := a.webMigrateSubtitleFallbackSession(r, requestedSessionID, sessionID, *ref); err != nil {
			writeJSON(w, http.StatusTooManyRequests, map[string]any{"message": "Unable to migrate playback session"})
			return
		}
		source = a.webBurninSourceFromPlayback(r, ref.ItemID, selection, playback)
	}
	if rawURL := webString(source["url"]); rawURL != "" {
		source["url"] = webEnsureBurninURL(rawURL, selection, sessionID)
	}

	playPath := webPlayPath(ref.ItemID, selection)
	if strings.Contains(playPath, "?") {
		playPath += "&subtitleMode=burnin"
	} else {
		playPath += "?subtitleMode=burnin"
	}

	if a.Logger != nil {
		a.Logger.Infof("Web subtitle fallback: itemId=%s trackId=%s mediaSourceId=%s streamIndex=%d mode=burnin sourceKind=%s strategy=%s sessionReused=%t playPath=%s reason=%s",
			ref.ItemID,
			r.PathValue("trackId"),
			ref.MediaSourceID,
			ref.StreamIndex,
			webString(source["kind"]),
			webString(source["strategy"]),
			sessionReused,
			playPath,
			reason,
		)
	}
	writeJSON(w, http.StatusOK, map[string]any{
		"mode":          "burnin",
		"source":        source,
		"playPath":      playPath,
		"sessionId":     sessionID,
		"mediaSourceId": ref.MediaSourceID,
		"sessionReused": sessionReused,
	})
}

func (a *App) webSubtitleSessionMatchesRef(sessionID string, ref webSubtitleRef) bool {
	if a == nil || a.IDStore == nil || sessionID == "" {
		return false
	}
	session := a.IDStore.ResolveVirtualID(sessionID)
	mediaSource := a.IDStore.ResolveVirtualID(ref.MediaSourceID)
	item := a.IDStore.ResolveVirtualID(ref.ItemID)
	if session == nil || mediaSource == nil || item == nil || session.ServerIndex != mediaSource.ServerIndex {
		return false
	}
	_, itemMatchesServer := translateVirtualIDForServer(ref.ItemID, session.ServerIndex, a.IDStore)
	return itemMatchesServer
}

func webPlaybackContainsSubtitleRef(playback map[string]any, ref webSubtitleRef) bool {
	for _, source := range asItems(map[string]any{"Items": playback["MediaSources"]}) {
		if webString(source["Id"]) != ref.MediaSourceID {
			continue
		}
		streams, _ := source["MediaStreams"].([]any)
		for _, raw := range streams {
			stream, ok := raw.(map[string]any)
			if !ok || webString(stream["Type"]) != "Subtitle" || webInt(stream["Index"]) != ref.StreamIndex {
				continue
			}
			switch ref.RendererKind {
			case "burnin":
				return true
			case "ass":
				return webIsASSSubtitleStream(stream)
			case "bitmap":
				return webIsPGSSubtitleStream(stream)
			case "text":
				return webSubtitleRendererKind(stream) == "text"
			}
			return false
		}
	}
	return false
}

func (a *App) webMigrateSubtitleFallbackSession(r *http.Request, oldSessionID, newSessionID string, ref webSubtitleRef) error {
	if a == nil || a.PlaybackLimiter == nil || a.IDStore == nil || a.ConfigStore == nil || newSessionID == "" || oldSessionID == newSessionID {
		return nil
	}
	reqCtx := requestContextFrom(r.Context())
	if reqCtx == nil || reqCtx.ProxyUser == nil || reqCtx.ProxyUser.Role == "admin" {
		return nil
	}
	newSession := a.IDStore.ResolveVirtualID(newSessionID)
	if newSession == nil {
		return fmt.Errorf("new playback session is not mapped")
	}
	newItemID, itemOK := translateVirtualIDForServer(ref.ItemID, newSession.ServerIndex, a.IDStore)
	newMediaSourceID, mediaOK := translateVirtualIDForServer(ref.MediaSourceID, newSession.ServerIndex, a.IDStore)
	if !itemOK || !mediaOK {
		return fmt.Errorf("new playback session does not match subtitle source")
	}
	cfg := a.ConfigStore.Snapshot()
	maxConcurrent := 0
	if newSession.ServerIndex >= 0 && newSession.ServerIndex < len(cfg.Upstream) {
		maxConcurrent = cfg.Upstream[newSession.ServerIndex].MaxConcurrent
	}
	newPlaybackID := playbackRegistrationID(reqCtx.ProxyUser.UserID, newSession.OriginalID, newItemID, newMediaSourceID)
	if oldSessionID == "" {
		if a.PlaybackLimiter.TryStart(reqCtx.ProxyUser.UserID, newSession.ServerIndex, newPlaybackID, maxConcurrent) {
			return nil
		}
		return fmt.Errorf("playback session registration rejected")
	}

	oldSession := a.IDStore.ResolveVirtualID(oldSessionID)
	if oldSession == nil {
		if a.PlaybackLimiter.TryStart(reqCtx.ProxyUser.UserID, newSession.ServerIndex, newPlaybackID, maxConcurrent) {
			return nil
		}
		return fmt.Errorf("playback session registration rejected")
	}
	oldItemID, oldItemOK := translateVirtualIDForServer(ref.ItemID, oldSession.ServerIndex, a.IDStore)
	oldMediaSourceID, oldMediaOK := translateVirtualIDForServer(ref.MediaSourceID, oldSession.ServerIndex, a.IDStore)
	if !oldItemOK || !oldMediaOK {
		if a.PlaybackLimiter.TryStart(reqCtx.ProxyUser.UserID, newSession.ServerIndex, newPlaybackID, maxConcurrent) {
			return nil
		}
		return fmt.Errorf("playback session migration rejected")
	}
	oldPlaybackID := playbackRegistrationID(reqCtx.ProxyUser.UserID, oldSession.OriginalID, oldItemID, oldMediaSourceID)
	if oldPlaybackID == newPlaybackID {
		return nil
	}
	a.PlaybackLimiter.StopByPlaybackID(oldPlaybackID)
	if a.PlaybackLimiter.TryStart(reqCtx.ProxyUser.UserID, newSession.ServerIndex, newPlaybackID, maxConcurrent) {
		return nil
	}
	oldMaxConcurrent := 0
	if oldSession.ServerIndex >= 0 && oldSession.ServerIndex < len(cfg.Upstream) {
		oldMaxConcurrent = cfg.Upstream[oldSession.ServerIndex].MaxConcurrent
	}
	_ = a.PlaybackLimiter.TryStart(reqCtx.ProxyUser.UserID, oldSession.ServerIndex, oldPlaybackID, oldMaxConcurrent)
	return fmt.Errorf("playback session migration rejected")
}

func (a *App) handleWebSessionSubtitleMode(w http.ResponseWriter, r *http.Request) {
	var body webSubtitleModeRequest
	if err := decodeJSONBody(r, &body); err != nil {
		writeJSON(w, http.StatusBadRequest, map[string]any{"message": "Invalid request body"})
		return
	}
	mode := strings.ToLower(strings.TrimSpace(body.Mode))
	if _, ok := webSubtitleModeWhitelist[mode]; !ok {
		writeJSON(w, http.StatusBadRequest, map[string]any{"message": "Unsupported subtitle mode"})
		return
	}
	if a.Logger != nil {
		a.Logger.Debugf("Web subtitle mode: sessionId=%s mode=%s", r.PathValue("sessionId"), mode)
	}
	writeJSON(w, http.StatusOK, map[string]any{
		"sessionId": r.PathValue("sessionId"),
		"mode":      mode,
		"accepted":  true,
	})
}

func (a *App) webBurninSourceFromPlayback(r *http.Request, itemID string, selection webSelection, playback map[string]any) map[string]any {
	selectedRequest := r.Clone(r.Context())
	query := selectedRequest.URL.Query()
	query.Set("mediaSourceId", selection.MediaSourceID)
	selectedRequest.URL.RawQuery = query.Encode()
	source := a.webPreferredSource(selectedRequest, playback)
	if webString(source["kind"]) == "hls" && webString(source["url"]) != "" {
		source["strategy"] = "upstream-transcode"
		return source
	}
	return map[string]any{
		"kind":     "hls",
		"url":      webBurninCompatibilityURL(itemID, selection, webString(playback["PlaySessionId"])),
		"strategy": "local-compat",
	}
}

func webEnsureBurninURL(rawURL string, selection webSelection, playSessionID string) string {
	parsed, err := url.Parse(rawURL)
	if err != nil {
		return rawURL
	}
	query := parsed.Query()
	setWebSubtitleQueryValue(query, "MediaSourceId", selection.MediaSourceID)
	if selection.AudioStreamIndex >= 0 {
		setWebSubtitleQueryValue(query, "AudioStreamIndex", strconv.Itoa(selection.AudioStreamIndex))
	}
	setWebSubtitleQueryValue(query, "SubtitleStreamIndex", strconv.Itoa(selection.SubtitleStreamIndex))
	setWebSubtitleQueryValue(query, "SubtitleMethod", "Encode")
	if playSessionID != "" {
		setWebSubtitleQueryValue(query, "PlaySessionId", playSessionID)
	}
	parsed.RawQuery = query.Encode()
	return parsed.String()
}

func setWebSubtitleQueryValue(query url.Values, canonicalKey, value string) {
	for key := range query {
		if strings.EqualFold(key, canonicalKey) {
			query.Del(key)
		}
	}
	if value != "" {
		query.Set(canonicalKey, value)
	}
}

func webBurninCompatibilityURL(itemID string, selection webSelection, playSessionID string) string {
	query := url.Values{}
	if selection.MediaSourceID != "" {
		query.Set("MediaSourceId", selection.MediaSourceID)
	}
	if selection.AudioStreamIndex >= 0 {
		query.Set("AudioStreamIndex", strconv.Itoa(selection.AudioStreamIndex))
	}
	if selection.SubtitleStreamIndex >= 0 {
		query.Set("SubtitleStreamIndex", strconv.Itoa(selection.SubtitleStreamIndex))
	}
	if playSessionID != "" {
		query.Set("PlaySessionId", playSessionID)
	}
	query.Set("SubtitleMethod", "Encode")
	return "/Videos/" + itemID + "/master.m3u8?" + query.Encode()
}
