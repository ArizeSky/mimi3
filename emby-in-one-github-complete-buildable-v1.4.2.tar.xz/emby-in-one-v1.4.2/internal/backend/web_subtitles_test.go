package backend

import (
	"bytes"
	"context"
	"encoding/base64"
	"encoding/binary"
	"encoding/json"
	"errors"
	"image"
	"image/png"
	"net/http"
	"net/http/httptest"
	"strings"
	"sync/atomic"
	"testing"
	"time"
	"unicode/utf16"

	"golang.org/x/text/encoding/simplifiedchinese"
	"golang.org/x/text/encoding/traditionalchinese"
	"golang.org/x/text/transform"
)

func TestWebParseTextSubtitlePayloadDecodesCommonEncodings(t *testing.T) {
	utf8SRT := "1\n00:00:01,000 --> 00:00:02,000\n这是中文字幕\n"
	traditionalSRT := "1\n00:00:01,000 --> 00:00:02,000\n這是中文字幕\n"
	gb18030, _, err := transform.Bytes(simplifiedchinese.GB18030.NewEncoder(), []byte(utf8SRT))
	if err != nil {
		t.Fatalf("encode GB18030 fixture: %v", err)
	}
	big5, _, err := transform.Bytes(traditionalchinese.Big5.NewEncoder(), []byte(traditionalSRT))
	if err != nil {
		t.Fatalf("encode Big5 fixture: %v", err)
	}

	cases := []struct {
		name     string
		body     []byte
		wantLine string
	}{
		{name: "utf8", body: []byte(utf8SRT), wantLine: "这是中文字幕"},
		{name: "utf16le-bom", body: encodeTestUTF16Subtitle(utf8SRT, binary.LittleEndian), wantLine: "这是中文字幕"},
		{name: "utf16be-bom", body: encodeTestUTF16Subtitle(utf8SRT, binary.BigEndian), wantLine: "这是中文字幕"},
		{name: "gb18030", body: gb18030, wantLine: "这是中文字幕"},
		{name: "big5", body: big5, wantLine: "這是中文字幕"},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			payload, err := webParseTextSubtitlePayload(tc.body)
			if err != nil {
				t.Fatalf("parse subtitle: %v", err)
			}
			if len(payload.Cues) != 1 || len(payload.Cues[0].Lines) != 1 || payload.Cues[0].Lines[0] != tc.wantLine {
				t.Fatalf("unexpected decoded cues: %#v", payload.Cues)
			}
		})
	}
}

func TestWebParseTextSubtitlePayloadRejectsUnknownOrEmptyDocuments(t *testing.T) {
	for _, body := range [][]byte{
		[]byte("plain text without subtitle timing"),
		[]byte("WEBVTT\n\nNOTE metadata only\n\n"),
		[]byte("1\ninvalid --> timing\ntext\n"),
	} {
		if _, err := webParseTextSubtitlePayload(body); !errors.Is(err, errWebSubtitleUnsupportedFormat) {
			t.Fatalf("expected unsupported subtitle error for %q, got %v", body, err)
		}
	}
}

func encodeTestUTF16Subtitle(text string, order binary.ByteOrder) []byte {
	units := utf16.Encode([]rune(text))
	body := make([]byte, 2+len(units)*2)
	if order == binary.LittleEndian {
		body[0], body[1] = 0xff, 0xfe
	} else {
		body[0], body[1] = 0xfe, 0xff
	}
	for i, unit := range units {
		order.PutUint16(body[2+i*2:2+i*2+2], unit)
	}
	return body
}

func TestWebSubtitleRoutesRequireWebUser(t *testing.T) {
	withTempApp(t, func(app *App, handler http.Handler) {
		trackID := encodeWebSubtitleTrackID(webSubtitleRef{
			ItemID:        "item-a",
			MediaSourceID: "ms-a",
			StreamIndex:   2,
			RendererKind:  "text",
		})
		cases := []struct {
			name   string
			method string
			target string
		}{
			{name: "text", method: http.MethodGet, target: "/web/api/subtitles/" + trackID + "/text"},
			{name: "ass", method: http.MethodGet, target: "/web/api/subtitles/" + trackID + "/ass"},
			{name: "bitmap", method: http.MethodGet, target: "/web/api/subtitles/" + trackID + "/bitmap"},
			{name: "fallback-stream", method: http.MethodPost, target: "/web/api/items/item-a/subtitles/" + trackID + "/fallback-stream"},
			{name: "subtitle-mode", method: http.MethodPost, target: "/web/api/sessions/session-a/subtitle-mode"},
		}
		for _, tc := range cases {
			tc := tc
			t.Run(tc.name, func(t *testing.T) {
				req := httptest.NewRequest(tc.method, tc.target, nil)
				rr := httptest.NewRecorder()
				handler.ServeHTTP(rr, req)
				if rr.Code == http.StatusNotFound {
					t.Fatalf("expected web subtitle route %s to be registered, got 404", tc.target)
				}
				if rr.Code != http.StatusUnauthorized && rr.Code != http.StatusForbidden {
					t.Fatalf("expected unauthorized web subtitle access to be rejected, got %d body=%s", rr.Code, rr.Body.String())
				}
			})
		}
	})
}

func TestWebSubtitleTextEndpointNormalizesSRTAndVTTToCueJSON(t *testing.T) {
	cases := []struct {
		name          string
		deliveryURL   string
		subtitleBody  string
		expectedLine  string
		expectedStart int64
		expectedEnd   int64
	}{
		{
			name:          "srt",
			deliveryURL:   "/Videos/item-a/ms-a/Subtitles/2/Stream.srt",
			subtitleBody:  "1\r\n00:00:01,000 --> 00:00:02,000\r\n你好\r\n",
			expectedLine:  "你好",
			expectedStart: 1000,
			expectedEnd:   2000,
		},
		{
			name:          "vtt",
			deliveryURL:   "/Videos/item-a/ms-a/Subtitles/2/Stream.vtt",
			subtitleBody:  "WEBVTT\n\n00:00:01.000 --> 00:00:02.000\n你好\n",
			expectedLine:  "你好",
			expectedStart: 1000,
			expectedEnd:   2000,
		},
	}

	for _, tc := range cases {
		tc := tc
		t.Run(tc.name, func(t *testing.T) {
			upstream := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
				switch r.URL.Path {
				case "/Users/AuthenticateByName":
					_ = json.NewEncoder(w).Encode(map[string]any{"AccessToken": "tok-a", "User": map[string]any{"Id": "user-a"}})
				case "/Items/item-a/PlaybackInfo":
					_ = json.NewEncoder(w).Encode(map[string]any{
						"MediaSources": []map[string]any{{
							"Id": "ms-a",
							"MediaStreams": []map[string]any{{
								"Type":        "Subtitle",
								"Index":       2,
								"Codec":       "srt",
								"DeliveryUrl": tc.deliveryURL,
							}},
						}},
					})
				case tc.deliveryURL:
					w.Header().Set("Content-Type", "text/plain; charset=utf-8")
					_, _ = w.Write([]byte(tc.subtitleBody))
				default:
					http.NotFound(w, r)
				}
			}))
			defer upstream.Close()

			withTempAppPrepared(t, singleUpstreamConfig(upstream.URL), nil, func(app *App, handler http.Handler, dir string) {
				user, err := app.UserStore.Create("alice", "pw-1", []int{0})
				if err != nil {
					t.Fatalf("create user: %v", err)
				}
				login := doJSONRequest(t, handler, http.MethodPost, "/web/api/login", map[string]string{"username": user.Username, "password": "pw-1"}, "")
				if login.Code != http.StatusOK {
					t.Fatalf("login status = %d, body=%s", login.Code, login.Body.String())
				}
				cookie := login.Result().Cookies()[0]

				virtualItemID := app.IDStore.GetOrCreateVirtualID("item-a", 0)
				virtualMediaSourceID := app.IDStore.GetOrCreateVirtualID("ms-a", 0)
				trackID := encodeWebSubtitleTrackID(webSubtitleRef{
					ItemID:        virtualItemID,
					MediaSourceID: virtualMediaSourceID,
					StreamIndex:   2,
					RendererKind:  "text",
				})

				req := httptest.NewRequest(http.MethodGet, "/web/api/subtitles/"+trackID+"/text", nil)
				req.AddCookie(cookie)
				rr := httptest.NewRecorder()
				handler.ServeHTTP(rr, req)
				if rr.Code != http.StatusOK {
					t.Fatalf("subtitle text status = %d, body=%s", rr.Code, rr.Body.String())
				}

				var payload webTextSubtitlePayload
				if err := json.Unmarshal(rr.Body.Bytes(), &payload); err != nil {
					t.Fatalf("unmarshal subtitle payload: %v", err)
				}
				if payload.Format != "cue-json" {
					t.Fatalf("format = %q, want cue-json", payload.Format)
				}
				if len(payload.Cues) != 1 {
					t.Fatalf("cues length = %d, want 1", len(payload.Cues))
				}
				cue := payload.Cues[0]
				if cue.StartMs != tc.expectedStart || cue.EndMs != tc.expectedEnd {
					t.Fatalf("cue timing = (%d,%d), want (%d,%d)", cue.StartMs, cue.EndMs, tc.expectedStart, tc.expectedEnd)
				}
				if len(cue.Lines) != 1 || cue.Lines[0] != tc.expectedLine {
					t.Fatalf("cue lines = %v, want [%q]", cue.Lines, tc.expectedLine)
				}
			})
		})
	}
}

func TestWebSubtitleTextEndpointDoesNotLeakUpstreamURL(t *testing.T) {
	var deliveryURL string
	upstream := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch r.URL.Path {
		case "/Users/AuthenticateByName":
			_ = json.NewEncoder(w).Encode(map[string]any{"AccessToken": "tok-a", "User": map[string]any{"Id": "user-a"}})
		case "/Items/item-a/PlaybackInfo":
			_ = json.NewEncoder(w).Encode(map[string]any{
				"MediaSources": []map[string]any{{
					"Id": "ms-a",
					"MediaStreams": []map[string]any{{
						"Type":        "Subtitle",
						"Index":       2,
						"Codec":       "vtt",
						"DeliveryUrl": deliveryURL,
					}},
				}},
			})
		case "/Videos/item-a/ms-a/Subtitles/2/Stream.vtt":
			w.Header().Set("Content-Type", "text/vtt; charset=utf-8")
			_, _ = w.Write([]byte("WEBVTT\n\n00:00:01.000 --> 00:00:02.000\n你好\n"))
		default:
			http.NotFound(w, r)
		}
	}))
	defer upstream.Close()
	deliveryURL = upstream.URL + "/Videos/item-a/ms-a/Subtitles/2/Stream.vtt?api_key=upstream-token"

	withTempAppPrepared(t, singleUpstreamConfig(upstream.URL), nil, func(app *App, handler http.Handler, dir string) {
		user, err := app.UserStore.Create("alice", "pw-1", []int{0})
		if err != nil {
			t.Fatalf("create user: %v", err)
		}
		login := doJSONRequest(t, handler, http.MethodPost, "/web/api/login", map[string]string{"username": user.Username, "password": "pw-1"}, "")
		if login.Code != http.StatusOK {
			t.Fatalf("login status = %d, body=%s", login.Code, login.Body.String())
		}
		cookie := login.Result().Cookies()[0]

		virtualItemID := app.IDStore.GetOrCreateVirtualID("item-a", 0)
		virtualMediaSourceID := app.IDStore.GetOrCreateVirtualID("ms-a", 0)
		trackID := encodeWebSubtitleTrackID(webSubtitleRef{
			ItemID:        virtualItemID,
			MediaSourceID: virtualMediaSourceID,
			StreamIndex:   2,
			RendererKind:  "text",
		})

		req := httptest.NewRequest(http.MethodGet, "/web/api/subtitles/"+trackID+"/text", nil)
		req.AddCookie(cookie)
		rr := httptest.NewRecorder()
		handler.ServeHTTP(rr, req)
		if rr.Code != http.StatusOK {
			t.Fatalf("subtitle text status = %d, body=%s", rr.Code, rr.Body.String())
		}

		body := rr.Body.String()
		if strings.Contains(body, upstream.URL) || strings.Contains(body, "upstream-token") || strings.Contains(body, "api_key") {
			t.Fatalf("expected subtitle text response not to leak upstream URL/token, body=%s", body)
		}
	})
}

func TestWebSubtitleTextEndpointDoesNotFallBackToAnotherMediaSource(t *testing.T) {
	var bHits int
	upstream := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch r.URL.Path {
		case "/Users/AuthenticateByName":
			_ = json.NewEncoder(w).Encode(map[string]any{"AccessToken": "tok-a", "User": map[string]any{"Id": "user-a"}})
		case "/Items/item-a/PlaybackInfo":
			_ = json.NewEncoder(w).Encode(map[string]any{
				"MediaSources": []map[string]any{
					{
						"Id": "ms-a",
						"MediaStreams": []map[string]any{
							{"Type": "Subtitle", "Index": 2, "Codec": "srt"},
						},
					},
					{
						"Id": "ms-b",
						"MediaStreams": []map[string]any{
							{"Type": "Subtitle", "Index": 2, "Codec": "vtt", "DeliveryUrl": "/Videos/item-a/ms-b/Subtitles/2/Stream.vtt"},
						},
					},
				},
			})
		case "/Videos/item-a/ms-b/Subtitles/2/Stream.vtt":
			bHits++
			w.Header().Set("Content-Type", "text/vtt; charset=utf-8")
			_, _ = w.Write([]byte("WEBVTT\n\n00:00:01.000 --> 00:00:02.000\nwrong source\n"))
		default:
			http.NotFound(w, r)
		}
	}))
	defer upstream.Close()

	withTempAppPrepared(t, singleUpstreamConfig(upstream.URL), nil, func(app *App, handler http.Handler, dir string) {
		user, err := app.UserStore.Create("alice", "pw-1", []int{0})
		if err != nil {
			t.Fatalf("create user: %v", err)
		}
		login := doJSONRequest(t, handler, http.MethodPost, "/web/api/login", map[string]string{"username": user.Username, "password": "pw-1"}, "")
		if login.Code != http.StatusOK {
			t.Fatalf("login status = %d, body=%s", login.Code, login.Body.String())
		}
		cookie := login.Result().Cookies()[0]

		virtualItemID := app.IDStore.GetOrCreateVirtualID("item-a", 0)
		virtualMediaSourceID := app.IDStore.GetOrCreateVirtualID("ms-a", 0)
		trackID := encodeWebSubtitleTrackID(webSubtitleRef{
			ItemID:        virtualItemID,
			MediaSourceID: virtualMediaSourceID,
			StreamIndex:   2,
			RendererKind:  "text",
		})

		req := httptest.NewRequest(http.MethodGet, "/web/api/subtitles/"+trackID+"/text", nil)
		req.AddCookie(cookie)
		rr := httptest.NewRecorder()
		handler.ServeHTTP(rr, req)
		if rr.Code != http.StatusBadGateway {
			t.Fatalf("expected subtitle lookup to stay bound to media source A and fail, got %d body=%s", rr.Code, rr.Body.String())
		}
		if bHits != 0 {
			t.Fatalf("expected media source B subtitle to remain unused, got bHits=%d", bHits)
		}
	})
}

func TestWebSubtitleTextEndpointLoadsSubtitleFromSecondaryMediaSource(t *testing.T) {
	primary := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch r.URL.Path {
		case "/Users/AuthenticateByName":
			_ = json.NewEncoder(w).Encode(map[string]any{"AccessToken": "tok-a", "User": map[string]any{"Id": "user-a"}})
		case "/Items/item-a/PlaybackInfo":
			_ = json.NewEncoder(w).Encode(map[string]any{
				"MediaSources": []map[string]any{{
					"Id": "ms-a",
					"MediaStreams": []map[string]any{
						{"Type": "Subtitle", "Index": 2, "Codec": "srt"},
					},
				}},
			})
		default:
			http.NotFound(w, r)
		}
	}))
	defer primary.Close()

	secondary := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch r.URL.Path {
		case "/Users/AuthenticateByName":
			_ = json.NewEncoder(w).Encode(map[string]any{"AccessToken": "tok-b", "User": map[string]any{"Id": "user-b"}})
		case "/Items/item-b/PlaybackInfo":
			_ = json.NewEncoder(w).Encode(map[string]any{
				"MediaSources": []map[string]any{{
					"Id": "ms-b",
					"MediaStreams": []map[string]any{
						{"Type": "Subtitle", "Index": 2, "Codec": "vtt", "DeliveryUrl": "/Videos/item-b/ms-b/Subtitles/2/Stream.vtt"},
					},
				}},
			})
		case "/Videos/item-b/ms-b/Subtitles/2/Stream.vtt":
			w.Header().Set("Content-Type", "text/vtt; charset=utf-8")
			_, _ = w.Write([]byte("WEBVTT\n\n00:00:01.000 --> 00:00:02.000\nsecondary source\n"))
		default:
			http.NotFound(w, r)
		}
	}))
	defer secondary.Close()

	withTempAppPrepared(t, dualUpstreamConfig(primary.URL, secondary.URL), nil, func(app *App, handler http.Handler, dir string) {
		user, err := app.UserStore.Create("alice", "pw-1", []int{0, 1})
		if err != nil {
			t.Fatalf("create user: %v", err)
		}
		login := doJSONRequest(t, handler, http.MethodPost, "/web/api/login", map[string]string{"username": user.Username, "password": "pw-1"}, "")
		if login.Code != http.StatusOK {
			t.Fatalf("login status = %d, body=%s", login.Code, login.Body.String())
		}
		cookie := login.Result().Cookies()[0]

		virtualItemID := app.IDStore.GetOrCreateVirtualID("item-a", 0)
		app.IDStore.AssociateAdditionalInstance(virtualItemID, "item-b", 1)
		virtualMediaSourceID := app.IDStore.GetOrCreateVirtualID("ms-b", 1)
		trackID := encodeWebSubtitleTrackID(webSubtitleRef{
			ItemID:        virtualItemID,
			MediaSourceID: virtualMediaSourceID,
			StreamIndex:   2,
			RendererKind:  "text",
		})

		req := httptest.NewRequest(http.MethodGet, "/web/api/subtitles/"+trackID+"/text", nil)
		req.AddCookie(cookie)
		rr := httptest.NewRecorder()
		handler.ServeHTTP(rr, req)
		if rr.Code != http.StatusOK {
			t.Fatalf("expected secondary media source subtitle to load, got %d body=%s", rr.Code, rr.Body.String())
		}

		var payload webTextSubtitlePayload
		if err := json.Unmarshal(rr.Body.Bytes(), &payload); err != nil {
			t.Fatalf("unmarshal subtitle payload: %v", err)
		}
		if payload.Format != "cue-json" || len(payload.Cues) != 1 || len(payload.Cues[0].Lines) != 1 || payload.Cues[0].Lines[0] != "secondary source" {
			t.Fatalf("unexpected subtitle payload: %#v", payload)
		}
	})
}

func TestWebSubtitleTextEndpointFallsBackFromVTTToSRTWithQueryParams(t *testing.T) {
	var srtHits atomic.Int32
	upstream := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch r.URL.Path {
		case "/Users/AuthenticateByName":
			_ = json.NewEncoder(w).Encode(map[string]any{"AccessToken": "tok-a", "User": map[string]any{"Id": "user-a"}})
		case "/Items/item-a/PlaybackInfo":
			_ = json.NewEncoder(w).Encode(map[string]any{
				"MediaSources": []map[string]any{{
					"Id": "ms-a",
					"MediaStreams": []map[string]any{{
						"Type":        "Subtitle",
						"Index":       2,
						"Codec":       "vtt",
						"DeliveryUrl": "/Videos/item-a/ms-a/Subtitles/2/Stream.vtt?foo=1",
					}},
				}},
			})
		case "/Videos/item-a/ms-a/Subtitles/2/Stream.vtt":
			http.NotFound(w, r)
		case "/Videos/item-a/ms-a/Subtitles/2/Stream.srt":
			if got := r.URL.Query().Get("foo"); got != "1" {
				t.Fatalf("expected fallback query foo=1 to be preserved, got %q", got)
			}
			srtHits.Add(1)
			w.Header().Set("Content-Type", "text/plain; charset=utf-8")
			_, _ = w.Write([]byte("1\r\n00:00:01,000 --> 00:00:02,000\r\nfallback source\r\n"))
		default:
			http.NotFound(w, r)
		}
	}))
	defer upstream.Close()

	withTempAppPrepared(t, singleUpstreamConfig(upstream.URL), nil, func(app *App, handler http.Handler, dir string) {
		user, err := app.UserStore.Create("alice", "pw-1", []int{0})
		if err != nil {
			t.Fatalf("create user: %v", err)
		}
		login := doJSONRequest(t, handler, http.MethodPost, "/web/api/login", map[string]string{"username": user.Username, "password": "pw-1"}, "")
		if login.Code != http.StatusOK {
			t.Fatalf("login status = %d, body=%s", login.Code, login.Body.String())
		}
		cookie := login.Result().Cookies()[0]

		virtualItemID := app.IDStore.GetOrCreateVirtualID("item-a", 0)
		virtualMediaSourceID := app.IDStore.GetOrCreateVirtualID("ms-a", 0)
		trackID := encodeWebSubtitleTrackID(webSubtitleRef{
			ItemID:        virtualItemID,
			MediaSourceID: virtualMediaSourceID,
			StreamIndex:   2,
			RendererKind:  "text",
		})

		req := httptest.NewRequest(http.MethodGet, "/web/api/subtitles/"+trackID+"/text", nil)
		req.AddCookie(cookie)
		rr := httptest.NewRecorder()
		handler.ServeHTTP(rr, req)
		if rr.Code != http.StatusOK {
			t.Fatalf("expected vtt->srt fallback to succeed, got %d body=%s", rr.Code, rr.Body.String())
		}
		if srtHits.Load() != 1 {
			t.Fatalf("expected srt fallback to be used once, got %d", srtHits.Load())
		}
	})
}

func TestWebSubtitleTextEndpointRefreshesUpstreamApiKeyForAbsoluteAndRelativeDeliveryURLs(t *testing.T) {
	cases := []struct {
		name        string
		deliveryURL string
	}{
		{name: "absolute", deliveryURL: "ABS"},
		{name: "relative", deliveryURL: "REL"},
	}
	for _, tc := range cases {
		tc := tc
		t.Run(tc.name, func(t *testing.T) {
			var baseURL string
			upstream := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
				switch r.URL.Path {
				case "/Users/AuthenticateByName":
					_ = json.NewEncoder(w).Encode(map[string]any{"AccessToken": "tok-a", "User": map[string]any{"Id": "user-a"}})
				case "/Items/item-a/PlaybackInfo":
					deliveryURL := "/Videos/item-a/ms-a/Subtitles/2/Stream.vtt?api_key=stale-token&foo=1"
					if tc.deliveryURL == "ABS" {
						deliveryURL = baseURL + deliveryURL
					}
					_ = json.NewEncoder(w).Encode(map[string]any{
						"MediaSources": []map[string]any{{
							"Id": "ms-a",
							"MediaStreams": []map[string]any{{
								"Type":        "Subtitle",
								"Index":       2,
								"Codec":       "vtt",
								"DeliveryUrl": deliveryURL,
							}},
						}},
					})
				case "/Videos/item-a/ms-a/Subtitles/2/Stream.vtt":
					if got := r.URL.Query().Get("api_key"); got != "tok-a" {
						w.WriteHeader(http.StatusUnauthorized)
						return
					}
					if got := r.URL.Query().Get("foo"); got != "1" {
						t.Fatalf("expected foo=1 to be preserved, got %q", got)
					}
					http.NotFound(w, r)
				case "/Videos/item-a/ms-a/Subtitles/2/Stream.srt":
					if got := r.URL.Query().Get("api_key"); got != "tok-a" {
						w.WriteHeader(http.StatusUnauthorized)
						return
					}
					if got := r.URL.Query().Get("foo"); got != "1" {
						t.Fatalf("expected foo=1 to be preserved, got %q", got)
					}
					w.Header().Set("Content-Type", "text/plain; charset=utf-8")
					_, _ = w.Write([]byte("1\r\n00:00:01,000 --> 00:00:02,000\r\nfresh token\r\n"))
				default:
					http.NotFound(w, r)
				}
			}))
			baseURL = upstream.URL
			defer upstream.Close()

			withTempAppPrepared(t, singleUpstreamConfig(upstream.URL), nil, func(app *App, handler http.Handler, dir string) {
				user, err := app.UserStore.Create("alice", "pw-1", []int{0})
				if err != nil {
					t.Fatalf("create user: %v", err)
				}
				login := doJSONRequest(t, handler, http.MethodPost, "/web/api/login", map[string]string{"username": user.Username, "password": "pw-1"}, "")
				if login.Code != http.StatusOK {
					t.Fatalf("login status = %d, body=%s", login.Code, login.Body.String())
				}
				cookie := login.Result().Cookies()[0]

				virtualItemID := app.IDStore.GetOrCreateVirtualID("item-a", 0)
				virtualMediaSourceID := app.IDStore.GetOrCreateVirtualID("ms-a", 0)
				trackID := encodeWebSubtitleTrackID(webSubtitleRef{
					ItemID:        virtualItemID,
					MediaSourceID: virtualMediaSourceID,
					StreamIndex:   2,
					RendererKind:  "text",
				})

				req := httptest.NewRequest(http.MethodGet, "/web/api/subtitles/"+trackID+"/text", nil)
				req.AddCookie(cookie)
				rr := httptest.NewRecorder()
				handler.ServeHTTP(rr, req)
				if rr.Code != http.StatusOK {
					t.Fatalf("expected upstream api_key refresh to succeed, got %d body=%s", rr.Code, rr.Body.String())
				}
				if !strings.Contains(rr.Body.String(), "fresh token") {
					t.Fatalf("unexpected subtitle payload: %s", rr.Body.String())
				}
			})
		})
	}
}

func TestResolveWebSubtitleTrackRoundTripsOpaqueID(t *testing.T) {
	ref := webSubtitleRef{
		ItemID:        "item-a",
		MediaSourceID: "ms-a",
		StreamIndex:   7,
		RendererKind:  "ass",
	}

	trackID := encodeWebSubtitleTrackID(ref)
	decoded, err := decodeWebSubtitleTrackID(trackID)
	if err != nil {
		t.Fatalf("decode track id: %v", err)
	}
	if decoded.MediaSourceID != ref.MediaSourceID {
		t.Fatalf("mediaSourceId = %q, want %q", decoded.MediaSourceID, ref.MediaSourceID)
	}
	if decoded.StreamIndex != ref.StreamIndex {
		t.Fatalf("streamIndex = %d, want %d", decoded.StreamIndex, ref.StreamIndex)
	}
	if decoded.RendererKind != ref.RendererKind {
		t.Fatalf("rendererKind = %q, want %q", decoded.RendererKind, ref.RendererKind)
	}
	if decoded.ItemID != ref.ItemID {
		t.Fatalf("itemId = %q, want %q", decoded.ItemID, ref.ItemID)
	}
}

func TestResolveWebSubtitleTrackRejectsItemMismatch(t *testing.T) {
	trackID := encodeWebSubtitleTrackID(webSubtitleRef{
		ItemID:        "item-a",
		MediaSourceID: "ms-a",
		StreamIndex:   7,
		RendererKind:  "ass",
	})
	req := httptest.NewRequest(http.MethodPost, "/web/api/items/item-b/subtitles/"+trackID+"/fallback-stream", nil)
	req.SetPathValue("itemId", "item-b")
	_, err := (&App{}).resolveWebSubtitleTrack(req, trackID)
	if status, _ := webSubtitleResolveErrorStatus(err); status != http.StatusNotFound {
		t.Fatalf("expected item mismatch to be rejected")
	}
}

func TestResolveWebSubtitleTrackRejectsMalformedID(t *testing.T) {
	for _, tc := range []struct {
		name    string
		trackID string
	}{
		{name: "not-base64", trackID: "sub-not-base64"},
		{name: "missing-item", trackID: encodeWebSubtitleTrackID(webSubtitleRef{MediaSourceID: "ms-a", StreamIndex: 1, RendererKind: "text"})},
		{name: "bad-renderer", trackID: encodeWebSubtitleTrackID(webSubtitleRef{ItemID: "item-a", MediaSourceID: "ms-a", StreamIndex: 1, RendererKind: "weird"})},
	} {
		t.Run(tc.name, func(t *testing.T) {
			req := httptest.NewRequest(http.MethodGet, "/web/api/subtitles/"+tc.trackID+"/text", nil)
			_, err := (&App{}).resolveWebSubtitleTrack(req, tc.trackID)
			if status, _ := webSubtitleResolveErrorStatus(err); status != http.StatusBadRequest {
				t.Fatalf("expected malformed track id %q to be rejected", tc.trackID)
			}
		})
	}
}

func TestResolveWebSubtitleTrackDoesNotCreatePlaybackInfoSession(t *testing.T) {
	var playbackInfoHits atomic.Int32
	upstream := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch r.URL.Path {
		case "/Users/AuthenticateByName":
			_ = json.NewEncoder(w).Encode(map[string]any{"AccessToken": "tok-a", "User": map[string]any{"Id": "user-a"}})
		case "/Items/item-a/PlaybackInfo":
			playbackInfoHits.Add(1)
			_ = json.NewEncoder(w).Encode(map[string]any{
				"MediaSources": []map[string]any{{
					"Id": "ms-a",
					"MediaStreams": []map[string]any{
						{"Type": "Subtitle", "Index": 2, "DisplayTitle": "中文字幕", "Codec": "srt"},
					},
				}},
			})
		default:
			http.NotFound(w, r)
		}
	}))
	defer upstream.Close()

	withTempAppPrepared(t, singleUpstreamConfig(upstream.URL), nil, func(app *App, handler http.Handler, dir string) {
		virtualItemID := app.IDStore.GetOrCreateVirtualID("item-a", 0)
		virtualMediaSourceID := app.IDStore.GetOrCreateVirtualID("ms-a", 0)
		req := httptest.NewRequest(http.MethodGet, "/web/api/subtitles/unused/text", nil)
		req.SetPathValue("itemId", virtualItemID)
		req = req.WithContext(context.WithValue(req.Context(), requestContextKey{}, &RequestContext{
			ProxyUser: &tokenInfo{Role: "admin"},
		}))
		validTrackID := encodeWebSubtitleTrackID(webSubtitleRef{
			ItemID:        virtualItemID,
			MediaSourceID: virtualMediaSourceID,
			StreamIndex:   2,
			RendererKind:  "text",
		})
		resolved, err := app.resolveWebSubtitleTrack(req, validTrackID)
		if err != nil {
			t.Fatalf("resolve web subtitle track: %v", err)
		}
		if resolved.ItemID != virtualItemID {
			t.Fatalf("resolved itemId = %q, want %q", resolved.ItemID, virtualItemID)
		}

		structurallyValidTrackID := encodeWebSubtitleTrackID(webSubtitleRef{
			ItemID:        virtualItemID,
			MediaSourceID: virtualMediaSourceID,
			StreamIndex:   99,
			RendererKind:  "text",
		})
		if _, err := app.resolveWebSubtitleTrack(req, structurallyValidTrackID); err != nil {
			t.Fatalf("structurally valid track id should be deferred to concrete loader: %v", err)
		}
		if got := playbackInfoHits.Load(); got != 0 {
			t.Fatalf("subtitle track ID validation created %d PlaybackInfo sessions", got)
		}
	})
}

func TestWebSubtitleRouteRejectsMalformedTrackID(t *testing.T) {
	upstream := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch r.URL.Path {
		case "/Users/AuthenticateByName":
			_ = json.NewEncoder(w).Encode(map[string]any{"AccessToken": "tok-a", "User": map[string]any{"Id": "user-a"}})
		default:
			http.NotFound(w, r)
		}
	}))
	defer upstream.Close()

	withTempAppPrepared(t, singleUpstreamConfig(upstream.URL), nil, func(app *App, handler http.Handler, dir string) {
		user, err := app.UserStore.Create("alice", "pw-1", []int{0})
		if err != nil {
			t.Fatalf("create user: %v", err)
		}
		login := doJSONRequest(t, handler, http.MethodPost, "/web/api/login", map[string]string{"username": user.Username, "password": "pw-1"}, "")
		if login.Code != http.StatusOK {
			t.Fatalf("login status = %d, body=%s", login.Code, login.Body.String())
		}
		cookie := login.Result().Cookies()[0]

		req := httptest.NewRequest(http.MethodGet, "/web/api/subtitles/sub-not-base64/text", nil)
		req.AddCookie(cookie)
		rr := httptest.NewRecorder()
		handler.ServeHTTP(rr, req)
		if rr.Code != http.StatusBadRequest {
			t.Fatalf("expected malformed track id to be rejected with 400, got %d body=%s", rr.Code, rr.Body.String())
		}
	})
}

func TestWebSubtitleRouteReturnsBadGatewayWhenPlaybackInfoFails(t *testing.T) {
	upstream := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch r.URL.Path {
		case "/Users/AuthenticateByName":
			_ = json.NewEncoder(w).Encode(map[string]any{"AccessToken": "tok-a", "User": map[string]any{"Id": "user-a"}})
		case "/Items/item-a/PlaybackInfo":
			w.WriteHeader(http.StatusInternalServerError)
		default:
			http.NotFound(w, r)
		}
	}))
	defer upstream.Close()

	withTempAppPrepared(t, singleUpstreamConfig(upstream.URL), nil, func(app *App, handler http.Handler, dir string) {
		user, err := app.UserStore.Create("alice", "pw-1", []int{0})
		if err != nil {
			t.Fatalf("create user: %v", err)
		}
		login := doJSONRequest(t, handler, http.MethodPost, "/web/api/login", map[string]string{"username": user.Username, "password": "pw-1"}, "")
		if login.Code != http.StatusOK {
			t.Fatalf("login status = %d, body=%s", login.Code, login.Body.String())
		}
		cookie := login.Result().Cookies()[0]

		virtualItemID := app.IDStore.GetOrCreateVirtualID("item-a", 0)
		virtualMediaSourceID := app.IDStore.GetOrCreateVirtualID("ms-a", 0)
		trackID := encodeWebSubtitleTrackID(webSubtitleRef{
			ItemID:        virtualItemID,
			MediaSourceID: virtualMediaSourceID,
			StreamIndex:   2,
			RendererKind:  "text",
		})

		req := httptest.NewRequest(http.MethodGet, "/web/api/subtitles/"+trackID+"/text", nil)
		req.AddCookie(cookie)
		rr := httptest.NewRecorder()
		handler.ServeHTTP(rr, req)
		if rr.Code != http.StatusBadGateway {
			t.Fatalf("expected playback info failure to be rejected with 502, got %d body=%s", rr.Code, rr.Body.String())
		}
	})
}

func TestWebSubtitleASSEndpointReturnsScriptFontsAndLiteProfileHints(t *testing.T) {
	upstream := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch r.URL.Path {
		case "/Users/AuthenticateByName":
			_ = json.NewEncoder(w).Encode(map[string]any{"AccessToken": "tok-a", "User": map[string]any{"Id": "user-a"}})
		case "/Items/item-a/PlaybackInfo":
			_ = json.NewEncoder(w).Encode(map[string]any{
				"MediaSources": []map[string]any{{
					"Id": "ms-a",
					"MediaStreams": []map[string]any{
						{
							"Type":        "Subtitle",
							"Index":       3,
							"Codec":       "ass",
							"DeliveryUrl": "/Videos/item-a/ms-a/Subtitles/3/Stream.ass",
						},
						{
							"Type":     "Attachment",
							"Index":    7,
							"Codec":    "ttf",
							"FileName": "NotoSansCJKSC.ttf",
						},
					},
				}},
			})
		case "/Videos/item-a/ms-a/Subtitles/3/Stream.ass":
			w.Header().Set("Content-Type", "text/plain; charset=utf-8")
			_, _ = w.Write([]byte(`[Script Info]
Title: Sample

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Default,Noto Sans CJK SC,42,&H00FFFFFF,0,0,0,0,100,100,0,0,1,2,1,2,20,20,20,1

[Events]
Format: Layer, Start, End, Style, Text
Dialogue: 0,0:00:01.00,0:00:02.00,Default,Hello`))
		default:
			http.NotFound(w, r)
		}
	}))
	defer upstream.Close()

	withTempAppPrepared(t, singleUpstreamConfig(upstream.URL), nil, func(app *App, handler http.Handler, dir string) {
		user, err := app.UserStore.Create("alice", "pw-1", []int{0})
		if err != nil {
			t.Fatalf("create user: %v", err)
		}
		login := doJSONRequest(t, handler, http.MethodPost, "/web/api/login", map[string]string{"username": user.Username, "password": "pw-1"}, "")
		if login.Code != http.StatusOK {
			t.Fatalf("login status = %d, body=%s", login.Code, login.Body.String())
		}
		cookie := login.Result().Cookies()[0]

		virtualItemID := app.IDStore.GetOrCreateVirtualID("item-a", 0)
		virtualMediaSourceID := app.IDStore.GetOrCreateVirtualID("ms-a", 0)
		trackID := encodeWebSubtitleTrackID(webSubtitleRef{
			ItemID:        virtualItemID,
			MediaSourceID: virtualMediaSourceID,
			StreamIndex:   3,
			RendererKind:  "ass",
		})

		req := httptest.NewRequest(http.MethodGet, "/web/api/subtitles/"+trackID+"/ass", nil)
		req.AddCookie(cookie)
		rr := httptest.NewRecorder()
		handler.ServeHTTP(rr, req)
		if rr.Code != http.StatusOK {
			t.Fatalf("ass subtitle status = %d, body=%s", rr.Code, rr.Body.String())
		}

		var payload map[string]any
		if err := json.Unmarshal(rr.Body.Bytes(), &payload); err != nil {
			t.Fatalf("unmarshal ass subtitle payload: %v", err)
		}
		if got := webString(payload["renderer"]); got != "ass" {
			t.Fatalf("renderer = %q, want ass", got)
		}
		if webString(payload["script"]) == "" && webString(payload["scriptUrl"]) == "" {
			t.Fatalf("expected ass payload to include script or scriptUrl, got %#v", payload)
		}
		requiredFonts, ok := payload["requiredFonts"].([]any)
		if !ok || len(requiredFonts) == 0 {
			t.Fatalf("expected ass payload to include required font family names, got %#v", payload["requiredFonts"])
		}
		if _, falselyAdvertised := payload["fonts"]; falselyAdvertised {
			t.Fatalf("font family requirements must not be advertised as downloadable assets: %#v", payload["fonts"])
		}
		fontAssets, ok := payload["fontAssets"].([]any)
		if !ok || len(fontAssets) != 1 {
			t.Fatalf("expected one real attachment font asset, got %#v", payload["fontAssets"])
		}
		fontAsset := mustJSONMap(t, fontAssets[0])
		if got := webString(fontAsset["url"]); got != "/Videos/"+virtualItemID+"/"+virtualMediaSourceID+"/Attachments/7" {
			t.Fatalf("font asset url = %q, want local authenticated attachment proxy", got)
		}
		profiles, ok := payload["profiles"].(map[string]any)
		if !ok {
			t.Fatalf("expected ass payload to include profiles, got %#v", payload["profiles"])
		}
		if !webBool(profiles["full"]) {
			t.Fatalf("profiles.full = %#v, want true", profiles["full"])
		}
		if !webBool(profiles["lite"]) {
			t.Fatalf("profiles.lite = %#v, want true", profiles["lite"])
		}
	})
}

func TestWebSubtitleCacheReusesASSPayloadWithinTTL(t *testing.T) {
	var assHits atomic.Int32
	upstream := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch r.URL.Path {
		case "/Users/AuthenticateByName":
			_ = json.NewEncoder(w).Encode(map[string]any{"AccessToken": "tok-a", "User": map[string]any{"Id": "user-a"}})
		case "/Items/item-a/PlaybackInfo":
			_ = json.NewEncoder(w).Encode(map[string]any{
				"MediaSources": []map[string]any{{
					"Id": "ms-a",
					"MediaStreams": []map[string]any{{
						"Type":        "Subtitle",
						"Index":       3,
						"Codec":       "ass",
						"DeliveryUrl": "/Videos/item-a/ms-a/Subtitles/3/Stream.ass",
					}},
				}},
			})
		case "/Videos/item-a/ms-a/Subtitles/3/Stream.ass":
			assHits.Add(1)
			w.Header().Set("Content-Type", "text/plain; charset=utf-8")
			_, _ = w.Write([]byte(`[Script Info]
Title: Cached

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Default,Noto Sans CJK SC,42,&H00FFFFFF,0,0,0,0,100,100,0,0,1,2,1,2,20,20,20,1

[Events]
Format: Layer, Start, End, Style, Text
Dialogue: 0,0:00:01.00,0:00:02.00,Default,Hello`))
		default:
			http.NotFound(w, r)
		}
	}))
	defer upstream.Close()

	withTempAppPrepared(t, singleUpstreamConfig(upstream.URL), nil, func(app *App, handler http.Handler, dir string) {
		user, err := app.UserStore.Create("alice", "pw-1", []int{0})
		if err != nil {
			t.Fatalf("create user: %v", err)
		}
		login := doJSONRequest(t, handler, http.MethodPost, "/web/api/login", map[string]string{"username": user.Username, "password": "pw-1"}, "")
		if login.Code != http.StatusOK {
			t.Fatalf("login status = %d, body=%s", login.Code, login.Body.String())
		}
		cookie := login.Result().Cookies()[0]

		virtualItemID := app.IDStore.GetOrCreateVirtualID("item-a", 0)
		virtualMediaSourceID := app.IDStore.GetOrCreateVirtualID("ms-a", 0)
		trackID := encodeWebSubtitleTrackID(webSubtitleRef{
			ItemID:        virtualItemID,
			MediaSourceID: virtualMediaSourceID,
			StreamIndex:   3,
			RendererKind:  "ass",
		})

		for i := 0; i < 2; i++ {
			req := httptest.NewRequest(http.MethodGet, "/web/api/subtitles/"+trackID+"/ass", nil)
			req.AddCookie(cookie)
			rr := httptest.NewRecorder()
			handler.ServeHTTP(rr, req)
			if rr.Code != http.StatusOK {
				t.Fatalf("request %d ass subtitle status = %d, body=%s", i+1, rr.Code, rr.Body.String())
			}
		}

		if got := assHits.Load(); got != 1 {
			t.Fatalf("expected ass payload extraction to be reused within ttl, got assHits=%d", got)
		}
	})
}

func TestWebSubtitleBitmapEndpointSupportsFullAndLiteProfiles(t *testing.T) {
	bitmapBody := buildTestPGSStream([]testPGSFrame{
		{PTS: 1000, ObjectID: 1, X: 140, Y: 720, Width: 4, Height: 2, ObjectData: buildTestPGSSolidObjectData(4, 2, 1)},
		{PTS: 2000, ObjectID: 1, X: 140, Y: 720, Width: 4, Height: 2, ObjectData: buildTestPGSSolidObjectData(4, 2, 1)},
		{PTS: 3500, ObjectID: 2, X: 180, Y: 700, Width: 5, Height: 3, ObjectData: buildTestPGSSolidObjectData(5, 3, 2)},
	})
	var bitmapHits atomic.Int32
	upstream := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch r.URL.Path {
		case "/Users/AuthenticateByName":
			_ = json.NewEncoder(w).Encode(map[string]any{"AccessToken": "tok-a", "User": map[string]any{"Id": "user-a"}})
		case "/Items/item-a/PlaybackInfo":
			_ = json.NewEncoder(w).Encode(map[string]any{
				"MediaSources": []map[string]any{{
					"Id":             "ms-a",
					"TranscodingUrl": "/Videos/item-a/master.m3u8?MediaSourceId=ms-a&api_key=upstream",
					"MediaStreams": []map[string]any{{
						"Type":        "Subtitle",
						"Index":       4,
						"Codec":       "pgs",
						"DeliveryUrl": "/Videos/item-a/ms-a/Subtitles/4/Stream.sup",
					}},
				}},
			})
		case "/Videos/item-a/ms-a/Subtitles/4/Stream.sup":
			bitmapHits.Add(1)
			w.Header().Set("Content-Type", "application/octet-stream")
			_, _ = w.Write(bitmapBody)
		default:
			http.NotFound(w, r)
		}
	}))
	defer upstream.Close()

	withTempAppPrepared(t, singleUpstreamConfig(upstream.URL), nil, func(app *App, handler http.Handler, dir string) {
		user, err := app.UserStore.Create("alice", "pw-1", []int{0})
		if err != nil {
			t.Fatalf("create user: %v", err)
		}
		login := doJSONRequest(t, handler, http.MethodPost, "/web/api/login", map[string]string{"username": user.Username, "password": "pw-1"}, "")
		if login.Code != http.StatusOK {
			t.Fatalf("login status = %d, body=%s", login.Code, login.Body.String())
		}
		cookie := login.Result().Cookies()[0]

		virtualItemID := app.IDStore.GetOrCreateVirtualID("item-a", 0)
		virtualMediaSourceID := app.IDStore.GetOrCreateVirtualID("ms-a", 0)
		trackID := encodeWebSubtitleTrackID(webSubtitleRef{
			ItemID:        virtualItemID,
			MediaSourceID: virtualMediaSourceID,
			StreamIndex:   4,
			RendererKind:  "bitmap",
		})

		requestBitmap := func(profile string) map[string]any {
			req := httptest.NewRequest(http.MethodGet, "/web/api/subtitles/"+trackID+"/bitmap?profile="+profile, nil)
			req.AddCookie(cookie)
			rr := httptest.NewRecorder()
			handler.ServeHTTP(rr, req)
			if rr.Code != http.StatusOK {
				t.Fatalf("%s bitmap status = %d, body=%s", profile, rr.Code, rr.Body.String())
			}
			var payload map[string]any
			if err := json.Unmarshal(rr.Body.Bytes(), &payload); err != nil {
				t.Fatalf("unmarshal %s bitmap payload: %v", profile, err)
			}
			return payload
		}

		fullPayload := requestBitmap("full")
		fullFrames, ok := fullPayload["frames"].([]any)
		if !ok || len(fullFrames) == 0 {
			t.Fatalf("expected full bitmap payload to include frames, got %#v", fullPayload["frames"])
		}
		if got := webString(fullPayload["profile"]); got != "full" {
			t.Fatalf("full profile = %q, want full", got)
		}
		if len(fullFrames) != 3 {
			t.Fatalf("expected full bitmap payload to preserve timeline, got %d frames", len(fullFrames))
		}
		firstFullFrame, ok := fullFrames[0].(map[string]any)
		if !ok {
			t.Fatalf("expected full frame to decode as object, got %#v", fullFrames[0])
		}
		if got := webInt(firstFullFrame["x"]); got != 140 {
			t.Fatalf("full frame x = %d, want 140", got)
		}
		if got := webInt(firstFullFrame["y"]); got != 720 {
			t.Fatalf("full frame y = %d, want 720", got)
		}
		if got := webInt(firstFullFrame["width"]); got != 4 {
			t.Fatalf("full frame width = %d, want 4", got)
		}
		if got := webInt(firstFullFrame["height"]); got != 2 {
			t.Fatalf("full frame height = %d, want 2", got)
		}
		if got := webInt(firstFullFrame["startMs"]); got != 1000 {
			t.Fatalf("full frame startMs = %d, want 1000", got)
		}
		if got := webInt(firstFullFrame["endMs"]); got != 2000 {
			t.Fatalf("full frame endMs = %d, want 2000", got)
		}
		firstAssetURL := webString(firstFullFrame["assetUrl"])
		if !strings.HasPrefix(firstAssetURL, "data:image/png;base64,") {
			t.Fatalf("expected full frame assetUrl to be a decoded PNG data URL, got %q", firstAssetURL)
		}
		firstAsset := decodePNGDataURL(t, firstAssetURL)
		if bounds := firstAsset.Bounds(); bounds.Dx() != 4 || bounds.Dy() != 2 {
			t.Fatalf("full frame asset bounds = %dx%d, want 4x2", bounds.Dx(), bounds.Dy())
		}
		r, g, b, a := firstAsset.At(0, 0).RGBA()
		if r < 0xf000 || g < 0xf000 || b < 0xf000 || a != 0xffff {
			t.Fatalf("expected decoded bitmap asset to preserve palette-derived opaque white pixel, got rgba=(%#04x,%#04x,%#04x,%#04x)", r, g, b, a)
		}

		litePayload := requestBitmap("lite")
		liteFrames, ok := litePayload["frames"].([]any)
		if !ok || len(liteFrames) == 0 {
			t.Fatalf("expected lite bitmap payload to include frames, got %#v", litePayload["frames"])
		}
		if got := webString(litePayload["profile"]); got != "lite" {
			t.Fatalf("lite profile = %q, want lite", got)
		}
		if got := webString(litePayload["assetStrategy"]); got != "merged" {
			t.Fatalf("lite assetStrategy = %q, want merged", got)
		}
		if len(liteFrames) != 2 {
			t.Fatalf("expected lite bitmap payload to merge compatible frames, got %d frames", len(liteFrames))
		}
		firstLiteFrame, ok := liteFrames[0].(map[string]any)
		if !ok {
			t.Fatalf("expected lite frame to decode as object, got %#v", liteFrames[0])
		}
		if got := webInt(firstLiteFrame["startMs"]); got != 1000 {
			t.Fatalf("lite frame startMs = %d, want 1000", got)
		}
		if got := webInt(firstLiteFrame["endMs"]); got != 3500 {
			t.Fatalf("lite frame endMs = %d, want 3500", got)
		}
		if got := webInt(firstLiteFrame["width"]); got != 4 {
			t.Fatalf("lite frame width = %d, want 4", got)
		}
		if got := webString(firstLiteFrame["assetUrl"]); !strings.HasPrefix(got, "data:image/png;base64,") {
			t.Fatalf("expected lite frame assetUrl to reuse decoded PNG bitmap data, got %q", got)
		}
		if got := bitmapHits.Load(); got != 2 {
			t.Fatalf("expected cached/generated bitmap payload to be reused per profile, got bitmapHits=%d", got)
		}
	})
}

func TestWebParsePGSBitmapFramesSnapshotsObjectsPalettesAndClearSets(t *testing.T) {
	var body bytes.Buffer
	first := testPGSFrame{PTS: 1000, ObjectID: 1, X: 10, Y: 20, Width: 2, Height: 1, ObjectData: buildTestPGSSolidObjectData(2, 1, 1)}
	writeTestPGSSegment(&body, uint32(first.PTS*90), 0x14, buildTestPDS(0, defaultTestPGSPalette()))
	writeTestPGSSegment(&body, uint32(first.PTS*90), 0x16, buildTestPCS(first))
	writeTestPGSSegment(&body, uint32(first.PTS*90), 0x15, buildTestODS(first))
	writeTestPGSSegment(&body, uint32(first.PTS*90), 0x80, nil)

	second := testPGSFrame{PTS: 2000, ObjectID: 1, X: 30, Y: 40, Width: 2, Height: 1}
	redPalette := []testPGSPaletteEntry{
		{Index: 0, Y: 16, Cr: 128, Cb: 128, Alpha: 0},
		{Index: 1, Y: 81, Cr: 240, Cb: 90, Alpha: 255},
	}
	writeTestPGSSegment(&body, uint32(second.PTS*90), 0x14, buildTestPDS(0, redPalette))
	writeTestPGSSegment(&body, uint32(second.PTS*90), 0x16, buildTestPCS(second))
	writeTestPGSSegment(&body, uint32(second.PTS*90), 0x80, nil)

	clearPTS := uint32(2600)
	writeTestPGSSegment(&body, clearPTS*90, 0x16, buildTestPGSClearPCS())
	writeTestPGSSegment(&body, clearPTS*90, 0x80, nil)

	frames, err := webParsePGSBitmapFrames(body.Bytes())
	if err != nil {
		t.Fatalf("parse PGS: %v", err)
	}
	if len(frames) != 2 {
		t.Fatalf("frames = %d, want 2: %#v", len(frames), frames)
	}
	if frames[0].EndMs != 2000 || frames[1].EndMs != int64(clearPTS) {
		t.Fatalf("clear-set timeline not preserved: %#v", frames)
	}
	if frames[0].AssetURL == frames[1].AssetURL {
		t.Fatalf("palette update retroactively changed/reused an earlier frame asset")
	}
	if frames[0].X != 10 || frames[1].X != 30 {
		t.Fatalf("composition object snapshots not preserved: %#v", frames)
	}
}

func TestWebParsePGSBitmapFramesKeepsMultipleObjectsInOneDisplaySet(t *testing.T) {
	var body bytes.Buffer
	pts := int64(1000)
	objects := []testPGSFrame{
		{PTS: pts, ObjectID: 1, X: 10, Y: 20, Width: 2, Height: 1, ObjectData: buildTestPGSSolidObjectData(2, 1, 1)},
		{PTS: pts, ObjectID: 2, X: 30, Y: 40, Width: 3, Height: 1, ObjectData: buildTestPGSSolidObjectData(3, 1, 2)},
	}
	writeTestPGSSegment(&body, uint32(pts*90), 0x14, buildTestPDS(0, defaultTestPGSPalette()))
	writeTestPGSSegment(&body, uint32(pts*90), 0x16, buildTestPGSMultiObjectPCS(objects))
	for _, object := range objects {
		writeTestPGSSegment(&body, uint32(pts*90), 0x15, buildTestODS(object))
	}
	writeTestPGSSegment(&body, uint32(pts*90), 0x80, nil)
	writeTestPGSSegment(&body, 1800*90, 0x16, buildTestPGSClearPCS())
	writeTestPGSSegment(&body, 1800*90, 0x80, nil)

	frames, err := webParsePGSBitmapFrames(body.Bytes())
	if err != nil {
		t.Fatalf("parse PGS: %v", err)
	}
	if len(frames) != 2 || frames[0].StartMs != 1000 || frames[1].StartMs != 1000 || frames[0].EndMs != 1800 || frames[1].EndMs != 1800 {
		t.Fatalf("multi-object display set timeline was serialized incorrectly: %#v", frames)
	}
}

func TestWebSubtitleRawBitmapStreamRejectsNonPGSFormats(t *testing.T) {
	playback := map[string]any{"MediaSources": []any{map[string]any{
		"Id": "ms-a",
		"MediaStreams": []any{map[string]any{
			"Type":  "Subtitle",
			"Index": 4,
			"Codec": "dvd_subtitle",
		}},
	}}}
	if _, _, err := webSubtitleRawBitmapStream(playback, "ms-a", 4); !errors.Is(err, errWebSubtitleUnsupportedFormat) {
		t.Fatalf("expected non-PGS bitmap format to be explicitly unsupported, got %v", err)
	}
}

func TestWebSubtitleBitmapEndpointDerivesManifestFromRequestedTrack(t *testing.T) {
	trackBodies := map[string][]byte{
		"/Videos/item-a/ms-a/Subtitles/4/Stream.sup": buildTestPGSStream([]testPGSFrame{
			{PTS: 1000, ObjectID: 1, X: 140, Y: 720, Width: 4, Height: 2, ObjectData: buildTestPGSSolidObjectData(4, 2, 1)},
			{PTS: 2200, ObjectID: 2, X: 160, Y: 704, Width: 5, Height: 3, ObjectData: buildTestPGSSolidObjectData(5, 3, 2)},
		}),
		"/Videos/item-a/ms-a/Subtitles/5/Stream.sup": buildTestPGSStream([]testPGSFrame{
			{PTS: 1500, ObjectID: 8, X: 220, Y: 640, Width: 6, Height: 2, ObjectData: buildTestPGSSolidObjectData(6, 2, 2)},
			{PTS: 2800, ObjectID: 9, X: 240, Y: 620, Width: 7, Height: 3, ObjectData: buildTestPGSSolidObjectData(7, 3, 1)},
		}),
	}
	upstream := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch r.URL.Path {
		case "/Users/AuthenticateByName":
			_ = json.NewEncoder(w).Encode(map[string]any{"AccessToken": "tok-a", "User": map[string]any{"Id": "user-a"}})
		case "/Items/item-a/PlaybackInfo":
			_ = json.NewEncoder(w).Encode(map[string]any{
				"MediaSources": []map[string]any{{
					"Id": "ms-a",
					"MediaStreams": []map[string]any{
						{
							"Type":        "Subtitle",
							"Index":       4,
							"Codec":       "pgs",
							"DeliveryUrl": "/Videos/item-a/ms-a/Subtitles/4/Stream.sup",
						},
						{
							"Type":        "Subtitle",
							"Index":       5,
							"Codec":       "pgs",
							"DeliveryUrl": "/Videos/item-a/ms-a/Subtitles/5/Stream.sup",
						},
					},
				}},
			})
		case "/Videos/item-a/ms-a/Subtitles/4/Stream.sup", "/Videos/item-a/ms-a/Subtitles/5/Stream.sup":
			w.Header().Set("Content-Type", "application/octet-stream")
			_, _ = w.Write(trackBodies[r.URL.Path])
		default:
			http.NotFound(w, r)
		}
	}))
	defer upstream.Close()

	withTempAppPrepared(t, singleUpstreamConfig(upstream.URL), nil, func(app *App, handler http.Handler, dir string) {
		user, err := app.UserStore.Create("alice", "pw-1", []int{0})
		if err != nil {
			t.Fatalf("create user: %v", err)
		}
		login := doJSONRequest(t, handler, http.MethodPost, "/web/api/login", map[string]string{"username": user.Username, "password": "pw-1"}, "")
		if login.Code != http.StatusOK {
			t.Fatalf("login status = %d, body=%s", login.Code, login.Body.String())
		}
		cookie := login.Result().Cookies()[0]

		virtualItemID := app.IDStore.GetOrCreateVirtualID("item-a", 0)
		virtualMediaSourceID := app.IDStore.GetOrCreateVirtualID("ms-a", 0)
		requestBitmap := func(streamIndex int) webBitmapSubtitlePayload {
			trackID := encodeWebSubtitleTrackID(webSubtitleRef{
				ItemID:        virtualItemID,
				MediaSourceID: virtualMediaSourceID,
				StreamIndex:   streamIndex,
				RendererKind:  "bitmap",
			})
			req := httptest.NewRequest(http.MethodGet, "/web/api/subtitles/"+trackID+"/bitmap?profile=full", nil)
			req.AddCookie(cookie)
			rr := httptest.NewRecorder()
			handler.ServeHTTP(rr, req)
			if rr.Code != http.StatusOK {
				t.Fatalf("bitmap status for stream %d = %d, body=%s", streamIndex, rr.Code, rr.Body.String())
			}
			var payload webBitmapSubtitlePayload
			if err := json.Unmarshal(rr.Body.Bytes(), &payload); err != nil {
				t.Fatalf("unmarshal bitmap payload for stream %d: %v", streamIndex, err)
			}
			return payload
		}

		first := requestBitmap(4)
		second := requestBitmap(5)
		if len(first.Frames) == 0 || len(second.Frames) == 0 {
			t.Fatalf("expected both payloads to include frames")
		}
		if first.Frames[0].AssetURL == second.Frames[0].AssetURL {
			t.Fatalf("expected asset URLs to differ per subtitle track, got %q", first.Frames[0].AssetURL)
		}
		if first.Frames[0].Width == second.Frames[0].Width && first.Frames[0].Height == second.Frames[0].Height && first.Frames[0].X == second.Frames[0].X && first.Frames[0].Y == second.Frames[0].Y {
			t.Fatalf("expected manifest geometry to differ per subtitle track, first=%+v second=%+v", first.Frames[0], second.Frames[0])
		}
	})
}

func TestWebSubtitleFallbackStreamReturnsBurninSource(t *testing.T) {
	upstream := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch r.URL.Path {
		case "/Users/AuthenticateByName":
			_ = json.NewEncoder(w).Encode(map[string]any{"AccessToken": "tok-a", "User": map[string]any{"Id": "user-a"}})
		case "/Items/item-a/PlaybackInfo":
			if got := r.URL.Query().Get("SubtitleStreamIndex"); got != "4" {
				t.Fatalf("expected burnin playback request to carry subtitle stream selection, got %q", got)
			}
			if got := r.URL.Query().Get("AudioStreamIndex"); got != "1" {
				t.Fatalf("expected burnin playback request to carry audio stream selection, got %q", got)
			}
			_ = json.NewEncoder(w).Encode(map[string]any{
				"PlaySessionId": "session-a",
				"MediaSources": []map[string]any{{
					"Id":              "ms-a",
					"TranscodingUrl":  "/Videos/item-a/master.m3u8?MediaSourceId=ms-a&subtitleStreamIndex=4&api_key=upstream",
					"DirectStreamUrl": "/Videos/item-a/stream.mp4?MediaSourceId=ms-a&api_key=upstream",
					"MediaStreams": []map[string]any{{
						"Type":  "Subtitle",
						"Index": 4,
						"Codec": "pgs",
					}},
				}},
			})
		default:
			http.NotFound(w, r)
		}
	}))
	defer upstream.Close()

	withTempAppPrepared(t, singleUpstreamConfig(upstream.URL), nil, func(app *App, handler http.Handler, dir string) {
		user, err := app.UserStore.Create("alice", "pw-1", []int{0})
		if err != nil {
			t.Fatalf("create user: %v", err)
		}
		login := doJSONRequest(t, handler, http.MethodPost, "/web/api/login", map[string]string{"username": user.Username, "password": "pw-1"}, "")
		if login.Code != http.StatusOK {
			t.Fatalf("login status = %d, body=%s", login.Code, login.Body.String())
		}
		cookie := login.Result().Cookies()[0]

		virtualItemID := app.IDStore.GetOrCreateVirtualID("item-a", 0)
		virtualMediaSourceID := app.IDStore.GetOrCreateVirtualID("ms-a", 0)
		trackID := encodeWebSubtitleTrackID(webSubtitleRef{
			ItemID:        virtualItemID,
			MediaSourceID: virtualMediaSourceID,
			StreamIndex:   4,
			RendererKind:  "bitmap",
		})

		req := httptest.NewRequest(http.MethodPost, "/web/api/items/"+virtualItemID+"/subtitles/"+trackID+"/fallback-stream", strings.NewReader(`{"audioStreamIndex":1}`))
		req.Header.Set("Content-Type", "application/json")
		req.AddCookie(cookie)
		rr := httptest.NewRecorder()
		handler.ServeHTTP(rr, req)
		if rr.Code != http.StatusOK {
			t.Fatalf("fallback stream status = %d, body=%s", rr.Code, rr.Body.String())
		}

		var payload map[string]any
		if err := json.Unmarshal(rr.Body.Bytes(), &payload); err != nil {
			t.Fatalf("unmarshal fallback payload: %v", err)
		}
		if got := webString(payload["mode"]); got != "burnin" {
			t.Fatalf("mode = %q, want burnin", got)
		}
		source, ok := payload["source"].(map[string]any)
		if !ok {
			t.Fatalf("expected fallback payload to include source, got %#v", payload["source"])
		}
		if got := webString(source["kind"]); got != "hls" {
			t.Fatalf("source.kind = %q, want hls", got)
		}
		if webString(source["url"]) == "" {
			t.Fatalf("expected burnin source url to be present")
		}
		if !strings.Contains(webString(source["url"]), "SubtitleMethod=Encode") {
			t.Fatalf("burnin source must force SubtitleMethod=Encode, got %q", webString(source["url"]))
		}
		if !strings.Contains(webString(source["url"]), "AudioStreamIndex=1") {
			t.Fatalf("burnin source lost selected audio stream, got %q", webString(source["url"]))
		}
		if got := webString(payload["sessionId"]); got == "" {
			t.Fatal("fallback response must return the playback session used by its source")
		}
		if got := webString(payload["mediaSourceId"]); got != virtualMediaSourceID {
			t.Fatalf("mediaSourceId = %q, want %q", got, virtualMediaSourceID)
		}
		if webBool(payload["sessionReused"]) {
			t.Fatal("fallback without a supplied session must report sessionReused=false")
		}
		playPath := webString(payload["playPath"])
		if !strings.Contains(playPath, "subtitleStreamIndex=4") {
			t.Fatalf("expected fallback playPath to carry subtitle stream selection, got %q", playPath)
		}
		if !strings.Contains(playPath, "mediaSourceId="+virtualMediaSourceID) {
			t.Fatalf("expected fallback playPath to carry media source selection, got %q", playPath)
		}
	})
}

func TestWebSubtitleFallbackStreamReusesExistingSessionWithoutPlaybackInfo(t *testing.T) {
	var playbackInfoHits atomic.Int32
	upstream := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch r.URL.Path {
		case "/Users/AuthenticateByName":
			_ = json.NewEncoder(w).Encode(map[string]any{"AccessToken": "tok-a", "User": map[string]any{"Id": "user-a"}})
		case "/Items/item-a/PlaybackInfo":
			playbackInfoHits.Add(1)
			http.Error(w, "must not be called", http.StatusInternalServerError)
		default:
			http.NotFound(w, r)
		}
	}))
	defer upstream.Close()

	withTempAppPrepared(t, singleUpstreamConfig(upstream.URL), nil, func(app *App, handler http.Handler, dir string) {
		user, err := app.UserStore.Create("alice", "pw-1", []int{0})
		if err != nil {
			t.Fatalf("create user: %v", err)
		}
		login := doJSONRequest(t, handler, http.MethodPost, "/web/api/login", map[string]string{"username": user.Username, "password": "pw-1"}, "")
		if login.Code != http.StatusOK {
			t.Fatalf("login status = %d, body=%s", login.Code, login.Body.String())
		}
		cookie := login.Result().Cookies()[0]
		virtualItemID := app.IDStore.GetOrCreateVirtualID("item-a", 0)
		virtualMediaSourceID := app.IDStore.GetOrCreateVirtualID("ms-a", 0)
		virtualSessionID := app.IDStore.GetOrCreateVirtualID("session-a", 0)
		trackID := encodeWebSubtitleTrackID(webSubtitleRef{
			ItemID:        virtualItemID,
			MediaSourceID: virtualMediaSourceID,
			StreamIndex:   4,
			RendererKind:  "burnin",
		})

		req := httptest.NewRequest(http.MethodPost, "/web/api/items/"+virtualItemID+"/subtitles/"+trackID+"/fallback-stream", strings.NewReader(`{"sessionId":"`+virtualSessionID+`","audioStreamIndex":0}`))
		req.Header.Set("Content-Type", "application/json")
		req.AddCookie(cookie)
		rr := httptest.NewRecorder()
		handler.ServeHTTP(rr, req)
		if rr.Code != http.StatusOK {
			t.Fatalf("fallback stream status = %d, body=%s", rr.Code, rr.Body.String())
		}
		payload := mustJSONObject(t, rr.Body.Bytes())
		if !webBool(payload["sessionReused"]) || webString(payload["sessionId"]) != virtualSessionID {
			t.Fatalf("expected existing session reuse contract, got %#v", payload)
		}
		source := mustJSONMap(t, payload["source"])
		if sourceURL := webString(source["url"]); !strings.Contains(sourceURL, "PlaySessionId="+virtualSessionID) || !strings.Contains(sourceURL, "SubtitleMethod=Encode") || !strings.Contains(sourceURL, "AudioStreamIndex=0") {
			t.Fatalf("unexpected reused-session burnin URL: %q", sourceURL)
		}
		if got := playbackInfoHits.Load(); got != 0 {
			t.Fatalf("existing fallback session caused %d redundant PlaybackInfo requests", got)
		}
	})
}

func TestWebSubtitleFallbackReusesSessionForMergedItemSecondaryInstance(t *testing.T) {
	var playbackInfoHits atomic.Int32
	newUpstream := func(userID string) *httptest.Server {
		return httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			switch r.URL.Path {
			case "/Users/AuthenticateByName":
				_ = json.NewEncoder(w).Encode(map[string]any{"AccessToken": "tok-" + userID, "User": map[string]any{"Id": userID}})
			default:
				if strings.HasSuffix(r.URL.Path, "/PlaybackInfo") {
					playbackInfoHits.Add(1)
				}
				http.NotFound(w, r)
			}
		}))
	}
	serverA := newUpstream("user-a")
	defer serverA.Close()
	serverB := newUpstream("user-b")
	defer serverB.Close()

	withTempAppPrepared(t, dualUpstreamConfig(serverA.URL, serverB.URL), nil, func(app *App, handler http.Handler, dir string) {
		user, err := app.UserStore.Create("alice", "pw-1", []int{0, 1})
		if err != nil {
			t.Fatalf("create user: %v", err)
		}
		login := doJSONRequest(t, handler, http.MethodPost, "/web/api/login", map[string]string{"username": user.Username, "password": "pw-1"}, "")
		if login.Code != http.StatusOK {
			t.Fatalf("login status = %d, body=%s", login.Code, login.Body.String())
		}
		cookie := login.Result().Cookies()[0]

		virtualItemID := app.IDStore.GetOrCreateVirtualID("item-a", 0)
		app.IDStore.AssociateAdditionalInstance(virtualItemID, "item-b", 1)
		virtualMediaSourceID := app.IDStore.GetOrCreateVirtualID("ms-b", 1)
		virtualSessionID := app.IDStore.GetOrCreateVirtualID("session-b", 1)
		trackID := encodeWebSubtitleTrackID(webSubtitleRef{
			ItemID:        virtualItemID,
			MediaSourceID: virtualMediaSourceID,
			StreamIndex:   4,
			RendererKind:  "burnin",
		})
		body := `{"sessionId":"` + virtualSessionID + `"}`
		req := httptest.NewRequest(http.MethodPost, "/web/api/items/"+virtualItemID+"/subtitles/"+trackID+"/fallback-stream", strings.NewReader(body))
		req.Header.Set("Content-Type", "application/json")
		req.AddCookie(cookie)
		rr := httptest.NewRecorder()
		handler.ServeHTTP(rr, req)
		if rr.Code != http.StatusOK {
			t.Fatalf("fallback stream status = %d, body=%s", rr.Code, rr.Body.String())
		}
		payload := mustJSONObject(t, rr.Body.Bytes())
		if !webBool(payload["sessionReused"]) || webString(payload["sessionId"]) != virtualSessionID {
			t.Fatalf("secondary-instance session was not reused: %#v", payload)
		}
		if got := playbackInfoHits.Load(); got != 0 {
			t.Fatalf("secondary-instance reuse caused %d redundant PlaybackInfo requests", got)
		}
	})
}

func TestWebSubtitleFallbackWithoutSessionRegistersPlaybackLimiter(t *testing.T) {
	upstream := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch r.URL.Path {
		case "/Users/AuthenticateByName":
			_ = json.NewEncoder(w).Encode(map[string]any{"AccessToken": "tok-a", "User": map[string]any{"Id": "user-a"}})
		case "/Items/item-a/PlaybackInfo":
			_ = json.NewEncoder(w).Encode(map[string]any{
				"PlaySessionId": "session-a",
				"MediaSources": []map[string]any{{
					"Id":                  "ms-a",
					"SupportsTranscoding": true,
					"MediaStreams":        []map[string]any{{"Type": "Subtitle", "Index": 4, "Codec": "pgs"}},
				}},
			})
		default:
			http.NotFound(w, r)
		}
	}))
	defer upstream.Close()

	withTempAppPrepared(t, limitedPlaybackConfig(upstream.URL), nil, func(app *App, handler http.Handler, dir string) {
		user, err := app.UserStore.Create("alice", "pw-1", []int{0})
		if err != nil {
			t.Fatalf("create user: %v", err)
		}
		login := doJSONRequest(t, handler, http.MethodPost, "/web/api/login", map[string]string{"username": user.Username, "password": "pw-1"}, "")
		if login.Code != http.StatusOK {
			t.Fatalf("login status = %d, body=%s", login.Code, login.Body.String())
		}
		cookie := login.Result().Cookies()[0]
		virtualItemID := app.IDStore.GetOrCreateVirtualID("item-a", 0)
		virtualMediaSourceID := app.IDStore.GetOrCreateVirtualID("ms-a", 0)
		trackID := encodeWebSubtitleTrackID(webSubtitleRef{
			ItemID:        virtualItemID,
			MediaSourceID: virtualMediaSourceID,
			StreamIndex:   4,
			RendererKind:  "burnin",
		})
		req := httptest.NewRequest(http.MethodPost, "/web/api/items/"+virtualItemID+"/subtitles/"+trackID+"/fallback-stream", strings.NewReader(`{}`))
		req.Header.Set("Content-Type", "application/json")
		req.AddCookie(cookie)
		rr := httptest.NewRecorder()
		handler.ServeHTTP(rr, req)
		if rr.Code != http.StatusOK {
			t.Fatalf("fallback stream status = %d, body=%s", rr.Code, rr.Body.String())
		}
		if got := app.PlaybackLimiter.CountForServer(0); got != 1 {
			t.Fatalf("fallback limiter slots = %d, want 1", got)
		}
	})
}

func TestWebSubtitleFallbackStreamAddsPlaySessionToLocalCompatBurninURL(t *testing.T) {
	upstream := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch r.URL.Path {
		case "/Users/AuthenticateByName":
			_ = json.NewEncoder(w).Encode(map[string]any{"AccessToken": "tok-a", "User": map[string]any{"Id": "user-a"}})
		case "/Items/item-a/PlaybackInfo":
			if got := r.URL.Query().Get("SubtitleStreamIndex"); got != "4" {
				t.Fatalf("expected burnin playback request to carry subtitle stream selection, got %q", got)
			}
			_ = json.NewEncoder(w).Encode(map[string]any{
				"PlaySessionId": "session-a",
				"MediaSources": []map[string]any{{
					"Id":              "ms-a",
					"DirectStreamUrl": "/Videos/item-a/stream.mp4?MediaSourceId=ms-a&api_key=upstream",
					"MediaStreams": []map[string]any{{
						"Type":  "Subtitle",
						"Index": 4,
						"Codec": "pgs",
					}},
				}},
			})
		default:
			http.NotFound(w, r)
		}
	}))
	defer upstream.Close()

	withTempAppPrepared(t, singleUpstreamConfig(upstream.URL), nil, func(app *App, handler http.Handler, dir string) {
		user, err := app.UserStore.Create("alice", "pw-1", []int{0})
		if err != nil {
			t.Fatalf("create user: %v", err)
		}
		login := doJSONRequest(t, handler, http.MethodPost, "/web/api/login", map[string]string{"username": user.Username, "password": "pw-1"}, "")
		if login.Code != http.StatusOK {
			t.Fatalf("login status = %d, body=%s", login.Code, login.Body.String())
		}
		cookie := login.Result().Cookies()[0]

		virtualItemID := app.IDStore.GetOrCreateVirtualID("item-a", 0)
		virtualMediaSourceID := app.IDStore.GetOrCreateVirtualID("ms-a", 0)
		virtualPlaySessionID := app.IDStore.GetOrCreateVirtualID("session-a", 0)
		trackID := encodeWebSubtitleTrackID(webSubtitleRef{
			ItemID:        virtualItemID,
			MediaSourceID: virtualMediaSourceID,
			StreamIndex:   4,
			RendererKind:  "bitmap",
		})

		req := httptest.NewRequest(http.MethodPost, "/web/api/items/"+virtualItemID+"/subtitles/"+trackID+"/fallback-stream", strings.NewReader(`{}`))
		req.Header.Set("Content-Type", "application/json")
		req.AddCookie(cookie)
		rr := httptest.NewRecorder()
		handler.ServeHTTP(rr, req)
		if rr.Code != http.StatusOK {
			t.Fatalf("fallback stream status = %d, body=%s", rr.Code, rr.Body.String())
		}

		payload := mustJSONObject(t, rr.Body.Bytes())
		source := mustJSONMap(t, payload["source"])
		if got := webString(source["kind"]); got != "hls" {
			t.Fatalf("source.kind = %q, want hls", got)
		}
		sourceURL := webString(source["url"])
		if !strings.Contains(sourceURL, "SubtitleMethod=Encode") {
			t.Fatalf("expected local compat burnin source, got %q", sourceURL)
		}
		if !strings.Contains(sourceURL, "PlaySessionId="+virtualPlaySessionID) {
			t.Fatalf("expected local compat burnin source to retain response sessionId %q, got %q", virtualPlaySessionID, sourceURL)
		}
		if strings.Contains(sourceURL, "PlaySessionId=session-a") {
			t.Fatalf("expected local compat burnin source to use virtual session id, got %q", sourceURL)
		}
	})
}

func TestWebSubtitleModeEndpointAcceptsKnownModes(t *testing.T) {
	withTempApp(t, func(app *App, handler http.Handler) {
		user, err := app.UserStore.Create("alice", "pw-1", []int{0})
		if err != nil {
			t.Fatalf("create user: %v", err)
		}
		login := doJSONRequest(t, handler, http.MethodPost, "/web/api/login", map[string]string{"username": user.Username, "password": "pw-1"}, "")
		if login.Code != http.StatusOK {
			t.Fatalf("login status = %d, body=%s", login.Code, login.Body.String())
		}
		cookie := login.Result().Cookies()[0]

		for _, mode := range []string{"text-full", "ass-full", "ass-lite", "bitmap-full", "bitmap-lite", "burnin"} {
			req := httptest.NewRequest(http.MethodPost, "/web/api/sessions/session-a/subtitle-mode", strings.NewReader(`{"mode":"`+mode+`"}`))
			req.Header.Set("Content-Type", "application/json")
			req.AddCookie(cookie)
			rr := httptest.NewRecorder()
			handler.ServeHTTP(rr, req)
			if rr.Code != http.StatusOK {
				t.Fatalf("mode %s status = %d, body=%s", mode, rr.Code, rr.Body.String())
			}
		}
	})
}

func TestWebSubtitleCacheCleanupIntervalDoesNotExceedTTL(t *testing.T) {
	ttl := 15 * time.Second

	if got := appMaintenanceTickerInterval(ttl); got > ttl {
		t.Fatalf("subtitle cache cleanup interval = %v, want <= %v", got, ttl)
	}
}

type testPGSFrame struct {
	PTS        int64
	ObjectID   uint16
	X          int
	Y          int
	Width      int
	Height     int
	ObjectData []byte
}

type testPGSPaletteEntry struct {
	Index byte
	Y     byte
	Cr    byte
	Cb    byte
	Alpha byte
}

func buildTestPGSStream(frames []testPGSFrame) []byte {
	var out bytes.Buffer
	for _, frame := range frames {
		pts := uint32(frame.PTS * 90)
		writeTestPGSSegment(&out, pts, 0x14, buildTestPDS(0, defaultTestPGSPalette()))
		writeTestPGSSegment(&out, pts, 0x16, buildTestPCS(frame))
		writeTestPGSSegment(&out, pts, 0x15, buildTestODS(frame))
		writeTestPGSSegment(&out, pts, 0x80, nil)
	}
	return out.Bytes()
}

func defaultTestPGSPalette() []testPGSPaletteEntry {
	return []testPGSPaletteEntry{
		{Index: 1, Y: 235, Cr: 128, Cb: 128, Alpha: 255},
		{Index: 2, Y: 16, Cr: 128, Cb: 128, Alpha: 255},
	}
}

func buildTestPCS(frame testPGSFrame) []byte {
	var payload bytes.Buffer
	_ = binary.Write(&payload, binary.BigEndian, uint16(1920))
	_ = binary.Write(&payload, binary.BigEndian, uint16(1080))
	payload.WriteByte(0x10)
	_ = binary.Write(&payload, binary.BigEndian, uint16(frame.ObjectID))
	payload.WriteByte(0x00)
	payload.WriteByte(0x00)
	payload.WriteByte(0x00)
	payload.WriteByte(0x01)
	_ = binary.Write(&payload, binary.BigEndian, frame.ObjectID)
	payload.WriteByte(0x00)
	payload.WriteByte(0x00)
	_ = binary.Write(&payload, binary.BigEndian, uint16(frame.X))
	_ = binary.Write(&payload, binary.BigEndian, uint16(frame.Y))
	return payload.Bytes()
}

func buildTestPGSClearPCS() []byte {
	var payload bytes.Buffer
	_ = binary.Write(&payload, binary.BigEndian, uint16(1920))
	_ = binary.Write(&payload, binary.BigEndian, uint16(1080))
	payload.WriteByte(0x10)
	_ = binary.Write(&payload, binary.BigEndian, uint16(0))
	payload.WriteByte(0x00)
	payload.WriteByte(0x00)
	payload.WriteByte(0x00)
	payload.WriteByte(0x00)
	return payload.Bytes()
}

func buildTestPGSMultiObjectPCS(objects []testPGSFrame) []byte {
	var payload bytes.Buffer
	_ = binary.Write(&payload, binary.BigEndian, uint16(1920))
	_ = binary.Write(&payload, binary.BigEndian, uint16(1080))
	payload.WriteByte(0x10)
	_ = binary.Write(&payload, binary.BigEndian, uint16(1))
	payload.WriteByte(0x00)
	payload.WriteByte(0x00)
	payload.WriteByte(0x00)
	payload.WriteByte(byte(len(objects)))
	for _, object := range objects {
		_ = binary.Write(&payload, binary.BigEndian, object.ObjectID)
		payload.WriteByte(0x00)
		payload.WriteByte(0x00)
		_ = binary.Write(&payload, binary.BigEndian, uint16(object.X))
		_ = binary.Write(&payload, binary.BigEndian, uint16(object.Y))
	}
	return payload.Bytes()
}

func buildTestPDS(paletteID byte, entries []testPGSPaletteEntry) []byte {
	var payload bytes.Buffer
	payload.WriteByte(paletteID)
	payload.WriteByte(0x00)
	for _, entry := range entries {
		payload.WriteByte(entry.Index)
		payload.WriteByte(entry.Y)
		payload.WriteByte(entry.Cr)
		payload.WriteByte(entry.Cb)
		payload.WriteByte(entry.Alpha)
	}
	return payload.Bytes()
}

func buildTestODS(frame testPGSFrame) []byte {
	var payload bytes.Buffer
	_ = binary.Write(&payload, binary.BigEndian, frame.ObjectID)
	payload.WriteByte(0x00)
	payload.WriteByte(0xC0)
	objectDataLength := uint32(len(frame.ObjectData) + 4)
	payload.Write([]byte{byte(objectDataLength >> 16), byte(objectDataLength >> 8), byte(objectDataLength)})
	_ = binary.Write(&payload, binary.BigEndian, uint16(frame.Width))
	_ = binary.Write(&payload, binary.BigEndian, uint16(frame.Height))
	payload.Write(frame.ObjectData)
	return payload.Bytes()
}

func buildTestPGSSolidObjectData(width, height int, color byte) []byte {
	data := make([]byte, 0, (width+2)*height)
	for y := 0; y < height; y++ {
		for x := 0; x < width; x++ {
			data = append(data, color)
		}
		data = append(data, 0x00, 0x00)
	}
	return data
}

func writeTestPGSSegment(out *bytes.Buffer, pts uint32, segmentType byte, payload []byte) {
	out.WriteString("PG")
	_ = binary.Write(out, binary.BigEndian, pts)
	_ = binary.Write(out, binary.BigEndian, uint32(0))
	out.WriteByte(segmentType)
	_ = binary.Write(out, binary.BigEndian, uint16(len(payload)))
	out.Write(payload)
}

func decodePNGDataURL(t *testing.T, raw string) image.Image {
	t.Helper()
	const prefix = "data:image/png;base64,"
	if !strings.HasPrefix(raw, prefix) {
		t.Fatalf("data URL prefix = %q, want %q", raw, prefix)
	}
	data, err := base64.StdEncoding.DecodeString(strings.TrimPrefix(raw, prefix))
	if err != nil {
		t.Fatalf("decode bitmap data URL: %v", err)
	}
	img, err := png.Decode(bytes.NewReader(data))
	if err != nil {
		t.Fatalf("decode PNG asset: %v", err)
	}
	return img
}

func TestWebSubtitleTextEndpointFallsBackAfterVTTTimeout(t *testing.T) {
	start := time.Now()
	upstream := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch r.URL.Path {
		case "/Users/AuthenticateByName":
			_ = json.NewEncoder(w).Encode(map[string]any{"AccessToken": "tok-a", "User": map[string]any{"Id": "user-a"}})
		case "/Items/item-srt/PlaybackInfo":
			_ = json.NewEncoder(w).Encode(map[string]any{
				"MediaSources": []map[string]any{{
					"Id": "ms-srt",
					"MediaStreams": []map[string]any{{
						"Type":  "Subtitle",
						"Index": 2,
						"Codec": "webvtt",
					}},
				}},
			})
		case "/Videos/item-srt/ms-srt/Subtitles/2/Stream.vtt":
			// first candidate: delay beyond 8s timeout
			time.Sleep(12 * time.Second)
			http.NotFound(w, r)
		case "/Videos/item-srt/ms-srt/Subtitles/2/Stream.srt":
			// second candidate: responds immediately
			w.Header().Set("Content-Type", "text/plain; charset=utf-8")
			_, _ = w.Write([]byte("1\r\n00:00:01,000 --> 00:00:03,000\r\nFell back to SRT\r\n"))
		default:
			http.NotFound(w, r)
		}
	}))
	defer upstream.Close()

	withTempAppPrepared(t, singleUpstreamConfig(upstream.URL), nil, func(app *App, handler http.Handler, dir string) {
		user, err := app.UserStore.Create("alice", "pw-1", []int{0})
		if err != nil {
			t.Fatalf("create user: %v", err)
		}
		login := doJSONRequest(t, handler, http.MethodPost, "/web/api/login", map[string]string{"username": user.Username, "password": "pw-1"}, "")
		if login.Code != http.StatusOK {
			t.Fatalf("login status = %d, body=%s", login.Code, login.Body.String())
		}
		cookie := login.Result().Cookies()[0]

		virtualItemID := app.IDStore.GetOrCreateVirtualID("item-srt", 0)
		virtualMediaSourceID := app.IDStore.GetOrCreateVirtualID("ms-srt", 0)
		trackID := encodeWebSubtitleTrackID(webSubtitleRef{
			ItemID:        virtualItemID,
			MediaSourceID: virtualMediaSourceID,
			StreamIndex:   2,
			RendererKind:  "text",
		})

		req := httptest.NewRequest(http.MethodGet, "/web/api/subtitles/"+trackID+"/text", nil)
		req.AddCookie(cookie)
		rr := httptest.NewRecorder()
		handler.ServeHTTP(rr, req)

		elapsed := time.Since(start)
		if elapsed > 60*time.Second {
			t.Fatalf("test took %v, expected well under 125s (short timeout should have fired)", elapsed)
		}
		if rr.Code != http.StatusOK {
			t.Fatalf("subtitle text status = %d, body=%s", rr.Code, rr.Body.String())
		}
		var payload webTextSubtitlePayload
		if err := json.Unmarshal(rr.Body.Bytes(), &payload); err != nil {
			t.Fatalf("unmarshal subtitle payload: %v", err)
		}
		if len(payload.Cues) == 0 {
			t.Fatal("expected at least one cue from fallback candidate, got zero")
		}
		if payload.Cues[0].Lines[0] != "Fell back to SRT" {
			t.Fatalf("cue text = %q, want 'Fell back to SRT'", payload.Cues[0].Lines[0])
		}
	})
}

func TestWebTextSubtitleCandidatesDoNotProbeVTTForSubRip(t *testing.T) {
	candidates := webTextSubtitleCandidates("item-srt", "ms-srt", map[string]any{
		"Type":  "Subtitle",
		"Index": 2,
		"Codec": "subrip",
	})
	if len(candidates) != 1 {
		t.Fatalf("candidate count = %d, want 1", len(candidates))
	}
	if candidates[0].Kind != "emby-export-subrip" {
		t.Fatalf("candidate kind = %q, want emby-export-subrip", candidates[0].Kind)
	}
	if strings.Contains(candidates[0].URL, "Stream.vtt") {
		t.Fatalf("subrip candidate should not probe vtt export, got %q", candidates[0].URL)
	}
	if !strings.Contains(candidates[0].URL, "Stream.srt") {
		t.Fatalf("subrip candidate should use srt export, got %q", candidates[0].URL)
	}
}

func TestWebSubtitleTextEndpointLoadsInternalSubRipWithoutDeliveryURL(t *testing.T) {
	upstream := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch r.URL.Path {
		case "/Users/AuthenticateByName":
			_ = json.NewEncoder(w).Encode(map[string]any{"AccessToken": "tok-a", "User": map[string]any{"Id": "user-a"}})
		case "/Items/item-srt/PlaybackInfo":
			_ = json.NewEncoder(w).Encode(map[string]any{
				"MediaSources": []map[string]any{{
					"Id": "ms-srt",
					"MediaStreams": []map[string]any{{
						"Type":  "Subtitle",
						"Index": 2,
						"Codec": "subrip",
						// deliberately no DeliveryUrl — this is an internal subtitle stream
					}},
				}},
			})
		case "/Videos/item-srt/ms-srt/Subtitles/2/Stream.srt":
			// candidate URL that the backend should try when DeliveryUrl is missing
			w.Header().Set("Content-Type", "text/plain; charset=utf-8")
			_, _ = w.Write([]byte("1\r\n00:00:01,000 --> 00:00:03,200\r\nHello World\r\n"))
		default:
			http.NotFound(w, r)
		}
	}))
	defer upstream.Close()

	withTempAppPrepared(t, singleUpstreamConfig(upstream.URL), nil, func(app *App, handler http.Handler, dir string) {
		user, err := app.UserStore.Create("alice", "pw-1", []int{0})
		if err != nil {
			t.Fatalf("create user: %v", err)
		}
		login := doJSONRequest(t, handler, http.MethodPost, "/web/api/login", map[string]string{"username": user.Username, "password": "pw-1"}, "")
		if login.Code != http.StatusOK {
			t.Fatalf("login status = %d, body=%s", login.Code, login.Body.String())
		}
		cookie := login.Result().Cookies()[0]

		virtualItemID := app.IDStore.GetOrCreateVirtualID("item-srt", 0)
		virtualMediaSourceID := app.IDStore.GetOrCreateVirtualID("ms-srt", 0)
		trackID := encodeWebSubtitleTrackID(webSubtitleRef{
			ItemID:        virtualItemID,
			MediaSourceID: virtualMediaSourceID,
			StreamIndex:   2,
			RendererKind:  "text",
		})

		req := httptest.NewRequest(http.MethodGet, "/web/api/subtitles/"+trackID+"/text", nil)
		req.AddCookie(cookie)
		rr := httptest.NewRecorder()
		handler.ServeHTTP(rr, req)
		if rr.Code != http.StatusOK {
			t.Fatalf("subtitle text status = %d, body=%s", rr.Code, rr.Body.String())
		}

		var payload webTextSubtitlePayload
		if err := json.Unmarshal(rr.Body.Bytes(), &payload); err != nil {
			t.Fatalf("unmarshal subtitle payload: %v", err)
		}
		if payload.Format != "cue-json" {
			t.Fatalf("format = %q, want cue-json", payload.Format)
		}
		if len(payload.Cues) == 0 {
			t.Fatal("expected at least one cue, got zero")
		}
		cue := payload.Cues[0]
		if cue.StartMs != 1000 || cue.EndMs != 3200 {
			t.Fatalf("cue timing = (%d,%d), want (1000,3200)", cue.StartMs, cue.EndMs)
		}
		if len(cue.Lines) != 1 || cue.Lines[0] != "Hello World" {
			t.Fatalf("cue lines = %v, want [\"Hello World\"]", cue.Lines)
		}
	})
}

func TestWebSubtitleCacheExpiresIdleEntriesAtTTL(t *testing.T) {
	ttl := 40 * time.Millisecond
	cache := newWebSubtitleCacheWithTTL(ttl)
	cache.Set("sub-key", "payload")

	waitForCondition(t, 500*time.Millisecond, func() bool {
		cache.mu.Lock()
		defer cache.mu.Unlock()
		_, ok := cache.items["sub-key"]
		return !ok
	}, "idle subtitle cache entry to expire without Get or Cleanup")
}

func TestWebTextCueCacheMaintenanceRemovesExpiredEntries(t *testing.T) {
	cache := newWebTextSubtitleCacheStore()
	cache.successTTL = 10 * time.Millisecond
	cache.failureTTL = 10 * time.Millisecond
	cache.items["success"] = webTextSubtitleCacheEntry{
		Payload:   webTextSubtitlePayload{Format: "cue-json"},
		CreatedAt: time.Now().Add(-time.Minute),
	}
	cache.items["failure"] = webTextSubtitleCacheEntry{
		Err:      context.Canceled,
		FailedAt: time.Now().Add(-time.Minute),
	}
	app := &App{webTextCueCache: cache}

	app.runMaintenanceTick()

	cache.mu.Lock()
	defer cache.mu.Unlock()
	if len(cache.items) != 0 {
		t.Fatalf("expected expired text cue cache entries to be removed, got %d", len(cache.items))
	}
}

func TestWebTextCueCacheKeyUsesResolvedUpstreamFingerprint(t *testing.T) {
	app := &App{ConfigStore: &ConfigStore{config: &Config{
		Upstream: []UpstreamConfig{{Name: "Server A", URL: "https://server-a.example"}},
	}}}
	key := app.webTextCueCacheKey(webSubtitleRef{
		ItemID:        "virtual-item",
		MediaSourceID: "virtual-ms",
		StreamIndex:   2,
	}, &routeResolution{
		ServerIndex: 0,
		OriginalID:  "item-a",
	}, "ms-a", map[string]any{"Codec": "subrip"})

	got := key.String()
	if !strings.Contains(got, "https://server-a.example|Server A") {
		t.Fatalf("cache key %q does not include stable upstream fingerprint", got)
	}
	if strings.Contains(got, "virtual-item") || strings.Contains(got, "virtual-ms") {
		t.Fatalf("cache key %q should use resolved upstream ids, not virtual ids", got)
	}
}

func TestWebSubtitleTextCacheReusesCuesAcrossTextAndWebVTT(t *testing.T) {
	var subtitleBodyRequests atomic.Int32
	upstream := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch r.URL.Path {
		case "/Users/AuthenticateByName":
			_ = json.NewEncoder(w).Encode(map[string]any{"AccessToken": "tok-a", "User": map[string]any{"Id": "user-a"}})
		case "/Items/item-a/PlaybackInfo":
			_ = json.NewEncoder(w).Encode(map[string]any{
				"MediaSources": []map[string]any{{
					"Id": "ms-a",
					"MediaStreams": []map[string]any{{
						"Type":        "Subtitle",
						"Index":       2,
						"Codec":       "srt",
						"DeliveryUrl": "/Videos/item-a/ms-a/Subtitles/2/Stream.srt",
					}},
				}},
			})
		case "/Videos/item-a/ms-a/Subtitles/2/Stream.srt":
			subtitleBodyRequests.Add(1)
			w.Header().Set("Content-Type", "text/plain; charset=utf-8")
			_, _ = w.Write([]byte("1\r\n00:00:01,000 --> 00:00:02,000\r\nCached\r\n"))
		default:
			http.NotFound(w, r)
		}
	}))
	defer upstream.Close()

	withTempAppPrepared(t, singleUpstreamConfig(upstream.URL), nil, func(app *App, handler http.Handler, dir string) {
		user, err := app.UserStore.Create("alice", "pw-1", []int{0})
		if err != nil {
			t.Fatalf("create user: %v", err)
		}
		login := doJSONRequest(t, handler, http.MethodPost, "/web/api/login", map[string]string{"username": user.Username, "password": "pw-1"}, "")
		if login.Code != http.StatusOK {
			t.Fatalf("login status = %d", login.Code)
		}
		cookie := login.Result().Cookies()[0]

		vItemID := app.IDStore.GetOrCreateVirtualID("item-a", 0)
		vMSID := app.IDStore.GetOrCreateVirtualID("ms-a", 0)
		trackID := encodeWebSubtitleTrackID(webSubtitleRef{
			ItemID: vItemID, MediaSourceID: vMSID, StreamIndex: 2, RendererKind: "text",
		})

		// First request: /text
		req1 := httptest.NewRequest(http.MethodGet, "/web/api/subtitles/"+trackID+"/text", nil)
		req1.AddCookie(cookie)
		rr1 := httptest.NewRecorder()
		handler.ServeHTTP(rr1, req1)
		if rr1.Code != http.StatusOK {
			t.Fatalf("/text status = %d", rr1.Code)
		}

		// Second request: /webvtt — should reuse cached cues, not hit upstream again
		req2 := httptest.NewRequest(http.MethodGet, "/web/api/subtitles/"+trackID+"/webvtt", nil)
		req2.AddCookie(cookie)
		rr2 := httptest.NewRecorder()
		handler.ServeHTTP(rr2, req2)
		if rr2.Code != http.StatusOK {
			t.Fatalf("/webvtt status = %d, body=%s", rr2.Code, rr2.Body.String())
		}

		body := rr2.Body.String()
		if !strings.HasPrefix(body, "WEBVTT") {
			t.Fatalf("webvtt body does not start with WEBVTT: %s", body[:min(len(body), 50)])
		}
		if !strings.Contains(body, "Cached") {
			t.Fatalf("webvtt does not contain cached subtitle text: %s", body[:min(len(body), 100)])
		}

		// Verify subtitle body was only fetched once (from /text), /webvtt reused cache
		if subtitleBodyRequests.Load() > 1 {
			t.Fatalf("subtitle body requested %d times, expected 1 (cache reuse)", subtitleBodyRequests.Load())
		}
	})
}

func TestWebSubtitleWebVTTEndpointUsesLocalCueGeneration(t *testing.T) {
	upstream := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch r.URL.Path {
		case "/Users/AuthenticateByName":
			_ = json.NewEncoder(w).Encode(map[string]any{"AccessToken": "tok-a", "User": map[string]any{"Id": "user-a"}})
		case "/Items/item-vtt/PlaybackInfo":
			_ = json.NewEncoder(w).Encode(map[string]any{
				"MediaSources": []map[string]any{{
					"Id": "ms-vtt",
					"MediaStreams": []map[string]any{{
						"Type":  "Subtitle",
						"Index": 2,
						"Codec": "subrip",
						// no DeliveryUrl — forces candidate fallback
					}},
				}},
			})
		case "/Videos/item-vtt/ms-vtt/Subtitles/2/Stream.srt":
			w.Header().Set("Content-Type", "text/plain; charset=utf-8")
			_, _ = w.Write([]byte("1\r\n00:00:01,000 --> 00:00:05,000\r\nLocal Generated VTT\r\n"))
		default:
			http.NotFound(w, r)
		}
	}))
	defer upstream.Close()

	withTempAppPrepared(t, singleUpstreamConfig(upstream.URL), nil, func(app *App, handler http.Handler, dir string) {
		user, err := app.UserStore.Create("alice", "pw-1", []int{0})
		if err != nil {
			t.Fatalf("create user: %v", err)
		}
		login := doJSONRequest(t, handler, http.MethodPost, "/web/api/login", map[string]string{"username": user.Username, "password": "pw-1"}, "")
		if login.Code != http.StatusOK {
			t.Fatalf("login status = %d", login.Code)
		}
		cookie := login.Result().Cookies()[0]

		vItemID := app.IDStore.GetOrCreateVirtualID("item-vtt", 0)
		vMSID := app.IDStore.GetOrCreateVirtualID("ms-vtt", 0)
		trackID := encodeWebSubtitleTrackID(webSubtitleRef{
			ItemID: vItemID, MediaSourceID: vMSID, StreamIndex: 2, RendererKind: "text",
		})

		req := httptest.NewRequest(http.MethodGet, "/web/api/subtitles/"+trackID+"/webvtt", nil)
		req.AddCookie(cookie)
		rr := httptest.NewRecorder()
		handler.ServeHTTP(rr, req)
		if rr.Code != http.StatusOK {
			t.Fatalf("webvtt status = %d, body=%s", rr.Code, rr.Body.String())
		}

		ct := rr.Header().Get("Content-Type")
		if !strings.HasPrefix(ct, "text/vtt") {
			t.Fatalf("Content-Type = %q, want text/vtt", ct)
		}

		body := rr.Body.String()
		if !strings.HasPrefix(body, "WEBVTT") {
			t.Fatalf("webvtt body does not start with WEBVTT: %s", body[:min(len(body), 50)])
		}
		if !strings.Contains(body, "Local Generated VTT") {
			t.Fatalf("webvtt does not contain expected cue text: %s", body[:min(len(body), 100)])
		}
		// Must not leak upstream host, api_key, or original path
		if strings.Contains(body, "tok-a") || strings.Contains(body, "api_key") {
			t.Fatal("webvtt body leaks upstream credentials")
		}
	})
}
