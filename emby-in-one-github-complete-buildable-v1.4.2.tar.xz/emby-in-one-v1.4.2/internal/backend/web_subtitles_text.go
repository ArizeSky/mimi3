package backend

import (
	"bytes"
	"context"
	"encoding/binary"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"strconv"
	"strings"
	"time"
	"unicode"
	"unicode/utf16"
	"unicode/utf8"

	"golang.org/x/text/encoding/simplifiedchinese"
	"golang.org/x/text/encoding/traditionalchinese"
	"golang.org/x/text/transform"
)

type webTextCue struct {
	StartMs int64    `json:"startMs"`
	EndMs   int64    `json:"endMs"`
	Lines   []string `json:"lines"`
}

type webTextSubtitlePayload struct {
	Format string       `json:"format"`
	Cues   []webTextCue `json:"cues"`
}

func (a *App) handleWebSubtitleText(w http.ResponseWriter, r *http.Request) {
	ref, err := a.resolveWebSubtitleTrack(r, r.PathValue("trackId"))
	if err != nil {
		if a.Logger != nil {
			a.Logger.Warnf("Web subtitle text failed: trackId=%s err=%v", r.PathValue("trackId"), err)
		}
		writeWebSubtitleResolveError(w, err)
		return
	}
	if err := requireWebSubtitleRenderer(*ref, "text"); err != nil {
		writeWebSubtitleLoadError(w, "text", err)
		return
	}
	if a.Logger != nil {
		a.Logger.Debugf("Web subtitle text request: itemId=%s mediaSourceId=%s streamIndex=%d", ref.ItemID, ref.MediaSourceID, ref.StreamIndex)
	}
	payload, err := a.webLoadTextSubtitlePayloadCached(r, *ref)
	if err != nil {
		if a.Logger != nil {
			a.Logger.Warnf("Web subtitle text load failed: itemId=%s mediaSourceId=%s streamIndex=%d err=%v", ref.ItemID, ref.MediaSourceID, ref.StreamIndex, err)
		}
		writeWebSubtitleLoadError(w, "text", err)
		return
	}
	if a.Logger != nil {
		a.Logger.Infof("Web subtitle text response: itemId=%s mediaSourceId=%s streamIndex=%d cues=%d", ref.ItemID, ref.MediaSourceID, ref.StreamIndex, len(payload.Cues))
	}
	writeJSON(w, http.StatusOK, payload)
}

func webSubtitleLogPath(rawURL string) string {
	parsed, err := url.Parse(rawURL)
	if err != nil {
		return rawURL
	}
	if parsed.Path != "" {
		return parsed.Path
	}
	return rawURL
}

func (a *App) resolveWebSubtitleTextTarget(r *http.Request, ref webSubtitleRef) (*routeResolution, string, error) {
	reqCtx := requestContextFrom(r.Context())
	resolved := a.resolveRouteIDForRequest(reqCtx, ref.ItemID)
	if resolved == nil {
		return nil, "", newWebSubtitleResolveError(http.StatusNotFound, "subtitle track not found", nil)
	}
	if a.IDStore == nil {
		return nil, "", fmt.Errorf("subtitle track not found")
	}
	mediaSourceResolved := a.IDStore.ResolveVirtualID(ref.MediaSourceID)
	if mediaSourceResolved == nil {
		return nil, "", newWebSubtitleResolveError(http.StatusNotFound, "subtitle track not found", nil)
	}
	if mediaSourceResolved.ServerIndex == resolved.ServerIndex {
		return resolved, mediaSourceResolved.OriginalID, nil
	}
	for _, other := range resolved.OtherInstances {
		if other.ServerIndex != mediaSourceResolved.ServerIndex {
			continue
		}
		client := a.Upstream.GetClient(other.ServerIndex)
		if client == nil || !client.IsOnline() {
			return nil, "", fmt.Errorf("subtitle track not found")
		}
		return &routeResolution{
			OriginalID:  other.OriginalID,
			ServerIndex: other.ServerIndex,
			Client:      client,
		}, mediaSourceResolved.OriginalID, nil
	}
	return nil, "", fmt.Errorf("subtitle track not found")
}

func webSubtitleRawStreamForText(playback map[string]any, mediaSourceID string, streamIndex int) (map[string]any, string, error) {
	sources := asItems(map[string]any{"Items": playback["MediaSources"]})
	for _, source := range sources {
		sourceID := webString(source["Id"])
		if sourceID != mediaSourceID {
			continue
		}
		streams, _ := source["MediaStreams"].([]any)
		for _, raw := range streams {
			stream, ok := raw.(map[string]any)
			if !ok || webString(stream["Type"]) != "Subtitle" || webInt(stream["Index"]) != streamIndex {
				continue
			}
			if webSubtitleRendererKind(stream) != "text" {
				return nil, "", fmt.Errorf("%w: codec %q is not a text subtitle", errWebSubtitleUnsupportedFormat, webSubtitleCodec(stream))
			}
			deliveryURL := webString(stream["DeliveryUrl"])
			return stream, deliveryURL, nil
		}
	}
	return nil, "", fmt.Errorf("subtitle stream not found")
}

type webTextSubtitleCandidate struct {
	Kind string // "delivery-url" | "emby-export-subrip" | "emby-export-webvtt"
	URL  string
}

func webTextSubtitleCandidates(itemID, mediaSourceID string, stream map[string]any) []webTextSubtitleCandidate {
	if deliveryURL := webString(stream["DeliveryUrl"]); deliveryURL != "" {
		return []webTextSubtitleCandidate{{Kind: "delivery-url", URL: deliveryURL}}
	}
	codec := strings.ToLower(webSubtitleCodec(stream))
	index := webInt(stream["Index"])
	candidates := make([]webTextSubtitleCandidate, 0, 2)
	switch codec {
	case "subrip", "srt":
		candidates = append(candidates, webTextSubtitleCandidate{
			Kind: "emby-export-subrip",
			URL:  fmt.Sprintf("/Videos/%s/%s/Subtitles/%d/Stream.srt", itemID, mediaSourceID, index),
		})
	case "webvtt", "vtt":
		candidates = append(candidates, webTextSubtitleCandidate{
			Kind: "emby-export-webvtt",
			URL:  fmt.Sprintf("/Videos/%s/%s/Subtitles/%d/Stream.vtt", itemID, mediaSourceID, index),
		}, webTextSubtitleCandidate{
			Kind: "emby-export-subrip",
			URL:  fmt.Sprintf("/Videos/%s/%s/Subtitles/%d/Stream.srt", itemID, mediaSourceID, index),
		})
	default:
		candidates = append(candidates, webTextSubtitleCandidate{
			Kind: "emby-export-subrip",
			URL:  fmt.Sprintf("/Videos/%s/%s/Subtitles/%d/Stream.srt", itemID, mediaSourceID, index),
		})
	}
	return candidates
}

func (a *App) webTextCueCacheKey(ref webSubtitleRef, resolved *routeResolution, rawMediaSourceID string, stream map[string]any) webTextSubtitleCacheKey {
	itemID := ref.ItemID
	if resolved != nil && resolved.OriginalID != "" {
		itemID = resolved.OriginalID
	}
	mediaSourceID := firstNonEmpty(rawMediaSourceID, ref.MediaSourceID)
	return webTextSubtitleCacheKey{
		UpstreamKey:   a.webTextCueUpstreamKey(resolved),
		ItemID:        itemID,
		MediaSourceID: mediaSourceID,
		StreamIndex:   ref.StreamIndex,
		Codec:         webSubtitleCodec(stream),
	}
}

func (a *App) webTextCueUpstreamKey(resolved *routeResolution) string {
	if resolved == nil {
		return "server:unknown"
	}
	if a != nil && a.ConfigStore != nil {
		cfg := a.ConfigStore.Snapshot()
		if resolved.ServerIndex >= 0 && resolved.ServerIndex < len(cfg.Upstream) {
			upstream := cfg.Upstream[resolved.ServerIndex]
			return upstream.URL + "|" + upstream.Name
		}
	}
	return fmt.Sprintf("server:%d", resolved.ServerIndex)
}

func webLoadSubtitleBody(ctx context.Context, reqCtx *RequestContext, client *UpstreamClient, identity *ClientIdentityService, rawURL string) ([]byte, error) {
	body, status, err := webFetchSubtitleBody(ctx, reqCtx, client, identity, rawURL)
	if err != nil {
		return nil, err
	}
	if status == http.StatusNotFound {
		if fallbackURL := replaceSubtitleExtension(rawURL, ".vtt", ".srt"); fallbackURL != rawURL {
			body, status, err = webFetchSubtitleBody(ctx, reqCtx, client, identity, fallbackURL)
			if err != nil {
				return nil, err
			}
		}
	}
	if status < http.StatusOK || status >= http.StatusMultipleChoices {
		return nil, fmt.Errorf("subtitle fetch failed: status %d", status)
	}
	return body, nil
}

func webLoadSubtitleBodyFromCandidates(
	ctx context.Context,
	reqCtx *RequestContext,
	client *UpstreamClient,
	identity *ClientIdentityService,
	candidates []webTextSubtitleCandidate,
) ([]byte, string, error) {
	for _, candidate := range candidates {
		candidateCtx, cancel := context.WithTimeout(ctx, 8*time.Second)
		body, status, err := webFetchSubtitleBody(candidateCtx, reqCtx, client, identity, candidate.URL)
		cancel()
		if err == nil && status >= http.StatusOK && status < http.StatusMultipleChoices {
			return body, candidate.Kind, nil
		}
		if status == http.StatusNotFound && candidate.Kind == "emby-export-webvtt" {
			if fallbackURL := replaceSubtitleExtension(candidate.URL, ".vtt", ".srt"); fallbackURL != candidate.URL {
				candidateCtx2, cancel2 := context.WithTimeout(ctx, 8*time.Second)
				body, status, err = webFetchSubtitleBody(candidateCtx2, reqCtx, client, identity, fallbackURL)
				cancel2()
				if err == nil && status >= http.StatusOK && status < http.StatusMultipleChoices {
					return body, "emby-export-subrip", nil
				}
			}
		}
	}
	return nil, "", fmt.Errorf("all subtitle candidates failed")
}

func webFetchSubtitleBody(ctx context.Context, reqCtx *RequestContext, client *UpstreamClient, identity *ClientIdentityService, rawURL string) ([]byte, int, error) {
	if client == nil || rawURL == "" {
		return nil, 0, fmt.Errorf("missing subtitle client or URL")
	}
	var resp *http.Response
	var err error
	absoluteURL, path, query, isAbsolute, parseErr := webNormalizeSubtitleRequestTarget(rawURL, client)
	if parseErr != nil {
		return nil, 0, parseErr
	}
	if isAbsolute {
		resp, err = client.StreamAbsolute(ctx, reqCtx, identity, absoluteURL)
	} else {
		resp, err = client.Stream(ctx, reqCtx, identity, path, query)
	}
	if err != nil {
		return nil, 0, err
	}
	defer resp.Body.Close()
	body, readErr := io.ReadAll(resp.Body)
	if readErr != nil {
		return nil, resp.StatusCode, readErr
	}
	return body, resp.StatusCode, nil
}

func webNormalizeSubtitleRequestTarget(rawURL string, client *UpstreamClient) (string, string, url.Values, bool, error) {
	parsed, err := url.Parse(rawURL)
	if err != nil {
		return "", "", nil, false, err
	}
	query := parsed.Query()
	query.Del("api_key")
	query.Del("ApiKey")
	if token := client.getAccessToken(); token != "" {
		query.Set("api_key", token)
	}
	parsed.RawQuery = query.Encode()
	if parsed.IsAbs() {
		return parsed.String(), "", nil, true, nil
	}
	return "", parsed.Path, query, false, nil
}

func webParseTextSubtitlePayload(body []byte) (webTextSubtitlePayload, error) {
	text, err := webDecodeSubtitleText(body)
	if err != nil {
		return webTextSubtitlePayload{}, err
	}
	text = strings.ReplaceAll(text, "\r\n", "\n")
	trimmed := strings.TrimSpace(text)
	if trimmed == "" {
		return webTextSubtitlePayload{}, fmt.Errorf("%w: empty subtitle document", errWebSubtitleUnsupportedFormat)
	}
	if !strings.HasPrefix(trimmed, "WEBVTT") {
		if !strings.Contains(text, "-->") {
			return webTextSubtitlePayload{}, fmt.Errorf("%w: expected WebVTT or SubRip timing lines", errWebSubtitleUnsupportedFormat)
		}
		text = string(convertSRTBodyToVTT([]byte(text)))
	}
	cues, err := webParseTextCues(strings.Split(strings.ReplaceAll(text, "\r\n", "\n"), "\n"))
	if err != nil {
		return webTextSubtitlePayload{}, err
	}
	if len(cues) == 0 {
		return webTextSubtitlePayload{}, fmt.Errorf("%w: subtitle document did not contain any valid cues", errWebSubtitleUnsupportedFormat)
	}
	return webTextSubtitlePayload{Format: "cue-json", Cues: cues}, nil
}

func webDecodeSubtitleText(body []byte) (string, error) {
	if len(body) == 0 {
		return "", fmt.Errorf("%w: empty subtitle body", errWebSubtitleUnsupportedFormat)
	}
	if bytes.HasPrefix(body, []byte{0x00, 0x00, 0xfe, 0xff}) || bytes.HasPrefix(body, []byte{0xff, 0xfe, 0x00, 0x00}) {
		return "", fmt.Errorf("%w: UTF-32 subtitles are not supported", errWebSubtitleUnsupportedFormat)
	}
	if bytes.HasPrefix(body, []byte{0xef, 0xbb, 0xbf}) {
		body = body[3:]
		if !utf8.Valid(body) {
			return "", fmt.Errorf("%w: invalid UTF-8 subtitle", errWebSubtitleUnsupportedFormat)
		}
		return string(body), nil
	}
	if bytes.HasPrefix(body, []byte{0xff, 0xfe}) {
		return webDecodeUTF16Subtitle(body[2:], binary.LittleEndian)
	}
	if bytes.HasPrefix(body, []byte{0xfe, 0xff}) {
		return webDecodeUTF16Subtitle(body[2:], binary.BigEndian)
	}
	if utf8.Valid(body) {
		return string(body), nil
	}
	return webDecodeLegacyChineseSubtitle(body)
}

func webDecodeUTF16Subtitle(body []byte, order binary.ByteOrder) (string, error) {
	if len(body)%2 != 0 {
		return "", fmt.Errorf("%w: truncated UTF-16 subtitle", errWebSubtitleUnsupportedFormat)
	}
	units := make([]uint16, len(body)/2)
	for i := range units {
		units[i] = order.Uint16(body[i*2 : i*2+2])
	}
	decoded := string(utf16.Decode(units))
	if strings.ContainsRune(decoded, utf8.RuneError) {
		return "", fmt.Errorf("%w: invalid UTF-16 subtitle", errWebSubtitleUnsupportedFormat)
	}
	return decoded, nil
}

type webLegacySubtitleCandidate struct {
	name  string
	text  string
	score int
}

func webDecodeLegacyChineseSubtitle(body []byte) (string, error) {
	candidates := make([]webLegacySubtitleCandidate, 0, 2)
	for _, candidate := range []struct {
		name    string
		decoder transform.Transformer
	}{
		{name: "gb18030", decoder: simplifiedchinese.GB18030.NewDecoder()},
		{name: "big5", decoder: traditionalchinese.Big5.NewDecoder()},
	} {
		decoded, _, err := transform.Bytes(candidate.decoder, body)
		if err != nil || !utf8.Valid(decoded) || bytes.Contains(decoded, []byte(string(utf8.RuneError))) {
			continue
		}
		text := string(decoded)
		if !webDecodedSubtitleTextPlausible(text) {
			continue
		}
		candidates = append(candidates, webLegacySubtitleCandidate{
			name:  candidate.name,
			text:  text,
			score: webLegacyChineseEncodingScore(body, text, candidate.name),
		})
	}
	if len(candidates) == 1 {
		return candidates[0].text, nil
	}
	if len(candidates) != 2 {
		return "", fmt.Errorf("%w: unknown subtitle character encoding", errWebSubtitleUnsupportedFormat)
	}
	if candidates[0].score == candidates[1].score {
		return "", fmt.Errorf("%w: ambiguous GB18030/Big5 subtitle encoding", errWebSubtitleUnsupportedFormat)
	}
	if candidates[1].score > candidates[0].score {
		candidates[0], candidates[1] = candidates[1], candidates[0]
	}
	if candidates[0].score-candidates[1].score < 2 {
		return "", fmt.Errorf("%w: ambiguous GB18030/Big5 subtitle encoding", errWebSubtitleUnsupportedFormat)
	}
	return candidates[0].text, nil
}

func webDecodedSubtitleTextPlausible(text string) bool {
	for _, r := range text {
		if r == utf8.RuneError || (unicode.IsControl(r) && r != '\n' && r != '\r' && r != '\t') {
			return false
		}
	}
	return true
}

func webLegacyChineseEncodingScore(body []byte, decoded, name string) int {
	gbScore, big5Score := 0, 0
	for i := 0; i < len(body); {
		lead := body[i]
		if lead < 0x80 {
			i++
			continue
		}
		if i+3 < len(body) && lead >= 0x81 && lead <= 0xfe && body[i+1] >= 0x30 && body[i+1] <= 0x39 && body[i+2] >= 0x81 && body[i+2] <= 0xfe && body[i+3] >= 0x30 && body[i+3] <= 0x39 {
			gbScore += 12
			i += 4
			continue
		}
		if i+1 >= len(body) {
			break
		}
		trail := body[i+1]
		if lead >= 0x81 && lead <= 0xfe && trail >= 0x40 && trail <= 0xfe && trail != 0x7f {
			gbScore++
			if lead >= 0xb0 && lead <= 0xf7 && trail >= 0xa1 {
				gbScore++
			}
		}
		if lead >= 0x81 && lead <= 0xfe && ((trail >= 0x40 && trail <= 0x7e) || (trail >= 0xa1 && trail <= 0xfe)) {
			big5Score++
			if trail >= 0x40 && trail <= 0x7e {
				big5Score += 3
			}
			if lead >= 0xa1 && lead <= 0xa9 {
				big5Score++
			}
		}
		if trail >= 0x80 && trail <= 0xa0 {
			gbScore += 4
		}
		i += 2
	}

	for _, r := range decoded {
		if strings.ContainsRune("这为国发后里么个们来时会说对从还没过见给现样进着实点开当无与体让头经长间问业东车门", r) {
			gbScore += 3
		}
		if strings.ContainsRune("這為國發後裡麼個們來時會說對從還沒過見給現樣進著實點開當無與體讓頭經長間問業東車門", r) {
			big5Score += 3
		}
		if unicode.Is(unicode.Co, r) {
			if name == "gb18030" {
				gbScore -= 4
			} else {
				big5Score -= 4
			}
		}
	}
	if name == "big5" {
		return big5Score - gbScore
	}
	return gbScore - big5Score
}

func webParseTextCues(lines []string) ([]webTextCue, error) {
	i := 0
	if len(lines) > 0 && strings.HasPrefix(strings.TrimSpace(lines[0]), "WEBVTT") {
		i++
		for i < len(lines) && strings.TrimSpace(lines[i]) != "" {
			i++
		}
		for i < len(lines) && strings.TrimSpace(lines[i]) == "" {
			i++
		}
	}
	cues := make([]webTextCue, 0)
	for i < len(lines) {
		line := strings.TrimSpace(lines[i])
		if line == "" {
			i++
			continue
		}
		switch {
		case strings.HasPrefix(line, "NOTE"):
			i = webSkipSubtitleBlock(lines, i+1)
			continue
		case strings.HasPrefix(line, "STYLE"), strings.HasPrefix(line, "REGION"):
			i = webSkipSubtitleBlock(lines, i+1)
			continue
		}
		timingLine := ""
		if strings.Contains(lines[i], "-->") {
			timingLine = strings.TrimSpace(lines[i])
			i++
		} else if i+1 < len(lines) && strings.Contains(lines[i+1], "-->") {
			i++
			timingLine = strings.TrimSpace(lines[i])
			i++
		} else {
			i++
			continue
		}
		startMs, endMs, ok := webParseTextTimingLine(timingLine)
		if !ok {
			continue
		}
		cueLines := make([]string, 0)
		for i < len(lines) && strings.TrimSpace(lines[i]) != "" {
			cueLines = append(cueLines, lines[i])
			i++
		}
		cues = append(cues, webTextCue{StartMs: startMs, EndMs: endMs, Lines: cueLines})
	}
	return cues, nil
}

func webSkipSubtitleBlock(lines []string, start int) int {
	i := start
	for i < len(lines) && strings.TrimSpace(lines[i]) != "" {
		i++
	}
	for i < len(lines) && strings.TrimSpace(lines[i]) == "" {
		i++
	}
	return i
}

func webParseTextTimingLine(line string) (int64, int64, bool) {
	parts := strings.SplitN(line, "-->", 2)
	if len(parts) != 2 {
		return 0, 0, false
	}
	startMs, ok := webParseSubtitleTimestamp(parts[0])
	if !ok {
		return 0, 0, false
	}
	endField := strings.Fields(strings.TrimSpace(parts[1]))
	if len(endField) == 0 {
		return 0, 0, false
	}
	endMs, ok := webParseSubtitleTimestamp(endField[0])
	if !ok {
		return 0, 0, false
	}
	return startMs, endMs, true
}

func webParseSubtitleTimestamp(raw string) (int64, bool) {
	raw = strings.TrimSpace(strings.ReplaceAll(raw, ",", "."))
	if raw == "" {
		return 0, false
	}
	parts := strings.Split(raw, ":")
	if len(parts) < 2 || len(parts) > 3 {
		return 0, false
	}
	last := parts[len(parts)-1]
	secondsPart := last
	msPart := 0
	if dot := strings.IndexByte(last, '.'); dot >= 0 {
		secondsPart = last[:dot]
		msDigits := last[dot+1:]
		if len(msDigits) > 3 {
			msDigits = msDigits[:3]
		}
		for len(msDigits) < 3 {
			msDigits += "0"
		}
		parsed, err := strconv.Atoi(msDigits)
		if err != nil {
			return 0, false
		}
		msPart = parsed
	}
	seconds, err := strconv.Atoi(secondsPart)
	if err != nil {
		return 0, false
	}
	minutes, err := strconv.Atoi(parts[len(parts)-2])
	if err != nil {
		return 0, false
	}
	hours := 0
	if len(parts) == 3 {
		hours, err = strconv.Atoi(parts[0])
		if err != nil {
			return 0, false
		}
	}
	total := int64(hours)*3600000 + int64(minutes)*60000 + int64(seconds)*1000 + int64(msPart)
	return total, true
}

func (a *App) webLoadTextSubtitlePayloadCached(r *http.Request, ref webSubtitleRef) (webTextSubtitlePayload, error) {
	reqCtx := requestContextFrom(r.Context())
	resolved, rawMediaSourceID, err := a.resolveWebSubtitleTextTarget(r, ref)
	if err != nil {
		return webTextSubtitlePayload{}, err
	}
	// resolve codec from PlaybackInfo for cache key
	codec := ""
	query := url.Values{}
	if rawMediaSourceID != "" {
		query.Set("MediaSourceId", rawMediaSourceID)
	}
	query.Del("api_key")
	query.Del("ApiKey")
	playbackPayload, err := resolved.Client.RequestJSON(r.Context(), reqCtx, a.Identity, http.MethodGet, "/Items/"+resolved.OriginalID+"/PlaybackInfo", query, nil)
	if err != nil {
		return webTextSubtitlePayload{}, err
	}
	playback, ok := playbackPayload.(map[string]any)
	if !ok {
		return webTextSubtitlePayload{}, fmt.Errorf("unexpected playback info payload")
	}
	stream, _, _ := webSubtitleRawStreamForText(playback, rawMediaSourceID, ref.StreamIndex)
	if stream != nil {
		codec = webSubtitleCodec(stream)
	}

	cacheKey := a.webTextCueCacheKey(ref, resolved, rawMediaSourceID, stream)
	if codec != "" {
		cacheKey.Codec = codec
	}
	return a.webTextCueCache.GetOrLoad(cacheKey, func() (webTextSubtitlePayload, string, error) {
		payload, err := a.webLoadTextSubtitlePayloadFromResolved(r, ref, resolved, rawMediaSourceID, playback, stream)
		return payload, "", err
	})
}

func (a *App) webLoadTextSubtitlePayloadFromResolved(
	r *http.Request, ref webSubtitleRef,
	resolved *routeResolution, rawMediaSourceID string,
	playback map[string]any, stream map[string]any,
) (webTextSubtitlePayload, error) {
	reqCtx := requestContextFrom(r.Context())
	_, deliveryURL, err := webSubtitleRawStreamForText(playback, rawMediaSourceID, ref.StreamIndex)
	if err != nil {
		return webTextSubtitlePayload{}, err
	}
	var body []byte
	if deliveryURL != "" {
		if a.Logger != nil {
			a.Logger.Debugf("Web subtitle text source: itemId=%s mediaSourceId=%s streamIndex=%d server=[%s] deliveryPath=%s",
				ref.ItemID, ref.MediaSourceID, ref.StreamIndex, resolved.Client.Name, webSubtitleLogPath(deliveryURL))
		}
		body, err = webLoadSubtitleBody(r.Context(), reqCtx, resolved.Client, a.Identity, deliveryURL)
	} else {
		candidates := webTextSubtitleCandidates(resolved.OriginalID, rawMediaSourceID, stream)
		if a.Logger != nil {
			a.Logger.Debugf("Web subtitle text candidates: itemId=%s mediaSourceId=%s streamIndex=%d codec=%s count=%d",
				ref.ItemID, ref.MediaSourceID, ref.StreamIndex, webSubtitleCodec(stream), len(candidates))
		}
		body, _, err = webLoadSubtitleBodyFromCandidates(r.Context(), reqCtx, resolved.Client, a.Identity, candidates)
	}
	if err != nil {
		return webTextSubtitlePayload{}, err
	}
	return webParseTextSubtitlePayload(body)
}

func (a *App) handleWebSubtitleWebVTT(w http.ResponseWriter, r *http.Request) {
	ref, err := a.resolveWebSubtitleTrack(r, r.PathValue("trackId"))
	if err != nil {
		if a.Logger != nil {
			a.Logger.Warnf("Web subtitle webvtt resolve failed: trackId=%s err=%v", r.PathValue("trackId"), err)
		}
		writeWebSubtitleResolveError(w, err)
		return
	}
	if err := requireWebSubtitleRenderer(*ref, "text"); err != nil {
		writeWebSubtitleLoadError(w, "text", err)
		return
	}
	payload, err := a.webLoadTextSubtitlePayloadCached(r, *ref)
	if err != nil {
		if a.Logger != nil {
			a.Logger.Warnf("Web subtitle webvtt load failed: itemId=%s mediaSourceId=%s streamIndex=%d err=%v",
				ref.ItemID, ref.MediaSourceID, ref.StreamIndex, err)
		}
		writeWebSubtitleLoadError(w, "text", err)
		return
	}
	vtt := webSerializeTextCuesAsVTT(payload.Cues)
	w.Header().Set("Content-Type", "text/vtt; charset=utf-8")
	w.Write(vtt)
}

func webSerializeTextCuesAsVTT(cues []webTextCue) []byte {
	var buf strings.Builder
	buf.WriteString("WEBVTT\n\n")
	for _, cue := range cues {
		buf.WriteString(webFormatVTTTimestamp(cue.StartMs))
		buf.WriteString(" --> ")
		buf.WriteString(webFormatVTTTimestamp(cue.EndMs))
		buf.WriteString("\n")
		for _, line := range cue.Lines {
			buf.WriteString(line)
			buf.WriteString("\n")
		}
		buf.WriteString("\n")
	}
	return []byte(buf.String())
}

func webFormatVTTTimestamp(ms int64) string {
	h := ms / 3600000
	m := (ms % 3600000) / 60000
	s := (ms % 60000) / 1000
	msPart := ms % 1000
	return fmt.Sprintf("%02d:%02d:%02d.%03d", h, m, s, msPart)
}
