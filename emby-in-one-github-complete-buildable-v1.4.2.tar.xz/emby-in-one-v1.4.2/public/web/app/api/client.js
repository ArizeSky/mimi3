function getCsrfToken() {
  if (typeof document === 'undefined') return '';
  const meta = document.querySelector('meta[name="csrf-token"]');
  if (meta) return meta.getAttribute('content');
  const cookie = String(document.cookie || '').split(';').find((c) => c.trim().startsWith('csrf_token='));
  return cookie ? cookie.split('=')[1].trim() : '';
}

function requestHeaders(options = {}) {
  const headers = {
    'Content-Type': 'application/json',
    ...(options.headers || {}),
  };
  if (options.method && options.method !== 'GET') {
    const csrfToken = getCsrfToken();
    if (csrfToken) headers['X-CSRF-Token'] = csrfToken;
  }
  return headers;
}

export async function api(path, options = {}) {
  const controller = new AbortController();
  const timeout = Number.isFinite(options.timeout) ? options.timeout : 30000;
  const timeoutId = timeout > 0 ? setTimeout(() => controller.abort(), timeout) : 0;
  const abortFromCaller = () => controller.abort();
  if (options.signal) {
    if (options.signal.aborted) controller.abort();
    else options.signal.addEventListener('abort', abortFromCaller, { once: true });
  }

  try {
    const response = await fetch(path, {
      method: options.method || 'GET',
      headers: requestHeaders(options),
      body: options.body ? JSON.stringify(options.body) : undefined,
      credentials: 'same-origin',
      signal: controller.signal,
      keepalive: Boolean(options.keepalive),
    });

    if (response.status === 204) return null;
    const payload = await response.json().catch(() => ({}));
    if (!response.ok) {
      const error = new Error(payload.message || `HTTP ${response.status}`);
      error.status = response.status;
      error.payload = payload;
      throw error;
    }
    return payload;
  } finally {
    if (timeoutId) clearTimeout(timeoutId);
    options.signal?.removeEventListener?.('abort', abortFromCaller);
  }
}

export function sendJSONBeacon(path, body) {
  const serialized = JSON.stringify(body || {});
  if (typeof navigator !== 'undefined' && typeof navigator.sendBeacon === 'function') {
    try {
      const payload = typeof Blob === 'function'
        ? new Blob([serialized], { type: 'application/json' })
        : serialized;
      if (navigator.sendBeacon(path, payload)) return true;
    } catch (_error) {
      // Fall through to keepalive fetch.
    }
  }
  fetch(path, {
    method: 'POST',
    headers: requestHeaders({ method: 'POST' }),
    body: serialized,
    credentials: 'same-origin',
    keepalive: true,
  }).catch(() => {});
  return false;
}
