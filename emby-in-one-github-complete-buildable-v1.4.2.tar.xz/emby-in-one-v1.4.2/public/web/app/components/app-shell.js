import { escapeHtml } from '../utils/escape.js';

export function renderAppShell({ title, content, showNav = true, session = null, pageClass = '' }) {
  const showUserMenu = showNav && session && session.username;
  const shellClass = ['app-shell', pageClass].filter(Boolean).join(' ');
  const userMenuLabel = showUserMenu ? escapeHtml(String(session.username).trim().charAt(0).toUpperCase() || '●') : '●';
  return `
    <div class="${shellClass}">
      <header class="topbar">
        <a class="brand" href="/web" data-nav>
          <div class="brand__mark">★</div>
          Emby-In-One
        </a>
        ${showNav ? `
        <nav class="topnav">
          <a href="/web" data-nav>首页</a>
          <a href="/web/search" data-nav>搜索</a>
          <a href="/web/resume" data-nav>继续观看</a>
        </nav>
        ` : ''}
        ${showUserMenu ? `
        <div class="topbar__actions">
          <button type="button" class="user-menu__button" data-user-menu-button aria-expanded="false" aria-haspopup="menu" aria-controls="web-user-menu">${userMenuLabel}</button>
          <div class="user-menu" id="web-user-menu" data-user-menu role="menu" hidden>
            <div class="user-menu__username" data-user-menu-username>${escapeHtml(session.username)}</div>
            <button type="button" class="user-menu__logout" data-user-menu-logout role="menuitem">退出登录</button>
          </div>
        </div>
        ` : ''}
      </header>
      <main class="page-wrap">
        ${title ? `<h1 class="page-title">${escapeHtml(title)}</h1>` : ''}
        ${content}
      </main>
    </div>
  `;
}
