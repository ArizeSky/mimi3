export function renderAuthShell({ content }) {
  return `
    <div class="auth-shell">
      <main class="auth-shell__main">
        <section class="auth-shell__brand">
          <div class="auth-shell__mark">★</div>
          <div class="auth-shell__title-group">
            <h1 class="auth-shell__title">Emby-In-One</h1>
            <p class="auth-shell__subtitle">登录后继续浏览你的内容库</p>
          </div>
        </section>
        <section class="auth-shell__panel">
          ${content}
        </section>
      </main>
    </div>
  `;
}
