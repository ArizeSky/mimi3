import { renderAppShell } from './app-shell.js';

export function renderBrowseShell({ title, content, showNav = true, session = null, pageClass = '' }) {
  return renderAppShell({ title, content, showNav, session, pageClass: `browse-shell ${pageClass}`.trim() });
}
