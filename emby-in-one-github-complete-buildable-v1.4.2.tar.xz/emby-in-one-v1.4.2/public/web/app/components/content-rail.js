import { renderMediaCard } from './media-card.js';
import { escapeAttr, escapeHtml } from '../utils/escape.js';

export function renderContentRailTrack(items, hrefBuilder) {
  return (items || []).map((item) => renderMediaCard(item, hrefBuilder(item))).join('');
}

export function renderContentRail({ id, title, items, hrefBuilder, titleHref = '', prevDisabled = true, nextDisabled = false }) {
  const railId = id || title;
  const safeTitle = escapeHtml(title);
  const heading = titleHref
    ? `<a href="${escapeAttr(titleHref)}" data-nav>${safeTitle}</a>`
    : safeTitle;
  return `
    <section class="content-rail" data-content-rail="${escapeAttr(railId)}">
      <div class="content-rail__header">
        <h2 class="content-rail__title">${heading}</h2>
        <div class="content-rail__controls">
          <button type="button" class="content-rail__control" data-rail-prev="${escapeAttr(railId)}" aria-label="向左浏览" ${prevDisabled ? 'disabled' : ''}>←</button>
          <button type="button" class="content-rail__control" data-rail-next="${escapeAttr(railId)}" aria-label="向右浏览" ${nextDisabled ? 'disabled' : ''}>→</button>
        </div>
      </div>
      <div class="content-rail__viewport" data-rail-viewport="${escapeAttr(railId)}">
        <div class="content-rail__track" data-rail-track="${escapeAttr(railId)}">
          ${renderContentRailTrack(items, hrefBuilder)}
        </div>
      </div>
      <div class="content-rail__status" data-rail-status="${escapeAttr(railId)}"></div>
    </section>
  `;
}

export function renderLibraryEntryArea(views) {
  return `
    <section class="home-library-entries">
      ${(views || []).map((view) => `
        <a class="home-library-entry" href="/web/library/${escapeAttr(view.id)}" data-nav>
          <div class="home-library-entry__title">${escapeHtml(view.name || '')}</div>
          <div class="home-library-entry__meta">媒体库</div>
        </a>
      `).join('')}
    </section>
  `;
}
