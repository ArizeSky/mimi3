import { renderAppShell } from './app-shell.js';

export function renderImmersiveShell(options) {
  return renderAppShell(options);
}
