import { escapeAttr, escapeHtml } from '../utils/escape.js';
import { formatVersionLabel } from '../utils/version-label.js';
import { renderAudioTrackOptions, renderSubtitleTrackOptions } from './track-select-options.js';

export function renderItemSidebar(detail, selection = {}) {
  const item = detail.item || {};
  const versions = detail.versions || [];
  const audioTracks = detail.audioTracks || [];
  const subtitleTracks = detail.subtitleTracks || [];
  const selectedVersion = String(selection.mediaSourceId || versions[0]?.id || '');
  const selectedAudio = selection.audioStreamIndex;
  const selectedSubtitle = selection.subtitleStreamIndex;
  return `
    <aside class="item-sidebar">
      <img class="item-sidebar__image" src="/Items/${escapeAttr(item.Id || item.id || '')}/Images/Primary" alt="${escapeAttr(item.Name || item.name || '')}">
      <h2 class="item-sidebar__title">${escapeHtml(item.Name || item.name || '')}</h2>
      <p class="item-sidebar__overview">${escapeHtml(item.Overview || item.overview || '')}</p>
      <div class="item-sidebar__controls">
        <label class="item-sidebar__field">版本
          <select class="item-sidebar__select" data-selection="mediaSourceId">${versions.map((version) => `<option value="${escapeAttr(version.id)}" ${selectedVersion === String(version.id) ? 'selected' : ''}>${escapeHtml(formatVersionLabel(versions, version))}</option>`).join('')}</select>
        </label>
        <label class="item-sidebar__field">音轨
          <select class="item-sidebar__select" data-selection="audioStreamIndex">${renderAudioTrackOptions(audioTracks, selectedVersion, selectedAudio)}</select>
        </label>
        <label class="item-sidebar__field">字幕
          <select class="item-sidebar__select" data-selection="subtitleStreamIndex">${renderSubtitleTrackOptions(subtitleTracks, selectedVersion, selectedSubtitle)}</select>
        </label>
      </div>
    </aside>
  `;
}
