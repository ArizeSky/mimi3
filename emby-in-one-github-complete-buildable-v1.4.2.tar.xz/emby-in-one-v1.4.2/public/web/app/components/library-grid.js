import { renderMediaCard } from './media-card.js';

export function renderLibraryGrid(items) {
  return `
    <section class="library-grid">
      ${(items || []).map((item) => renderMediaCard(item, item.href || `/web/item/${item.id}`)).join('')}
    </section>
  `;
}
