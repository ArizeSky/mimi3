import { escapeAttr } from '../utils/escape.js';

export function renderLibraryPagination({ libraryId, currentPage, totalPages }) {
  const prevDisabled = currentPage <= 1;
  const nextDisabled = currentPage >= totalPages;
  return `
    <nav class="library-pagination" aria-label="媒体库分页">
      <button type="button" class="library-pagination__button" data-library-page-prev ${prevDisabled ? 'disabled' : ''} data-library-id="${escapeAttr(libraryId)}">上一页</button>
      <div class="library-pagination__status">第 ${currentPage} 页 · 共 ${totalPages} 页</div>
      <button type="button" class="library-pagination__button" data-library-page-next ${nextDisabled ? 'disabled' : ''} data-library-id="${escapeAttr(libraryId)}">下一页</button>
      <div class="library-pagination__jump">
        <input type="number" min="1" class="library-pagination__input" data-library-page-input value="${currentPage}">
        <button type="button" class="library-pagination__button" data-library-page-submit data-library-id="${escapeAttr(libraryId)}">跳转</button>
      </div>
    </nav>
  `;
}
