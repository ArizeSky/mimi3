import { escapeAttr, escapeHtml } from '../utils/escape.js';

export function renderMediaCard(item, href) {
  const meta = [item.subtitle, item.type, item.year ? String(item.year) : ''].filter(Boolean).join(' · ');
  return `
    <a class="media-card" href="${escapeAttr(href)}" data-nav>
      <img class="media-card__image" src="${escapeAttr(item.image || '')}" alt="${escapeAttr(item.name || '')}" loading="lazy">
      <div class="media-card__body">
        <div class="media-card__title">${escapeHtml(item.name || '')}</div>
        <div class="media-card__meta">${escapeHtml(meta)}</div>
      </div>
    </a>
  `;
}
