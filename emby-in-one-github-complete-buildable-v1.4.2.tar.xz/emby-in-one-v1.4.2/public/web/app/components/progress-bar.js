const STATE = { active: false, percent: 0, frame: 0, fadeTimer: 0 };

function ensureBar() {
  if (typeof document === 'undefined' || !document.body) return null;
  let bar = document.getElementById('web-progress-bar');
  if (bar) return bar;
  bar = document.createElement('div');
  bar.id = 'web-progress-bar';
  bar.dataset.webProgressBar = '';
  document.body.appendChild(bar);
  return bar;
}

function paint(percent) {
  const bar = ensureBar();
  if (!bar) return;
  bar.style.width = `${percent}%`;
  bar.style.opacity = '1';
}

function hasWindowFn(name) {
  return typeof window !== 'undefined' && typeof window[name] === 'function';
}

export function start() {
  if (STATE.active) return;
  if (!hasWindowFn('requestAnimationFrame')) return;
  STATE.active = true;
  STATE.percent = 0;
  if (STATE.fadeTimer && hasWindowFn('clearTimeout')) {
    window.clearTimeout(STATE.fadeTimer);
    STATE.fadeTimer = 0;
  }
  paint(0);
  const tick = () => {
    if (!STATE.active) return;
    const ceiling = 80;
    STATE.percent += (ceiling - STATE.percent) * 0.08;
    if (STATE.percent < ceiling - 0.5) {
      paint(STATE.percent);
      STATE.frame = window.requestAnimationFrame(tick);
    } else {
      paint(ceiling);
    }
  };
  STATE.frame = window.requestAnimationFrame(tick);
}

export function done() {
  if (!STATE.active) return;
  STATE.active = false;
  if (STATE.frame && hasWindowFn('cancelAnimationFrame')) {
    window.cancelAnimationFrame(STATE.frame);
  }
  STATE.frame = 0;
  paint(100);
  if (!hasWindowFn('setTimeout')) {
    const bar = ensureBar();
    if (bar) {
      bar.style.opacity = '0';
      bar.style.width = '0%';
    }
    return;
  }
  STATE.fadeTimer = window.setTimeout(() => {
    const bar = ensureBar();
    if (!bar) return;
    bar.style.opacity = '0';
    bar.style.width = '0%';
    STATE.fadeTimer = 0;
  }, 200);
}
