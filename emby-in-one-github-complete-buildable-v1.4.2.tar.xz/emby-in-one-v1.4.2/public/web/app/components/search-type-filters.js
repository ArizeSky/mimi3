import { searchFilterOptions } from '../search/filter-config.js';

export function renderSearchTypeFilters(enabledTypes) {
  const enabled = new Set(enabledTypes || []);
  return `
    <div class="search-filter-bar" data-search-filter-bar>
      ${searchFilterOptions.map((option) => `
        <label class="search-filter-bar__option">
          <input type="checkbox" data-search-filter="${option.type}" value="${option.type}" ${enabled.has(option.type) ? 'checked' : ''}>
          <span>${option.label}</span>
        </label>
      `).join('')}
    </div>
  `;
}
