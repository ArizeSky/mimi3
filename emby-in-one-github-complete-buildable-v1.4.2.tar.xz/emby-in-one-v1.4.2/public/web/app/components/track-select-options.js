import { encodeTrackSelectionValue, tracksForMediaSource } from '../state/selection.js';
import { escapeAttr, escapeHtml } from '../utils/escape.js';

function isSelectedTrack(track, selectedMediaSourceId, selectedStreamIndex) {
  if (!Number.isInteger(selectedStreamIndex) || track?.index !== selectedStreamIndex) return false;
  const trackMediaSourceId = String(track?.mediaSourceId || '');
  return !trackMediaSourceId || trackMediaSourceId === String(selectedMediaSourceId || '');
}

export function renderAudioTrackOptions(tracks, selectedMediaSourceId, selectedStreamIndex) {
  const filtered = tracksForMediaSource(tracks, selectedMediaSourceId);
  const defaultSelected = !Number.isInteger(selectedStreamIndex)
    || !filtered.some((track) => isSelectedTrack(track, selectedMediaSourceId, selectedStreamIndex));
  return [
    `<option value="" ${defaultSelected ? 'selected' : ''}>默认</option>`,
    ...filtered.map((track) => `<option value="${escapeAttr(encodeTrackSelectionValue(track.mediaSourceId || selectedMediaSourceId, track.index))}" ${isSelectedTrack(track, selectedMediaSourceId, selectedStreamIndex) ? 'selected' : ''}>${escapeHtml(track.name || `音轨 ${track.index}`)}</option>`),
  ].join('');
}

export function renderSubtitleTrackOptions(tracks, selectedMediaSourceId, selectedStreamIndex) {
  const filtered = tracksForMediaSource(tracks, selectedMediaSourceId);
  const disabled = !Number.isInteger(selectedStreamIndex)
    || !filtered.some((track) => isSelectedTrack(track, selectedMediaSourceId, selectedStreamIndex));
  return [
    `<option value="" ${disabled ? 'selected' : ''}>关闭</option>`,
    ...filtered.map((track) => `<option value="${escapeAttr(encodeTrackSelectionValue(track.mediaSourceId || selectedMediaSourceId, track.index))}" ${isSelectedTrack(track, selectedMediaSourceId, selectedStreamIndex) ? 'selected' : ''}>${escapeHtml(track.name || `字幕 ${track.index}`)}</option>`),
  ].join('');
}
