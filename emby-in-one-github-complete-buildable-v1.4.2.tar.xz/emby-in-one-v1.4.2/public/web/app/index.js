import { matchWebRoute, navigate } from './router.js';
import { loadViewerSession } from './state/session.js';
import { api } from './api/client.js';
import { renderLoginPage } from './pages/login.js';
import { renderHomePage } from './pages/home.js';
import { renderSearchPage } from './pages/search.js';
import { renderItemPage } from './pages/item.js';
import { renderLibraryPage } from './pages/library.js';
import { renderPlayPage } from './pages/play.js';
import { renderResumePage } from './pages/resume.js';
import { renderNotFoundPage } from './pages/not-found.js';
import { renderAppShell } from './components/app-shell.js';
import { escapeHtml } from './utils/escape.js';
import { start as progressStart, done as progressDone } from './components/progress-bar.js';

export async function applyRenderedPage(app, page) {
  app.innerHTML = page.html;
  if (typeof page.mount === 'function') {
    await page.mount();
  }
}

function closeUserMenu({ restoreFocus = false } = {}) {
  const menu = document.querySelector('[data-user-menu]');
  const button = document.querySelector('[data-user-menu-button]');
  if (menu) menu.hidden = true;
  if (button) {
    button.setAttribute('aria-expanded', 'false');
    if (restoreFocus && typeof button.focus === 'function') button.focus();
  }
}

function toggleUserMenu() {
  const menu = document.querySelector('[data-user-menu]');
  const button = document.querySelector('[data-user-menu-button]');
  if (!menu || !button) return;
  const nextHidden = !menu.hidden;
  menu.hidden = nextHidden;
  button.setAttribute('aria-expanded', String(!nextHidden));
}

function renderErrorPage(session, route, error) {
  const title = route?.page === 'play' ? '播放失败' : '页面加载失败';
  const message = String(error?.payload?.message || error?.message || '页面加载失败，请稍后重试。').trim();
  return renderAppShell({
    title,
    session,
    content: `
      <section class="error-shell">
        <p>${escapeHtml(message || '页面加载失败，请稍后重试。')}</p>
        <p><a href="/web" data-nav>返回首页</a></p>
      </section>
    `,
  });
}

async function render() {
  const app = document.getElementById('web-app');
  if (!app) return;
  progressStart();
  let session = null;
  let current = matchWebRoute(window.location.pathname);
  try {
    session = await loadViewerSession();
    const route = matchWebRoute(window.location.pathname);
    if (!session && route.page !== 'login') {
      window.history.replaceState({}, '', '/web/login');
    }
    current = matchWebRoute(window.location.pathname);
    const renderer = {
      login: renderLoginPage,
      home: renderHomePage,
      search: renderSearchPage,
      item: renderItemPage,
      library: renderLibraryPage,
      play: renderPlayPage,
      resume: renderResumePage,
      'not-found': renderNotFoundPage,
    }[current.page] || renderNotFoundPage;
    const page = await renderer(session, current.params);
    await applyRenderedPage(app, page);
    closeUserMenu();
  } catch (error) {
    app.innerHTML = renderErrorPage(session, current, error);
    closeUserMenu();
  } finally {
    progressDone();
  }
}

if (typeof window !== 'undefined') {
  window.addEventListener('popstate', render);
  window.addEventListener('web:navigate', render);
  document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape') {
      closeUserMenu({ restoreFocus: true });
    }
  });
  document.addEventListener('click', async (event) => {
    const navLink = event.target.closest('[data-nav]');
    if (navLink) {
      const href = navLink.getAttribute('href');
      if (!href || !href.startsWith('/web')) {
        return;
      }
      event.preventDefault();
      navigate(href);
      return;
    }

    const logoutButton = event.target.closest('[data-user-menu-logout]');
    if (logoutButton) {
      event.preventDefault();
      await api('/web/api/logout', { method: 'POST' });
      closeUserMenu();
      navigate('/web/login');
      return;
    }

    const userMenuButton = event.target.closest('[data-user-menu-button]');
    if (userMenuButton) {
      event.preventDefault();
      toggleUserMenu();
      return;
    }

    if (!event.target.closest('[data-user-menu]')) {
      closeUserMenu();
    }
  });
  render();
}
