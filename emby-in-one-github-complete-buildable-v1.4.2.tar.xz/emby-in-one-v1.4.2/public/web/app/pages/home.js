import { api } from '../api/client.js';
import { renderBrowseShell } from '../components/browse-shell.js';
import { renderContentRail, renderContentRailTrack, renderLibraryEntryArea } from '../components/content-rail.js';
import { createHomeRailState } from '../state/home-rails.js';
import { resumePlaybackHref } from '../utils/playback-href.js';

const RAIL_BATCH_SIZE = 12;

function railItemHref(item) {
  return `/web/item/${item.id}`;
}

function renderRailTrackInto(track, items) {
  if (track) track.innerHTML = renderContentRailTrack(items, railItemHref);
}

function syncRailControls(viewport, state, prevButton, nextButton) {
  const scrollLeft = viewport?.scrollLeft || 0;
  const clientWidth = viewport?.clientWidth || 0;
  const scrollWidth = viewport?.scrollWidth || 0;
  const canScrollLeft = scrollLeft > 0;
  const canScrollRight = scrollWidth > 0 && scrollLeft + clientWidth < scrollWidth - 1;

  if (prevButton) prevButton.disabled = !canScrollLeft;
  if (nextButton) nextButton.disabled = !state.hasMore && !canScrollRight;
}

export async function renderHomePage(session) {
  const payload = await api('/web/api/home');
  const views = payload.views || [];
  const railStates = new Map(
    views.map((section) => [section.id, createHomeRailState(section.items || [], RAIL_BATCH_SIZE)]),
  );

  const sections = [
    renderContentRail({
      id: 'resume',
      title: '继续观看',
      items: payload.resume || [],
      hrefBuilder: resumePlaybackHref,
      nextDisabled: true,
    }),
    renderLibraryEntryArea(views),
    ...views.map((section) => renderContentRail({
      id: section.id,
      title: section.name,
      items: section.items || [],
      hrefBuilder: railItemHref,
      titleHref: `/web/library/${section.id}`,
      nextDisabled: false,
    })),
    renderContentRail({
      id: 'latest',
      title: '最新内容',
      items: payload.latest || [],
      hrefBuilder: railItemHref,
      nextDisabled: true,
    }),
    renderContentRail({
      id: 'next-up',
      title: '继续追剧',
      items: payload.nextUp || [],
      hrefBuilder: railItemHref,
      nextDisabled: true,
    }),
  ];

  return {
    html: renderBrowseShell({ title: '首页', content: sections.join(''), session }),
    mount() {
      for (const section of views) {
        const state = railStates.get(section.id);
        const prevButton = document.querySelector(`[data-rail-prev="${section.id}"]`);
        const nextButton = document.querySelector(`[data-rail-next="${section.id}"]`);
        const viewport = document.querySelector(`[data-rail-viewport="${section.id}"]`);
        const track = document.querySelector(`[data-rail-track="${section.id}"]`);
        const status = document.querySelector(`[data-rail-status="${section.id}"]`);
        if (!state || !nextButton || !track) continue;

        syncRailControls(viewport, state, prevButton, nextButton);
        viewport?.addEventListener('scroll', () => {
          syncRailControls(viewport, state, prevButton, nextButton);
        });

        prevButton?.addEventListener('click', (event) => {
          event.preventDefault();
          viewport?.scrollBy({ left: -Math.max(320, viewport?.clientWidth || 0) });
          syncRailControls(viewport, state, prevButton, nextButton);
        });

        nextButton.addEventListener('click', async (event) => {
          event.preventDefault();
          const scrollLeft = viewport?.scrollLeft || 0;
          const clientWidth = viewport?.clientWidth || 0;
          const scrollWidth = viewport?.scrollWidth || 0;
          const canScrollRight = scrollWidth > 0 && scrollLeft + clientWidth < scrollWidth - 1;

          if (canScrollRight) {
            viewport?.scrollBy({ left: Math.max(320, viewport?.clientWidth || 0) });
            syncRailControls(viewport, state, prevButton, nextButton);
            return;
          }

          if (state.loading || !state.hasMore) return;
          state.startLoading();
          if (status) status.textContent = '加载中...';

          try {
            const nextPayload = await api(`/web/api/libraries/${section.id}?offset=${state.offset}&limit=${RAIL_BATCH_SIZE}`);
            state.appendBatch(nextPayload.items || [], nextPayload.hasMore);
            renderRailTrackInto(track, state.items);
            if (status) status.textContent = '';
            viewport?.scrollBy({ left: Math.max(320, viewport?.clientWidth || 0) });
            syncRailControls(viewport, state, prevButton, nextButton);
          } catch (_error) {
            state.setError();
            if (status) status.textContent = state.error;
            syncRailControls(viewport, state, prevButton, nextButton);
          }
        });
      }
    },
  };
}

export { createHomeRailState, syncRailControls };
