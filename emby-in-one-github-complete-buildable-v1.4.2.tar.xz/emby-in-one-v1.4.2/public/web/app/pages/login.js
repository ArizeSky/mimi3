import { api } from '../api/client.js';
import { renderAuthShell } from '../components/auth-shell.js';
import { navigate } from '../router.js';

export function renderLoginPage() {
  return {
    html: renderAuthShell({
      content: `
        <form class="login-form" data-login-form>
          <div class="error" data-login-error></div>
          <label>用户名<input name="username" type="text" required></label>
          <label>密码<input name="password" type="password" required></label>
          <button type="submit">登录</button>
        </form>
      `,
    }),
    mount() {
      const form = document.querySelector('[data-login-form]');
      form?.addEventListener('submit', async (event) => {
        event.preventDefault();
        const formData = new FormData(form);
        const errorBox = document.querySelector('[data-login-error]');
        if (errorBox) errorBox.textContent = '';
        try {
          await api('/web/api/login', {
            method: 'POST',
            body: {
              username: formData.get('username'),
              password: formData.get('password'),
            },
          });
          navigate('/web');
        } catch (error) {
          if (errorBox) errorBox.textContent = error.message;
        }
      });
    },
  };
}
