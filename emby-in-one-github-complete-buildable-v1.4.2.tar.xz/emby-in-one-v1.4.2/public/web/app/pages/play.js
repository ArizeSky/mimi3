import { api } from '../api/client.js';
import { renderImmersiveShell } from '../components/immersive-shell.js';
import { renderPlayerShell } from '../components/player-shell.js';
import { attachPlayer } from '../player/hls-player.js';
import { applyPlaybackRate, getSavedPlaybackRate, savePlaybackRate } from '../player/playback-rate.js';
import { createPlaybackReporter } from '../player/playback-session.js';
import { createIOSNativeSubtitleTrackAdapter } from '../player/subtitles/ios-native-track.js';
import { createTextOverlayRenderer } from '../player/subtitles/text-overlay-renderer.js';
import { loadTextSubtitle } from '../player/subtitles/text-resource-client.js';
import { navigate } from '../router.js';
import { nextSelection, parseTrackSelectionValue, toPlaybackQuery } from '../state/selection.js';
import { start as progressStart } from '../components/progress-bar.js';

const TICKS_PER_SECOND = 10000000;

function resolveSelectionMediaSourceID(playback, selection) {
  return selection.mediaSourceId
    || playback.selection?.mediaSourceId
    || playback.versions?.[0]?.id
    || playback.sources?.[0]?.mediaSourceId
    || playback.source?.mediaSourceId
    || playback.subtitleTracks?.[0]?.mediaSourceId
    || '';
}

function replaceSelection(target, next) {
  Object.keys(target).forEach((key) => delete target[key]);
  Object.assign(target, next);
}

function normalizePlaybackSelection(playback, selection) {
  const next = nextSelection(selection, {});
  const mediaSourceId = resolveSelectionMediaSourceID(playback, next);
  if (mediaSourceId) next.mediaSourceId = mediaSourceId;
  if (!Number.isInteger(next.audioStreamIndex) || next.audioStreamIndex < 0) delete next.audioStreamIndex;
  if (!Number.isInteger(next.subtitleStreamIndex) || next.subtitleStreamIndex < 0) delete next.subtitleStreamIndex;
  return next;
}

function resolveSelectedSubtitleTrack(playback, selection) {
  const subtitleTracks = playback.subtitleTracks || [];
  if (!subtitleTracks.length || !Number.isInteger(selection.subtitleStreamIndex)) return null;
  const mediaSourceId = resolveSelectionMediaSourceID(playback, selection);
  const scoped = subtitleTracks.filter((track) => String(track.mediaSourceId || '') === String(mediaSourceId || ''));
  const candidates = scoped.length ? scoped : subtitleTracks.filter((track) => !track.mediaSourceId);
  return candidates.find((track) => track.index === selection.subtitleStreamIndex) || null;
}

function syncSubtitleTrack(video, subtitleTrack) {
  if (!video?.querySelectorAll || typeof document === 'undefined' || typeof document.createElement !== 'function') return;
  video.querySelectorAll('track[data-player-subtitle-track]').forEach((track) => track.remove());
  if (!subtitleTrack?.url) return;
  const track = document.createElement('track');
  track.dataset.playerSubtitleTrack = 'true';
  track.kind = 'subtitles';
  track.label = subtitleTrack.name || '字幕';
  track.srclang = subtitleTrack.language || 'zh';
  track.src = subtitleTrack.url;
  track.default = true;
  video.appendChild(track);
  if (track.track && 'mode' in track.track) track.track.mode = 'showing';
}

function playbackSources(payload) {
  return [
    ...(Array.isArray(payload?.sources) ? payload.sources : []),
    payload?.source,
  ].filter(Boolean);
}

function selectedResumeTicks(playback, query) {
  const candidates = [
    query.get('resumePositionTicks'),
    playback.resumePositionTicks,
    playback.resumePosition,
  ];
  for (const candidate of candidates) {
    const ticks = Number(candidate);
    if (Number.isFinite(ticks) && ticks > 0) return Math.trunc(ticks);
  }
  return 0;
}

function createDeferredSeek(video, seconds) {
  let applied = false;
  const apply = () => {
    if (applied || !Number.isFinite(seconds) || seconds <= 0) return;
    try {
      const duration = Number(video?.duration);
      const safeSeconds = Number.isFinite(duration) && duration > 0
        ? Math.min(seconds, Math.max(0, duration - 0.25))
        : seconds;
      video.currentTime = safeSeconds;
      applied = true;
    } catch (_error) {
      // Metadata may not be ready yet; loadedmetadata will retry.
    }
  };
  video?.addEventListener?.('loadedmetadata', apply);
  return {
    apply,
    dispose() {
      video?.removeEventListener?.('loadedmetadata', apply);
    },
  };
}

function setMessage(selector, message) {
  const element = document.querySelector(selector);
  if (!element) return;
  element.textContent = message || '';
  element.hidden = !message;
}

function setPlaybackStatus(message) {
  setMessage('[data-player-status]', message);
}

function setPlaybackError(message) {
  setMessage('[data-player-error]', message);
}

async function requestBurninFallback(playback, subtitleTrack, sessionId, audioStreamIndex, reason = '', signal) {
  if (!subtitleTrack?.id) return null;
  const body = { sessionId: sessionId || '' };
  if (Number.isInteger(audioStreamIndex) && audioStreamIndex >= 0) {
    body.audioStreamIndex = audioStreamIndex;
  }
  if (reason) body.reason = reason;
  return api(`/web/api/items/${encodeURIComponent(playback.itemId)}/subtitles/${encodeURIComponent(subtitleTrack.id)}/fallback-stream`, {
    method: 'POST',
    body,
    signal,
  });
}

function resolvePlaybackMountPlan(playback, selection) {
  const subtitleTrack = resolveSelectedSubtitleTrack(playback, selection);
  if (!subtitleTrack) return { subtitleTrack: null, rendererKind: null, requiresBurnin: false };
  if (subtitleTrack.rendererKind === 'text') {
    return { subtitleTrack, rendererKind: 'text', requiresBurnin: false };
  }
  if (subtitleTrack.rendererKind === 'ass'
    || subtitleTrack.rendererKind === 'bitmap'
    || subtitleTrack.rendererKind === 'burnin') {
    return { subtitleTrack, rendererKind: subtitleTrack.rendererKind, requiresBurnin: true };
  }
  return { subtitleTrack, rendererKind: null, requiresBurnin: false };
}

function bindPlaybackRate(video, initialRate) {
  const savedRate = applyPlaybackRate(video, initialRate);
  const rateSelect = document.querySelector('[data-player-rate]');
  if (!rateSelect) return;
  rateSelect.value = String(savedRate);
  rateSelect.addEventListener('change', (event) => {
    const applied = applyPlaybackRate(video, event.target.value);
    event.target.value = String(applied);
    savePlaybackRate(applied);
  });
}

function bindSelectionControls(selection, closePlayback, itemId) {
  const navigateToSelection = (patch, { resetTracks = false } = {}) => {
    const nextPatch = resetTracks
      ? { ...patch, audioStreamIndex: undefined, subtitleStreamIndex: undefined }
      : patch;
    replaceSelection(selection, nextSelection(selection, nextPatch));
    closePlayback({ reason: 'selection-change' });
    progressStart();
    const query = toPlaybackQuery(selection).toString();
    const basePath = `/web/play/${encodeURIComponent(itemId)}`;
    navigate(query ? `${basePath}?${query}` : basePath);
  };

  document.querySelector('[data-player-version]')?.addEventListener('change', (event) => {
    navigateToSelection({ mediaSourceId: event.target.value }, { resetTracks: true });
  });
  document.querySelector('[data-player-audio]')?.addEventListener('change', (event) => {
    const parsed = parseTrackSelectionValue(event.target.value);
    navigateToSelection({
      mediaSourceId: parsed?.mediaSourceId || selection.mediaSourceId,
      audioStreamIndex: parsed?.streamIndex,
    });
  });
  document.querySelector('[data-player-subtitle]')?.addEventListener('change', (event) => {
    const parsed = parseTrackSelectionValue(event.target.value);
    navigateToSelection({
      mediaSourceId: parsed?.mediaSourceId || selection.mediaSourceId,
      subtitleStreamIndex: parsed?.streamIndex,
    });
  });
}

function bindEpisodeNavigation(playback, navigateWithSelection) {
  document.querySelector('[data-player-prev]')?.addEventListener('click', (event) => {
    event.preventDefault();
    if (!playback.previousEpisode?.id) return;
    progressStart();
    navigateWithSelection(playback.previousEpisode.id).catch(() => {});
  });
  document.querySelector('[data-player-next]')?.addEventListener('click', (event) => {
    event.preventDefault();
    if (!playback.nextEpisode?.id) return;
    progressStart();
    navigateWithSelection(playback.nextEpisode.id).catch(() => {});
  });
}

function bindPlaybackLifecycle(video, reporter, closePlayback) {
  const cleanups = [];
  const listen = (target, type, listener, options) => {
    if (typeof target?.addEventListener !== 'function') return;
    target.addEventListener(type, listener, options);
    cleanups.push(() => target.removeEventListener?.(type, listener, options));
  };

  listen(window, 'beforeunload', () => closePlayback({ unloading: true, reason: 'beforeunload' }));
  listen(window, 'pagehide', () => closePlayback({ unloading: true, reason: 'pagehide' }));
  listen(window, 'web:navigate', () => closePlayback({ reason: 'navigate' }));
  listen(video, 'playing', () => reporter.started().catch(() => {}));
  listen(video, 'pause', () => reporter.progress('pause').catch(() => {}));
  listen(video, 'seeked', () => reporter.progress('seeked').catch(() => {}));
  listen(video, 'ended', async () => {
    try {
      await reporter.progress('ended');
    } catch (_error) {
      // A failed final progress report must not prevent the stop/release event.
    }
    closePlayback({ isEnded: true, reason: 'ended' });
  });
  return () => cleanups.splice(0).forEach((cleanup) => cleanup());
}

function startTextSubtitleRuntime(video, overlayHost, subtitleTrack, switchToFallback) {
  const abortController = new AbortController();
  let disposed = false;
  let overlayRenderer = null;
  let overlayTimeUpdate = null;
  let nativeAdapter = null;

  const cleanup = () => {
    if (disposed) return;
    disposed = true;
    abortController.abort();
    if (overlayTimeUpdate) video?.removeEventListener?.('timeupdate', overlayTimeUpdate);
    overlayRenderer?.dispose();
    nativeAdapter?.dispose();
  };

  const ready = Promise.resolve().then(async () => {
    if (!overlayHost) {
      await switchToFallback('renderer-disposed-before-ready');
      return;
    }
    overlayRenderer = createTextOverlayRenderer();
    overlayRenderer.attach(video, overlayHost);
    nativeAdapter = createIOSNativeSubtitleTrackAdapter({ documentRef: document, overlayHost });
    nativeAdapter.onNativeTrackFailed = (reason) => {
      switchToFallback(reason).catch(() => {});
    };
    nativeAdapter.attach(video, subtitleTrack);

    try {
      const payload = await loadTextSubtitle(subtitleTrack.id, { signal: abortController.signal });
      if (disposed) return;
      if (!Array.isArray(payload?.cues)) throw new Error('Invalid subtitle cue payload');
      overlayRenderer.load(payload.cues);
      overlayTimeUpdate = () => overlayRenderer.sync(Number(video?.currentTime || 0) * 1000);
      overlayTimeUpdate();
      video?.addEventListener?.('timeupdate', overlayTimeUpdate, { passive: true });
    } catch (error) {
      if (disposed || error?.name === 'AbortError') return;
      console.warn('字幕加载失败:', error);
      await switchToFallback('text-cue-load-failed');
    }
  });

  return { cleanup, ready };
}

export async function renderPlayPage(session, params) {
  const query = new URLSearchParams(window.location.search);
  const playback = await api(`/web/api/items/${encodeURIComponent(params.itemId)}/playback?${query.toString()}`);
  const selection = normalizePlaybackSelection(playback, { ...(playback.selection || {}) });
  const initialRate = getSavedPlaybackRate();
  const resumeTicks = selectedResumeTicks(playback, query);
  return {
    html: renderImmersiveShell({
      title: '播放',
      session,
      content: renderPlayerShell({ ...playback, playbackRate: initialRate, selection }),
    }),
    async mount() {
      const video = document.querySelector('[data-player]');
      if (!video) return;
      const overlayHost = document.querySelector('[data-subtitle-overlay]');
      const playbackPlan = resolvePlaybackMountPlan(playback, selection);
      const reporter = createPlaybackReporter({
        itemId: playback.itemId || params.itemId,
        sessionId: playback.sessionId,
        mediaSourceId: selection.mediaSourceId,
        video,
      });
      let closed = false;
      let cleanupPlayer = () => {};
      let cleanupSeek = () => {};
      let cleanupSubtitleRuntime = () => {};
      let cleanupLifecycle = () => {};
      let timer = 0;
      let fallbackStarted = false;
      const fallbackController = new AbortController();

      const closePlayback = ({ unloading = false, isEnded = false, reason = 'stop' } = {}) => {
        if (closed) return;
        closed = true;
        window.clearInterval?.(timer);
        cleanupLifecycle();
        fallbackController.abort();
        cleanupSubtitleRuntime();
        reporter.stop({ unloading, isEnded, reason }).catch(() => {});
        cleanupSeek();
        cleanupPlayer();
      };

      const attachSourceSet = (sources, resumeSeconds, statusMessage = '正在加载视频…') => {
        cleanupSeek();
        cleanupPlayer();
        setPlaybackError('');
        setPlaybackStatus(statusMessage);
        const deferredSeek = createDeferredSeek(video, resumeSeconds);
        cleanupSeek = deferredSeek.dispose;
        cleanupPlayer = attachPlayer(video, sources, {
          onSourceChange(source) {
            reporter.setMediaSource(source.mediaSourceId || selection.mediaSourceId);
          },
          onReady() {
            deferredSeek.apply();
            setPlaybackStatus('');
          },
          onWarning(data) {
            console.warn('HLS 播放警告:', data?.details || data?.type || data);
          },
          onError(error) {
            setPlaybackStatus('');
            setPlaybackError(error?.message || '视频加载失败，请稍后重试。');
            reporter.stop({ reason: 'source-error' }).catch(() => {});
          },
        });
      };

      const switchToSubtitleFallback = async (reason = '') => {
        if (fallbackStarted || closed || !playbackPlan.subtitleTrack) return;
        fallbackStarted = true;
        cleanupSubtitleRuntime();
        cleanupSubtitleRuntime = () => {};
        syncSubtitleTrack(video, null);
        setPlaybackStatus('正在准备兼容字幕（服务端转码）…');
        try {
          const resumeSeconds = Number(video.currentTime || (resumeTicks / TICKS_PER_SECOND));
          const fallback = await requestBurninFallback(
            playback,
            playbackPlan.subtitleTrack,
            reporter.sessionId,
            selection.audioStreamIndex,
            reason,
            fallbackController.signal,
          );
          if (closed) return;
          await reporter.replaceSession(fallback?.sessionId, fallback?.mediaSourceId);
          const sources = playbackSources(fallback);
          if (!sources.length) throw new Error('兼容字幕转码未返回可用播放源');
          attachSourceSet(sources, resumeSeconds, '兼容字幕已启用，正在加载视频…');
        } catch (error) {
          if (closed || error?.name === 'AbortError') return;
          console.warn('字幕 fallback 失败:', error);
          setPlaybackStatus('');
          setPlaybackError(`字幕加载失败：${error?.message || '无法启动兼容字幕转码'}`);
        }
      };

      cleanupLifecycle = bindPlaybackLifecycle(video, reporter, closePlayback);
      timer = window.setInterval?.(() => {
        if (closed || video.paused || video.ended) return;
        reporter.progress('interval').catch(() => {});
      }, 10000) || 0;
      bindPlaybackRate(video, initialRate);
      bindSelectionControls(selection, closePlayback, params.itemId);
      bindEpisodeNavigation(playback, async (episodeId) => {
        const response = await api(`/web/api/items/${encodeURIComponent(params.itemId)}/select`, {
          method: 'POST',
          body: { ...selection, episodeId },
        });
        closePlayback({ reason: 'episode-change' });
        navigate(response.playPath);
      });

      if (playbackPlan.requiresBurnin) {
        await switchToSubtitleFallback();
        return;
      }

      attachSourceSet(playbackSources(playback), resumeTicks / TICKS_PER_SECOND);
      if (playbackPlan.rendererKind === 'text' && playbackPlan.subtitleTrack) {
        const runtime = startTextSubtitleRuntime(
          video,
          overlayHost,
          playbackPlan.subtitleTrack,
          switchToSubtitleFallback,
        );
        cleanupSubtitleRuntime = runtime.cleanup;
        await runtime.ready;
      } else {
        syncSubtitleTrack(video, playbackPlan.subtitleTrack);
      }
    },
  };
}
