import { api } from '../api/client.js';
import { renderBrowseShell } from '../components/browse-shell.js';
import { renderLibraryGrid } from '../components/library-grid.js';
import { resumePlaybackHref } from '../utils/playback-href.js';

function withResumeHrefs(items) {
  return (items || []).map((item) => ({ ...item, href: resumePlaybackHref(item) }));
}

export async function renderResumePage(session) {
  const payload = await api('/web/api/resume');
  return {
    html: renderBrowseShell({
      title: '继续观看',
      session,
      content: renderLibraryGrid(withResumeHrefs(payload.items || [])),
    }),
  };
}
