const HLS_MIME_TYPES = [
  'application/vnd.apple.mpegurl',
  'application/x-mpegURL',
];

const DIRECT_MIME_BY_CONTAINER = {
  mp4: 'video/mp4',
  m4v: 'video/mp4',
  mov: 'video/mp4',
  webm: 'video/webm',
  ogv: 'video/ogg',
  ogg: 'video/ogg',
  mp3: 'audio/mpeg',
  m4a: 'audio/mp4',
  aac: 'audio/aac',
  wav: 'audio/wav',
  flac: 'audio/flac',
};

function globalHls() {
  return typeof window !== 'undefined' ? window.Hls : null;
}

function normalizeSources(sources) {
  const list = Array.isArray(sources) ? sources : [sources];
  const seen = new Set();
  return list.filter((source) => {
    const url = String(source?.url || '');
    const kind = String(source?.kind || '').toLowerCase();
    const pathname = url.split(/[?#]/, 1)[0].toLowerCase();
    if (!url || kind === 'dash' || pathname.endsWith('.mpd') || seen.has(url)) return false;
    seen.add(url);
    return true;
  });
}

function sourceContainer(source) {
  if (source?.container) return String(source.container).toLowerCase();
  const pathname = String(source?.url || '').split(/[?#]/, 1)[0];
  const dot = pathname.lastIndexOf('.');
  return dot >= 0 ? pathname.slice(dot + 1).toLowerCase() : '';
}

function directMimeType(source) {
  if (source?.mimeType) return String(source.mimeType);
  return DIRECT_MIME_BY_CONTAINER[sourceContainer(source)] || '';
}

export function canPlayNativeHls(video) {
  if (!video || typeof video.canPlayType !== 'function') return true;
  return HLS_MIME_TYPES.some((mime) => Boolean(video.canPlayType(mime)));
}

function canUseHlsJs() {
  const Hls = globalHls();
  return Boolean(Hls && typeof Hls.isSupported === 'function' && Hls.isSupported());
}

function directSupportScore(video, source) {
  if (!video || typeof video.canPlayType !== 'function') return 1;
  const mimeType = directMimeType(source);
  if (!mimeType) return 1;
  const result = video.canPlayType(mimeType);
  if (result === 'probably') return 3;
  if (result === 'maybe') return 2;
  return 0;
}

export function orderPlaybackSources(sources, video) {
  const list = normalizeSources(sources);
  const hlsAvailable = canPlayNativeHls(video) || canUseHlsJs();
  return list
    .map((source, index) => {
      let rank = 1;
      if (source.kind === 'direct') {
        const support = directSupportScore(video, source);
        rank = support > 1 ? 50 + support : support === 1 ? 20 : 5;
      } else if (source.kind === 'hls') {
        rank = hlsAvailable ? 40 : 0;
      }
      return { source, index, rank };
    })
    .sort((left, right) => right.rank - left.rank || left.index - right.index)
    .map(({ source }) => source);
}

export function pickPreferredSource(sources, video) {
  return orderPlaybackSources(sources, video)[0] || null;
}

function playableError(message, cause) {
  const error = new Error(message);
  error.name = 'PlaybackSourceError';
  if (cause) error.cause = cause;
  return error;
}

export function attachPlayer(video, sources, callbacks = {}) {
  if (!video) return () => {};
  const orderedSources = orderPlaybackSources(sources, video);
  let disposed = false;
  let hls = null;
  let currentSource = null;
  let currentListeners = [];

  const removeCurrentListeners = () => {
    currentListeners.forEach(([target, type, listener]) => {
      target?.removeEventListener?.(type, listener);
    });
    currentListeners = [];
  };

  const listen = (target, type, listener, options) => {
    if (typeof target?.addEventListener !== 'function') return;
    target.addEventListener(type, listener, options);
    currentListeners.push([target, type, listener]);
  };

  const resetMedia = () => {
    removeCurrentListeners();
    if (hls) {
      try { hls.destroy(); } catch (_error) { /* no-op */ }
      hls = null;
    }
    try { video.pause?.(); } catch (_error) { /* no-op */ }
    try { video.removeAttribute?.('src'); } catch (_error) { /* no-op */ }
    try { video.load?.(); } catch (_error) { /* no-op */ }
  };

  const tryPlay = () => {
    try {
      const result = video.play?.();
      result?.catch?.(() => {});
    } catch (_error) {
      // Autoplay rejection is not a media-source failure.
    }
  };

  const emitReady = (source) => {
    callbacks.onReady?.(source);
    tryPlay();
  };

  const exhaust = (lastError) => {
    resetMedia();
    const error = playableError(
      orderedSources.length
        ? '所有可用播放源均加载失败，请尝试切换版本或稍后重试。'
        : '没有可用的播放源。',
      lastError,
    );
    callbacks.onError?.(error, { source: currentSource, sources: orderedSources });
  };

  const mountSource = (sourceIndex, nativeAttempt = 0, previousError = null) => {
    if (disposed) return;
    resetMedia();
    const source = orderedSources[sourceIndex];
    if (!source) {
      exhaust(previousError);
      return;
    }
    currentSource = source;
    callbacks.onSourceChange?.(source, sourceIndex);

    const advance = (error) => {
      if (disposed) return;
      mountSource(sourceIndex + 1, 0, error);
    };

    if (source.kind === 'hls' && !canPlayNativeHls(video)) {
      const Hls = globalHls();
      if (!Hls || typeof Hls.isSupported !== 'function' || !Hls.isSupported()) {
        advance(playableError('当前浏览器不支持 HLS 播放。'));
        return;
      }
      let networkRecoveryCount = 0;
      let mediaRecoveryCount = 0;
      hls = new Hls({
        manifestLoadingMaxRetry: 2,
        levelLoadingMaxRetry: 2,
        fragLoadingMaxRetry: 2,
        manifestLoadingRetryDelay: 500,
        levelLoadingRetryDelay: 500,
        fragLoadingRetryDelay: 500,
      });
      hls.on(Hls.Events.MANIFEST_PARSED, () => {
        callbacks.onAudioTracks?.(hls.audioTracks || []);
        callbacks.onSubtitleTracks?.(hls.subtitleTracks || []);
        emitReady(source);
      });
      hls.on(Hls.Events.ERROR, (_event, data = {}) => {
        if (!data.fatal) {
          callbacks.onWarning?.(data);
          return;
        }
        if (data.type === Hls.ErrorTypes.NETWORK_ERROR && networkRecoveryCount < 1) {
          networkRecoveryCount += 1;
          hls.startLoad?.();
          return;
        }
        if (data.type === Hls.ErrorTypes.MEDIA_ERROR && mediaRecoveryCount < 1) {
          mediaRecoveryCount += 1;
          hls.recoverMediaError?.();
          return;
        }
        advance(playableError(`HLS 加载失败：${data.details || data.type || 'unknown'}`));
      });
      try {
        hls.attachMedia(video);
        hls.loadSource(source.url);
      } catch (error) {
        advance(error);
      }
      return;
    }

    const onReady = () => emitReady(source);
    const onError = () => {
      const error = playableError(`播放源加载失败：${source.url}`);
      if (nativeAttempt < 1) {
        mountSource(sourceIndex, nativeAttempt + 1, error);
      } else {
        advance(error);
      }
    };
    listen(video, 'loadedmetadata', onReady, { once: true });
    listen(video, 'canplay', onReady, { once: true });
    listen(video, 'error', onError, { once: true });
    try {
      video.src = source.url;
      video.load?.();
      if (Number(video.readyState) >= 1) emitReady(source);
    } catch (error) {
      onError(error);
    }
  };

  mountSource(0);
  return () => {
    if (disposed) return;
    disposed = true;
    resetMedia();
  };
}
