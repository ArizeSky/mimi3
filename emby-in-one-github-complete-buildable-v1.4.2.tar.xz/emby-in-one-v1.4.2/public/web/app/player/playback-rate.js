export const playbackRates = [0.5, 0.75, 1, 1.25, 1.5, 1.75, 2];

const playbackRateStorageKey = 'web:player:rate';

function normalizePlaybackRate(rate) {
  const parsed = Number(rate);
  return playbackRates.includes(parsed) ? parsed : 1;
}

export function getSavedPlaybackRate() {
  if (typeof window === 'undefined' || !window.localStorage) {
    return 1;
  }
  return normalizePlaybackRate(window.localStorage.getItem(playbackRateStorageKey));
}

export function savePlaybackRate(rate) {
  const normalized = normalizePlaybackRate(rate);
  if (typeof window !== 'undefined' && window.localStorage) {
    window.localStorage.setItem(playbackRateStorageKey, String(normalized));
  }
  return normalized;
}

export function applyPlaybackRate(video, rate) {
  if (!video) {
    return 1;
  }
  const normalized = normalizePlaybackRate(rate);
  video.playbackRate = normalized;
  return normalized;
}
