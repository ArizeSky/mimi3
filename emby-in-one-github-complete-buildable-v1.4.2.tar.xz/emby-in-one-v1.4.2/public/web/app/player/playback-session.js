import { api, sendJSONBeacon } from '../api/client.js';

const TICKS_PER_SECOND = 10000000;

export function playbackReportPath(itemId, sessionId, suffix) {
  if (sessionId) return `/web/api/sessions/${encodeURIComponent(sessionId)}/${suffix}`;
  return `/web/api/items/${encodeURIComponent(itemId)}/${suffix}`;
}

function mediaTicks(seconds) {
  const value = Number(seconds);
  return Number.isFinite(value) && value > 0 ? Math.round(value * TICKS_PER_SECOND) : 0;
}

export function createPlaybackReporter({ itemId, sessionId = '', mediaSourceId = '', video }) {
  let activeSessionId = String(sessionId || '');
  let activeMediaSourceId = String(mediaSourceId || '');
  const startedSessions = new Set();
  const startingSessions = new Map();
  const stoppedSessions = new Set();

  const sessionKey = (value) => String(value || `item:${itemId}`);
  const bodyFor = (targetSessionId, targetMediaSourceId, extra = {}) => ({
    itemId,
    mediaSourceId: targetMediaSourceId,
    positionTicks: mediaTicks(video?.currentTime),
    runTimeTicks: mediaTicks(video?.duration),
    playSessionId: String(targetSessionId || ''),
    ...extra,
  });

  const send = (suffix, {
    targetSessionId = activeSessionId,
    targetMediaSourceId = activeMediaSourceId,
    unloading = false,
    extra = {},
  } = {}) => {
    const path = playbackReportPath(itemId, targetSessionId, suffix);
    const body = bodyFor(targetSessionId, targetMediaSourceId, extra);
    if (unloading) {
      sendJSONBeacon(path, body);
      return Promise.resolve();
    }
    return api(path, { method: 'POST', body, keepalive: suffix === 'stop' });
  };

  return {
    get sessionId() {
      return activeSessionId;
    },

    get mediaSourceId() {
      return activeMediaSourceId;
    },

    setMediaSource(mediaSourceIdValue) {
      if (mediaSourceIdValue) activeMediaSourceId = String(mediaSourceIdValue);
    },

    started() {
      const key = sessionKey(activeSessionId);
      if (startedSessions.has(key) || stoppedSessions.has(key)) return Promise.resolve();
      if (startingSessions.has(key)) return startingSessions.get(key);
      const targetSessionId = activeSessionId;
      const targetMediaSourceId = activeMediaSourceId;
      const pending = send('started', {
        targetSessionId,
        targetMediaSourceId,
        extra: { eventName: 'playing' },
      }).then(() => {
        if (!stoppedSessions.has(key)) startedSessions.add(key);
      }).finally(() => {
        startingSessions.delete(key);
      });
      startingSessions.set(key, pending);
      return pending;
    },

    progress(eventName = 'progress') {
      const key = sessionKey(activeSessionId);
      if (stoppedSessions.has(key)) return Promise.resolve();
      const targetSessionId = activeSessionId;
      const targetMediaSourceId = activeMediaSourceId;
      const sendProgress = () => {
        if (stoppedSessions.has(key) || !startedSessions.has(key)) return Promise.resolve();
        return send('progress', {
          targetSessionId,
          targetMediaSourceId,
          extra: {
            eventName,
            isPaused: Boolean(video?.paused),
          },
        });
      };
      if (startedSessions.has(key)) return sendProgress();
      const starting = startingSessions.get(key);
      return starting ? starting.then(sendProgress).catch(() => {}) : Promise.resolve();
    },

    stop({ unloading = false, isEnded = false, reason = 'stop' } = {}) {
      const key = sessionKey(activeSessionId);
      if (stoppedSessions.has(key)) return Promise.resolve();
      stoppedSessions.add(key);
      return send('stop', {
        unloading,
        extra: { eventName: reason, isEnded },
      });
    },

    async replaceSession(nextSessionId, nextMediaSourceId = '') {
      const normalized = String(nextSessionId || '');
      if (!normalized || normalized === activeSessionId) {
        if (nextMediaSourceId) activeMediaSourceId = String(nextMediaSourceId);
        return;
      }
      const previousSessionId = activeSessionId;
      const previousMediaSourceId = activeMediaSourceId;
      if (previousSessionId) {
        const previousKey = sessionKey(previousSessionId);
        if (!stoppedSessions.has(previousKey)) {
          stoppedSessions.add(previousKey);
          await send('stop', {
            targetSessionId: previousSessionId,
            targetMediaSourceId: previousMediaSourceId,
            extra: { eventName: 'session-replaced', isEnded: false },
          }).catch(() => {});
        }
      }
      activeSessionId = normalized;
      if (nextMediaSourceId) activeMediaSourceId = String(nextMediaSourceId);
    },
  };
}
