/**
 * 在 DOM 字幕不可见的原生全屏、画中画与 AirPlay 场景中临时启用 WebVTT。
 * 适配器只创建一个 <track>，不预取同一 URL，且用代次令牌避免异步退出竞态。
 */
export function createIOSNativeSubtitleTrackAdapter({
    documentRef = typeof document !== 'undefined' ? document : null,
    overlayHost = null,
} = {}) {
    let video = null;
    let subtitleTrack = null;
    let trackElement = null;
    let onFail = null;
    let onVisibilityChange = null;
    let generation = 0;
    let disposed = false;
    const activeModes = new Set();
    const listeners = [];

    function listen(target, type, listener) {
        if (typeof target?.addEventListener !== 'function') return;
        target.addEventListener(type, listener);
        listeners.push([target, type, listener]);
    }

    function setOverlayHidden(hidden) {
        if (overlayHost) overlayHost.hidden = Boolean(hidden);
        onVisibilityChange?.(Boolean(hidden));
    }

    function removeTrackElement() {
        generation += 1;
        const current = trackElement;
        trackElement = null;
        if (!current) return;
        try {
            if (current.track && 'mode' in current.track) current.track.mode = 'disabled';
        } catch (_error) { /* no-op */ }
        if (current.parentNode?.removeChild) current.parentNode.removeChild(current);
        else if (video?.removeChild) {
            try { video.removeChild(current); } catch (_error) { /* no-op */ }
        } else {
            current.remove?.();
        }
    }

    function failureReason() {
        if (activeModes.has('pip') || activeModes.has('airplay')) {
            return 'pip-airplay-overlay-unavailable';
        }
        return 'ios-native-track-error';
    }

    function ensureNativeTrack() {
        if (disposed || !video || !subtitleTrack?.id || trackElement || !documentRef?.createElement) return;
        const currentGeneration = generation + 1;
        generation = currentGeneration;
        const vttUrl = `/web/api/subtitles/${encodeURIComponent(subtitleTrack.id)}/webvtt`;
        const track = documentRef.createElement('track');
        track.dataset.iosNativeSubtitleTrack = 'true';
        track.kind = 'subtitles';
        track.label = subtitleTrack.name || '字幕';
        track.srclang = subtitleTrack.language || 'zh';
        track.src = vttUrl;
        track.default = true;
        trackElement = track;
        setOverlayHidden(true);

        const showTrack = () => {
            if (disposed || currentGeneration !== generation || trackElement !== track || activeModes.size === 0) return;
            if (track.track && 'mode' in track.track) track.track.mode = 'showing';
        };
        const failTrack = () => {
            if (disposed || currentGeneration !== generation || trackElement !== track || activeModes.size === 0) return;
            onFail?.(failureReason());
        };
        track.addEventListener?.('load', showTrack, { once: true });
        track.addEventListener?.('error', failTrack, { once: true });
        video.appendChild(track);
        showTrack();
    }

    function activate(mode) {
        if (disposed) return;
        activeModes.add(mode);
        ensureNativeTrack();
    }

    function deactivate(mode) {
        activeModes.delete(mode);
        if (activeModes.size > 0) return;
        removeTrackElement();
        setOverlayHidden(false);
    }

    function syncDocumentFullscreen() {
        const fullscreenElement = documentRef?.fullscreenElement || documentRef?.webkitFullscreenElement || null;
        const overlayContained = Boolean(
            fullscreenElement
            && overlayHost
            && fullscreenElement !== video
            && typeof fullscreenElement.contains === 'function'
            && fullscreenElement.contains(overlayHost),
        );
        if (fullscreenElement === video || (fullscreenElement && !overlayContained)) activate('fullscreen');
        else deactivate('fullscreen');
    }

    function detach() {
        listeners.splice(0).forEach(([target, type, listener]) => {
            target?.removeEventListener?.(type, listener);
        });
        activeModes.clear();
        removeTrackElement();
        setOverlayHidden(false);
        video = null;
        subtitleTrack = null;
    }

    return {
        set onNativeTrackFailed(fn) {
            onFail = fn;
        },

        set onNativeVisibilityChange(fn) {
            onVisibilityChange = fn;
        },

        attach(videoEl, track) {
            detach();
            disposed = false;
            if (!videoEl || !track?.id || typeof videoEl.addEventListener !== 'function') return;
            video = videoEl;
            subtitleTrack = track;

            listen(video, 'webkitbeginfullscreen', () => activate('ios-fullscreen'));
            listen(video, 'webkitendfullscreen', () => deactivate('ios-fullscreen'));
            listen(video, 'enterpictureinpicture', () => activate('pip'));
            listen(video, 'leavepictureinpicture', () => deactivate('pip'));
            listen(video, 'webkitcurrentplaybacktargetiswirelesschanged', () => {
                if (video.webkitCurrentPlaybackTargetIsWireless) activate('airplay');
                else deactivate('airplay');
            });
            listen(documentRef, 'fullscreenchange', syncDocumentFullscreen);
            listen(documentRef, 'webkitfullscreenchange', syncDocumentFullscreen);

            if (video.webkitDisplayingFullscreen) activate('ios-fullscreen');
            if (video.webkitCurrentPlaybackTargetIsWireless) activate('airplay');
            syncDocumentFullscreen();
        },

        disable() {
            activeModes.clear();
            removeTrackElement();
            setOverlayHidden(false);
        },

        dispose() {
            if (disposed) return;
            disposed = true;
            detach();
            onFail = null;
            onVisibilityChange = null;
        },
    };
}
