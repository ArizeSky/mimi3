/**
 * @returns {Object}
 */
export function createTextOverlayRenderer() {
    let host = null;
    let cues = [];
    let activeCueKey = null;
    let disposed = false;

    const renderer = {
        attach(video, overlayHost) {
            host = overlayHost;
        },

        load(cueList) {
            cues = [...(cueList || [])].sort((left, right) => left.startMs - right.startMs || left.endMs - right.endMs);
            activeCueKey = null;
        },

        sync(currentTimeMs) {
            if (disposed || !host || !cues.length) {
                this._clear();
                return;
            }
            const active = [];
            for (let index = 0; index < cues.length; index += 1) {
                const cue = cues[index];
                if (cue.startMs > currentTimeMs) break;
                if (currentTimeMs >= cue.startMs && currentTimeMs < cue.endMs) {
                    active.push({ cue, index });
                }
            }
            const nextKey = active.map(({ index }) => index).join(',');
            if (nextKey !== activeCueKey) {
                activeCueKey = nextKey;
                this._render(active.map(({ cue }) => cue));
            }
        },

        dispose() {
            disposed = true;
            this._clear();
            cues = [];
            host = null;
        },

        _clear() {
            if (!host) return;
            host.textContent = '';
            if ('innerHTML' in host) host.innerHTML = '';
        },

        _render(activeCues) {
            if (!host) return;
            const lines = (activeCues || []).flatMap((cue) => cue?.lines || []);
            if (!lines.length) {
                this._clear();
                return;
            }
            host.innerHTML = lines
                .map((line) => escapeSubtitleHTML(line))
                .join('<br>');
        },
    };

    return renderer;
}

function escapeSubtitleHTML(value) {
    return String(value ?? '').replace(/[&<>"']/g, (char) => ({
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#39;',
    }[char]));
}
