import { api } from '../../api/client.js';

/**
 * @param {string} trackId
 * @param {Object} [options]
 * @param {AbortSignal} [options.signal]
 * @returns {Promise<{format: string, cues: Array<{startMs: number, endMs: number, lines: string[]}>}>}
 */
export async function loadTextSubtitle(trackId, options = {}) {
    return api(`/web/api/subtitles/${encodeURIComponent(trackId)}/text`, { signal: options.signal });
}
