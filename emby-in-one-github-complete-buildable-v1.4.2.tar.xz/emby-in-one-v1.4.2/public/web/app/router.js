export function matchWebRoute(pathname) {
  const path = pathname.replace(/\/+$/, '') || '/web';
  if (path === '/web' || path === '/web/') return { page: 'home', params: {} };
  if (path === '/web/login') return { page: 'login', params: {} };
  if (path === '/web/search') return { page: 'search', params: {} };
  if (path === '/web/resume') return { page: 'resume', params: {} };
  const libraryMatch = path.match(/^\/web\/library\/([^/]+)$/);
  if (libraryMatch) return { page: 'library', params: { libraryId: decodeURIComponent(libraryMatch[1]) } };
  const itemMatch = path.match(/^\/web\/item\/([^/]+)$/);
  if (itemMatch) return { page: 'item', params: { itemId: decodeURIComponent(itemMatch[1]) } };
  const playMatch = path.match(/^\/web\/play\/([^/]+)$/);
  if (playMatch) return { page: 'play', params: { itemId: decodeURIComponent(playMatch[1]) } };
  return { page: 'not-found', params: {} };
}

export function navigate(path) {
  if (typeof window !== 'undefined' && typeof window.__testNavigate === 'function') {
    window.__testNavigate(path);
    return;
  }
  window.history.pushState({}, '', path);
  window.dispatchEvent(new Event('web:navigate'));
}
