export const searchFilterOptions = [
  { type: 'Movie', label: '电影' },
  { type: 'Series', label: '剧集' },
  { type: 'Episode', label: '单集' },
  { type: 'Video', label: '视频' },
  { type: 'Channel', label: '频道' },
  { type: 'BoxSet', label: '合集' },
  { type: 'Person', label: '演职人员' },
];

export const defaultSearchTypes = ['Movie', 'Series'];
