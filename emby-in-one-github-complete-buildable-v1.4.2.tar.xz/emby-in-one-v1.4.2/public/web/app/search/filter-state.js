import { defaultSearchTypes } from './filter-config.js';

export function defaultSearchFilterTypes() {
  return [...defaultSearchTypes];
}

export function filterSearchItems(items, enabledTypes) {
  const enabled = new Set(enabledTypes);
  return (items || []).filter((item) => enabled.has(item.type));
}

export function toggleSearchFilterType(enabledTypes, type) {
  const next = new Set(enabledTypes);
  if (next.has(type)) next.delete(type);
  else next.add(type);
  return [...next];
}
