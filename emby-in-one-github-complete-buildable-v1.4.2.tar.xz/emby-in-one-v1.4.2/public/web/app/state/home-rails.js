export function createHomeRailState(initialItems = [], batchSize = 12) {
  let items = dedupeRailItems(initialItems);
  let offset = items.length;
  let hasMore = true;
  let loading = false;
  let error = '';

  return {
    get items() {
      return items;
    },
    get offset() {
      return offset;
    },
    get hasMore() {
      return hasMore;
    },
    get loading() {
      return loading;
    },
    get error() {
      return error;
    },
    startLoading() {
      loading = true;
      error = '';
    },
    appendBatch(nextItems = [], nextHasMore) {
      items = dedupeRailItems([...items, ...nextItems]);
      offset = items.length;
      loading = false;
      hasMore = typeof nextHasMore === 'boolean' ? nextHasMore : nextItems.length >= batchSize;
    },
    setError(message) {
      loading = false;
      error = message || '加载失败';
    },
  };
}

function dedupeRailItems(items) {
  const seen = new Set();
  const next = [];
  for (const item of items || []) {
    const id = item && item.id ? String(item.id) : '';
    if (!id || seen.has(id)) continue;
    seen.add(id);
    next.push(item);
  }
  return next;
}
