export function nextSelection(current, patch) {
  const next = { ...current };
  for (const [key, value] of Object.entries(patch || {})) {
    if (value === undefined || value === null || value === '') {
      delete next[key];
      continue;
    }
    next[key] = value;
  }
  return next;
}

export function parseNumericSelectionValue(value) {
  if (value === '' || value == null) return undefined;
  const parsed = Number(value);
  if (!Number.isInteger(parsed) || parsed < 0) return undefined;
  return parsed;
}

export function encodeTrackSelectionValue(mediaSourceId, streamIndex) {
  if (!Number.isInteger(streamIndex) || streamIndex < 0) return '';
  return `track:${encodeURIComponent(String(mediaSourceId || ''))}|${streamIndex}`;
}

export function parseTrackSelectionValue(value) {
  if (value === '' || value == null) return null;
  const raw = String(value);
  if (!raw.startsWith('track:')) {
    const streamIndex = parseNumericSelectionValue(raw);
    return Number.isInteger(streamIndex) ? { mediaSourceId: '', streamIndex } : null;
  }
  const separator = raw.lastIndexOf('|');
  if (separator < 6) return null;
  const streamIndex = parseNumericSelectionValue(raw.slice(separator + 1));
  if (!Number.isInteger(streamIndex)) return null;
  try {
    return {
      mediaSourceId: decodeURIComponent(raw.slice(6, separator)),
      streamIndex,
    };
  } catch (_error) {
    return null;
  }
}

export function tracksForMediaSource(tracks, mediaSourceId) {
  const list = Array.isArray(tracks) ? tracks : [];
  const selected = String(mediaSourceId || '');
  const hasScopedTracks = list.some((track) => String(track?.mediaSourceId || '') !== '');
  if (!hasScopedTracks || !selected) return list;
  return list.filter((track) => String(track?.mediaSourceId || '') === selected);
}

export function toPlaybackQuery(selection) {
  const query = new URLSearchParams();
  if (selection.episodeId) query.set('episodeId', selection.episodeId);
  if (selection.mediaSourceId) query.set('mediaSourceId', selection.mediaSourceId);
  if (Number.isInteger(selection.audioStreamIndex) && selection.audioStreamIndex >= 0) {
    query.set('audioStreamIndex', String(selection.audioStreamIndex));
  }
  if (Number.isInteger(selection.subtitleStreamIndex) && selection.subtitleStreamIndex >= 0) {
    query.set('subtitleStreamIndex', String(selection.subtitleStreamIndex));
  }
  return query;
}
