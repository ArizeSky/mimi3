import { api } from '../api/client.js';

export async function loadViewerSession() {
  try {
    return await api('/web/api/me');
  } catch (error) {
    if (error.status === 401) {
      return null;
    }
    throw error;
  }
}
