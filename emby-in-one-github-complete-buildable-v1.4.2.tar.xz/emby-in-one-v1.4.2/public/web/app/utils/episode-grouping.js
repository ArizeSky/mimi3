function seasonTitle(seasonNumber) {
  if (seasonNumber === null) return '其他';
  if (seasonNumber === 0) return '特别篇';
  return `第 ${seasonNumber} 季`;
}

function seasonKeyOf(value) {
  return Number.isInteger(value) ? String(value) : null;
}

export function groupEpisodesBySeason(seasons, episodes) {
  const buckets = new Map();
  for (const episode of episodes || []) {
    const key = seasonKeyOf(episode && episode.ParentIndexNumber) || '__unspecified__';
    if (!buckets.has(key)) buckets.set(key, []);
    buckets.get(key).push(episode);
  }

  for (const list of buckets.values()) {
    list.sort((a, b) => {
      const ai = Number.isInteger(a && a.IndexNumber) ? a.IndexNumber : Number.MAX_SAFE_INTEGER;
      const bi = Number.isInteger(b && b.IndexNumber) ? b.IndexNumber : Number.MAX_SAFE_INTEGER;
      return ai - bi;
    });
  }

  const orderedKeys = [];
  const seen = new Set();
  for (const season of seasons || []) {
    const key = seasonKeyOf(season && season.IndexNumber);
    if (key !== null && buckets.has(key) && !seen.has(key)) {
      orderedKeys.push(key);
      seen.add(key);
    }
  }
  for (const key of buckets.keys()) {
    if (key === '__unspecified__' || seen.has(key)) continue;
    orderedKeys.push(key);
    seen.add(key);
  }
  if (buckets.has('__unspecified__')) orderedKeys.push('__unspecified__');

  return orderedKeys.map((key) => {
    const seasonNumber = key === '__unspecified__' ? null : Number(key);
    return {
      seasonNumber,
      title: seasonTitle(seasonNumber),
      episodes: buckets.get(key) || [],
    };
  });
}
