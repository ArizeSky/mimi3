export function appendResumePosition(path, positionTicks) {
  const ticks = Math.max(0, Math.trunc(Number(positionTicks) || 0));
  if (!path || ticks <= 0) return path;
  const separator = String(path).includes('?') ? '&' : '?';
  return `${path}${separator}resumePositionTicks=${ticks}`;
}

export function resumePlaybackHref(item) {
  const itemId = encodeURIComponent(String(item?.id || ''));
  const ticks = item?.userData?.PlaybackPositionTicks
    ?? item?.userData?.playbackPositionTicks
    ?? item?.resumePositionTicks
    ?? item?.resumePosition
    ?? 0;
  return appendResumePosition(`/web/play/${itemId}`, ticks);
}
