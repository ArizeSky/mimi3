export function readPositivePage(search) {
  const params = new URLSearchParams(search || '');
  const raw = params.get('page');
  if (!raw) return 1;
  const parsed = Number.parseInt(raw, 10);
  if (!Number.isFinite(parsed) || parsed < 1) return 1;
  return parsed;
}

export function updateQueryParam(path, key, value) {
  const url = new URL(path, 'http://localhost');
  if (value === null || value === undefined || value === '') {
    url.searchParams.delete(key);
  } else {
    url.searchParams.set(key, String(value));
  }
  const search = url.searchParams.toString();
  return `${url.pathname}${search ? `?${search}` : ''}`;
}
