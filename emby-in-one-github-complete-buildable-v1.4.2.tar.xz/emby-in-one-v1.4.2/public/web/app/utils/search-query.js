export function readSearchQuery(search) {
  const params = new URLSearchParams(search || '');
  return params.get('q') || params.get('SearchTerm') || '';
}

export function buildSearchPath(query) {
  const params = new URLSearchParams();
  params.set('SearchTerm', query == null ? '' : String(query));
  return `/web/search?${params.toString()}`;
}
