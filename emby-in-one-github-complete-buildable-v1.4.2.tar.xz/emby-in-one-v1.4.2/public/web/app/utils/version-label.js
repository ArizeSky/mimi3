export function formatVersionLabel(versions, version) {
  const distinct = new Set(
    (versions || [])
      .map((v) => (v && v.serverName) || '')
      .filter((name) => name !== ''),
  );
  if (distinct.size <= 1) return (version && version.name) || '';
  const suffix = ((version && version.serverName) || '').trim();
  if (!suffix) return (version && version.name) || '';
  return `${(version && version.name) || ''} - ${suffix}`;
}
